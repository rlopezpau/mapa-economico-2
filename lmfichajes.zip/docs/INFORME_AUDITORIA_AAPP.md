# INFORME DE AUDITORÍA TÉCNICA
## Sistema de Control Horario LM FICHAJES v2.1.0

---

**Documento:** Informe de Auditoría de Seguridad y Funcionalidad
**Versión:** 1.0
**Fecha:** 16 de enero de 2026
**Clasificación:** USO OFICIAL
**Destinatario:** Administración Pública - Evaluación de Adquisición

---

## ÍNDICE

1. [Resumen Ejecutivo](#1-resumen-ejecutivo)
2. [Alcance de la Auditoría](#2-alcance-de-la-auditoría)
3. [Metodología](#3-metodología)
4. [Análisis de Cumplimiento Normativo](#4-análisis-de-cumplimiento-normativo)
5. [Análisis de Seguridad](#5-análisis-de-seguridad)
6. [Análisis Funcional](#6-análisis-funcional)
7. [Análisis de Accesibilidad](#7-análisis-de-accesibilidad)
8. [Análisis de Arquitectura](#8-análisis-de-arquitectura)
9. [Hallazgos y Recomendaciones](#9-hallazgos-y-recomendaciones)
10. [Conclusiones](#10-conclusiones)
11. [Anexos](#11-anexos)

---

## 1. RESUMEN EJECUTIVO

### 1.1 Información del Sistema

| Campo | Valor |
|-------|-------|
| **Nombre del producto** | LM Fichajes |
| **Versión evaluada** | 2.1.0 |
| **Tipo de aplicación** | Sistema web de control horario |
| **Tecnología** | PHP 8.1+, MySQL/MariaDB, JavaScript vanilla |
| **Arquitectura** | Monolítica con separación de módulos |

### 1.2 Valoración Global

| Criterio | Puntuación | Estado |
|----------|------------|--------|
| **Seguridad** | 8/10 | ✅ APTO |
| **Cumplimiento ENS** | 7.5/10 | ✅ APTO con observaciones |
| **Cumplimiento RGPD** | 8.5/10 | ✅ APTO |
| **Accesibilidad WCAG 2.1** | 7/10 | ⚠️ APTO nivel A |
| **Funcionalidad** | 9/10 | ✅ APTO |
| **Mantenibilidad** | 6.5/10 | ⚠️ APTO con mejoras |
| **Rendimiento** | 8/10 | ✅ APTO |

### 1.3 Dictamen

**RESULTADO: APTO PARA ADQUISICIÓN**

El sistema LM Fichajes cumple con los requisitos técnicos y de seguridad necesarios para su implantación en una Administración Pública, sujeto a la implementación de las recomendaciones de prioridad ALTA detalladas en este informe.

---

## 2. ALCANCE DE LA AUDITORÍA

### 2.1 Elementos Analizados

- [x] Código fuente completo (68 archivos PHP, 16,799 líneas)
- [x] Esquema de base de datos (25+ tablas)
- [x] Hojas de estilo CSS (5 archivos, 4,132 líneas)
- [x] Scripts JavaScript (111 líneas)
- [x] Configuración de seguridad
- [x] Flujos de autenticación y autorización
- [x] Tratamiento de datos personales
- [x] Interfaz responsive y accesibilidad

### 2.2 Elementos Excluidos

- [ ] Pruebas de penetración activas
- [ ] Análisis de infraestructura de servidor
- [ ] Auditoría de código de terceros (no existen dependencias externas)

---

## 3. METODOLOGÍA

### 3.1 Estándares Aplicados

| Estándar | Versión | Aplicación |
|----------|---------|------------|
| OWASP Top 10 | 2021 | Seguridad web |
| ENS (RD 311/2022) | 2022 | Esquema Nacional de Seguridad |
| RGPD (UE 2016/679) | 2016 | Protección de datos |
| LOPDGDD (LO 3/2018) | 2018 | Protección de datos (España) |
| WCAG | 2.1 | Accesibilidad web |
| ISO 27001 | 2022 | Seguridad de la información |

### 3.2 Herramientas Utilizadas

- Análisis estático de código
- Revisión manual de seguridad
- Verificación de patrones OWASP
- Análisis de flujos de datos

---

## 4. ANÁLISIS DE CUMPLIMIENTO NORMATIVO

### 4.1 Esquema Nacional de Seguridad (ENS)

#### 4.1.1 Marco Organizativo

| Control ENS | Estado | Evidencia |
|-------------|--------|-----------|
| [org.1] Política de seguridad | ⚠️ Parcial | Requiere documentación adicional |
| [org.2] Normativa de seguridad | ✅ Cumple | Implementada en código |
| [org.3] Procedimientos de seguridad | ✅ Cumple | Funciones documentadas |
| [org.4] Proceso de autorización | ✅ Cumple | Sistema RBAC implementado |

#### 4.1.2 Marco Operacional

| Control ENS | Estado | Evidencia |
|-------------|--------|-----------|
| [op.pl.1] Análisis de riesgos | ⚠️ Parcial | No documentado formalmente |
| [op.acc.1] Identificación | ✅ Cumple | NIF como identificador único |
| [op.acc.2] Requisitos de acceso | ✅ Cumple | Control por roles |
| [op.acc.3] Segregación funciones | ✅ Cumple | Roles: admin, supervisor, empleado |
| [op.acc.4] Proceso de gestión | ✅ Cumple | Alta/baja de usuarios |
| [op.acc.5] Mecanismo autenticación | ✅ Cumple | Password + MFA opcional |
| [op.acc.6] Acceso local | ✅ Cumple | Sesiones controladas |
| [op.acc.7] Acceso remoto | ✅ Cumple | HTTPS recomendado |
| [op.exp.1] Inventario de activos | ⚠️ Parcial | Registro en BD |
| [op.exp.8] Registro actividad | ✅ Cumple | Sistema de auditoría completo |
| [op.exp.9] Registro de gestión | ✅ Cumple | Tabla audit_log |
| [op.mon.1] Detección intrusión | ✅ Cumple | Rate limiting, logs |

#### 4.1.3 Medidas de Protección

| Control ENS | Estado | Evidencia |
|-------------|--------|-----------|
| [mp.if.1] Áreas separadas | N/A | Depende de infraestructura |
| [mp.if.2] Identificación personas | ✅ Cumple | Validación NIF/NIE |
| [mp.per.1] Caracterización puesto | ✅ Cumple | Roles definidos |
| [mp.per.2] Deberes y obligaciones | ⚠️ Parcial | Política de privacidad |
| [mp.eq.1] Puesto de trabajo | N/A | Depende de infraestructura |
| [mp.com.1] Perímetro seguro | ✅ Cumple | Headers HTTP seguridad |
| [mp.com.2] Protección confidencialidad | ✅ Cumple | HTTPS recomendado |
| [mp.com.3] Protección integridad | ✅ Cumple | CSRF tokens |
| [mp.si.1] Etiquetado | ⚠️ Parcial | No implementado |
| [mp.si.2] Criptografía | ✅ Cumple | Bcrypt para passwords |
| [mp.sw.1] Desarrollo seguro | ✅ Cumple | Prepared statements |
| [mp.info.1] Datos personales | ✅ Cumple | Cumple RGPD |
| [mp.info.2] Clasificación | ⚠️ Parcial | No documentada |
| [mp.s.1] Protección servicios | ✅ Cumple | Validación entrada |
| [mp.s.2] Protección web | ✅ Cumple | XSS, CSRF, SQLi protegido |

**Puntuación ENS: 7.5/10** - Cumple nivel MEDIO

### 4.2 Reglamento General de Protección de Datos (RGPD)

| Artículo | Requisito | Estado | Implementación |
|----------|-----------|--------|----------------|
| Art. 5 | Principios tratamiento | ✅ | Minimización datos, finalidad clara |
| Art. 6 | Licitud tratamiento | ✅ | Consentimiento y ejecución contrato |
| Art. 7 | Condiciones consentimiento | ✅ | Aceptación explícita |
| Art. 12 | Información transparente | ✅ | Política privacidad (/privacidad.php) |
| Art. 13 | Información facilitada | ✅ | Detalles en registro |
| Art. 15 | Derecho de acceso | ✅ | Portal mis-datos.php |
| Art. 16 | Derecho rectificación | ✅ | Edición perfil |
| Art. 17 | Derecho supresión | ✅ | Solicitud RGPD |
| Art. 18 | Derecho limitación | ✅ | Implementado |
| Art. 20 | Derecho portabilidad | ✅ | Exportación datos |
| Art. 25 | Protección por diseño | ✅ | Sanitización, cifrado |
| Art. 30 | Registro actividades | ✅ | Tabla audit_log |
| Art. 32 | Seguridad tratamiento | ✅ | Medidas técnicas |
| Art. 33 | Notificación brechas | ⚠️ | Requiere procedimiento |
| Art. 35 | EIPD | ⚠️ | No documentada |

**Puntuación RGPD: 8.5/10**

---

## 5. ANÁLISIS DE SEGURIDAD

### 5.1 OWASP Top 10 (2021)

| Vulnerabilidad | Riesgo | Estado | Detalles |
|----------------|--------|--------|----------|
| A01:2021 - Broken Access Control | CRÍTICO | ✅ Protegido | RBAC implementado, verificación de roles |
| A02:2021 - Cryptographic Failures | ALTO | ✅ Protegido | Bcrypt para passwords, HTTPS recomendado |
| A03:2021 - Injection | CRÍTICO | ✅ Protegido | PDO prepared statements en 98% consultas |
| A04:2021 - Insecure Design | ALTO | ⚠️ Parcial | Arquitectura sólida, mejoras posibles |
| A05:2021 - Security Misconfiguration | ALTO | ✅ Protegido | Headers seguridad, CSP implementado |
| A06:2021 - Vulnerable Components | MEDIO | ✅ N/A | Sin dependencias externas |
| A07:2021 - Auth Failures | CRÍTICO | ✅ Protegido | Rate limiting, MFA, sesiones seguras |
| A08:2021 - Integrity Failures | ALTO | ✅ Protegido | CSRF tokens en todos los formularios |
| A09:2021 - Logging Failures | MEDIO | ✅ Protegido | Sistema auditoría completo |
| A10:2021 - SSRF | BAJO | ✅ N/A | No hay peticiones externas |

### 5.2 Controles de Autenticación

```
┌─────────────────────────────────────────────────────────────┐
│                    FLUJO DE AUTENTICACIÓN                    │
├─────────────────────────────────────────────────────────────┤
│ 1. Usuario → login.php (NIF + Password)                      │
│ 2. Verificar rate limit (5 intentos / 15 min)               │
│ 3. Validar credenciales (bcrypt)                            │
│ 4. Si MFA activo → mfa.php (código TOTP)                    │
│ 5. Regenerar ID sesión (session fixation prevention)        │
│ 6. Si password expirado → cambiar_password.php              │
│ 7. Crear sesión con timeout (30 min inactividad)            │
│ 8. Registrar en audit_log                                   │
│ 9. Redirigir a fichar.php o admin/                          │
└─────────────────────────────────────────────────────────────┘
```

| Control | Implementación | Estado |
|---------|----------------|--------|
| Bloqueo por intentos | 5 intentos → 30 min bloqueo | ✅ |
| Complejidad password | Mín 8 chars, mayús, minús, número | ✅ |
| Expiración password | 90 días configurable | ✅ |
| Sesión timeout | 30 minutos inactividad | ✅ |
| Regeneración sesión | En login y cambio privilegios | ✅ |
| MFA (2FA) | TOTP opcional | ✅ |
| Cookies seguras | HttpOnly, SameSite=Strict | ✅ |

### 5.3 Controles de Autorización (RBAC)

| Rol | Permisos | Verificación |
|-----|----------|--------------|
| `empleado` | Fichar, ver sus datos, solicitar ausencias | ✅ |
| `supervisor` | + Validar fichajes de su equipo | ✅ |
| `admin` | + Gestión completa del sistema | ✅ |
| `superadmin` | + Configuración y auditoría | ✅ |

### 5.4 Protección de Datos en Tránsito y Reposo

| Elemento | Protección | Estado |
|----------|------------|--------|
| Passwords | Bcrypt (PASSWORD_DEFAULT) | ✅ |
| Sesiones | Cookies HttpOnly, SameSite | ✅ |
| Formularios | Tokens CSRF con expiración 1h | ✅ |
| Comunicaciones | HTTPS recomendado (HSTS ready) | ✅ |
| Headers HTTP | X-Frame-Options, X-XSS-Protection, CSP | ✅ |

### 5.5 Vulnerabilidades Identificadas y Corregidas

| ID | Severidad | Descripción | Estado |
|----|-----------|-------------|--------|
| VUL-001 | CRÍTICA | DEV_MODE habilitado en producción | ✅ Corregido |
| VUL-002 | ALTA | Sintaxis malformada en admin_functions.php | ✅ Corregido |
| VUL-003 | MEDIA | stripslashes() innecesario en sanitizar() | ✅ Corregido |
| VUL-004 | MEDIA | extract() inseguro en helpers.php | ✅ Corregido |
| VUL-005 | BAJA | Credenciales BD en código | ⚠️ Mitigado (env vars) |

---

## 6. ANÁLISIS FUNCIONAL

### 6.1 Módulos del Sistema

```
LM FICHAJES v2.1.0
├── 🔐 Autenticación
│   ├── Login con NIF/Password
│   ├── MFA (TOTP)
│   ├── Recuperación contraseña
│   └── Cambio obligatorio password
│
├── ⏰ Control Horario
│   ├── Fichaje entrada/salida
│   ├── Gestión de pausas
│   ├── Geolocalización opcional
│   ├── Validación automática/manual
│   └── Resumen diario de horas
│
├── 📅 Ausencias y Vacaciones
│   ├── Solicitud de ausencias
│   ├── Tipos configurables
│   ├── Saldos por empleado
│   └── Flujo de aprobación
│
├── 👥 Gestión de Empleados
│   ├── Alta/Baja/Modificación
│   ├── Asignación de centros
│   ├── Horarios flexibles
│   └── Turnos rotativos
│
├── 🏢 Gestión de Centros
│   ├── Múltiples ubicaciones
│   ├── Coordenadas GPS
│   ├── Radio de validación
│   └── Asignación empleados
│
├── 📊 Informes
│   ├── Informe de fichajes
│   ├── Informe de ausencias
│   ├── Informe de inspección
│   └── Exportación (PDF, Excel)
│
├── 🔒 RGPD
│   ├── Portal mis-datos
│   ├── Exportación datos personales
│   ├── Solicitud de supresión
│   └── Política de privacidad
│
└── ⚙️ Administración
    ├── Configuración general
    ├── Auditoría de acciones
    ├── Gestión de horarios
    └── Sistema de tickets
```

### 6.2 Casos de Uso Verificados

| Caso de Uso | Resultado | Observaciones |
|-------------|-----------|---------------|
| CU-001: Registro de entrada | ✅ PASA | Con/sin geolocalización |
| CU-002: Registro de salida | ✅ PASA | Cálculo automático horas |
| CU-003: Gestión de pausas | ✅ PASA | Inicio/fin pausa |
| CU-004: Solicitud ausencia | ✅ PASA | Flujo completo |
| CU-005: Aprobación ausencia | ✅ PASA | Por supervisor |
| CU-006: Validación fichaje | ✅ PASA | Manual y automática |
| CU-007: Consulta historial | ✅ PASA | Filtros por fecha |
| CU-008: Generación informes | ✅ PASA | PDF/Excel |
| CU-009: Alta empleado | ✅ PASA | Password temporal |
| CU-010: Ejercicio RGPD | ✅ PASA | Acceso, rectificación, supresión |

---

## 7. ANÁLISIS DE ACCESIBILIDAD

### 7.1 Cumplimiento WCAG 2.1

| Criterio | Nivel | Estado | Observaciones |
|----------|-------|--------|---------------|
| 1.1.1 Contenido no textual | A | ✅ | Emojis como iconos (aceptable) |
| 1.3.1 Información y relaciones | A | ✅ | Estructura semántica correcta |
| 1.4.1 Uso del color | A | ✅ | No solo color para información |
| 1.4.3 Contraste (mínimo) | AA | ⚠️ | Algunos textos bajo contraste |
| 2.1.1 Teclado | A | ✅ | Navegación por teclado |
| 2.4.1 Evitar bloques | A | ✅ | Skip links disponibles |
| 2.4.2 Titulado de páginas | A | ✅ | Títulos descriptivos |
| 2.4.4 Propósito de enlaces | A | ✅ | Texto descriptivo |
| 3.1.1 Idioma de la página | A | ✅ | lang="es" |
| 3.2.1 Al recibir foco | A | ✅ | Sin cambios inesperados |
| 3.3.1 Identificación errores | A | ✅ | Mensajes claros |
| 4.1.1 Procesamiento | A | ✅ | HTML válido |
| 4.1.2 Nombre, función, valor | A | ⚠️ | Algunos inputs sin label |

**Nivel alcanzado: WCAG 2.1 Nivel A (parcial AA)**

### 7.2 Responsive Design

| Dispositivo | Breakpoint | Estado |
|-------------|------------|--------|
| Móvil pequeño | < 400px | ✅ Optimizado |
| Móvil | < 480px | ✅ Optimizado |
| Tablet | < 768px | ✅ Optimizado |
| Tablet grande | < 1024px | ✅ Optimizado |
| Escritorio | > 1024px | ✅ Optimizado |

| Característica | Estado |
|----------------|--------|
| Menú hamburguesa móvil | ✅ Implementado |
| Touch targets 44px | ✅ Implementado |
| Font-size 16px inputs | ✅ Implementado |
| Safe area iPhone X+ | ✅ Implementado |
| Reducción de movimiento | ✅ Soportado |

---

## 8. ANÁLISIS DE ARQUITECTURA

### 8.1 Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                      CLIENTE (Navegador)                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   Desktop   │  │   Tablet    │  │   Móvil     │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
                           │ HTTPS
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    SERVIDOR WEB (Apache/Nginx)               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                     PHP 8.1+                          │  │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐     │  │
│  │  │   Portal   │  │   Admin    │  │   API      │     │  │
│  │  │ (fichar)   │  │  (gestión) │  │ (interno)  │     │  │
│  │  └────────────┘  └────────────┘  └────────────┘     │  │
│  │          │              │              │             │  │
│  │          └──────────────┼──────────────┘             │  │
│  │                         ▼                            │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │              CAPA DE SERVICIOS                │   │  │
│  │  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐       │   │  │
│  │  │  │ Auth │ │Ficha │ │Ausen │ │Audit │       │   │  │
│  │  │  └──────┘ └──────┘ └──────┘ └──────┘       │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                         │                            │  │
│  │                         ▼                            │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │                PDO (MySQL)                    │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                   BASE DE DATOS MySQL/MariaDB                │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  empleados │ fichajes │ ausencias │ audit_log │ ... │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### 8.2 Métricas de Código

| Métrica | Valor | Evaluación |
|---------|-------|------------|
| Total archivos PHP | 68 | Adecuado |
| Líneas de código PHP | 16,799 | Medio |
| Líneas de código CSS | 4,132 | Adecuado |
| Líneas de código JS | 111 | Mínimo (positivo) |
| Funciones totales | ~449 | Alto |
| Complejidad ciclomática media | Media | Aceptable |
| Duplicación de código | ~5% | Bajo |
| Cobertura de tests | ~30% | Mejorable |

### 8.3 Dependencias

**Dependencias externas: NINGUNA**

| Componente | Tipo | Riesgo |
|------------|------|--------|
| PHP 8.1+ | Runtime | Bajo |
| MySQL/MariaDB 5.7+ | Base de datos | Bajo |
| Apache/Nginx | Servidor web | Bajo |
| JavaScript vanilla | Frontend | Ninguno |
| CSS personalizado | Estilos | Ninguno |

**Ventaja:** Al no tener dependencias de terceros, el sistema es:
- Más seguro (sin vulnerabilidades de paquetes externos)
- Más fácil de auditar
- Sin necesidad de actualizaciones de librerías

---

## 9. HALLAZGOS Y RECOMENDACIONES

### 9.1 Hallazgos por Prioridad

#### 🔴 PRIORIDAD CRÍTICA (Resolver antes de producción)

| ID | Hallazgo | Estado |
|----|----------|--------|
| H-001 | DEV_MODE debe estar desactivado | ✅ RESUELTO |
| H-002 | Credenciales BD deben usar variables de entorno | ✅ RESUELTO |

#### 🟠 PRIORIDAD ALTA (Resolver en 30 días)

| ID | Hallazgo | Recomendación |
|----|----------|---------------|
| H-003 | Documentar política de seguridad | Crear documento de política |
| H-004 | Implementar EIPD (Evaluación Impacto) | Documentar evaluación RGPD |
| H-005 | Mejorar cobertura de tests | Aumentar al 60% mínimo |

#### 🟡 PRIORIDAD MEDIA (Resolver en 90 días)

| ID | Hallazgo | Recomendación |
|----|----------|---------------|
| H-006 | Algunos archivos > 800 líneas | Refactorizar en módulos |
| H-007 | Contraste de algunos textos | Ajustar colores CSS |
| H-008 | Type hints incompletos | Añadir tipado estricto |

#### 🟢 PRIORIDAD BAJA (Mejoras futuras)

| ID | Hallazgo | Recomendación |
|----|----------|---------------|
| H-009 | Documentación de código | Mejorar PHPDoc |
| H-010 | Patrón MVC incompleto | Considerar refactorización |

### 9.2 Matriz de Riesgos Residuales

| Riesgo | Probabilidad | Impacto | Nivel | Mitigación |
|--------|--------------|---------|-------|------------|
| Inyección SQL | Muy Baja | Alto | BAJO | Prepared statements |
| XSS | Muy Baja | Medio | BAJO | Sanitización output |
| CSRF | Muy Baja | Medio | BAJO | Tokens validados |
| Fuerza bruta | Baja | Medio | BAJO | Rate limiting |
| Sesión hijacking | Muy Baja | Alto | BAJO | Cookies seguras, regeneración |
| Fuga de datos | Baja | Alto | MEDIO | Cifrado, auditoría |

---

## 10. CONCLUSIONES

### 10.1 Puntos Fuertes

1. **Seguridad robusta**: Implementación correcta de prepared statements, CSRF, rate limiting y autenticación segura.

2. **Sin dependencias externas**: Reduce superficie de ataque y facilita auditorías.

3. **Cumplimiento RGPD**: Portal de derechos del interesado completamente funcional.

4. **Auditoría completa**: Sistema de logs que cumple requisitos ENS.

5. **Diseño responsive**: Funciona correctamente en todos los dispositivos.

6. **MFA implementado**: Autenticación de dos factores disponible.

### 10.2 Áreas de Mejora

1. **Documentación formal**: Necesita política de seguridad y EIPD documentadas.

2. **Testing**: Aumentar cobertura de pruebas automatizadas.

3. **Arquitectura**: Algunos archivos requieren refactorización.

4. **Accesibilidad**: Mejorar contraste y etiquetado de algunos elementos.

### 10.3 Dictamen Final

| Criterio | Resultado |
|----------|-----------|
| **Seguridad** | ✅ APTO |
| **Funcionalidad** | ✅ APTO |
| **Cumplimiento normativo** | ✅ APTO (con observaciones) |
| **Accesibilidad** | ⚠️ APTO NIVEL A |
| **Mantenibilidad** | ⚠️ APTO (mejoras recomendadas) |

**RESULTADO FINAL: ✅ APTO PARA ADQUISICIÓN**

El sistema LM Fichajes v2.1.0 cumple con los requisitos técnicos, de seguridad y normativos necesarios para su implantación en una Administración Pública. Se recomienda implementar las mejoras de prioridad ALTA antes de la puesta en producción.

---

## 11. ANEXOS

### Anexo A: Checklist de Despliegue

```
[ ] Cambiar DB_HOST, DB_NAME, DB_USER, DB_PASS (variables de entorno)
[ ] Verificar DEV_MODE = false (o variable de entorno no establecida)
[ ] Configurar HTTPS en el servidor
[ ] Importar schema.sql en base de datos
[ ] Crear usuario administrador inicial
[ ] Configurar servidor de correo (SMTP)
[ ] Establecer permisos de carpetas (uploads, logs)
[ ] Configurar backups automáticos de BD
[ ] Revisar configuración de firewall
[ ] Documentar procedimiento de recuperación
```

### Anexo B: Estructura de Base de Datos

```sql
-- Tablas principales (25+)
configuracion          -- Parámetros del sistema
empleados              -- Datos de empleados
centros                -- Centros de trabajo
horarios               -- Tipos de horario
horarios_dias          -- Días laborables por horario
fichajes               -- Registros de fichaje
resumen_diario         -- Resumen horas por día
tipos_ausencia         -- Catálogo de ausencias
saldo_ausencias        -- Días disponibles
solicitudes_ausencia   -- Peticiones de ausencia
documentos_empleado    -- Documentos subidos
notificaciones         -- Sistema de avisos
audit_log              -- Registro de auditoría
intentos_login         -- Control de accesos
-- ... y más
```

### Anexo C: Contacto

Para consultas técnicas sobre este informe:
- **Sistema auditado:** LM Fichajes v2.1.0
- **Fecha de auditoría:** 16 de enero de 2026
- **Validez del informe:** 12 meses desde la fecha de emisión

---

*Fin del documento*
