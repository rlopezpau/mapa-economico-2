<?php
/**
 * LM FICHAJES - Portal Inspección de Trabajo
 * 
 * Acceso de solo lectura para Inspección de Trabajo según RD 8/2019.
 * Requiere código de acceso temporal generado por el administrador.
 * 
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';

if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}

establecer_headers_seguridad();

// ============================================================================
// VERIFICACIÓN DE ACCESO
// ============================================================================

$error = '';
$acceso_valido = false;
$datos_acceso = null;

// Verificar si hay sesión de inspección activa
if (isset($_SESSION['inspeccion_acceso']) && $_SESSION['inspeccion_acceso'] === true) {
    $acceso_valido = true;
    $datos_acceso = $_SESSION['inspeccion_datos'] ?? null;
}

// Procesar código de acceso
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['codigo_acceso'])) {
    $codigo = trim($_POST['codigo_acceso'] ?? '');
    
    // Buscar código válido en BD
    $stmt = $pdo->prepare("
        SELECT * FROM inspeccion_accesos 
        WHERE codigo = ? 
        AND activo = 1 
        AND fecha_expiracion >= NOW()
        AND (usos_restantes IS NULL OR usos_restantes > 0)
    ");
    $stmt->execute([$codigo]);
    $acceso = $stmt->fetch();
    
    if ($acceso) {
        // Código válido
        $_SESSION['inspeccion_acceso'] = true;
        $_SESSION['inspeccion_datos'] = [
            'id' => $acceso->id,
            'fecha_desde' => $acceso->fecha_desde,
            'fecha_hasta' => $acceso->fecha_hasta,
            'motivo' => $acceso->motivo,
            'inspector' => $acceso->nombre_inspector
        ];
        $acceso_valido = true;
        $datos_acceso = $_SESSION['inspeccion_datos'];
        
        // Decrementar usos si aplica
        if ($acceso->usos_restantes !== null) {
            $pdo->prepare("UPDATE inspeccion_accesos SET usos_restantes = usos_restantes - 1 WHERE id = ?")->execute([$acceso->id]);
        }
        
        // Registrar acceso
        $pdo->prepare("UPDATE inspeccion_accesos SET ultimo_acceso = NOW(), total_accesos = total_accesos + 1 WHERE id = ?")->execute([$acceso->id]);
        
        // Auditoría ENS
        if (function_exists('registrar_auditoria')) {
            registrar_auditoria('INSPECCION_ACCESO', "Acceso Inspección Trabajo - Inspector: {$acceso->nombre_inspector}", 
                ['codigo_id' => $acceso->id, 'motivo' => $acceso->motivo], 'WARNING', null, 'inspeccion_accesos', $acceso->id);
        }
    } else {
        $error = 'Código de acceso inválido o expirado';
        
        // Auditoría ENS - intento fallido
        if (function_exists('registrar_auditoria')) {
            registrar_auditoria('INSPECCION_ACCESO_FALLIDO', "Intento fallido acceso Inspección - Código: " . substr($codigo, 0, 4) . "***", 
                ['ip' => obtener_ip_cliente()], 'WARNING', null, null, null);
        }
    }
}

// Cerrar sesión de inspección
if (isset($_GET['salir'])) {
    unset($_SESSION['inspeccion_acceso'], $_SESSION['inspeccion_datos']);
    header('Location: inspeccion.php');
    exit;
}

// ============================================================================
// SI HAY ACCESO VÁLIDO - MOSTRAR DATOS
// ============================================================================

$fichajes = [];
$empleados = [];
$filtros = [];

if ($acceso_valido && $datos_acceso) {
    $filtros = [
        'fecha_desde' => $_GET['fecha_desde'] ?? $datos_acceso['fecha_desde'],
        'fecha_hasta' => $_GET['fecha_hasta'] ?? $datos_acceso['fecha_hasta'],
        'empleado_id' => (int)($_GET['empleado_id'] ?? 0),
        'formato' => $_GET['formato'] ?? 'pantalla'
    ];
    
    // Obtener empleados (solo nombre y NIF anonimizado para privacidad)
    $empleados = $pdo->query("
        SELECT id, 
               CONCAT(SUBSTRING(nif, 1, 3), '****', SUBSTRING(nif, -1)) as nif_parcial,
               CONCAT(nombre, ' ', apellido1) as nombre_completo
        FROM empleados 
        WHERE activo = 1 
        ORDER BY apellido1, nombre
    ")->fetchAll();
    
    // Construir query de fichajes
    $where = ["f.fecha BETWEEN ? AND ?"];
    $params = [$filtros['fecha_desde'], $filtros['fecha_hasta']];
    
    if ($filtros['empleado_id']) {
        $where[] = "f.empleado_id = ?";
        $params[] = $filtros['empleado_id'];
    }
    
    $whereSQL = implode(' AND ', $where);
    
    // Consulta adaptada a la estructura real de la tabla fichajes
    // La tabla usa 'hora' y 'tipo', no hora_entrada/hora_salida
    $fichajes = $pdo->prepare("
        SELECT 
            f.fecha,
            MIN(CASE WHEN f.tipo = 'entrada' THEN f.hora END) as hora_entrada,
            MAX(CASE WHEN f.tipo = 'salida' THEN f.hora END) as hora_salida,
            f.estado,
            CONCAT(SUBSTRING(e.nif, 1, 3), '****', SUBSTRING(e.nif, -1)) as nif_parcial,
            CONCAT(e.nombre, ' ', e.apellido1) as empleado_nombre,
            c.nombre as centro_nombre
        FROM fichajes f
        INNER JOIN empleados e ON f.empleado_id = e.id
        LEFT JOIN centros c ON f.centro_id = c.id
        WHERE {$whereSQL}
        GROUP BY f.fecha, f.empleado_id, e.nif, e.nombre, e.apellido1, c.nombre, f.estado
        ORDER BY f.fecha DESC, e.apellido1, e.nombre
    ");
    $fichajes->execute($params);
    $fichajes = $fichajes->fetchAll();
    
    // Exportar CSV si se solicita
    if ($filtros['formato'] === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="registro_jornada_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // BOM para Excel
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Cabecera
        fputcsv($output, ['NIF (Parcial)', 'Empleado', 'Fecha', 'Hora Entrada', 'Hora Salida', 'Centro', 'Minutos Trabajados', 'Estado'], ';');
        
        foreach ($fichajes as $f) {
            // Calcular minutos trabajados
            $minutos = 0;
            if ($f->hora_entrada && $f->hora_salida) {
                $minutos = (strtotime($f->hora_salida) - strtotime($f->hora_entrada)) / 60;
            }
            
            fputcsv($output, [
                $f->nif_parcial,
                $f->empleado_nombre,
                date('d/m/Y', strtotime($f->fecha)),
                $f->hora_entrada ? date('H:i', strtotime($f->hora_entrada)) : '-',
                $f->hora_salida ? date('H:i', strtotime($f->hora_salida)) : '-',
                $f->centro_nombre ?? 'Sin centro',
                $minutos,
                ucfirst($f->estado)
            ], ';');
        }
        
        fclose($output);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Inspección de Trabajo - <?= APP_NAME ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f1f5f9; min-height: 100vh; }
        
        .header { background: linear-gradient(135deg, #7c3aed, #a855f7); color: white; padding: 1.5rem 2rem; }
        .header h1 { font-size: 1.5rem; margin-bottom: 0.25rem; }
        .header p { opacity: 0.9; font-size: 0.9rem; }
        .header-info { display: flex; gap: 2rem; margin-top: 1rem; font-size: 0.85rem; }
        .header-info span { background: rgba(255,255,255,0.2); padding: 0.25rem 0.75rem; border-radius: 1rem; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; }
        
        .login-box { max-width: 450px; margin: 4rem auto; background: white; border-radius: 1rem; padding: 2.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .login-box h2 { color: #7c3aed; margin-bottom: 0.5rem; text-align: center; }
        .login-box .subtitle { color: #64748b; text-align: center; margin-bottom: 2rem; font-size: 0.9rem; }
        .login-box .icon { font-size: 4rem; text-align: center; margin-bottom: 1.5rem; }
        
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 0.5rem; color: #374151; }
        .form-group input { width: 100%; padding: 0.875rem 1rem; border: 2px solid #e2e8f0; border-radius: 0.5rem; font-size: 1rem; transition: border-color 0.2s; }
        .form-group input:focus { outline: none; border-color: #7c3aed; }
        
        .btn { display: inline-block; padding: 0.875rem 1.5rem; border-radius: 0.5rem; font-weight: 600; text-decoration: none; cursor: pointer; border: none; font-size: 1rem; transition: all 0.2s; }
        .btn-primary { background: #7c3aed; color: white; width: 100%; }
        .btn-primary:hover { background: #6d28d9; }
        .btn-outline { background: transparent; border: 2px solid #e2e8f0; color: #64748b; }
        .btn-outline:hover { background: #f8fafc; }
        .btn-success { background: #10b981; color: white; }
        
        .alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-warning { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
        
        .legal-notice { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 0.5rem; padding: 1rem; margin-top: 1.5rem; font-size: 0.8rem; color: #64748b; }
        .legal-notice strong { color: #374151; }
        
        .filters { background: white; border-radius: 0.75rem; padding: 1.25rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .filters form { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end; }
        .filters .form-group { margin: 0; flex: 1; min-width: 150px; }
        .filters input, .filters select { padding: 0.625rem 0.875rem; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
        .stat-card { background: white; padding: 1.25rem; border-radius: 0.75rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-card .value { font-size: 2rem; font-weight: 700; color: #7c3aed; }
        .stat-card .label { color: #64748b; font-size: 0.875rem; }
        
        .data-table { width: 100%; background: white; border-radius: 0.75rem; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .data-table th, .data-table td { padding: 0.875rem 1rem; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .data-table th { background: #f8fafc; font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 600; }
        .data-table tr:hover { background: #f8fafc; }
        .data-table .empty { text-align: center; padding: 3rem; color: #64748b; }
        
        .badge { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-secondary { background: #e2e8f0; color: #64748b; }
        
        .actions-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
        
        @media (max-width: 768px) {
            .container { padding: 1rem; }
            .filters form { flex-direction: column; }
            .filters .form-group { width: 100%; }
            .data-table { font-size: 0.875rem; }
            .data-table th, .data-table td { padding: 0.625rem 0.5rem; }
        }
    </style>
</head>
<body>

<?php if (!$acceso_valido): ?>
<!-- FORMULARIO DE ACCESO -->
<div class="container">
    <div class="login-box">
        <div class="icon">🔐</div>
        <h2>Acceso Inspección de Trabajo</h2>
        <p class="subtitle">Portal de consulta de registros de jornada según RD 8/2019</p>
        
        <?php if ($error): ?>
        <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="codigo_acceso">Código de Acceso</label>
                <input type="text" id="codigo_acceso" name="codigo_acceso" 
                       placeholder="Introduzca el código proporcionado" 
                       required autocomplete="off" autofocus
                       pattern="[A-Za-z0-9-]+" minlength="8">
            </div>
            
            <button type="submit" class="btn btn-primary">🔓 Acceder</button>
        </form>
        
        <div class="legal-notice">
            <strong>⚠️ Aviso Legal:</strong><br>
            Este portal está destinado exclusivamente a la Inspección de Trabajo y Seguridad Social 
            para el ejercicio de sus funciones de control del cumplimiento del RD 8/2019. 
            El acceso no autorizado está prohibido y será registrado.
        </div>
    </div>
</div>

<?php else: ?>
<!-- PORTAL DE DATOS -->
<div class="header">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1>📋 Registro de Jornada Laboral</h1>
            <p>Acceso Inspección de Trabajo - Art. 34.9 Estatuto de los Trabajadores</p>
        </div>
        <a href="?salir=1" class="btn btn-outline" style="color: white; border-color: rgba(255,255,255,0.5);">🚪 Cerrar Sesión</a>
    </div>
    <div class="header-info">
        <span>👤 Inspector: <?= htmlspecialchars($datos_acceso['inspector'] ?? 'N/D') ?></span>
        <span>📅 Período autorizado: <?= date('d/m/Y', strtotime($datos_acceso['fecha_desde'])) ?> - <?= date('d/m/Y', strtotime($datos_acceso['fecha_hasta'])) ?></span>
        <?php if ($datos_acceso['motivo']): ?>
        <span>📝 Motivo: <?= htmlspecialchars($datos_acceso['motivo']) ?></span>
        <?php endif; ?>
    </div>
</div>

<div class="container">
    <div class="alert alert-warning">
        ⚠️ <strong>Acceso de Solo Lectura.</strong> 
        Los datos mostrados son los registrados en el sistema de control horario. 
        Se muestra NIF parcializado para protección de datos personales según RGPD.
    </div>
    
    <!-- Filtros -->
    <div class="filters">
        <form method="GET">
            <div class="form-group">
                <label>Desde</label>
                <input type="date" name="fecha_desde" value="<?= $filtros['fecha_desde'] ?>" 
                       min="<?= $datos_acceso['fecha_desde'] ?>" max="<?= $datos_acceso['fecha_hasta'] ?>">
            </div>
            <div class="form-group">
                <label>Hasta</label>
                <input type="date" name="fecha_hasta" value="<?= $filtros['fecha_hasta'] ?>"
                       min="<?= $datos_acceso['fecha_desde'] ?>" max="<?= $datos_acceso['fecha_hasta'] ?>">
            </div>
            <div class="form-group" style="flex: 2;">
                <label>Empleado</label>
                <select name="empleado_id">
                    <option value="">Todos los empleados</option>
                    <?php foreach ($empleados as $emp): ?>
                    <option value="<?= $emp->id ?>" <?= $filtros['empleado_id'] == $emp->id ? 'selected' : '' ?>>
                        <?= htmlspecialchars($emp->nif_parcial . ' - ' . $emp->nombre_completo) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
            <a href="?fecha_desde=<?= $filtros['fecha_desde'] ?>&fecha_hasta=<?= $filtros['fecha_hasta'] ?>&empleado_id=<?= $filtros['empleado_id'] ?>&formato=csv" 
               class="btn btn-success">📥 Exportar CSV</a>
        </form>
    </div>
    
    <!-- Estadísticas -->
    <?php
    $totalRegistros = count($fichajes);
    // Calcular total de minutos trabajados
    $totalMinutos = 0;
    foreach ($fichajes as $f) {
        if ($f->hora_entrada && $f->hora_salida) {
            $totalMinutos += (strtotime($f->hora_salida) - strtotime($f->hora_entrada)) / 60;
        }
    }
    $totalHoras = $totalMinutos / 60;
    $empleadosUnicos = count(array_unique(array_column($fichajes, 'empleado_nombre')));
    ?>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="value"><?= number_format($totalRegistros) ?></div>
            <div class="label">📋 Total Registros</div>
        </div>
        <div class="stat-card">
            <div class="value"><?= number_format($totalHoras, 1) ?>h</div>
            <div class="label">⏱️ Horas Registradas</div>
        </div>
        <div class="stat-card">
            <div class="value"><?= $empleadosUnicos ?></div>
            <div class="label">👥 Empleados</div>
        </div>
    </div>
    
    <!-- Tabla de datos -->
    <table class="data-table">
        <thead>
            <tr>
                <th>NIF</th>
                <th>Empleado</th>
                <th>Fecha</th>
                <th>Entrada</th>
                <th>Salida</th>
                <th>Centro</th>
                <th>Tiempo</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($fichajes)): ?>
            <tr>
                <td colspan="8" class="empty">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">📭</div>
                    No hay registros en el período seleccionado
                </td>
            </tr>
            <?php else: ?>
                <?php foreach ($fichajes as $f): ?>
                <tr>
                    <td><code><?= $f->nif_parcial ?></code></td>
                    <td><?= htmlspecialchars($f->empleado_nombre) ?></td>
                    <td><?= date('d/m/Y', strtotime($f->fecha)) ?></td>
                    <td><?= $f->hora_entrada ? date('H:i', strtotime($f->hora_entrada)) : '-' ?></td>
                    <td><?= $f->hora_salida ? date('H:i', strtotime($f->hora_salida)) : '<span style="color:#f59e0b">En curso</span>' ?></td>
                    <td><?= htmlspecialchars($f->centro_nombre ?? 'Sin centro') ?></td>
                    <td>
                        <?php if ($f->hora_entrada && $f->hora_salida): 
                            $mins = (strtotime($f->hora_salida) - strtotime($f->hora_entrada)) / 60;
                        ?>
                            <?= floor($mins / 60) ?>h <?= round((int)$mins % 60) ?>m
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php
                        $badgeClass = match($f->estado) {
                            'validado' => 'badge-success',
                            'pendiente' => 'badge-warning',
                            default => 'badge-secondary'
                        };
                        ?>
                        <span class="badge <?= $badgeClass ?>"><?= ucfirst($f->estado) ?></span>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="legal-notice" style="margin-top: 2rem;">
        <strong>📋 Información del Registro:</strong><br>
        • Empresa: Consultar configuración del sistema<br>
        • Generado: <?= date('d/m/Y H:i:s') ?><br>
        • Total registros mostrados: <?= $totalRegistros ?><br>
        • Este listado se genera en cumplimiento del Art. 34.9 del Estatuto de los Trabajadores
    </div>
</div>
<?php endif; ?>

</body>
</html>
