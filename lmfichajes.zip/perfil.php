<?php
/**
 * LM FICHAJES - Mi Perfil (Portal del Empleado)
 * 
 * El empleado puede ver:
 * - Datos personales (solo lectura)
 * - Rol, horario, centros
 * - Supervisores
 * - Vacaciones y permisos
 * - Bolsa de horas
 * - Documentos (nóminas, circulares, etc.)
 * 
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);
$centros = obtener_centros_usuario($pdo);

// Obtener datos completos del empleado
$stmt = $pdo->prepare("
    SELECT e.*, 
           h.nombre as horario_nombre,
           tg.nombre as turno_nombre,
           CONCAT(s1.nombre, ' ', s1.apellido1) as supervisor_nombre,
           CONCAT(s2.nombre, ' ', s2.apellido1) as supervisor2_nombre
    FROM empleados e
    LEFT JOIN horarios h ON e.horario_id = h.id
    LEFT JOIN turnos_grupo tg ON e.turno_grupo_id = tg.id
    LEFT JOIN empleados s1 ON e.supervisor_id = s1.id
    LEFT JOIN empleados s2 ON e.supervisor2_id = s2.id
    WHERE e.id = ?
");
$stmt->execute([$usuario->id]);
$empleado = $stmt->fetch();

// Calcular horas semanales
$horasSemanales = 37.5;
if ($empleado->horario_id) {
    try {
        $stmt = $pdo->prepare("SELECT SUM(horas_esperadas) as t FROM horarios_dias WHERE horario_id = ?");
        $stmt->execute([$empleado->horario_id]);
        $r = $stmt->fetch();
        if ($r && $r->t) $horasSemanales = $r->t;
    } catch (PDOException $e) {}
}
$horasAnuales = round($horasSemanales * 46.5, 0);

// Bolsa de horas
$bolsa = ['hoy' => 0, 'semana' => 0, 'mes' => 0, 'acumulado' => 0];
try {
    $hoy = date('Y-m-d');
    $stmt = $pdo->prepare("SELECT minutos_balance FROM resumen_diario WHERE empleado_id = ? AND fecha = ?");
    $stmt->execute([$usuario->id, $hoy]);
    $r = $stmt->fetch();
    if ($r) $bolsa['hoy'] = $r->minutos_balance;
    
    $inicioSemana = date('Y-m-d', strtotime('monday this week'));
    $stmt = $pdo->prepare("SELECT SUM(minutos_balance) as t FROM resumen_diario WHERE empleado_id = ? AND fecha >= ?");
    $stmt->execute([$usuario->id, $inicioSemana]);
    $r = $stmt->fetch();
    if ($r) $bolsa['semana'] = $r->t ?? 0;
    
    $stmt = $pdo->prepare("SELECT minutos_balance, saldo_acumulado FROM banco_horas WHERE empleado_id = ? AND periodo = ?");
    $stmt->execute([$usuario->id, date('Y-m')]);
    $r = $stmt->fetch();
    if ($r) {
        $bolsa['mes'] = $r->minutos_balance;
        $bolsa['acumulado'] = $r->saldo_acumulado;
    }
} catch (PDOException $e) {}

// Obtener documentos del empleado
$documentos = [];
try {
    // Primero obtener centros del empleado (si existen)
    $centrosEmpleado = [];
    try {
        $stmtCentros = $pdo->prepare("SELECT centro_id FROM empleados_centros WHERE empleado_id = ? AND activo = 1");
        $stmtCentros->execute([$usuario->id]);
        $centrosEmpleado = $stmtCentros->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        // Tabla empleados_centros puede no existir - ignorar
    }
    
    // Query de documentos más robusta
    $sql = "SELECT d.*, 
               (SELECT COUNT(*) FROM documentos_confirmaciones dc WHERE dc.documento_id = d.id AND dc.empleado_id = ?) as confirmado
        FROM documentos_empleado d
        WHERE d.visible_empleado = 1
          AND (d.empleado_id = ? OR d.empleado_id IS NULL";
    
    $params = [$usuario->id, $usuario->id];
    
    if (!empty($centrosEmpleado)) {
        $placeholders = implode(',', array_fill(0, count($centrosEmpleado), '?'));
        $sql .= " OR d.centro_id IN ($placeholders)";
        $params = array_merge($params, $centrosEmpleado);
    }
    
    $sql .= ")
        ORDER BY d.created_at DESC
        LIMIT 50";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $documentos = $stmt->fetchAll();
} catch (PDOException $e) {}

// Procesar confirmación de lectura
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_doc'])) {
    if (verificar_csrf($_POST['csrf_token'] ?? '')) {
        $docId = (int)$_POST['confirmar_doc'];
        try {
            $stmt = $pdo->prepare("INSERT IGNORE INTO documentos_confirmaciones (documento_id, empleado_id, confirmado_fecha, ip_address) VALUES (?, ?, NOW(), ?)");
            $stmt->execute([$docId, $usuario->id, obtener_ip_cliente()]);
        } catch (PDOException $e) {}
    }
    header('Location: perfil.php?tab=documentos');
    exit;
}

// Tab activa
$tabActiva = $_GET['tab'] ?? 'datos';

function formatoHoras($minutos) {
    if ($minutos === null) return '0:00';
    $signo = $minutos < 0 ? '-' : '+';
    $minutos = abs($minutos);
    return $signo . floor($minutos / 60) . ':' . str_pad((int)$minutos % 60, 2, '0', STR_PAD_LEFT);
}

$tiposDocumento = [
    'nomina' => '💰 Nómina',
    'contrato' => '📝 Contrato',
    'certificado' => '🏅 Certificado',
    'circular' => '📢 Circular',
    'formacion' => '🎓 Formación',
    'otro' => '📄 Documento'
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - LM Fichajes</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
            padding-bottom: 80px;
        }
        
        .header {
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 100%);
            color: white;
            padding: 15px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-content {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 { font-size: 18px; }
        
        .btn-header {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Tabs */
        .tabs {
            display: flex;
            gap: 5px;
            background: white;
            padding: 5px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .tab {
            flex: 1;
            padding: 12px;
            text-align: center;
            border: none;
            background: transparent;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            color: #64748b;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .tab:hover { background: #f1f5f9; }
        .tab.active { background: #1a365d; color: white; }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .card h2 {
            font-size: 16px;
            color: #1a365d;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
        }
        
        .info-item {
            background: #f8fafc;
            padding: 12px;
            border-radius: 8px;
        }
        
        .info-item label {
            font-size: 11px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-item p {
            font-size: 15px;
            color: #1e293b;
            margin-top: 4px;
            font-weight: 500;
        }
        
        /* Bolsa de horas */
        .bolsa-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        
        @media (max-width: 600px) {
            .bolsa-grid { grid-template-columns: repeat(2, 1fr); }
        }
        
        .bolsa-item {
            text-align: center;
            padding: 15px 10px;
            background: #f8fafc;
            border-radius: 8px;
        }
        
        .bolsa-item.acumulado {
            background: #eff6ff;
            border: 2px solid #3b82f6;
        }
        
        .bolsa-item .label { font-size: 12px; color: #64748b; }
        .bolsa-item .valor { font-size: 20px; font-weight: 700; margin-top: 5px; }
        .bolsa-item .valor.positivo { color: #059669; }
        .bolsa-item .valor.negativo { color: #dc2626; }
        
        /* Vacaciones */
        .vacaciones-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        @media (max-width: 500px) {
            .vacaciones-grid { grid-template-columns: 1fr; }
        }
        
        .vacaciones-box {
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }
        
        .vacaciones-box.vacaciones { background: #dcfce7; }
        .vacaciones-box.permisos { background: #e0f2fe; }
        
        .vacaciones-box .titulo { font-size: 14px; color: #374151; margin-bottom: 10px; }
        .vacaciones-box .total { font-size: 28px; font-weight: 700; }
        .vacaciones-box.vacaciones .total { color: #059669; }
        .vacaciones-box.permisos .total { color: #0369a1; }
        .vacaciones-box .detalle { font-size: 12px; color: #64748b; margin-top: 5px; }
        
        /* Centro tags */
        .centro-tag {
            display: inline-block;
            padding: 6px 12px;
            background: #e0e7ff;
            color: #3730a3;
            border-radius: 20px;
            font-size: 13px;
            margin: 3px;
        }
        
        .centro-tag.principal { background: #1a365d; color: white; }
        
        /* Documentos */
        .doc-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            margin-bottom: 8px;
        }
        
        .doc-icon {
            font-size: 24px;
            width: 40px;
            text-align: center;
        }
        
        .doc-info { flex: 1; }
        .doc-info .nombre { font-weight: 500; color: #1e293b; }
        .doc-info .meta { font-size: 12px; color: #64748b; margin-top: 2px; }
        
        .doc-actions { display: flex; gap: 8px; }
        
        .btn-doc {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            text-decoration: none;
            border: none;
            cursor: pointer;
        }
        
        .btn-descargar { background: #3b82f6; color: white; }
        .btn-confirmar { background: #10b981; color: white; }
        
        .badge-nuevo {
            background: #ef4444;
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 10px;
            margin-left: 5px;
        }
        
        /* Menu inferior */
        .menu-inferior {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 100;
        }
        
        .menu-item {
            text-align: center;
            text-decoration: none;
            color: #64748b;
            font-size: 12px;
            padding: 5px 15px;
        }
        
        .menu-item .icon { font-size: 20px; display: block; margin-bottom: 2px; }
        .menu-item.active { color: #1a365d; }
        
        .sin-datos {
            text-align: center;
            padding: 30px;
            color: #64748b;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>👤 Mi Perfil</h1>
            <a href="?logout=1" class="btn-header">🚪 Salir</a>
        </div>
    </header>
    
    <div class="container">
        <!-- Tabs -->
        <div class="tabs">
            <a href="?tab=datos" class="tab <?= $tabActiva === 'datos' ? 'active' : '' ?>">📋 Mis Datos</a>
            <a href="?tab=horas" class="tab <?= $tabActiva === 'horas' ? 'active' : '' ?>">⏱️ Bolsa Horas</a>
            <a href="?tab=documentos" class="tab <?= $tabActiva === 'documentos' ? 'active' : '' ?>">📁 Documentos</a>
        </div>
        
        <?php if ($tabActiva === 'datos'): ?>
        <!-- TAB: DATOS PERSONALES -->
        
        <div class="card">
            <h2>👤 Datos Personales</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>NIF</label>
                    <p><?= htmlspecialchars($empleado->nif) ?></p>
                </div>
                <div class="info-item">
                    <label>Nombre</label>
                    <p><?= htmlspecialchars($empleado->nombre . ' ' . $empleado->apellido1 . ' ' . ($empleado->apellido2 ?? '')) ?></p>
                </div>
                <div class="info-item">
                    <label>Email</label>
                    <p><?= htmlspecialchars($empleado->email ?: '-') ?></p>
                </div>
                <div class="info-item">
                    <label>Teléfono</label>
                    <p><?= htmlspecialchars($empleado->telefono ?: '-') ?></p>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>🔐 Rol y Horario</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>Rol</label>
                    <p><?= ucfirst($empleado->rol) ?></p>
                </div>
                <div class="info-item">
                    <label>Horario</label>
                    <p><?= $empleado->turno_nombre ? '🔄 ' . htmlspecialchars($empleado->turno_nombre) : ($empleado->horario_nombre ? '🕐 ' . htmlspecialchars($empleado->horario_nombre) : '-') ?></p>
                </div>
                <div class="info-item">
                    <label>Horas/Semana</label>
                    <p><?= number_format($horasSemanales, 1) ?>h</p>
                </div>
                <div class="info-item">
                    <label>Horas/Año</label>
                    <p><?= number_format($horasAnuales, 0) ?>h</p>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>👥 Supervisores</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>Supervisor Principal</label>
                    <p><?= htmlspecialchars($empleado->supervisor_nombre ?: 'No asignado') ?></p>
                </div>
                <div class="info-item">
                    <label>Supervisor Secundario</label>
                    <p><?= htmlspecialchars($empleado->supervisor2_nombre ?: 'No asignado') ?></p>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>🏛️ Centros Asignados</h2>
            <?php if (empty($centros)): ?>
                <p class="sin-datos">Sin centros asignados</p>
            <?php else: ?>
                <?php foreach ($centros as $c): ?>
                    <span class="centro-tag <?= $c->es_principal ? 'principal' : '' ?>">
                        <?= htmlspecialchars($c->nombre) ?>
                        <?= $c->es_principal ? '⭐' : '' ?>
                    </span>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h2>🏖️ Vacaciones y Permisos</h2>
            <div class="vacaciones-grid">
                <div class="vacaciones-box vacaciones">
                    <div class="titulo">Vacaciones</div>
                    <div class="total"><?= ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0) ?> días</div>
                    <div class="detalle"><?= $empleado->dias_vacaciones ?? 22 ?> base + <?= $empleado->dias_vacaciones_antiguedad ?? 0 ?> antigüedad</div>
                </div>
                <div class="vacaciones-box permisos">
                    <div class="titulo">Libre Disposición</div>
                    <div class="total"><?= ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0) ?> días</div>
                    <div class="detalle"><?= $empleado->dias_libre_disposicion ?? 6 ?> base + <?= $empleado->dias_libre_disp_antiguedad ?? 0 ?> antigüedad</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>📅 Fechas</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>Fecha de Alta</label>
                    <p><?= $empleado->fecha_alta ? date('d/m/Y', strtotime($empleado->fecha_alta)) : '-' ?></p>
                </div>
                <div class="info-item">
                    <label>Antigüedad Desde</label>
                    <p><?= $empleado->fecha_antiguedad ? date('d/m/Y', strtotime($empleado->fecha_antiguedad)) : '-' ?></p>
                </div>
                <div class="info-item">
                    <label>Último Acceso</label>
                    <p><?= $empleado->ultimo_acceso ? date('d/m/Y H:i', strtotime($empleado->ultimo_acceso)) : 'Primer acceso' ?></p>
                </div>
            </div>
        </div>
        
        <?php elseif ($tabActiva === 'horas'): ?>
        <!-- TAB: BOLSA DE HORAS -->
        
        <div class="card">
            <h2>⏱️ Bolsa de Horas</h2>
            <div class="bolsa-grid">
                <div class="bolsa-item">
                    <div class="label">Hoy</div>
                    <div class="valor <?= $bolsa['hoy'] >= 0 ? 'positivo' : 'negativo' ?>"><?= formatoHoras($bolsa['hoy']) ?></div>
                </div>
                <div class="bolsa-item">
                    <div class="label">Esta Semana</div>
                    <div class="valor <?= $bolsa['semana'] >= 0 ? 'positivo' : 'negativo' ?>"><?= formatoHoras($bolsa['semana']) ?></div>
                </div>
                <div class="bolsa-item">
                    <div class="label">Este Mes</div>
                    <div class="valor <?= $bolsa['mes'] >= 0 ? 'positivo' : 'negativo' ?>"><?= formatoHoras($bolsa['mes']) ?></div>
                </div>
                <div class="bolsa-item acumulado">
                    <div class="label">ACUMULADO</div>
                    <div class="valor <?= $bolsa['acumulado'] >= 0 ? 'positivo' : 'negativo' ?>"><?= formatoHoras($bolsa['acumulado']) ?></div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>📊 Tu Jornada</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>Horas Semanales</label>
                    <p><?= number_format($horasSemanales, 1) ?>h</p>
                </div>
                <div class="info-item">
                    <label>Horas Anuales</label>
                    <p><?= number_format($horasAnuales, 0) ?>h</p>
                </div>
                <div class="info-item">
                    <label>Horario/Turno</label>
                    <p><?= $empleado->turno_nombre ? '🔄 ' . htmlspecialchars($empleado->turno_nombre) : ($empleado->horario_nombre ?: '-') ?></p>
                </div>
            </div>
        </div>
        
        <?php elseif ($tabActiva === 'documentos'): ?>
        <!-- TAB: DOCUMENTOS -->
        
        <div class="card">
            <h2>📁 Mis Documentos</h2>
            
            <?php if (empty($documentos)): ?>
                <p class="sin-datos">No tienes documentos disponibles</p>
            <?php else: ?>
                <?php foreach ($documentos as $doc): ?>
                    <div class="doc-item">
                        <div class="doc-icon"><?= $tiposDocumento[$doc->tipo_documento] ?? '📄' ?></div>
                        <div class="doc-info">
                            <div class="nombre">
                                <?= htmlspecialchars($doc->nombre) ?>
                                <?php if (!$doc->confirmado && $doc->requiere_confirmacion): ?>
                                    <span class="badge-nuevo">NUEVO</span>
                                <?php endif; ?>
                            </div>
                            <div class="meta">
                                <?= date('d/m/Y', strtotime($doc->created_at)) ?>
                                <?php if ($doc->mes && $doc->anio): ?>
                                    · Periodo: <?= str_pad($doc->mes, 2, '0', STR_PAD_LEFT) ?>/<?= $doc->anio ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="doc-actions">
                            <a href="admin/descargar_documento.php?id=<?= $doc->id ?>" class="btn-doc btn-descargar">⬇️ Descargar</a>
                            <?php if ($doc->requiere_confirmacion && !$doc->confirmado): ?>
                                <form method="POST" style="display: inline;">
                                    <?= csrf_campo() ?>
                                    <button type="submit" name="confirmar_doc" value="<?= $doc->id ?>" class="btn-doc btn-confirmar">✓ Confirmar</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php endif; ?>
    </div>
    
    <!-- Menú inferior -->
    <nav class="menu-inferior">
        <a href="portal_v2.php" class="menu-item">
            <span class="icon">🏠</span>
            Fichar
        </a>
        <a href="historial.php" class="menu-item">
            <span class="icon">📅</span>
            Historial
        </a>
        <a href="ausencias.php" class="menu-item">
            <span class="icon">🗓️</span>
            Ausencias
        </a>
        <a href="perfil.php" class="menu-item active">
            <span class="icon">👤</span>
            Perfil
        </a>
    </nav>
</body>
</html>
