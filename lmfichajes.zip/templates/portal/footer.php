<?php
/**
 * LM FICHAJES - Template Footer Portal
 * 
 * Incluir al final de cada página del portal.
 * 
 * Variables esperadas:
 * - $showNav (bool) - Mostrar navegación inferior (default: true)
 * - $currentPage (string) - Página actual para marcar activa en nav
 * - $esAdmin (bool) - Si el usuario es admin/manager
 * 
 * @package LMFichajes
 * @version 2.0.0
 */

$showNav = $showNav ?? true;
$currentPage = $currentPage ?? '';
$esAdmin = $esAdmin ?? false;
?>

<?php if ($showNav): ?>
<!-- Navegación inferior -->
<nav class="nav-bottom">
    <a href="/fichar.php" class="nav-item <?= $currentPage === 'fichar' ? 'active' : '' ?>">
        <span class="icon">🕐</span>
        <span>Fichar</span>
    </a>
    <a href="/mis-gestiones.php" class="nav-item <?= $currentPage === 'gestiones' ? 'active' : '' ?>">
        <span class="icon">📋</span>
        <span>Gestiones</span>
    </a>
    <a href="/mi-ficha.php" class="nav-item <?= $currentPage === 'ficha' ? 'active' : '' ?>">
        <span class="icon">👤</span>
        <span>Mi Ficha</span>
    </a>
    <?php if ($esAdmin): ?>
    <a href="/admin/" class="nav-item <?= $currentPage === 'admin' ? 'active' : '' ?>">
        <span class="icon">⚙️</span>
        <span>Admin</span>
    </a>
    <?php else: ?>
    <a href="/perfil.php" class="nav-item <?= $currentPage === 'perfil' ? 'active' : '' ?>">
        <span class="icon">⚙️</span>
        <span>Perfil</span>
    </a>
    <?php endif; ?>
</nav>
<?php endif; ?>

<!-- JavaScript -->
<script src="/assets/js/portal.js"></script>

<?php if (!empty($extraJs)): ?>
<script><?= $extraJs ?></script>
<?php endif; ?>

</body>
</html>
