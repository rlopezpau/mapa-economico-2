<?php
/**
 * LM FICHAJES - Template Header Portal (Accesible WCAG 2.1 AA)
 * 
 * Variables esperadas:
 * - $pageTitle (string) - Título de la página
 * - $nombreEmpresa (string) - Nombre de la empresa
 * - $bodyClass (string) - Clase adicional para body (opcional)
 * 
 * @package LMFichajes
 * @version 2.1.0 - Accesibilidad WCAG 2.1 AA
 */

$pageTitle = $pageTitle ?? 'LM Fichajes';
$nombreEmpresa = $nombreEmpresa ?? 'LM Fichajes';
$bodyClass = $bodyClass ?? 'has-nav-bottom';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="theme-color" content="#1e3a5f">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="<?= htmlspecialchars($nombreEmpresa) ?>">
    <meta name="application-name" content="<?= htmlspecialchars($nombreEmpresa) ?>">
    <meta name="msapplication-TileColor" content="#1e3a5f">
    <meta name="msapplication-TileImage" content="/assets/img/icon-144x144.png">
    <meta name="robots" content="noindex, nofollow">
    <meta name="description" content="Sistema de control horario - <?= htmlspecialchars($nombreEmpresa) ?>">
    
    <title><?= htmlspecialchars($pageTitle) ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/img/favicon-16x16.png">
    
    <!-- Apple Touch Icons -->
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/assets/img/icon-152x152.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/assets/img/icon-144x144.png">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="/manifest.json">
    
    <!-- CSS Unificado + Accesibilidad -->
    <link rel="stylesheet" href="/assets/css/portal-unified.css">
    <link rel="stylesheet" href="/assets/css/accesibilidad.css">
    
    <?php if (!empty($extraCss)): ?>
    <style><?= $extraCss ?></style>
    <?php endif; ?>
</head>
<body class="<?= htmlspecialchars($bodyClass) ?>">
    <!-- Skip Link para accesibilidad -->
    <a href="#main-content" class="skip-link">Saltar al contenido principal</a>
    
    <!-- Anuncio para lectores de pantalla -->
    <div aria-live="polite" aria-atomic="true" class="sr-only" id="screen-reader-announcements"></div>
