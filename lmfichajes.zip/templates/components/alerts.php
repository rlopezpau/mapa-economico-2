<?php
/**
 * LM FICHAJES - Componente de Alertas
 * 
 * Muestra mensajes de éxito, error, warning, info.
 * 
 * Variables esperadas:
 * - $mensaje (string) - Mensaje de éxito
 * - $error (string) - Mensaje de error
 * - $warning (string) - Mensaje de warning
 * - $info (string) - Mensaje informativo
 * 
 * @package LMFichajes
 * @version 2.0.0
 */
?>

<?php if (!empty($mensaje)): ?>
<div class="mensaje success">
    <span>✓</span>
    <?= htmlspecialchars($mensaje) ?>
</div>
<?php endif; ?>

<?php if (!empty($error)): ?>
<div class="mensaje error">
    <span>✗</span>
    <?= htmlspecialchars($error) ?>
</div>
<?php endif; ?>

<?php if (!empty($warning)): ?>
<div class="mensaje warning">
    <span>⚠</span>
    <?= htmlspecialchars($warning) ?>
</div>
<?php endif; ?>

<?php if (!empty($info)): ?>
<div class="mensaje info">
    <span>ℹ</span>
    <?= htmlspecialchars($info) ?>
</div>
<?php endif; ?>
