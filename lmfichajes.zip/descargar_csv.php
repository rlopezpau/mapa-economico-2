<?php
/**
 * LM FICHAJES - Descargar fichajes en CSV (RGPD)
 *
 * @package     LMFichajes
 * @version     2.2.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);

if (!$usuario) {
    header('Location: login.php');
    exit;
}

// Obtener fichajes
$fichajes = [];
try {
    $stmt = $pdo->prepare("
        SELECT f.fecha, f.hora, f.tipo, f.modo, f.estado, f.observacion,
               c.nombre as centro
        FROM fichajes f
        LEFT JOIN centros c ON f.centro_id = c.id
        WHERE f.empleado_id = ?
        ORDER BY f.fecha DESC, f.hora DESC
    ");
    $stmt->execute([$usuario->id]);
    $fichajes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error obteniendo fichajes');
}

// Registrar en auditoría
if (function_exists('registrar_auditoria')) {
    registrar_auditoria('RGPD_EXPORT', 'Exportación de fichajes en CSV',
        ['empleado_id' => $usuario->id, 'registros' => count($fichajes)], 'INFO', $usuario->id);
}

// Enviar archivo CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="mis_fichajes_' . $usuario->nif . '_' . date('Ymd') . '.csv"');
header('Cache-Control: no-cache, must-revalidate');

// BOM para Excel
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

// Cabeceras
fputcsv($output, ['Fecha', 'Hora', 'Tipo', 'Modo', 'Estado', 'Centro', 'Observacion'], ';');

// Datos
foreach ($fichajes as $f) {
    fputcsv($output, [
        $f['fecha'],
        $f['hora'],
        ucfirst(str_replace('_', ' ', $f['tipo'])),
        ucfirst($f['modo']),
        ucfirst(str_replace('_', ' ', $f['estado'])),
        $f['centro'] ?? '',
        $f['observacion'] ?? ''
    ], ';');
}

fclose($output);
exit;
