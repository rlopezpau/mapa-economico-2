<?php
/**
 * LM FICHAJES - Mis Datos (Portal RGPD)
 * @version 1.0.8 - Con CSRF
 */

define('LMFICHAJES', true);
require_once 'config.php';
require_once 'includes/auth.php';

requerir_login();

$usuario_id = obtener_usuario_id();
$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$tipo_mensaje = '';

$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
try {
    $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
    $config = $stmt->fetch();
    if ($config && !empty($config->valor)) $nombreEmpresa = $config->valor;
} catch (Exception $e) {}

// Procesar con CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tipo_derecho'])) {
    if (!isset($_POST['csrf_token']) || !verificar_csrf($_POST['csrf_token'])) {
        $mensaje = 'Error de seguridad. Recarga la página.';
        $tipo_mensaje = 'error';
    } else {
        require_once 'includes/rgpd.php';
        $tipo_derecho = $_POST['tipo_derecho'] ?? '';
        $descripcion = trim($_POST['descripcion'] ?? '');
        $tipos_validos = ['acceso', 'rectificacion', 'supresion', 'oposicion', 'portabilidad', 'limitacion'];
        
        if (in_array($tipo_derecho, $tipos_validos)) {
            $solicitud_id = registrar_solicitud_rgpd($pdo, $usuario_id, $tipo_derecho, $descripcion);
            $mensaje = $solicitud_id ? 'Solicitud registrada. Respuesta en máximo 30 días.' : 'Error al registrar.';
            $tipo_mensaje = $solicitud_id ? 'success' : 'error';
        }
    }
}

$csrf_token = generar_csrf();

try {
    $stmt = $pdo->prepare("SELECT * FROM empleados WHERE id = ?");
    $stmt->execute([$usuario_id]);
    $empleado = $stmt->fetch();
} catch (Exception $e) { $empleado = null; }

$total_fichajes = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM fichajes WHERE empleado_id = ?");
    $stmt->execute([$usuario_id]);
    $result = $stmt->fetch();
    $total_fichajes = $result->total ?? 0;
} catch (Exception $e) {}

$solicitudes = [];
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'solicitudes_rgpd'");
    if ($stmt->rowCount() > 0) {
        $stmt = $pdo->prepare("SELECT * FROM solicitudes_rgpd WHERE empleado_id = ? ORDER BY created_at DESC");
        $stmt->execute([$usuario_id]);
        $solicitudes = $stmt->fetchAll();
    }
} catch (Exception $e) {}

function nombre_completo($emp) {
    if (!$emp) return 'Usuario';
    $n = $emp->nombre ?? '';
    if (isset($emp->apellidos)) return $n . ' ' . $emp->apellidos;
    if (isset($emp->apellido1)) return trim($n . ' ' . ($emp->apellido1 ?? '') . ' ' . ($emp->apellido2 ?? ''));
    return $n;
}
function traducir_derecho($t) { return ['acceso'=>'Acceso','rectificacion'=>'Rectificación','supresion'=>'Supresión','portabilidad'=>'Portabilidad'][$t] ?? $t; }
function traducir_estado($e) { return ['pendiente'=>'Pendiente','completada'=>'Completada','rechazada'=>'Rechazada'][$e] ?? $e; }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Datos RGPD - <?= htmlspecialchars($nombreEmpresa) ?></title>
    <style>
        :root { --primary: #1e3a5f; --primary-light: #2d5a87; --success: #10b981; --gray-100: #f1f5f9; --gray-200: #e2e8f0; --gray-500: #64748b; --gray-700: #334155; --gray-900: #0f172a; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: var(--gray-100); min-height: 100vh; }
        .header { background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100; }
        .header h1 { font-size: 1.2rem; display: flex; align-items: center; gap: 10px; }
        .header-actions { display: flex; gap: 10px; align-items: center; }
        .header-actions a, .header-actions span { color: white; text-decoration: none; padding: 8px 14px; border-radius: 8px; font-size: 0.9rem; }
        .header-actions a { background: rgba(255,255,255,0.15); }
        .header-actions a:hover { background: rgba(255,255,255,0.25); }
        .header-actions a.btn-fichar { background: var(--success); }
        .nav-tabs { background: white; display: flex; overflow-x: auto; border-bottom: 1px solid var(--gray-200); padding: 0 10px; }
        .nav-tab { padding: 15px 20px; text-decoration: none; color: var(--gray-500); font-size: 0.9rem; font-weight: 500; white-space: nowrap; border-bottom: 3px solid transparent; }
        .nav-tab:hover { color: var(--primary); }
        .nav-tab.active { color: var(--primary); border-bottom-color: var(--primary); }
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 20px; overflow: hidden; }
        .card-header { padding: 15px 20px; border-bottom: 1px solid var(--gray-200); }
        .card-header h2 { font-size: 1.1rem; color: var(--gray-900); display: flex; align-items: center; gap: 8px; }
        .card-body { padding: 20px; }
        .dato-row { display: flex; padding: 10px 0; border-bottom: 1px solid var(--gray-100); }
        .dato-row:last-child { border-bottom: none; }
        .dato-label { font-weight: 600; color: var(--gray-500); width: 150px; }
        .dato-valor { color: var(--gray-900); }
        .btn-group { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn { display: inline-flex; align-items: center; padding: 12px 20px; border-radius: 8px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; font-size: 0.95rem; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-secondary { background: var(--gray-100); color: var(--gray-700); }
        .mensaje { padding: 16px; border-radius: 8px; margin-bottom: 20px; }
        .mensaje.success { background: #d1fae5; color: #065f46; }
        .mensaje.error { background: #fee2e2; color: #991b1b; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; color: var(--gray-700); }
        .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid var(--gray-200); border-radius: 8px; }
        .form-group textarea { min-height: 80px; }
        .info-fichajes { background: #f0fdf4; padding: 12px 16px; border-radius: 8px; margin-top: 15px; color: #166534; }
        .solicitud-item { padding: 12px 15px; background: #f8fafc; border-radius: 8px; margin-bottom: 10px; display: flex; justify-content: space-between; }
        .estado { padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; }
        .estado-pendiente { background: #fef3c7; color: #92400e; }
        .estado-completada { background: #d1fae5; color: #065f46; }
        .info-box { background: #eff6ff; border-left: 4px solid var(--primary); padding: 15px; margin-bottom: 20px; color: var(--primary); }
    </style>
</head>
<body>
    <header class="header">
        <h1><img src="/assets/img/logo-header.png" alt="LMF" style="height:36px;border-radius:6px;margin-right:8px;"> <?= htmlspecialchars($nombreEmpresa) ?></h1>
        <div class="header-actions">
            <span><?= htmlspecialchars($usuario->nombre . ' ' . ($usuario->apellido1 ?? '')) ?></span>
            <a href="fichar.php" class="btn-fichar">🕐 Fichar</a>
            <?php if (function_exists('es_supervisor') && es_supervisor()): ?><a href="admin/">⚙️ Admin</a><?php endif; ?>
            <a href="login.php?logout=1">Salir</a>
        </div>
    </header>
    <nav class="nav-tabs">
        <a href="mis-gestiones.php?seccion=historial" class="nav-tab">📋 Mi Historial</a>
        <a href="mis-gestiones.php?seccion=ausencias" class="nav-tab">🏖️ Mis Ausencias</a>
        <a href="mis-gestiones.php?seccion=documentos" class="nav-tab">📁 Mis Documentos</a>
        <a href="mis-gestiones.php?seccion=perfil" class="nav-tab">👤 Mi Perfil</a>
        <a href="mis-datos.php" class="nav-tab active">🔐 Mis Datos RGPD</a>
    </nav>
    <div class="container">
        <div class="info-box">En cumplimiento del RGPD, puedes consultar, exportar y gestionar tus datos personales.</div>
        <?php if ($mensaje): ?><div class="mensaje <?= $tipo_mensaje ?>"><?= htmlspecialchars($mensaje) ?></div><?php endif; ?>
        <div class="card">
            <div class="card-header"><h2>📋 Datos Personales</h2></div>
            <div class="card-body">
                <?php if ($empleado): ?>
                <div class="dato-row"><span class="dato-label">NIF/NIE:</span><span class="dato-valor"><?= htmlspecialchars($empleado->nif ?? '-') ?></span></div>
                <div class="dato-row"><span class="dato-label">Nombre:</span><span class="dato-valor"><?= htmlspecialchars(nombre_completo($empleado)) ?></span></div>
                <div class="dato-row"><span class="dato-label">Email:</span><span class="dato-valor"><?= htmlspecialchars($empleado->email ?? '-') ?></span></div>
                <div class="dato-row"><span class="dato-label">Teléfono:</span><span class="dato-valor"><?= htmlspecialchars($empleado->telefono ?? '-') ?></span></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h2>📥 Descargar Mis Datos</h2></div>
            <div class="card-body">
                <div class="btn-group">
                    <a href="descargar_json.php" class="btn btn-primary">📄 Descargar Todo (JSON)</a>
                    <a href="descargar_csv.php" class="btn btn-secondary">📊 Descargar Fichajes (CSV)</a>
                </div>
                <div class="info-fichajes">ℹ️ Tienes <strong><?= $total_fichajes ?></strong> fichajes registrados.</div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h2>⚖️ Ejercer Mis Derechos</h2></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                    <div class="form-group">
                        <label>Tipo de Solicitud</label>
                        <select name="tipo_derecho" required>
                            <option value="">Selecciona...</option>
                            <option value="acceso">Derecho de Acceso</option>
                            <option value="rectificacion">Derecho de Rectificación</option>
                            <option value="supresion">Derecho de Supresión</option>
                            <option value="portabilidad">Derecho de Portabilidad</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Descripción (opcional)</label>
                        <textarea name="descripcion" placeholder="Describe tu solicitud..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Enviar Solicitud</button>
                </form>
            </div>
        </div>
        <?php if (!empty($solicitudes)): ?>
        <div class="card">
            <div class="card-header"><h2>📜 Historial de Solicitudes</h2></div>
            <div class="card-body">
                <?php foreach ($solicitudes as $s): ?>
                <div class="solicitud-item">
                    <div><strong><?= htmlspecialchars(traducir_derecho($s->tipo_derecho)) ?></strong> <span style="color:var(--gray-500);font-size:0.85rem;margin-left:10px;"><?= date('d/m/Y', strtotime($s->created_at)) ?></span></div>
                    <span class="estado estado-<?= htmlspecialchars($s->estado) ?>"><?= htmlspecialchars(traducir_estado($s->estado)) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        <p style="text-align:center;margin-top:30px;"><a href="privacidad.php" style="color:var(--primary);">Política de Privacidad</a></p>
    </div>
</body>
</html>
