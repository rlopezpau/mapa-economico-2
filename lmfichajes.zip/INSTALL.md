# GUÍA DE INSTALACIÓN - LM Fichajes v2.1.0

## Requisitos del Sistema

### Servidor
- **PHP:** 8.1 o superior
- **MySQL/MariaDB:** 5.7+ / 10.3+
- **Apache:** 2.4+ con mod_rewrite habilitado
- **Extensiones PHP requeridas:**
  - pdo
  - pdo_mysql
  - json
  - mbstring
  - session

### Verificar requisitos (en tu hosting)
```bash
php -v                    # Debe ser 8.1+
php -m | grep pdo         # Debe mostrar pdo y pdo_mysql
```

---

## PASO 1: Subir archivos al hosting

### Opción A: Usando FTP (FileZilla, etc.)
1. Conecta a tu hosting por FTP
2. Ve a la carpeta `public_html` (o `www` o `htdocs`)
3. Sube TODO el contenido de la carpeta `lmfichajes`
4. **NO** subas la carpeta `lmfichajes` en sí, solo su contenido

### Opción B: Usando cPanel File Manager
1. Entra en cPanel → File Manager
2. Ve a `public_html`
3. Sube el archivo ZIP
4. Extrae el ZIP
5. Mueve el contenido a `public_html`

### Estructura final en tu hosting:
```
public_html/
├── admin/
├── assets/
├── includes/
├── src/
├── uploads/
├── logs/
├── config.php
├── login.php
├── fichar.php
├── .htaccess
└── ... (resto de archivos)
```

---

## PASO 2: Crear la base de datos

### En cPanel → MySQL Databases:

1. **Crear base de datos:**
   - Nombre: `tuusuario_lmfichajes` (o el nombre que quieras)
   - Click en "Crear base de datos"

2. **Crear usuario de BD:**
   - Usuario: `tuusuario_lmfich`
   - Contraseña: (genera una segura)
   - Click en "Crear usuario"

3. **Asignar usuario a base de datos:**
   - Selecciona el usuario y la base de datos
   - Marca "TODOS LOS PRIVILEGIOS"
   - Click en "Hacer cambios"

### Importar el esquema:

1. Ve a **cPanel → phpMyAdmin**
2. Selecciona tu base de datos (`tuusuario_lmfichajes`)
3. Click en **"Importar"**
4. Selecciona el archivo: `admin/sql/schema.sql`
5. Click en **"Continuar"**

**Verificar:** Deberías ver ~17 tablas creadas.

---

## PASO 3: Configurar la aplicación

### Editar config.php

Abre `config.php` con el editor de cPanel (o descarga, edita, y sube):

```php
// Líneas 33-36 aproximadamente - CAMBIAR ESTOS VALORES:

define('DB_HOST', 'localhost');  // Normalmente es localhost
define('DB_NAME', 'tuusuario_lmfichajes');  // Tu base de datos
define('DB_USER', 'tuusuario_lmfich');  // Tu usuario de BD
define('DB_PASS', 'TuContraseñaSegura123!');  // Tu contraseña de BD
```

### Configurar URL de la aplicación (línea ~55):
```php
define('APP_URL', 'https://tudominio.com');  // SIN barra final
```

### Desactivar modo desarrollo (línea ~102):
```php
define('DEV_MODE', false);  // IMPORTANTE: poner false en producción
```

---

## PASO 4: Configurar permisos

En cPanel → File Manager, click derecho → "Change Permissions":

| Carpeta/Archivo | Permisos |
|-----------------|----------|
| `uploads/` | 755 |
| `logs/` | 755 |
| `config.php` | 644 |
| `.htaccess` | 644 |

---

## PASO 5: Crear usuario administrador

### Opción A: Usando phpMyAdmin

1. Ve a **phpMyAdmin → tabla `empleados`**
2. Click en **"Insertar"**
3. Rellena los campos:

```
nif: 12345678Z (o tu NIF real)
nombre: Admin
apellido1: Sistema
email: admin@tudominio.com
password: [ver abajo cómo generarlo]
rol: superadmin
activo: 1
```

**Para generar el password hash:**

Crea un archivo temporal `generar_pass.php` en tu hosting:
```php
<?php
echo password_hash('TuPasswordAdmin123!', PASSWORD_DEFAULT);
```

Accede a `https://tudominio.com/generar_pass.php`, copia el hash, y úsalo en el campo `password`.

**¡IMPORTANTE!** Borra `generar_pass.php` después de usarlo.

### Opción B: SQL directo en phpMyAdmin

```sql
INSERT INTO empleados (nif, nombre, apellido1, email, password, rol, activo, created_at)
VALUES (
    '12345678Z',
    'Admin',
    'Sistema',
    'admin@tudominio.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: "password"
    'superadmin',
    1,
    NOW()
);
```

⚠️ **CAMBIA LA CONTRASEÑA** inmediatamente después del primer login.

---

## PASO 6: Probar la instalación

### 1. Accede al login:
```
https://tudominio.com/login.php
```

### 2. Inicia sesión con:
- **NIF:** 12345678Z (o el que pusiste)
- **Contraseña:** password (o la que generaste)

### 3. Verifica que funcione:
- [ ] Login funciona
- [ ] Se muestra el panel de fichaje
- [ ] Puedes acceder a `/admin/` (panel administración)
- [ ] Puedes crear un empleado de prueba
- [ ] Puedes hacer un fichaje de prueba

---

## PASO 7: Configuración adicional (recomendado)

### Configurar email (para notificaciones):

En **Admin → Configuración → Email:**
- Servidor SMTP: (el de tu hosting)
- Puerto: 587 (o 465 para SSL)
- Usuario: noreply@tudominio.com
- Contraseña: (la del email)

### Configurar centros de trabajo:

En **Admin → Centros:**
1. Click "Nuevo Centro"
2. Nombre: "Oficina Principal"
3. Dirección: Tu dirección
4. Coordenadas: (opcional, para geolocalización)
5. Radio: 100 metros

### Configurar horarios:

En **Admin → Horarios:**
1. Click "Nuevo Horario"
2. Nombre: "Jornada Completa"
3. Tipo: Continua
4. Hora entrada: 08:00
5. Hora salida: 15:00
6. Días laborables: Lunes a Viernes

---

## Solución de Problemas

### Error "No se puede conectar a la base de datos"
- Verifica DB_HOST, DB_NAME, DB_USER, DB_PASS en config.php
- Verifica que el usuario tiene permisos sobre la base de datos

### Página en blanco
- Activa DEV_MODE temporalmente para ver errores
- Revisa `logs/php_errors.log`

### Error 500
- Verifica que `.htaccess` es compatible con tu hosting
- Algunos hostings no permiten ciertas directivas

### No se guardan fichajes
- Verifica permisos de escritura en la base de datos
- Revisa que las tablas se crearon correctamente

### No funciona la geolocalización
- Requiere HTTPS (certificado SSL)
- El navegador debe dar permiso de ubicación

---

## Configuración HTTPS (Muy Recomendado)

1. En cPanel → SSL/TLS o Let's Encrypt
2. Genera certificado para tu dominio
3. Activa "Forzar HTTPS"
4. Descomenta estas líneas en `.htaccess`:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## Actualizar la Aplicación

1. Haz backup de `config.php` y carpeta `uploads/`
2. Sube los nuevos archivos (excepto config.php)
3. Si hay cambios de BD, ejecuta los SQL de actualización
4. Restaura tu `config.php`

---

## Soporte

- **Documentación:** `docs/MANUAL-USUARIO.md`
- **Auditoría:** `docs/INFORME_AUDITORIA_AAPP.md`
- **Política de seguridad:** `docs/POLITICA-SEGURIDAD.md`

---

**Versión:** 2.1.0
**Última actualización:** Enero 2026
