<?php
/**
 * LM FICHAJES - Mi Ficha (Portal del Empleado)
 * 
 * Ficha completa del empleado en modo SOLO LECTURA:
 * - Datos personales
 * - Domicilio (teletrabajo)
 * - Rol y horario
 * - Supervisores
 * - Centros asignados
 * - Vacaciones y permisos
 * - Bolsa de horas
 * - Fechas importantes
 * 
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);
$centros = obtener_centros_usuario($pdo);

// Obtener configuración de empresa
$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
try {
    $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
    $config = $stmt->fetch();
    if ($config && !empty($config->valor)) {
        $nombreEmpresa = $config->valor;
    }
} catch (Exception $e) {}

// Obtener datos COMPLETOS del empleado
$stmt = $pdo->prepare("
    SELECT e.*, 
           h.nombre as horario_nombre,
           tg.nombre as turno_nombre,
           CONCAT(s1.nombre, ' ', s1.apellido1) as supervisor_nombre,
           CONCAT(s2.nombre, ' ', s2.apellido1) as supervisor2_nombre
    FROM empleados e
    LEFT JOIN horarios h ON e.horario_id = h.id
    LEFT JOIN turnos_grupo tg ON e.turno_grupo_id = tg.id
    LEFT JOIN empleados s1 ON e.supervisor_id = s1.id
    LEFT JOIN empleados s2 ON e.supervisor2_id = s2.id
    WHERE e.id = ?
");
$stmt->execute([$usuario->id]);
$empleado = $stmt->fetch();

// Calcular horas semanales
$horasSemanales = 37.5;
if ($empleado->horario_id) {
    try {
        $stmt = $pdo->prepare("SELECT SUM(horas_esperadas) as t FROM horarios_dias WHERE horario_id = ?");
        $stmt->execute([$empleado->horario_id]);
        $r = $stmt->fetch();
        if ($r && $r->t) $horasSemanales = $r->t;
    } catch (PDOException $e) {}
}
$horasAnuales = round($horasSemanales * 46.5, 0);

// Bolsa de horas
$bolsa = ['hoy' => 0, 'semana' => 0, 'mes' => 0, 'acumulado' => 0];
$hoy = date('Y-m-d');
try {
    $stmt = $pdo->prepare("SELECT minutos_balance FROM resumen_diario WHERE empleado_id = ? AND fecha = ?");
    $stmt->execute([$usuario->id, $hoy]);
    $r = $stmt->fetch();
    if ($r) $bolsa['hoy'] = $r->minutos_balance;
    
    $inicioSemana = date('Y-m-d', strtotime('monday this week'));
    $stmt = $pdo->prepare("SELECT SUM(minutos_balance) as t FROM resumen_diario WHERE empleado_id = ? AND fecha >= ?");
    $stmt->execute([$usuario->id, $inicioSemana]);
    $r = $stmt->fetch();
    if ($r) $bolsa['semana'] = $r->t ?? 0;
    
    $stmt = $pdo->prepare("SELECT minutos_balance, saldo_acumulado FROM banco_horas WHERE empleado_id = ? AND periodo = ?");
    $stmt->execute([$usuario->id, date('Y-m')]);
    $r = $stmt->fetch();
    if ($r) {
        $bolsa['mes'] = $r->minutos_balance;
        $bolsa['acumulado'] = $r->saldo_acumulado;
    }
} catch (PDOException $e) {}

function formatoHoras($minutos) {
    if ($minutos === null || $minutos == 0) return '0:00';
    $signo = $minutos < 0 ? '-' : '+';
    $minutos = abs($minutos);
    return $signo . floor($minutos / 60) . ':' . str_pad((int)$minutos % 60, 2, '0', STR_PAD_LEFT);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Ficha - <?= htmlspecialchars($nombreEmpresa) ?></title>
    <style>
        :root {
            --primary: #1a365d;
            --primary-light: #2d5a87;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --info: #0369a1;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-900: #111827;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            min-height: 100vh;
            color: var(--gray-900);
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            padding: 15px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
        }
        
        .header-content {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.2s;
        }
        
        .btn-back:hover { background: rgba(255,255,255,0.3); }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Perfil Header */
        .perfil-header {
            background: white;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            flex-shrink: 0;
        }
        
        .perfil-info h2 {
            font-size: 22px;
            color: var(--gray-900);
            margin-bottom: 5px;
        }
        
        .perfil-info .nif {
            font-size: 14px;
            color: var(--gray-500);
            margin-bottom: 8px;
        }
        
        .badges {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-rol { background: var(--primary); color: white; }
        .badge-activo { background: #dcfce7; color: var(--success); }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        .card-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-header .icon { font-size: 20px; }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--primary);
        }
        
        .card-body { padding: 20px; }
        
        /* Grid de información */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .info-item {
            background: var(--gray-50);
            padding: 12px 15px;
            border-radius: 8px;
        }
        
        .info-item label {
            font-size: 11px;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: block;
            margin-bottom: 4px;
        }
        
        .info-item p {
            font-size: 15px;
            color: var(--gray-900);
            font-weight: 500;
        }
        
        .info-item.full { grid-column: 1 / -1; }
        
        /* Bolsa de horas */
        .bolsa-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }
        
        @media (max-width: 600px) {
            .bolsa-grid { grid-template-columns: repeat(2, 1fr); }
        }
        
        .bolsa-item {
            text-align: center;
            padding: 15px;
            background: var(--gray-50);
            border-radius: 10px;
        }
        
        .bolsa-item.acumulado {
            border: 2px solid var(--primary);
            background: #eff6ff;
        }
        
        .bolsa-item .label {
            font-size: 11px;
            color: var(--gray-500);
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .bolsa-item .valor {
            font-size: 24px;
            font-weight: 700;
        }
        
        .positivo { color: var(--success); }
        .negativo { color: var(--danger); }
        
        /* Vacaciones */
        .vacaciones-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        @media (max-width: 500px) {
            .vacaciones-grid { grid-template-columns: 1fr; }
        }
        
        .vacaciones-box {
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }
        
        .vacaciones-box.vacaciones { background: #dcfce7; }
        .vacaciones-box.permisos { background: #e0f2fe; }
        
        .vacaciones-box .titulo {
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
        
        .vacaciones-box.vacaciones .titulo { color: #065f46; }
        .vacaciones-box.permisos .titulo { color: #0369a1; }
        
        .vacaciones-box .total {
            font-size: 36px;
            font-weight: 700;
            line-height: 1;
        }
        
        .vacaciones-box.vacaciones .total { color: var(--success); }
        .vacaciones-box.permisos .total { color: var(--info); }
        
        .vacaciones-box .unidad {
            font-size: 14px;
            margin-top: 5px;
        }
        
        .vacaciones-box .detalle {
            font-size: 12px;
            color: var(--gray-500);
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid rgba(0,0,0,0.1);
        }
        
        /* Centros */
        .centro-tag {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 8px 14px;
            background: #e0e7ff;
            color: #3730a3;
            border-radius: 8px;
            font-size: 14px;
            margin: 4px;
        }
        
        .centro-tag.principal {
            background: var(--primary);
            color: white;
        }
        
        /* Domicilio mapa */
        .mapa-container {
            height: 200px;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 15px;
            background: var(--gray-100);
        }
        
        .mapa-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        
        .no-domicilio {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-500);
            flex-direction: column;
            gap: 10px;
        }
        
        .no-domicilio .icon { font-size: 40px; opacity: 0.5; }
        
        /* Jornada */
        .jornada-stats {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--gray-200);
        }
        
        .jornada-stat {
            text-align: center;
        }
        
        .jornada-stat .valor {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary);
        }
        
        .jornada-stat .label {
            font-size: 12px;
            color: var(--gray-500);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>📋 Mi Ficha</h1>
            <a href="portal.php" class="btn-back">← Volver</a>
        </div>
    </header>
    
    <div class="container">
        <!-- Cabecera Perfil -->
        <div class="perfil-header">
            <div class="avatar">
                <?= strtoupper(substr($empleado->nombre, 0, 1) . substr($empleado->apellido1, 0, 1)) ?>
            </div>
            <div class="perfil-info">
                <h2><?= htmlspecialchars($empleado->nombre . ' ' . $empleado->apellido1 . ' ' . ($empleado->apellido2 ?? '')) ?></h2>
                <div class="nif">NIF: <?= htmlspecialchars($empleado->nif) ?></div>
                <div class="badges">
                    <span class="badge badge-rol"><?= ucfirst($empleado->rol) ?></span>
                    <?php if ($empleado->activo): ?>
                        <span class="badge badge-activo">✓ Activo</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Datos Personales -->
        <div class="card">
            <div class="card-header">
                <span class="icon">👤</span>
                <span class="card-title">Datos Personales</span>
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <label>NIF/NIE</label>
                        <p><?= htmlspecialchars($empleado->nif) ?></p>
                    </div>
                    <div class="info-item">
                        <label>Nombre</label>
                        <p><?= htmlspecialchars($empleado->nombre) ?></p>
                    </div>
                    <div class="info-item">
                        <label>Primer Apellido</label>
                        <p><?= htmlspecialchars($empleado->apellido1) ?></p>
                    </div>
                    <div class="info-item">
                        <label>Segundo Apellido</label>
                        <p><?= htmlspecialchars($empleado->apellido2 ?: '-') ?></p>
                    </div>
                    <div class="info-item">
                        <label>Email</label>
                        <p><?= htmlspecialchars($empleado->email ?: 'No configurado') ?></p>
                    </div>
                    <div class="info-item">
                        <label>Teléfono</label>
                        <p><?= htmlspecialchars($empleado->telefono ?: 'No configurado') ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Domicilio (Teletrabajo) -->
        <div class="card">
            <div class="card-header">
                <span class="icon">🏠</span>
                <span class="card-title">Domicilio (Teletrabajo)</span>
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item full">
                        <label>Dirección</label>
                        <p><?= htmlspecialchars($empleado->direccion ?: 'No configurada') ?></p>
                    </div>
                    <div class="info-item">
                        <label>Coordenadas</label>
                        <p><?= $empleado->coordenadas_domicilio ?: 'No configuradas' ?></p>
                    </div>
                    <div class="info-item">
                        <label>Radio permitido</label>
                        <p><?= $empleado->radio_domicilio ?? 50 ?> metros</p>
                    </div>
                </div>
                
                <div class="mapa-container" style="text-align: center; padding: 1.5rem;">
                    <?php if ($empleado->coordenadas_domicilio): ?>
                        <p style="margin-bottom: 0.5rem; color: #64748b;">📍 <?= htmlspecialchars($empleado->coordenadas_domicilio) ?></p>
                        <a href="https://www.google.com/maps?q=<?= urlencode($empleado->coordenadas_domicilio) ?>" target="_blank" class="btn btn-primary">🗺️ Ver en Google Maps</a>
                    <?php else: ?>
                        <div class="no-domicilio">
                            <span class="icon">📍</span>
                            <span>Domicilio no configurado</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Rol y Horario -->
        <div class="card">
            <div class="card-header">
                <span class="icon">🕐</span>
                <span class="card-title">Rol y Horario</span>
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <label>Rol</label>
                        <p><?= ucfirst($empleado->rol) ?></p>
                    </div>
                    <div class="info-item">
                        <label>Horario / Turno</label>
                        <p>
                            <?php if ($empleado->turno_nombre): ?>
                                🔄 <?= htmlspecialchars($empleado->turno_nombre) ?>
                            <?php elseif ($empleado->horario_nombre): ?>
                                🕐 <?= htmlspecialchars($empleado->horario_nombre) ?>
                            <?php else: ?>
                                Sin asignar
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="info-item">
                        <label>Supervisor Principal</label>
                        <p><?= htmlspecialchars($empleado->supervisor_nombre ?: 'No asignado') ?></p>
                    </div>
                    <div class="info-item">
                        <label>Supervisor Secundario</label>
                        <p><?= htmlspecialchars($empleado->supervisor2_nombre ?: 'No asignado') ?></p>
                    </div>
                </div>
                
                <div class="jornada-stats">
                    <div class="jornada-stat">
                        <div class="valor"><?= number_format($horasSemanales, 1) ?></div>
                        <div class="label">Horas/semana</div>
                    </div>
                    <div class="jornada-stat">
                        <div class="valor"><?= number_format($horasAnuales, 0) ?></div>
                        <div class="label">Horas/año</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Centros Asignados -->
        <div class="card">
            <div class="card-header">
                <span class="icon">🏛️</span>
                <span class="card-title">Centros de Trabajo</span>
            </div>
            <div class="card-body">
                <?php if (empty($centros)): ?>
                    <p style="color: var(--gray-500); text-align: center; padding: 20px;">
                        No tienes centros asignados
                    </p>
                <?php else: ?>
                    <div>
                        <?php foreach ($centros as $c): ?>
                            <span class="centro-tag <?= $c->es_principal ? 'principal' : '' ?>">
                                <?= htmlspecialchars($c->nombre) ?>
                                <?= $c->es_principal ? '⭐' : '' ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Vacaciones y Permisos -->
        <div class="card">
            <div class="card-header">
                <span class="icon">🏖️</span>
                <span class="card-title">Vacaciones y Permisos</span>
            </div>
            <div class="card-body">
                <div class="vacaciones-grid">
                    <div class="vacaciones-box vacaciones">
                        <div class="titulo">Vacaciones</div>
                        <div class="total"><?= ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0) ?></div>
                        <div class="unidad">días disponibles</div>
                        <div class="detalle">
                            <?= $empleado->dias_vacaciones ?? 22 ?> base + <?= $empleado->dias_vacaciones_antiguedad ?? 0 ?> por antigüedad
                        </div>
                    </div>
                    <div class="vacaciones-box permisos">
                        <div class="titulo">Libre Disposición</div>
                        <div class="total"><?= ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0) ?></div>
                        <div class="unidad">días disponibles</div>
                        <div class="detalle">
                            <?= $empleado->dias_libre_disposicion ?? 6 ?> base + <?= $empleado->dias_libre_disp_antiguedad ?? 0 ?> por antigüedad
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bolsa de Horas -->
        <div class="card">
            <div class="card-header">
                <span class="icon">⏱️</span>
                <span class="card-title">Bolsa de Horas</span>
            </div>
            <div class="card-body">
                <div class="bolsa-grid">
                    <div class="bolsa-item">
                        <div class="label">Hoy</div>
                        <div class="valor <?= $bolsa['hoy'] >= 0 ? 'positivo' : 'negativo' ?>">
                            <?= formatoHoras($bolsa['hoy']) ?>
                        </div>
                    </div>
                    <div class="bolsa-item">
                        <div class="label">Esta Semana</div>
                        <div class="valor <?= $bolsa['semana'] >= 0 ? 'positivo' : 'negativo' ?>">
                            <?= formatoHoras($bolsa['semana']) ?>
                        </div>
                    </div>
                    <div class="bolsa-item">
                        <div class="label">Este Mes</div>
                        <div class="valor <?= $bolsa['mes'] >= 0 ? 'positivo' : 'negativo' ?>">
                            <?= formatoHoras($bolsa['mes']) ?>
                        </div>
                    </div>
                    <div class="bolsa-item acumulado">
                        <div class="label">Acumulado Total</div>
                        <div class="valor <?= $bolsa['acumulado'] >= 0 ? 'positivo' : 'negativo' ?>">
                            <?= formatoHoras($bolsa['acumulado']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Fechas -->
        <div class="card">
            <div class="card-header">
                <span class="icon">📅</span>
                <span class="card-title">Fechas</span>
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <label>Fecha de Alta</label>
                        <p><?= $empleado->fecha_alta ? date('d/m/Y', strtotime($empleado->fecha_alta)) : 'No registrada' ?></p>
                    </div>
                    <div class="info-item">
                        <label>Antigüedad Desde</label>
                        <p><?= $empleado->fecha_antiguedad ? date('d/m/Y', strtotime($empleado->fecha_antiguedad)) : 'No registrada' ?></p>
                    </div>
                    <div class="info-item">
                        <label>Último Acceso</label>
                        <p><?= $empleado->ultimo_acceso ? date('d/m/Y H:i', strtotime($empleado->ultimo_acceso)) : 'Primer acceso' ?></p>
                    </div>
                    <div class="info-item">
                        <label>Fecha de Baja</label>
                        <p><?= $empleado->fecha_baja ? date('d/m/Y', strtotime($empleado->fecha_baja)) : '-' ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
