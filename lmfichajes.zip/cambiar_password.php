<?php
/**
 * LM FICHAJES - Cambiar Contraseña
 *
 * Página para cambio obligatorio de contraseña.
 *
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

if (file_exists(INCLUDES_PATH . '/password_policy.php')) {
    require_once INCLUDES_PATH . '/password_policy.php';
}

establecer_headers_seguridad();

// Verificar que hay un cambio de contraseña pendiente
if (!isset($_SESSION['cambio_password_pendiente']) || !$_SESSION['cambio_password_pendiente']) {
    // Si ya está logueado normalmente, redirigir
    if (esta_logueado()) {
        header('Location: fichar.php');
        exit;
    }
    header('Location: login.php');
    exit;
}

$usuarioId = $_SESSION['cambio_password_usuario_id'] ?? null;
$usuarioNombre = $_SESSION['cambio_password_usuario_nombre'] ?? 'Usuario';

if (!$usuarioId) {
    header('Location: login.php');
    exit;
}

$error = '';
$mensaje = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf()) {
        $error = 'Error de seguridad. Recarga la página.';
    } else {
        $passwordActual = $_POST['password_actual'] ?? '';
        $passwordNueva = $_POST['password_nueva'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';

        if (empty($passwordActual) || empty($passwordNueva) || empty($passwordConfirm)) {
            $error = 'Todos los campos son obligatorios';
        } elseif ($passwordNueva !== $passwordConfirm) {
            $error = 'Las contraseñas nuevas no coinciden';
        } elseif (strlen($passwordNueva) < 8) {
            $error = 'La contraseña debe tener al menos 8 caracteres';
        } elseif ($passwordActual === $passwordNueva) {
            $error = 'La nueva contraseña debe ser diferente a la actual';
        } else {
            // Verificar fortaleza
            if (function_exists('verificar_fortaleza_password')) {
                $fortaleza = verificar_fortaleza_password($passwordNueva);
                if (!$fortaleza['valida']) {
                    $error = 'Contraseña débil: ' . implode(', ', $fortaleza['errores']);
                }
            }

            if (!$error) {
                // Verificar contraseña actual
                $stmt = $pdo->prepare("SELECT password FROM empleados WHERE id = ?");
                $stmt->execute([$usuarioId]);
                $usuario = $stmt->fetch();

                if (!$usuario || !password_verify($passwordActual, $usuario->password)) {
                    $error = 'La contraseña actual no es correcta';
                } else {
                    // Actualizar contraseña
                    $hash = password_hash($passwordNueva, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        UPDATE empleados SET
                            password = ?,
                            debe_cambiar_password = 0,
                            password_temporal = 0,
                            password_cambiado = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([$hash, $usuarioId]);

                    // Limpiar sesión temporal y hacer login completo
                    unset($_SESSION['cambio_password_pendiente']);
                    unset($_SESSION['cambio_password_usuario_id']);
                    unset($_SESSION['cambio_password_usuario_nombre']);

                    // Obtener usuario completo para login
                    $stmt = $pdo->prepare("SELECT * FROM empleados WHERE id = ?");
                    $stmt->execute([$usuarioId]);
                    $usuarioCompleto = $stmt->fetch();

                    if ($usuarioCompleto) {
                        completar_login($pdo, $usuarioCompleto);
                        header('Location: fichar.php');
                        exit;
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Cambiar Contraseña - LM Fichajes</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 50%, #3d7ab5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container { width: 100%; max-width: 420px; }

        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            padding: 30px;
            text-align: center;
            color: white;
        }

        .header h1 { font-size: 24px; margin-bottom: 10px; }
        .header p { font-size: 14px; opacity: 0.9; }

        .body { padding: 30px; }

        .alert {
            padding: 14px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-warning {
            background: #fef3c7;
            border: 1px solid #fcd34d;
            color: #92400e;
        }

        .alert-error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
        }

        .form-group { margin-bottom: 20px; }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #f59e0b;
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.1);
        }

        .btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(245, 158, 11, 0.4);
        }

        .requisitos {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 13px;
            color: #64748b;
        }

        .requisitos ul { margin-left: 20px; margin-top: 8px; }
        .requisitos li { margin-bottom: 4px; }

        .footer {
            text-align: center;
            padding: 20px;
            border-top: 1px solid #f3f4f6;
            font-size: 12px;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>🔐 Cambiar Contraseña</h1>
                <p>Hola, <?= htmlspecialchars($usuarioNombre) ?></p>
            </div>

            <div class="body">
                <div class="alert alert-warning">
                    ⚠️ Tu contraseña es temporal o ha expirado. Debes cambiarla para continuar.
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <div class="requisitos">
                    <strong>Requisitos de la contraseña:</strong>
                    <ul>
                        <li>Mínimo 8 caracteres</li>
                        <li>Al menos una mayúscula</li>
                        <li>Al menos una minúscula</li>
                        <li>Al menos un número</li>
                        <li>Diferente a la actual</li>
                    </ul>
                </div>

                <form method="POST">
                    <?= csrf_campo() ?>

                    <div class="form-group">
                        <label for="password_actual">Contraseña actual</label>
                        <input type="password" id="password_actual" name="password_actual" required
                               placeholder="Tu contraseña temporal">
                    </div>

                    <div class="form-group">
                        <label for="password_nueva">Nueva contraseña</label>
                        <input type="password" id="password_nueva" name="password_nueva" required
                               placeholder="Mínimo 8 caracteres" minlength="8">
                    </div>

                    <div class="form-group">
                        <label for="password_confirm">Confirmar contraseña</label>
                        <input type="password" id="password_confirm" name="password_confirm" required
                               placeholder="Repite la nueva contraseña">
                    </div>

                    <button type="submit" class="btn">Cambiar Contraseña</button>
                </form>
            </div>

            <div class="footer">
                <p>LM Fichajes v<?= APP_VERSION ?></p>
            </div>
        </div>
    </div>
</body>
</html>
