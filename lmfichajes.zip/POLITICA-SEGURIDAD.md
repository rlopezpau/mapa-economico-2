# 🔐 POLÍTICA DE SEGURIDAD DE LA INFORMACIÓN

## LM Fichajes - Sistema de Control Horario

**Versión:** 1.0.0  
**Fecha:** Enero 2026  
**Clasificación:** INTERNO  
**Propietario:** Dirección de Sistemas  

---

## 1. OBJETIVO

Establecer las directrices y requisitos de seguridad de la información para el sistema LM Fichajes, garantizando la confidencialidad, integridad y disponibilidad de los datos de control horario de los empleados.

---

## 2. ALCANCE

Esta política aplica a:
- Todo el personal que administre o utilice el sistema LM Fichajes
- Todos los componentes técnicos del sistema (servidores, bases de datos, aplicación)
- Todos los datos personales y de fichajes procesados por el sistema

---

## 3. NORMATIVA APLICABLE

| Normativa | Descripción |
|-----------|-------------|
| RD 8/2019 | Registro obligatorio de jornada laboral |
| RGPD (UE 2016/679) | Protección de datos personales |
| LOPDGDD (LO 3/2018) | Ley Orgánica de Protección de Datos |
| ENS (RD 311/2022) | Esquema Nacional de Seguridad |
| RD 1112/2018 | Accesibilidad de sitios web del sector público |

---

## 4. PRINCIPIOS DE SEGURIDAD

### 4.1 Confidencialidad
- Los datos personales solo serán accesibles por personal autorizado
- Se implementará control de acceso basado en roles (RBAC)
- Las contraseñas se almacenarán con hash bcrypt

### 4.2 Integridad
- Todas las transacciones críticas serán auditadas
- Se implementará protección CSRF en formularios
- Los datos de fichaje no podrán ser modificados sin registro

### 4.3 Disponibilidad
- El sistema estará disponible en horario laboral (99.5% SLA)
- Se realizarán copias de seguridad diarias
- Tiempo máximo de recuperación: 4 horas

---

## 5. CONTROL DE ACCESO

### 5.1 Roles del Sistema

| Rol | Descripción | Permisos |
|-----|-------------|----------|
| Empleado | Usuario básico | Fichar, ver su ficha, solicitar ausencias |
| Supervisor | Responsable de equipo | + Validar fichajes de su equipo |
| Manager | Gestor de área | + Gestionar empleados de su área |
| Admin | Administrador | Acceso total al sistema |

### 5.2 Política de Contraseñas
- Longitud mínima: 8 caracteres
- Debe incluir: mayúsculas, minúsculas y números
- Caducidad: 90 días
- Historial: No reutilizar las últimas 5 contraseñas
- Bloqueo: 5 intentos fallidos = bloqueo 15 minutos

### 5.3 Gestión de Sesiones
- Timeout por inactividad: 30 minutos
- Sesiones únicas por usuario
- Regeneración de ID de sesión en login

---

## 6. PROTECCIÓN DE DATOS

### 6.1 Datos Tratados

| Categoría | Datos | Clasificación |
|-----------|-------|---------------|
| Identificación | NIF, Nombre, Apellidos | CONFIDENCIAL |
| Contacto | Email, Teléfono | CONFIDENCIAL |
| Laboral | Puesto, Centro, Horario | INTERNO |
| Fichajes | Fecha, Hora, Ubicación | CONFIDENCIAL |
| Ausencias | Tipo, Fechas, Justificante | CONFIDENCIAL |

### 6.2 Retención de Datos
- Registros de fichaje: 4 años (RD 8/2019)
- Logs de auditoría: 4 años
- Datos de empleados dados de baja: 4 años tras la baja

### 6.3 Derechos ARCO+
El sistema debe permitir ejercer:
- **Acceso**: Consulta de datos propios
- **Rectificación**: Corrección de datos incorrectos
- **Cancelación/Supresión**: Eliminación cuando proceda
- **Oposición**: Oposición al tratamiento
- **Portabilidad**: Exportación de datos en formato estándar

---

## 7. AUDITORÍA Y TRAZABILIDAD

### 7.1 Eventos Auditados
- Inicios y cierres de sesión
- Fichajes (entrada/salida)
- Modificaciones de datos de empleados
- Cambios de configuración
- Accesos a datos sensibles
- Intentos de acceso fallidos

### 7.2 Información Registrada
- Timestamp del evento
- Usuario que realiza la acción
- Dirección IP de origen
- Tipo de acción
- Datos antes/después (cuando aplique)

---

## 8. GESTIÓN DE INCIDENTES

### 8.1 Clasificación de Incidentes

| Nivel | Descripción | Tiempo Respuesta |
|-------|-------------|------------------|
| CRÍTICO | Brecha de datos, sistema caído | 1 hora |
| ALTO | Vulnerabilidad explotada | 4 horas |
| MEDIO | Intento de ataque detectado | 24 horas |
| BAJO | Anomalía menor | 72 horas |

### 8.2 Procedimiento
1. Detección y registro del incidente
2. Clasificación y escalado
3. Contención inmediata
4. Investigación y análisis
5. Erradicación y recuperación
6. Lecciones aprendidas

---

## 9. RESPONSABILIDADES

| Rol | Responsabilidad |
|-----|-----------------|
| Dirección | Aprobar política, asignar recursos |
| Responsable Seguridad | Implementar y supervisar controles |
| Administradores | Configurar y mantener el sistema |
| Usuarios | Cumplir la política, reportar incidentes |

---

## 10. REVISIÓN Y ACTUALIZACIÓN

Esta política será revisada:
- Anualmente de forma ordinaria
- Tras incidentes de seguridad significativos
- Ante cambios normativos relevantes

---

## 11. APROBACIÓN

| Cargo | Nombre | Fecha | Firma |
|-------|--------|-------|-------|
| Director General | _________________ | ___/___/______ | _______ |
| Responsable Seguridad | _________________ | ___/___/______ | _______ |
| DPO | _________________ | ___/___/______ | _______ |

---

*Documento clasificado como INTERNO*  
*Prohibida su distribución fuera de la organización*
