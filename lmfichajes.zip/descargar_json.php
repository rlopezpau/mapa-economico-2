<?php
/**
 * LM FICHAJES - Descargar datos personales en JSON (RGPD)
 *
 * @package     LMFichajes
 * @version     2.2.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);

if (!$usuario) {
    header('Location: login.php');
    exit;
}

// Recopilar todos los datos del usuario
$datos = [
    'exportado_en' => date('Y-m-d H:i:s'),
    'datos_personales' => [
        'nif' => $usuario->nif,
        'nombre' => $usuario->nombre,
        'apellido1' => $usuario->apellido1,
        'apellido2' => $usuario->apellido2,
        'email' => $usuario->email,
        'telefono' => $usuario->telefono,
        'direccion' => $usuario->direccion,
        'fecha_alta' => $usuario->fecha_alta,
        'rol' => $usuario->rol
    ],
    'fichajes' => [],
    'ausencias' => []
];

// Obtener fichajes
try {
    $stmt = $pdo->prepare("
        SELECT fecha, hora, tipo, modo, observacion, created_at
        FROM fichajes
        WHERE empleado_id = ?
        ORDER BY fecha DESC, hora DESC
        LIMIT 1000
    ");
    $stmt->execute([$usuario->id]);
    $datos['fichajes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $datos['fichajes'] = ['error' => 'No se pudieron obtener los fichajes'];
}

// Obtener ausencias
try {
    $stmt = $pdo->prepare("
        SELECT sa.fecha_inicio, sa.fecha_fin, sa.dias_solicitados, sa.estado, sa.motivo, ta.nombre as tipo
        FROM solicitudes_ausencia sa
        LEFT JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
        WHERE sa.empleado_id = ?
        ORDER BY sa.fecha_inicio DESC
    ");
    $stmt->execute([$usuario->id]);
    $datos['ausencias'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $datos['ausencias'] = ['error' => 'No se pudieron obtener las ausencias'];
}

// Registrar en auditoría
if (function_exists('registrar_auditoria')) {
    registrar_auditoria('RGPD_EXPORT', 'Exportación de datos personales en JSON',
        ['empleado_id' => $usuario->id], 'INFO', $usuario->id);
}

// Enviar archivo JSON
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="mis_datos_' . $usuario->nif . '_' . date('Ymd') . '.json"');
header('Cache-Control: no-cache, must-revalidate');

echo json_encode($datos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;
