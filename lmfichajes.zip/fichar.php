<?php
/**
 * LM FICHAJES - Portal de Fichaje
 *
 * Página principal para registrar entrada/salida del empleado.
 *
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/fichajes.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);
$centros = obtener_centros_usuario($pdo);

// Obtener configuración
$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
try {
    $stmt = $pdo->query("SELECT clave, valor FROM configuracion WHERE clave IN ('nombre_empresa', 'permitir_teletrabajo', 'requiere_geolocalizacion')");
    while ($config = $stmt->fetch()) {
        if ($config->clave === 'nombre_empresa' && !empty($config->valor)) {
            $nombreEmpresa = $config->valor;
        }
    }
} catch (Exception $e) {}

// Obtener centro principal o único
$centroActual = null;
if (!empty($centros)) {
    foreach ($centros as $c) {
        if ($c->es_principal) {
            $centroActual = $c;
            break;
        }
    }
    if (!$centroActual) {
        $centroActual = $centros[0];
    }
}

// Obtener último fichaje del día
$hoy = date('Y-m-d');
$ultimoFichaje = null;
$estadoActual = 'sin_fichar'; // sin_fichar, trabajando, en_pausa

try {
    $stmt = $pdo->prepare("
        SELECT * FROM fichajes
        WHERE empleado_id = ? AND fecha = ? AND estado != 'rechazado'
        ORDER BY hora DESC
        LIMIT 1
    ");
    $stmt->execute([$usuario->id, $hoy]);
    $ultimoFichaje = $stmt->fetch();

    if ($ultimoFichaje) {
        if ($ultimoFichaje->tipo === 'entrada') {
            $estadoActual = 'trabajando';
        } elseif ($ultimoFichaje->tipo === 'pausa_inicio') {
            $estadoActual = 'en_pausa';
        } elseif ($ultimoFichaje->tipo === 'salida') {
            $estadoActual = 'sin_fichar';
        } elseif ($ultimoFichaje->tipo === 'pausa_fin') {
            $estadoActual = 'trabajando';
        }
    }
} catch (PDOException $e) {
    error_log("Error obteniendo fichajes: " . $e->getMessage());
}

// Obtener resumen del día
$resumenDia = [
    'fichajes' => [],
    'horas_trabajadas' => 0,
    'hora_entrada' => null,
    'hora_salida' => null
];

try {
    $stmt = $pdo->prepare("
        SELECT * FROM fichajes
        WHERE empleado_id = ? AND fecha = ? AND estado != 'rechazado'
        ORDER BY hora ASC
    ");
    $stmt->execute([$usuario->id, $hoy]);
    $resumenDia['fichajes'] = $stmt->fetchAll();

    // Calcular primera entrada y última salida
    foreach ($resumenDia['fichajes'] as $f) {
        if ($f->tipo === 'entrada' && !$resumenDia['hora_entrada']) {
            $resumenDia['hora_entrada'] = $f->hora;
        }
        if ($f->tipo === 'salida') {
            $resumenDia['hora_salida'] = $f->hora;
        }
    }

    // Obtener minutos trabajados del resumen diario
    $stmt = $pdo->prepare("SELECT minutos_trabajados FROM resumen_diario WHERE empleado_id = ? AND fecha = ?");
    $stmt->execute([$usuario->id, $hoy]);
    $resumen = $stmt->fetch();
    if ($resumen) {
        $resumenDia['horas_trabajadas'] = $resumen->minutos_trabajados;
    }
} catch (PDOException $e) {}

$mensaje = '';
$error = '';

// Procesar fichaje
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    if (!verificar_csrf()) {
        $error = 'Error de seguridad. Recarga la página.';
    } else {
        $accion = $_POST['accion'];
        $modo = $_POST['modo'] ?? 'presencial';
        $centroId = $_POST['centro_id'] ?? ($centroActual->id ?? null);
        $observacion = trim($_POST['observacion'] ?? '');
        $latitud = $_POST['latitud'] ?? null;
        $longitud = $_POST['longitud'] ?? null;

        // Combinar coordenadas para el backend
        $coordenadas = null;
        if (!empty($latitud) && !empty($longitud)) {
            $coordenadas = $latitud . ',' . $longitud;
        }

        $datos = [
            'centro_id' => $centroId,
            'modo' => $modo,
            'observacion' => $observacion,
            'coordenadas' => $coordenadas
        ];

        $tipoFichaje = null;
        switch ($accion) {
            case 'entrada':
                $tipoFichaje = FICHAJE_ENTRADA;
                break;
            case 'salida':
                $tipoFichaje = FICHAJE_SALIDA;
                break;
            case 'pausa_inicio':
                $tipoFichaje = FICHAJE_PAUSA_INICIO;
                break;
            case 'pausa_fin':
                $tipoFichaje = FICHAJE_PAUSA_FIN;
                break;
        }

        if ($tipoFichaje) {
            $resultado = registrar_fichaje($pdo, $usuario->id, $tipoFichaje, $datos);

            if ($resultado['exito']) {
                $mensaje = $resultado['mensaje'];
                if (!empty($resultado['incidencias'])) {
                    $mensaje .= ' (' . implode('. ', $resultado['incidencias']) . ')';
                }
                // Recargar para actualizar estado
                header('Location: fichar.php?ok=1');
                exit;
            } else {
                $error = $resultado['mensaje'];
            }
        }
    }
}

if (isset($_GET['ok'])) {
    $mensaje = 'Fichaje registrado correctamente';
}

// Formatear tiempo
function formatoTiempo($minutos) {
    if (!$minutos) return '0h 0m';
    $h = floor($minutos / 60);
    $m = $minutos % 60;
    return "{$h}h {$m}m";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#1e3a5f">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>Fichar - <?= htmlspecialchars($nombreEmpresa) ?></title>
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f0f4f8;
            min-height: 100vh;
            padding-bottom: 80px;
        }

        .header {
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .header h1 { font-size: 20px; margin-bottom: 5px; }
        .header p { font-size: 14px; opacity: 0.9; }

        .container { max-width: 600px; margin: 0 auto; padding: 20px; }

        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            padding: 24px;
            margin-bottom: 20px;
        }

        .estado-actual {
            text-align: center;
            padding: 30px 20px;
        }

        .estado-icono { font-size: 64px; margin-bottom: 15px; }

        .estado-texto {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .estado-hora { font-size: 36px; font-weight: 300; color: #64748b; }

        .estado-sin_fichar .estado-texto { color: #64748b; }
        .estado-trabajando .estado-texto { color: #16a34a; }
        .estado-en_pausa .estado-texto { color: #f59e0b; }

        .botones-fichaje {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 20px;
        }

        .btn-fichar {
            padding: 20px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .btn-fichar:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-entrada {
            background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%);
            color: white;
            grid-column: span 2;
        }

        .btn-salida {
            background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
            color: white;
            grid-column: span 2;
        }

        .btn-pausa {
            background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
            color: white;
        }

        .btn-continuar {
            background: linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%);
            color: white;
        }

        .btn-fichar:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .btn-icon { font-size: 28px; }

        .resumen-dia h3 {
            font-size: 16px;
            color: #374151;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .fichajes-lista {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .fichaje-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: #f8fafc;
            border-radius: 10px;
        }

        .fichaje-icono { font-size: 20px; }
        .fichaje-hora { font-weight: 600; color: #1e3a5f; }
        .fichaje-tipo { font-size: 14px; color: #64748b; }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 15px;
        }

        .stat-item {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .stat-valor { font-size: 24px; font-weight: 700; color: #1e3a5f; }
        .stat-label { font-size: 12px; color: #64748b; margin-top: 5px; }

        .mensaje {
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .mensaje-ok {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #16a34a;
        }

        .mensaje-error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
        }

        .nav-bottom {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            z-index: 100;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: #64748b;
            font-size: 12px;
            padding: 5px 15px;
        }

        .nav-item.active { color: #1e3a5f; }
        .nav-icon { font-size: 24px; margin-bottom: 4px; }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 16px;
        }

        .opciones-fichaje {
            display: none;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e5e7eb;
        }

        .opciones-fichaje.visible { display: block; }

        /* Alerta de incidencia */
        .alerta-incidencia {
            display: none;
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border: 2px solid #f59e0b;
            border-radius: 12px;
            padding: 16px;
            margin: 15px 0;
            text-align: left;
        }

        .alerta-incidencia.visible { display: block; }

        .alerta-incidencia h4 {
            color: #92400e;
            font-size: 14px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alerta-incidencia p {
            color: #78350f;
            font-size: 13px;
            margin-bottom: 12px;
        }

        .alerta-incidencia .campo-observacion {
            background: white;
            border-radius: 8px;
            padding: 12px;
        }

        .alerta-incidencia label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #92400e;
            margin-bottom: 6px;
        }

        .alerta-incidencia input,
        .alerta-incidencia textarea {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #fbbf24;
            border-radius: 8px;
            font-size: 16px;
            background: white;
        }

        .alerta-incidencia textarea {
            min-height: 80px;
            resize: vertical;
        }

        .alerta-incidencia input:focus,
        .alerta-incidencia textarea:focus {
            outline: none;
            border-color: #f59e0b;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.2);
        }

        .incidencia-tipo {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: #fef3c7;
            color: #92400e;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-right: 6px;
            margin-bottom: 6px;
        }

        /* Estado de ubicación */
        .estado-ubicacion {
            font-size: 12px;
            color: #64748b;
            margin-top: 10px;
            padding: 8px 12px;
            background: #f8fafc;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .estado-ubicacion.ok { color: #16a34a; background: #f0fdf4; }
        .estado-ubicacion.warning { color: #d97706; background: #fffbeb; }
        .estado-ubicacion.error { color: #dc2626; background: #fef2f2; }

        @media (max-width: 400px) {
            .botones-fichaje { grid-template-columns: 1fr; }
            .btn-entrada, .btn-salida { grid-column: span 1; }
            .stat-grid { grid-template-columns: 1fr; }
            .estado-hora { font-size: 28px; }
            .container { padding: 12px; }
            .card { padding: 16px; }
        }

        /* Mejoras táctiles */
        @media (max-width: 768px) {
            .btn-fichar {
                min-height: 60px;
            }
            .nav-item {
                min-height: 48px;
                padding: 8px 12px;
            }
            .form-group select,
            .form-group input {
                min-height: 48px;
                font-size: 16px; /* Evita zoom en iOS */
            }
        }

        /* Safe area para iPhones */
        @supports (padding: env(safe-area-inset-bottom)) {
            .nav-bottom {
                padding-bottom: calc(10px + env(safe-area-inset-bottom));
            }
            body {
                padding-bottom: calc(80px + env(safe-area-inset-bottom));
            }
        }

        /* Reducir animaciones si el usuario lo prefiere */
        @media (prefers-reduced-motion: reduce) {
            .btn-fichar {
                transition: none;
            }
            .btn-fichar:hover:not(:disabled) {
                transform: none;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <h1><?= htmlspecialchars($nombreEmpresa) ?></h1>
        <p><?= htmlspecialchars($usuario->nombre . ' ' . $usuario->apellido1) ?></p>
    </header>

    <div class="container">
        <?php if ($mensaje): ?>
            <div class="mensaje mensaje-ok"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="mensaje mensaje-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Estado Actual -->
        <div class="card estado-actual estado-<?= $estadoActual ?>">
            <div class="estado-icono">
                <?php if ($estadoActual === 'sin_fichar'): ?>
                    🏠
                <?php elseif ($estadoActual === 'trabajando'): ?>
                    💼
                <?php elseif ($estadoActual === 'en_pausa'): ?>
                    ☕
                <?php endif; ?>
            </div>

            <div class="estado-texto">
                <?php if ($estadoActual === 'sin_fichar'): ?>
                    Sin fichar
                <?php elseif ($estadoActual === 'trabajando'): ?>
                    Trabajando
                <?php elseif ($estadoActual === 'en_pausa'): ?>
                    En pausa
                <?php endif; ?>
            </div>

            <div class="estado-hora" id="reloj"><?= date('H:i:s') ?></div>

            <form method="POST" id="formFichaje">
                <?= csrf_campo() ?>
                <input type="hidden" name="latitud" id="latitud">
                <input type="hidden" name="longitud" id="longitud">

                <!-- Alerta de incidencia (se muestra automáticamente) -->
                <div class="alerta-incidencia" id="alertaIncidencia">
                    <h4>⚠️ Se ha detectado una incidencia</h4>
                    <p id="incidenciaTipos"></p>
                    <div class="campo-observacion">
                        <label for="observacionIncidencia">Justificación (obligatoria)</label>
                        <textarea name="observacion" id="observacionIncidencia"
                            placeholder="Por favor, indica el motivo de la incidencia..."
                            rows="3"></textarea>
                    </div>
                </div>

                <!-- Estado de ubicación -->
                <div class="estado-ubicacion" id="estadoUbicacion">
                    <span id="ubicacionIcono">📍</span>
                    <span id="ubicacionTexto">Obteniendo ubicación...</span>
                </div>

                <div class="botones-fichaje">
                    <?php if ($estadoActual === 'sin_fichar'): ?>
                        <button type="submit" name="accion" value="entrada" class="btn-fichar btn-entrada" id="btnFichar">
                            <span class="btn-icon">▶️</span>
                            <span>Fichar Entrada</span>
                        </button>
                    <?php elseif ($estadoActual === 'trabajando'): ?>
                        <button type="submit" name="accion" value="pausa_inicio" class="btn-fichar btn-pausa">
                            <span class="btn-icon">⏸️</span>
                            <span>Iniciar Pausa</span>
                        </button>
                        <button type="submit" name="accion" value="salida" class="btn-fichar btn-salida" id="btnFichar">
                            <span class="btn-icon">⏹️</span>
                            <span>Fichar Salida</span>
                        </button>
                    <?php elseif ($estadoActual === 'en_pausa'): ?>
                        <button type="submit" name="accion" value="pausa_fin" class="btn-fichar btn-continuar">
                            <span class="btn-icon">▶️</span>
                            <span>Continuar</span>
                        </button>
                        <button type="submit" name="accion" value="salida" class="btn-fichar btn-salida" id="btnFichar">
                            <span class="btn-icon">⏹️</span>
                            <span>Fichar Salida</span>
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Opciones adicionales -->
                <div class="opciones-fichaje" id="opcionesFichaje">
                    <?php if (count($centros) > 1): ?>
                    <div class="form-group">
                        <label for="centro_id">Centro de trabajo</label>
                        <select name="centro_id" id="centro_id">
                            <?php foreach ($centros as $c): ?>
                                <option value="<?= $c->id ?>" <?= ($centroActual && $centroActual->id == $c->id) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c->nombre) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php else: ?>
                        <input type="hidden" name="centro_id" value="<?= $centroActual->id ?? '' ?>">
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="modo">Modo</label>
                        <select name="modo" id="modo">
                            <option value="presencial">Presencial</option>
                            <option value="teletrabajo">Teletrabajo</option>
                            <option value="visita">Visita cliente</option>
                            <option value="formacion">Formación</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="observacion">Observaciones (opcional)</label>
                        <input type="text" name="observacion" id="observacion" placeholder="Ej: Reunión externa...">
                    </div>
                </div>
            </form>

            <p style="margin-top: 15px; font-size: 12px; color: #9ca3af;">
                <a href="#" onclick="document.getElementById('opcionesFichaje').classList.toggle('visible'); return false;">
                    ⚙️ Opciones avanzadas
                </a>
            </p>
        </div>

        <!-- Resumen del día -->
        <div class="card resumen-dia">
            <h3>📊 Resumen de hoy</h3>

            <div class="stat-grid">
                <div class="stat-item">
                    <div class="stat-valor"><?= $resumenDia['hora_entrada'] ? substr($resumenDia['hora_entrada'], 0, 5) : '--:--' ?></div>
                    <div class="stat-label">Entrada</div>
                </div>
                <div class="stat-item">
                    <div class="stat-valor"><?= $resumenDia['hora_salida'] ? substr($resumenDia['hora_salida'], 0, 5) : '--:--' ?></div>
                    <div class="stat-label">Salida</div>
                </div>
                <div class="stat-item">
                    <div class="stat-valor"><?= formatoTiempo($resumenDia['horas_trabajadas']) ?></div>
                    <div class="stat-label">Trabajado</div>
                </div>
                <div class="stat-item">
                    <div class="stat-valor"><?= count($resumenDia['fichajes']) ?></div>
                    <div class="stat-label">Fichajes</div>
                </div>
            </div>

            <?php if (!empty($resumenDia['fichajes'])): ?>
            <div class="fichajes-lista" style="margin-top: 20px;">
                <?php foreach ($resumenDia['fichajes'] as $f): ?>
                <div class="fichaje-item">
                    <span class="fichaje-icono">
                        <?php
                        switch ($f->tipo) {
                            case 'entrada': echo '🟢'; break;
                            case 'salida': echo '🔴'; break;
                            case 'pausa_inicio': echo '⏸️'; break;
                            case 'pausa_fin': echo '▶️'; break;
                            default: echo '📍';
                        }
                        ?>
                    </span>
                    <span class="fichaje-hora"><?= substr($f->hora, 0, 5) ?></span>
                    <span class="fichaje-tipo">
                        <?php
                        switch ($f->tipo) {
                            case 'entrada': echo 'Entrada'; break;
                            case 'salida': echo 'Salida'; break;
                            case 'pausa_inicio': echo 'Inicio pausa'; break;
                            case 'pausa_fin': echo 'Fin pausa'; break;
                            default: echo ucfirst($f->tipo);
                        }
                        if ($f->modo !== 'presencial') {
                            echo ' (' . ucfirst($f->modo) . ')';
                        }
                        ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Navegación inferior -->
    <nav class="nav-bottom">
        <a href="fichar.php" class="nav-item active">
            <span class="nav-icon">🕐</span>
            <span>Fichar</span>
        </a>
        <a href="mi-ficha.php" class="nav-item">
            <span class="nav-icon">📋</span>
            <span>Mi Ficha</span>
        </a>
        <a href="mis-gestiones.php" class="nav-item">
            <span class="nav-icon">📝</span>
            <span>Gestiones</span>
        </a>
        <a href="perfil.php" class="nav-item">
            <span class="nav-icon">👤</span>
            <span>Perfil</span>
        </a>
    </nav>

    <script>
        // Configuración del centro y horario desde PHP
        const configCentro = <?php
            $centroConfig = null;
            if ($centroActual) {
                $centroConfig = [
                    'id' => $centroActual->id,
                    'nombre' => $centroActual->nombre,
                    'latitud' => null,
                    'longitud' => null,
                    'radio' => $centroActual->radio_metros ?? 100
                ];
                if (!empty($centroActual->coordenadas)) {
                    $coords = explode(',', $centroActual->coordenadas);
                    if (count($coords) === 2) {
                        $centroConfig['latitud'] = floatval(trim($coords[0]));
                        $centroConfig['longitud'] = floatval(trim($coords[1]));
                    }
                }
            }
            echo json_encode($centroConfig);
        ?>;

        const configHorario = <?php
            $horarioConfig = null;
            if ($usuario && $usuario->horario_id) {
                $stmtH = $pdo->prepare("SELECT * FROM horarios WHERE id = ?");
                $stmtH->execute([$usuario->horario_id]);
                $horario = $stmtH->fetch();
                if ($horario) {
                    $horarioConfig = [
                        'hora_entrada' => $horario->hora_entrada,
                        'hora_salida' => $horario->hora_salida,
                        'troncal_inicio' => $horario->troncal_inicio,
                        'troncal_fin' => $horario->troncal_fin,
                        'tolerancia' => $horario->tolerancia_minutos ?? 15,
                        'cortesia_entrada' => $horario->cortesia_entrada ?? 5,
                        'cortesia_salida' => $horario->cortesia_salida ?? 5
                    ];
                }
            }
            echo json_encode($horarioConfig);
        ?>;

        const estadoActual = '<?= $estadoActual ?>';

        // Estado de incidencias
        let incidencias = {
            ubicacion: false,
            horario: false,
            mensajes: []
        };

        // Reloj en tiempo real
        function actualizarReloj() {
            const ahora = new Date();
            const h = String(ahora.getHours()).padStart(2, '0');
            const m = String(ahora.getMinutes()).padStart(2, '0');
            const s = String(ahora.getSeconds()).padStart(2, '0');
            document.getElementById('reloj').textContent = h + ':' + m + ':' + s;

            // Verificar horario cada segundo
            verificarHorario();
        }
        setInterval(actualizarReloj, 1000);

        // Calcular distancia entre dos puntos GPS (Haversine)
        function calcularDistancia(lat1, lon1, lat2, lon2) {
            const R = 6371000; // Radio de la Tierra en metros
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                      Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return Math.round(R * c);
        }

        // Verificar si está fuera de ubicación
        function verificarUbicacion(userLat, userLon) {
            const estadoEl = document.getElementById('estadoUbicacion');
            const iconoEl = document.getElementById('ubicacionIcono');
            const textoEl = document.getElementById('ubicacionTexto');

            if (!configCentro || !configCentro.latitud || !configCentro.longitud) {
                estadoEl.className = 'estado-ubicacion';
                iconoEl.textContent = '📍';
                textoEl.textContent = 'Centro sin coordenadas configuradas';
                return;
            }

            const distancia = calcularDistancia(userLat, userLon, configCentro.latitud, configCentro.longitud);
            const radio = configCentro.radio || 100;

            if (distancia > radio) {
                incidencias.ubicacion = true;
                incidencias.mensajes = incidencias.mensajes.filter(m => !m.includes('ubicación'));
                incidencias.mensajes.push(`Fuera de ubicación (${distancia}m del centro, permitido: ${radio}m)`);

                estadoEl.className = 'estado-ubicacion warning';
                iconoEl.textContent = '⚠️';
                textoEl.textContent = `Fuera del centro (${distancia}m)`;
            } else {
                incidencias.ubicacion = false;
                incidencias.mensajes = incidencias.mensajes.filter(m => !m.includes('ubicación'));

                estadoEl.className = 'estado-ubicacion ok';
                iconoEl.textContent = '✅';
                textoEl.textContent = `Dentro del centro (${distancia}m)`;
            }

            actualizarAlertaIncidencia();
        }

        // Verificar si está fuera de horario
        function verificarHorario() {
            if (!configHorario) return;

            const ahora = new Date();
            const horaActual = ahora.getHours() * 60 + ahora.getMinutes(); // Minutos desde medianoche

            incidencias.mensajes = incidencias.mensajes.filter(m => !m.includes('horario'));
            incidencias.horario = false;

            // Para entrada: verificar si está llegando tarde
            if (estadoActual === 'sin_fichar' && configHorario.hora_entrada) {
                const [hE, mE] = configHorario.hora_entrada.split(':').map(Number);
                const horaEntrada = hE * 60 + mE;
                const tolerancia = configHorario.tolerancia || 15;
                const cortesia = configHorario.cortesia_entrada || 5;

                // Si tiene troncal, usar ese
                let limiteEntrada = horaEntrada + tolerancia + cortesia;
                if (configHorario.troncal_inicio) {
                    const [hT, mT] = configHorario.troncal_inicio.split(':').map(Number);
                    limiteEntrada = hT * 60 + mT + cortesia;
                }

                if (horaActual > limiteEntrada) {
                    incidencias.horario = true;
                    const horaLimite = configHorario.troncal_inicio || configHorario.hora_entrada;
                    incidencias.mensajes.push(`Entrada fuera de horario (límite: ${horaLimite.substring(0,5)})`);
                }
            }

            // Para salida: verificar si sale antes de tiempo
            if (estadoActual === 'trabajando' && configHorario.hora_salida) {
                const [hS, mS] = configHorario.hora_salida.split(':').map(Number);
                let horaSalida = hS * 60 + mS;
                const cortesia = configHorario.cortesia_salida || 5;

                // Si tiene troncal, usar ese
                if (configHorario.troncal_fin) {
                    const [hT, mT] = configHorario.troncal_fin.split(':').map(Number);
                    horaSalida = hT * 60 + mT;
                }

                if (horaActual < horaSalida - cortesia) {
                    incidencias.horario = true;
                    const horaMinima = configHorario.troncal_fin || configHorario.hora_salida;
                    incidencias.mensajes.push(`Salida antes de horario (mínimo: ${horaMinima.substring(0,5)})`);
                }
            }

            actualizarAlertaIncidencia();
        }

        // Actualizar la alerta de incidencia en la UI
        function actualizarAlertaIncidencia() {
            const alertaEl = document.getElementById('alertaIncidencia');
            const tiposEl = document.getElementById('incidenciaTipos');
            const obsEl = document.getElementById('observacionIncidencia');
            const obsNormal = document.getElementById('observacion');

            if (incidencias.ubicacion || incidencias.horario) {
                alertaEl.classList.add('visible');

                // Mostrar tipos de incidencias
                let html = '';
                incidencias.mensajes.forEach(msg => {
                    html += `<span class="incidencia-tipo">⚠️ ${msg}</span>`;
                });
                tiposEl.innerHTML = html;

                // Hacer obligatorio el campo de observación
                obsEl.required = true;

                // Ocultar el campo de observación normal si existe
                if (obsNormal) {
                    obsNormal.closest('.form-group').style.display = 'none';
                }
            } else {
                alertaEl.classList.remove('visible');
                obsEl.required = false;

                // Mostrar el campo de observación normal
                if (obsNormal) {
                    obsNormal.closest('.form-group').style.display = '';
                }
            }
        }

        // Validar antes de enviar
        document.getElementById('formFichaje').addEventListener('submit', function(e) {
            const obsEl = document.getElementById('observacionIncidencia');

            if ((incidencias.ubicacion || incidencias.horario) && obsEl.value.trim() === '') {
                e.preventDefault();
                alert('Por favor, indica el motivo de la incidencia antes de fichar.');
                obsEl.focus();
                return false;
            }
        });

        // Geolocalización con verificación de incidencias
        const estadoEl = document.getElementById('estadoUbicacion');
        const iconoEl = document.getElementById('ubicacionIcono');
        const textoEl = document.getElementById('ubicacionTexto');

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    document.getElementById('latitud').value = pos.coords.latitude;
                    document.getElementById('longitud').value = pos.coords.longitude;

                    // Verificar ubicación
                    verificarUbicacion(pos.coords.latitude, pos.coords.longitude);
                },
                function(err) {
                    console.log('Geolocalización no disponible:', err);
                    estadoEl.className = 'estado-ubicacion error';
                    iconoEl.textContent = '❌';
                    textoEl.textContent = 'No se pudo obtener ubicación';
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        } else {
            estadoEl.className = 'estado-ubicacion error';
            iconoEl.textContent = '❌';
            textoEl.textContent = 'Geolocalización no soportada';
        }

        // Verificar horario al cargar
        verificarHorario();
    </script>
</body>
</html>
