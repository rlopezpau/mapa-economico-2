<?php

declare(strict_types=1);

namespace LMFichajes\Core;

use Closure;
use InvalidArgumentException;
use ReflectionClass;
use ReflectionException;
use ReflectionNamedType;
use RuntimeException;

/**
 * Contenedor de Inyección de Dependencias
 *
 * Implementación simple de un contenedor IoC para gestionar
 * las dependencias de la aplicación.
 *
 * @package LMFichajes\Core
 */
class Container
{
    private static ?Container $instance = null;

    /** @var array<string, Closure|object|string> Bindings registrados */
    private array $bindings = [];

    /** @var array<string, object> Instancias singleton */
    private array $instances = [];

    /** @var array<string, bool> Servicios marcados como singleton */
    private array $singletons = [];

    /**
     * Obtiene la instancia del contenedor (Singleton)
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Registra un binding en el contenedor
     *
     * @param string $abstract Interfaz o nombre abstracto
     * @param Closure|string|null $concrete Implementación concreta
     * @param bool $singleton Si debe ser singleton
     */
    public function bind(string $abstract, Closure|string|null $concrete = null, bool $singleton = false): void
    {
        $this->bindings[$abstract] = $concrete ?? $abstract;

        if ($singleton) {
            $this->singletons[$abstract] = true;
        }
    }

    /**
     * Registra un singleton en el contenedor
     *
     * @param string $abstract Interfaz o nombre abstracto
     * @param Closure|string|null $concrete Implementación concreta
     */
    public function singleton(string $abstract, Closure|string|null $concrete = null): void
    {
        $this->bind($abstract, $concrete, true);
    }

    /**
     * Registra una instancia existente como singleton
     *
     * @param string $abstract Nombre abstracto
     * @param object $instance Instancia a registrar
     */
    public function instance(string $abstract, object $instance): void
    {
        $this->instances[$abstract] = $instance;
    }

    /**
     * Resuelve una dependencia del contenedor
     *
     * @template T
     * @param class-string<T>|string $abstract Nombre a resolver
     * @param array<string, mixed> $parameters Parámetros adicionales
     * @return T|mixed
     * @throws RuntimeException Si no se puede resolver
     */
    public function make(string $abstract, array $parameters = []): mixed
    {
        // ¿Ya existe una instancia singleton?
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        // Obtener el concrete
        $concrete = $this->bindings[$abstract] ?? $abstract;

        // Resolver
        $object = $this->build($concrete, $parameters);

        // ¿Es singleton?
        if (isset($this->singletons[$abstract])) {
            $this->instances[$abstract] = $object;
        }

        return $object;
    }

    /**
     * Alias de make() para compatibilidad
     *
     * @template T
     * @param class-string<T>|string $abstract
     * @return T|mixed
     */
    public function get(string $abstract): mixed
    {
        return $this->make($abstract);
    }

    /**
     * Verifica si existe un binding
     *
     * @param string $abstract Nombre a verificar
     * @return bool
     */
    public function has(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) || isset($this->instances[$abstract]);
    }

    /**
     * Construye una instancia de una clase
     *
     * @param Closure|string $concrete Clase o closure a construir
     * @param array<string, mixed> $parameters Parámetros adicionales
     * @return object
     * @throws RuntimeException
     */
    private function build(Closure|string $concrete, array $parameters = []): object
    {
        // Si es un closure, ejecutarlo
        if ($concrete instanceof Closure) {
            return $concrete($this, $parameters);
        }

        // Usar reflection para construir la clase
        try {
            $reflector = new ReflectionClass($concrete);
        } catch (ReflectionException $e) {
            throw new RuntimeException("La clase {$concrete} no existe: " . $e->getMessage());
        }

        // Verificar que sea instanciable
        if (!$reflector->isInstantiable()) {
            throw new RuntimeException("La clase {$concrete} no es instanciable");
        }

        // Obtener el constructor
        $constructor = $reflector->getConstructor();

        // Si no hay constructor, instanciar directamente
        if ($constructor === null) {
            return new $concrete();
        }

        // Resolver las dependencias del constructor
        $dependencies = $this->resolveDependencies(
            $constructor->getParameters(),
            $parameters
        );

        return $reflector->newInstanceArgs($dependencies);
    }

    /**
     * Resuelve las dependencias de un constructor
     *
     * @param array<\ReflectionParameter> $dependencies Parámetros a resolver
     * @param array<string, mixed> $parameters Parámetros proporcionados
     * @return array<int, mixed>
     * @throws RuntimeException
     */
    private function resolveDependencies(array $dependencies, array $parameters): array
    {
        $resolved = [];

        foreach ($dependencies as $dependency) {
            $name = $dependency->getName();

            // ¿Se proporcionó el parámetro?
            if (isset($parameters[$name])) {
                $resolved[] = $parameters[$name];
                continue;
            }

            // Obtener el tipo
            $type = $dependency->getType();

            // Si no tiene tipo o es builtin, usar valor por defecto
            if ($type === null || !$type instanceof ReflectionNamedType || $type->isBuiltin()) {
                if ($dependency->isDefaultValueAvailable()) {
                    $resolved[] = $dependency->getDefaultValue();
                } elseif ($dependency->allowsNull()) {
                    $resolved[] = null;
                } else {
                    throw new RuntimeException(
                        "No se puede resolver el parámetro \${$name}"
                    );
                }
                continue;
            }

            // Resolver la clase del tipo
            $typeName = $type->getName();
            $resolved[] = $this->make($typeName);
        }

        return $resolved;
    }

    /**
     * Llama a un método resolviendo sus dependencias
     *
     * @param object|string $target Objeto o clase
     * @param string $method Nombre del método
     * @param array<string, mixed> $parameters Parámetros adicionales
     * @return mixed
     */
    public function call(object|string $target, string $method, array $parameters = []): mixed
    {
        if (is_string($target)) {
            $target = $this->make($target);
        }

        $reflector = new ReflectionClass($target);
        $methodReflector = $reflector->getMethod($method);

        $dependencies = $this->resolveDependencies(
            $methodReflector->getParameters(),
            $parameters
        );

        return $methodReflector->invokeArgs($target, $dependencies);
    }

    /**
     * Resetea el contenedor (para tests)
     */
    public function flush(): void
    {
        $this->bindings = [];
        $this->instances = [];
        $this->singletons = [];
    }

    /**
     * Resetea la instancia singleton (para tests)
     */
    public static function resetInstance(): void
    {
        self::$instance = null;
    }
}
