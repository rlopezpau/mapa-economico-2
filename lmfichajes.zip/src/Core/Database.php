<?php

declare(strict_types=1);

namespace LMFichajes\Core;

use PDO;
use PDOException;
use PDOStatement;
use RuntimeException;

/**
 * Gestión de conexión a base de datos
 *
 * Singleton que maneja la conexión PDO con configuración segura.
 *
 * @package LMFichajes\Core
 */
class Database
{
    private static ?Database $instance = null;
    private ?PDO $pdo = null;

    /** @var array<string, mixed> Configuración de conexión */
    private array $config;

    /**
     * Constructor privado (Singleton)
     *
     * @param array<string, mixed> $config Configuración de BD
     */
    private function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Obtiene la instancia única de Database
     *
     * @param array<string, mixed>|null $config Configuración inicial
     * @return self
     */
    public static function getInstance(?array $config = null): self
    {
        if (self::$instance === null) {
            if ($config === null) {
                $config = [
                    'host' => getenv('DB_HOST') ?: 'localhost',
                    'name' => getenv('DB_NAME') ?: 'lmfichajes',
                    'user' => getenv('DB_USER') ?: 'root',
                    'pass' => getenv('DB_PASS') ?: '',
                    'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
                    'port' => (int)(getenv('DB_PORT') ?: 3306),
                ];
            }
            self::$instance = new self($config);
        }

        return self::$instance;
    }

    /**
     * Obtiene la conexión PDO
     *
     * @return PDO
     * @throws RuntimeException Si no se puede conectar
     */
    public function getConnection(): PDO
    {
        if ($this->pdo === null) {
            $this->connect();
        }

        return $this->pdo;
    }

    /**
     * Establece la conexión a la base de datos
     *
     * @throws RuntimeException Si la conexión falla
     */
    private function connect(): void
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $this->config['host'],
            $this->config['port'],
            $this->config['name'],
            $this->config['charset']
        );

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->config['charset']} COLLATE utf8mb4_unicode_ci",
        ];

        try {
            $this->pdo = new PDO($dsn, $this->config['user'], $this->config['pass'], $options);
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            throw new RuntimeException('No se pudo conectar a la base de datos');
        }
    }

    /**
     * Ejecuta una consulta preparada
     *
     * @param string $sql Consulta SQL
     * @param array<int|string, mixed> $params Parámetros
     * @return PDOStatement
     */
    public function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Obtiene un único registro
     *
     * @param string $sql Consulta SQL
     * @param array<int|string, mixed> $params Parámetros
     * @return object|null
     */
    public function fetchOne(string $sql, array $params = []): ?object
    {
        $result = $this->query($sql, $params)->fetch();
        return $result ?: null;
    }

    /**
     * Obtiene todos los registros
     *
     * @param string $sql Consulta SQL
     * @param array<int|string, mixed> $params Parámetros
     * @return array<int, object>
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    /**
     * Obtiene un valor escalar
     *
     * @param string $sql Consulta SQL
     * @param array<int|string, mixed> $params Parámetros
     * @return mixed
     */
    public function fetchColumn(string $sql, array $params = []): mixed
    {
        return $this->query($sql, $params)->fetchColumn();
    }

    /**
     * Inserta un registro y devuelve el ID
     *
     * @param string $table Nombre de la tabla
     * @param array<string, mixed> $data Datos a insertar
     * @return int ID insertado
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));

        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, array_values($data));

        return (int)$this->getConnection()->lastInsertId();
    }

    /**
     * Actualiza registros
     *
     * @param string $table Nombre de la tabla
     * @param array<string, mixed> $data Datos a actualizar
     * @param string $where Condición WHERE
     * @param array<int|string, mixed> $whereParams Parámetros del WHERE
     * @return int Filas afectadas
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $sets = [];
        foreach (array_keys($data) as $column) {
            $sets[] = "{$column} = ?";
        }
        $setClause = implode(', ', $sets);

        $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        $params = array_merge(array_values($data), $whereParams);

        return $this->query($sql, $params)->rowCount();
    }

    /**
     * Elimina registros
     *
     * @param string $table Nombre de la tabla
     * @param string $where Condición WHERE
     * @param array<int|string, mixed> $params Parámetros
     * @return int Filas afectadas
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        return $this->query($sql, $params)->rowCount();
    }

    /**
     * Inicia una transacción
     */
    public function beginTransaction(): bool
    {
        return $this->getConnection()->beginTransaction();
    }

    /**
     * Confirma una transacción
     */
    public function commit(): bool
    {
        return $this->getConnection()->commit();
    }

    /**
     * Revierte una transacción
     */
    public function rollBack(): bool
    {
        return $this->getConnection()->rollBack();
    }

    /**
     * Ejecuta código dentro de una transacción
     *
     * @template T
     * @param callable(): T $callback
     * @return T
     * @throws \Throwable
     */
    public function transaction(callable $callback): mixed
    {
        $this->beginTransaction();

        try {
            $result = $callback();
            $this->commit();
            return $result;
        } catch (\Throwable $e) {
            $this->rollBack();
            throw $e;
        }
    }

    /**
     * Previene clonación (Singleton)
     */
    private function __clone()
    {
    }

    /**
     * Previene deserialización (Singleton)
     */
    public function __wakeup(): void
    {
        throw new RuntimeException('No se puede deserializar un singleton');
    }

    /**
     * Resetea la instancia (solo para tests)
     */
    public static function resetInstance(): void
    {
        self::$instance = null;
    }
}
