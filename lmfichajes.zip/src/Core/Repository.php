<?php

declare(strict_types=1);

namespace LMFichajes\Core;

use PDO;

/**
 * Repositorio Base
 *
 * Clase base para todos los repositorios de datos.
 * Proporciona operaciones CRUD básicas.
 *
 * @package LMFichajes\Core
 */
abstract class Repository
{
    protected Database $db;
    protected string $table;
    protected string $primaryKey = 'id';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Obtiene todos los registros
     *
     * @param array<string, mixed> $conditions Condiciones WHERE
     * @param string|null $orderBy Orden
     * @param int|null $limit Límite
     * @param int $offset Offset
     * @return array<int, object>
     */
    public function findAll(
        array $conditions = [],
        ?string $orderBy = null,
        ?int $limit = null,
        int $offset = 0
    ): array {
        $sql = "SELECT * FROM {$this->table}";
        $params = [];

        if (!empty($conditions)) {
            [$whereClause, $params] = $this->buildWhere($conditions);
            $sql .= " WHERE {$whereClause}";
        }

        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy}";
        }

        if ($limit) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Obtiene un registro por ID
     *
     * @param int|string $id
     * @return object|null
     */
    public function find(int|string $id): ?object
    {
        return $this->findOneBy([$this->primaryKey => $id]);
    }

    /**
     * Obtiene un registro por condiciones
     *
     * @param array<string, mixed> $conditions
     * @return object|null
     */
    public function findOneBy(array $conditions): ?object
    {
        [$whereClause, $params] = $this->buildWhere($conditions);
        $sql = "SELECT * FROM {$this->table} WHERE {$whereClause} LIMIT 1";

        return $this->db->fetchOne($sql, $params);
    }

    /**
     * Obtiene registros por condiciones
     *
     * @param array<string, mixed> $conditions
     * @param string|null $orderBy
     * @return array<int, object>
     */
    public function findBy(array $conditions, ?string $orderBy = null): array
    {
        return $this->findAll($conditions, $orderBy);
    }

    /**
     * Cuenta registros
     *
     * @param array<string, mixed> $conditions
     * @return int
     */
    public function count(array $conditions = []): int
    {
        $sql = "SELECT COUNT(*) FROM {$this->table}";
        $params = [];

        if (!empty($conditions)) {
            [$whereClause, $params] = $this->buildWhere($conditions);
            $sql .= " WHERE {$whereClause}";
        }

        return (int)$this->db->fetchColumn($sql, $params);
    }

    /**
     * Verifica si existe un registro
     *
     * @param array<string, mixed> $conditions
     * @return bool
     */
    public function exists(array $conditions): bool
    {
        return $this->count($conditions) > 0;
    }

    /**
     * Crea un nuevo registro
     *
     * @param array<string, mixed> $data
     * @return int ID del registro creado
     */
    public function create(array $data): int
    {
        // Añadir timestamps si existen las columnas
        if (!isset($data['created_at'])) {
            $data['created_at'] = date('Y-m-d H:i:s');
        }

        return $this->db->insert($this->table, $data);
    }

    /**
     * Actualiza un registro por ID
     *
     * @param int|string $id
     * @param array<string, mixed> $data
     * @return bool
     */
    public function update(int|string $id, array $data): bool
    {
        // Añadir timestamp de actualización
        if (!isset($data['updated_at'])) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }

        $affected = $this->db->update(
            $this->table,
            $data,
            "{$this->primaryKey} = ?",
            [$id]
        );

        return $affected > 0;
    }

    /**
     * Actualiza registros por condiciones
     *
     * @param array<string, mixed> $conditions
     * @param array<string, mixed> $data
     * @return int Filas afectadas
     */
    public function updateWhere(array $conditions, array $data): int
    {
        if (!isset($data['updated_at'])) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }

        [$whereClause, $params] = $this->buildWhere($conditions);

        return $this->db->update($this->table, $data, $whereClause, $params);
    }

    /**
     * Elimina un registro por ID
     *
     * @param int|string $id
     * @return bool
     */
    public function delete(int|string $id): bool
    {
        $affected = $this->db->delete(
            $this->table,
            "{$this->primaryKey} = ?",
            [$id]
        );

        return $affected > 0;
    }

    /**
     * Elimina registros por condiciones
     *
     * @param array<string, mixed> $conditions
     * @return int Filas eliminadas
     */
    public function deleteWhere(array $conditions): int
    {
        [$whereClause, $params] = $this->buildWhere($conditions);
        return $this->db->delete($this->table, $whereClause, $params);
    }

    /**
     * Soft delete (si la tabla lo soporta)
     *
     * @param int|string $id
     * @return bool
     */
    public function softDelete(int|string $id): bool
    {
        return $this->update($id, [
            'activo' => 0,
            'deleted_at' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Construye cláusula WHERE
     *
     * @param array<string, mixed> $conditions
     * @return array{0: string, 1: array<int, mixed>}
     */
    protected function buildWhere(array $conditions): array
    {
        $clauses = [];
        $params = [];

        foreach ($conditions as $column => $value) {
            if ($value === null) {
                $clauses[] = "{$column} IS NULL";
            } elseif (is_array($value)) {
                $placeholders = implode(', ', array_fill(0, count($value), '?'));
                $clauses[] = "{$column} IN ({$placeholders})";
                $params = array_merge($params, $value);
            } else {
                $clauses[] = "{$column} = ?";
                $params[] = $value;
            }
        }

        return [implode(' AND ', $clauses), $params];
    }

    /**
     * Paginación con metadatos
     *
     * @param int $page Página actual (1-indexed)
     * @param int $perPage Elementos por página
     * @param array<string, mixed> $conditions Condiciones
     * @param string|null $orderBy Orden
     * @return array{data: array, meta: array{total: int, per_page: int, current_page: int, last_page: int}}
     */
    public function paginate(
        int $page = 1,
        int $perPage = 20,
        array $conditions = [],
        ?string $orderBy = null
    ): array {
        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;

        $total = $this->count($conditions);
        $data = $this->findAll($conditions, $orderBy, $perPage, $offset);

        return [
            'data' => $data,
            'meta' => [
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'last_page' => (int)ceil($total / $perPage),
            ],
        ];
    }
}
