<?php

declare(strict_types=1);

namespace LMFichajes\Core;

/**
 * PSR-4 Autoloader para LM Fichajes
 *
 * Carga automáticamente las clases del namespace LMFichajes
 * siguiendo el estándar PSR-4.
 *
 * @package LMFichajes
 * @version 2.0.0
 */
class Autoloader
{
    /** @var array<string, string> Mapa de namespaces a directorios */
    private array $prefixes = [];

    /**
     * Registra el autoloader con SPL
     */
    public function register(): void
    {
        spl_autoload_register([$this, 'loadClass']);
    }

    /**
     * Añade un namespace base y su directorio
     *
     * @param string $prefix Namespace prefix (ej: 'LMFichajes\\')
     * @param string $baseDir Directorio base para el namespace
     * @param bool $prepend Si true, añade al inicio del stack
     */
    public function addNamespace(string $prefix, string $baseDir, bool $prepend = false): void
    {
        // Normalizar el namespace prefix
        $prefix = trim($prefix, '\\') . '\\';

        // Normalizar el directorio base
        $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . '/';

        // Inicializar array si no existe
        if (!isset($this->prefixes[$prefix])) {
            $this->prefixes[$prefix] = [];
        }

        // Añadir el directorio base
        if ($prepend) {
            array_unshift($this->prefixes[$prefix], $baseDir);
        } else {
            $this->prefixes[$prefix][] = $baseDir;
        }
    }

    /**
     * Carga el archivo de clase para un nombre de clase dado
     *
     * @param string $class El nombre completo de la clase
     * @return string|false La ruta del archivo cargado o false si no se encontró
     */
    public function loadClass(string $class): string|false
    {
        // El namespace prefix actual
        $prefix = $class;

        // Buscar hacia atrás en el nombre para encontrar el namespace
        while (($pos = strrpos($prefix, '\\')) !== false) {
            // Obtener el namespace prefix con el separador
            $prefix = substr($class, 0, $pos + 1);

            // El nombre relativo de la clase
            $relativeClass = substr($class, $pos + 1);

            // Intentar cargar el archivo
            $mappedFile = $this->loadMappedFile($prefix, $relativeClass);
            if ($mappedFile) {
                return $mappedFile;
            }

            // Eliminar el separador final para la siguiente iteración
            $prefix = rtrim($prefix, '\\');
        }

        return false;
    }

    /**
     * Carga el archivo mapeado para un namespace prefix y nombre de clase relativo
     *
     * @param string $prefix El namespace prefix
     * @param string $relativeClass El nombre relativo de la clase
     * @return string|false La ruta del archivo o false si no existe
     */
    protected function loadMappedFile(string $prefix, string $relativeClass): string|false
    {
        // ¿Existe este namespace prefix?
        if (!isset($this->prefixes[$prefix])) {
            return false;
        }

        // Buscar en los directorios base
        foreach ($this->prefixes[$prefix] as $baseDir) {
            // Reemplazar namespace separators con directory separators
            // y añadir .php
            $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

            // Si el archivo existe, cargarlo
            if ($this->requireFile($file)) {
                return $file;
            }
        }

        return false;
    }

    /**
     * Requiere un archivo si existe
     *
     * @param string $file El archivo a cargar
     * @return bool True si existe y se cargó
     */
    protected function requireFile(string $file): bool
    {
        if (file_exists($file)) {
            require $file;
            return true;
        }
        return false;
    }
}
