<?php

declare(strict_types=1);

namespace LMFichajes\Repositories;

use LMFichajes\Core\Repository;
use LMFichajes\Core\Database;

/**
 * Repositorio de Empleados
 *
 * @package LMFichajes\Repositories
 */
class EmpleadoRepository extends Repository
{
    protected string $table = 'empleados';

    /**
     * Busca empleado por NIF
     */
    public function findByNif(string $nif): ?object
    {
        return $this->findOneBy(['nif' => $nif]);
    }

    /**
     * Busca empleado por email
     */
    public function findByEmail(string $email): ?object
    {
        return $this->findOneBy(['email' => $email]);
    }

    /**
     * Obtiene empleados activos
     *
     * @return array<int, object>
     */
    public function findActivos(): array
    {
        return $this->findBy(['activo' => 1], 'apellido1, apellido2, nombre');
    }

    /**
     * Obtiene empleados por rol
     *
     * @param string $rol
     * @return array<int, object>
     */
    public function findByRol(string $rol): array
    {
        return $this->findBy(['rol' => $rol, 'activo' => 1], 'apellido1, nombre');
    }

    /**
     * Obtiene empleados con su información de horario
     *
     * @param array<string, mixed> $filters
     * @return array<int, object>
     */
    public function findWithHorario(array $filters = []): array
    {
        $sql = "
            SELECT e.*, h.nombre as horario_nombre,
                   (SELECT GROUP_CONCAT(c.nombre SEPARATOR ', ')
                    FROM empleados_centros ec
                    INNER JOIN centros c ON ec.centro_id = c.id
                    WHERE ec.empleado_id = e.id AND ec.activo = 1) as centros
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE 1=1
        ";
        $params = [];

        if (isset($filters['activo'])) {
            $sql .= " AND e.activo = ?";
            $params[] = $filters['activo'];
        }

        if (!empty($filters['busqueda'])) {
            $busqueda = '%' . $filters['busqueda'] . '%';
            $sql .= " AND (e.nif LIKE ? OR e.nombre LIKE ? OR e.apellido1 LIKE ? OR e.email LIKE ?)";
            $params = array_merge($params, [$busqueda, $busqueda, $busqueda, $busqueda]);
        }

        if (!empty($filters['rol'])) {
            $sql .= " AND e.rol = ?";
            $params[] = $filters['rol'];
        }

        if (!empty($filters['centro_id'])) {
            $sql .= " AND EXISTS (
                SELECT 1 FROM empleados_centros ec
                WHERE ec.empleado_id = e.id AND ec.centro_id = ? AND ec.activo = 1
            )";
            $params[] = $filters['centro_id'];
        }

        $sql .= " ORDER BY e.apellido1, e.apellido2, e.nombre";

        if (isset($filters['limit'])) {
            $sql .= " LIMIT " . (int)$filters['limit'];
            if (isset($filters['offset'])) {
                $sql .= " OFFSET " . (int)$filters['offset'];
            }
        }

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Obtiene empleado con todos sus datos relacionados
     */
    public function findWithRelations(int $id): ?object
    {
        $empleado = $this->find($id);

        if ($empleado) {
            // Obtener centros asignados
            $empleado->centros = $this->db->fetchAll("
                SELECT ec.*, c.nombre as centro_nombre
                FROM empleados_centros ec
                INNER JOIN centros c ON ec.centro_id = c.id
                WHERE ec.empleado_id = ? AND ec.activo = 1
                ORDER BY ec.es_principal DESC, c.nombre
            ", [$id]);

            // Obtener horario
            if ($empleado->horario_id) {
                $empleado->horario = $this->db->fetchOne(
                    "SELECT * FROM horarios WHERE id = ?",
                    [$empleado->horario_id]
                );
            }
        }

        return $empleado;
    }

    /**
     * Obtiene supervisores disponibles (excluyendo un empleado)
     *
     * @param int|null $excludeId
     * @return array<int, object>
     */
    public function findSupervisores(?int $excludeId = null): array
    {
        $sql = "
            SELECT id, nif, nombre, apellido1, apellido2, rol
            FROM empleados
            WHERE activo = 1 AND rol IN ('admin', 'supervisor', 'superadmin')
        ";
        $params = [];

        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }

        $sql .= " ORDER BY apellido1, apellido2, nombre";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Verifica si el NIF ya existe (excluyendo un empleado)
     */
    public function nifExists(string $nif, ?int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) FROM empleados WHERE nif = ?";
        $params = [$nif];

        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }

        return (int)$this->db->fetchColumn($sql, $params) > 0;
    }

    /**
     * Actualiza último acceso del empleado
     */
    public function updateUltimoAcceso(int $id): bool
    {
        return $this->update($id, [
            'ultimo_acceso' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Cambia contraseña del empleado
     */
    public function updatePassword(int $id, string $hashedPassword): bool
    {
        return $this->update($id, [
            'password' => $hashedPassword,
            'password_changed_at' => date('Y-m-d H:i:s'),
            'debe_cambiar_password' => 0,
        ]);
    }

    /**
     * Activa/Desactiva empleado
     */
    public function toggleActivo(int $id): bool
    {
        $empleado = $this->find($id);
        if (!$empleado) {
            return false;
        }

        return $this->update($id, [
            'activo' => $empleado->activo ? 0 : 1,
        ]);
    }
}
