<?php

declare(strict_types=1);

namespace LMFichajes\Repositories;

use LMFichajes\Core\Repository;
use DateTimeInterface;

/**
 * Repositorio de Fichajes
 *
 * @package LMFichajes\Repositories
 */
class FichajeRepository extends Repository
{
    protected string $table = 'fichajes';

    // Tipos de fichaje
    public const TIPO_ENTRADA = 'entrada';
    public const TIPO_SALIDA = 'salida';
    public const TIPO_PAUSA_INICIO = 'pausa_inicio';
    public const TIPO_PAUSA_FIN = 'pausa_fin';

    // Estados
    public const ESTADO_PENDIENTE = 'pendiente';
    public const ESTADO_VALIDADO = 'validado';
    public const ESTADO_RECHAZADO = 'rechazado';
    public const ESTADO_AUTO_APROBADO = 'auto_aprobado';

    /**
     * Obtiene fichajes de un empleado en una fecha
     *
     * @return array<int, object>
     */
    public function findByEmpleadoFecha(int $empleadoId, string $fecha): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM fichajes
             WHERE empleado_id = ? AND fecha = ? AND estado != 'rechazado'
             ORDER BY hora ASC",
            [$empleadoId, $fecha]
        );
    }

    /**
     * Obtiene el último fichaje del día de un empleado
     */
    public function findUltimoDelDia(int $empleadoId, string $fecha): ?object
    {
        return $this->db->fetchOne(
            "SELECT * FROM fichajes
             WHERE empleado_id = ? AND fecha = ? AND estado != 'rechazado'
             ORDER BY hora DESC
             LIMIT 1",
            [$empleadoId, $fecha]
        );
    }

    /**
     * Obtiene fichajes pendientes de validación con paginación
     *
     * @param array<string, mixed> $filters
     * @param int $limit
     * @param int $offset
     * @return array{fichajes: array, total: int}
     */
    public function findPendientes(array $filters = [], int $limit = 20, int $offset = 0): array
    {
        $where = ["f.estado = 'pendiente'"];
        $params = [];

        if (!empty($filters['fecha_desde'])) {
            $where[] = "f.fecha >= ?";
            $params[] = $filters['fecha_desde'];
        }

        if (!empty($filters['fecha_hasta'])) {
            $where[] = "f.fecha <= ?";
            $params[] = $filters['fecha_hasta'];
        }

        if (!empty($filters['empleado_id'])) {
            $where[] = "f.empleado_id = ?";
            $params[] = $filters['empleado_id'];
        }

        if (!empty($filters['centro_id'])) {
            $where[] = "f.centro_id = ?";
            $params[] = $filters['centro_id'];
        }

        if (!empty($filters['incidencia'])) {
            if ($filters['incidencia'] === 'ubicacion') {
                $where[] = "f.incidencia_ubicacion = 1";
            } elseif ($filters['incidencia'] === 'horario') {
                $where[] = "f.incidencia_horario = 1";
            }
        }

        $whereClause = implode(' AND ', $where);

        // Contar total
        $total = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM fichajes f WHERE {$whereClause}",
            $params
        );

        // Obtener fichajes
        $fichajes = $this->db->fetchAll("
            SELECT f.*,
                   e.nif, e.nombre, e.apellido1, e.apellido2,
                   c.nombre as centro_nombre
            FROM fichajes f
            INNER JOIN empleados e ON f.empleado_id = e.id
            LEFT JOIN centros c ON f.centro_id = c.id
            WHERE {$whereClause}
            ORDER BY f.fecha DESC, f.hora DESC
            LIMIT {$limit} OFFSET {$offset}
        ", $params);

        return [
            'fichajes' => $fichajes,
            'total' => $total,
        ];
    }

    /**
     * Obtiene resumen de fichajes del día para un empleado
     *
     * @return array{primera_entrada: string|null, ultima_salida: string|null, fichajes: array}
     */
    public function getResumenDia(int $empleadoId, string $fecha): array
    {
        $fichajes = $this->findByEmpleadoFecha($empleadoId, $fecha);

        $primeraEntrada = null;
        $ultimaSalida = null;

        foreach ($fichajes as $fichaje) {
            if ($fichaje->tipo === self::TIPO_ENTRADA && !$primeraEntrada) {
                $primeraEntrada = $fichaje->hora;
            }
            if ($fichaje->tipo === self::TIPO_SALIDA) {
                $ultimaSalida = $fichaje->hora;
            }
        }

        return [
            'primera_entrada' => $primeraEntrada,
            'ultima_salida' => $ultimaSalida,
            'fichajes' => $fichajes,
        ];
    }

    /**
     * Crea un nuevo fichaje
     *
     * @param array<string, mixed> $data
     * @return int
     */
    public function crearFichaje(array $data): int
    {
        $defaults = [
            'fecha' => date('Y-m-d'),
            'hora' => date('H:i:s'),
            'estado' => self::ESTADO_PENDIENTE,
            'incidencia_ubicacion' => 0,
            'incidencia_horario' => 0,
        ];

        $data = array_merge($defaults, $data);

        return $this->create($data);
    }

    /**
     * Valida un fichaje
     */
    public function validar(
        int $fichajeId,
        int $validadorId,
        bool $aprobar,
        ?string $horaCorregida = null,
        ?string $observacion = null
    ): bool {
        $estado = $aprobar ? self::ESTADO_VALIDADO : self::ESTADO_RECHAZADO;

        return $this->update($fichajeId, [
            'estado' => $estado,
            'validado_por' => $validadorId,
            'validado_fecha' => date('Y-m-d H:i:s'),
            'hora_corregida' => $horaCorregida,
            'observacion_validador' => $observacion,
        ]);
    }

    /**
     * Validación masiva de fichajes
     *
     * @param array<int> $fichajesIds
     * @return int Número de fichajes validados
     */
    public function validarMasivo(array $fichajesIds, int $validadorId, bool $aprobar): int
    {
        $estado = $aprobar ? self::ESTADO_VALIDADO : self::ESTADO_RECHAZADO;
        $procesados = 0;

        foreach ($fichajesIds as $id) {
            $affected = $this->db->update(
                $this->table,
                [
                    'estado' => $estado,
                    'validado_por' => $validadorId,
                    'validado_fecha' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                "id = ? AND estado = 'pendiente'",
                [$id]
            );
            $procesados += $affected;
        }

        return $procesados;
    }

    /**
     * Obtiene estadísticas de fichajes
     *
     * @return array<string, int>
     */
    public function getEstadisticas(): array
    {
        $hoy = date('Y-m-d');

        return [
            'pendientes_total' => (int)$this->db->fetchColumn(
                "SELECT COUNT(*) FROM fichajes WHERE estado = 'pendiente'"
            ),
            'pendientes_hoy' => (int)$this->db->fetchColumn(
                "SELECT COUNT(*) FROM fichajes WHERE estado = 'pendiente' AND fecha = ?",
                [$hoy]
            ),
            'fichados_hoy' => (int)$this->db->fetchColumn(
                "SELECT COUNT(DISTINCT empleado_id) FROM fichajes WHERE fecha = ? AND tipo = 'entrada'",
                [$hoy]
            ),
            'trabajando_ahora' => (int)$this->db->fetchColumn("
                SELECT COUNT(DISTINCT f1.empleado_id)
                FROM fichajes f1
                WHERE f1.fecha = ?
                AND f1.tipo = 'entrada'
                AND NOT EXISTS (
                    SELECT 1 FROM fichajes f2
                    WHERE f2.empleado_id = f1.empleado_id
                    AND f2.fecha = f1.fecha
                    AND f2.tipo = 'salida'
                    AND f2.hora > f1.hora
                )
            ", [$hoy]),
        ];
    }

    /**
     * Obtiene fichajes para informe
     *
     * @param string $fechaInicio
     * @param string $fechaFin
     * @param int|null $empleadoId
     * @param int|null $centroId
     * @return array<int, object>
     */
    public function getParaInforme(
        string $fechaInicio,
        string $fechaFin,
        ?int $empleadoId = null,
        ?int $centroId = null
    ): array {
        $sql = "
            SELECT f.*,
                   e.nif, e.nombre, e.apellido1, e.apellido2,
                   c.nombre as centro_nombre
            FROM fichajes f
            INNER JOIN empleados e ON f.empleado_id = e.id
            LEFT JOIN centros c ON f.centro_id = c.id
            WHERE f.fecha BETWEEN ? AND ?
            AND f.estado IN ('validado', 'auto_aprobado')
        ";
        $params = [$fechaInicio, $fechaFin];

        if ($empleadoId) {
            $sql .= " AND f.empleado_id = ?";
            $params[] = $empleadoId;
        }

        if ($centroId) {
            $sql .= " AND f.centro_id = ?";
            $params[] = $centroId;
        }

        $sql .= " ORDER BY e.apellido1, e.nombre, f.fecha, f.hora";

        return $this->db->fetchAll($sql, $params);
    }
}
