<?php

declare(strict_types=1);

namespace LMFichajes\Services;

/**
 * Servicio de Seguridad
 *
 * Funciones de seguridad: CSRF, sanitización, headers, etc.
 *
 * @package LMFichajes\Services
 */
class SecurityService
{
    private const CSRF_TOKEN_EXPIRY = 3600; // 1 hora
    private const CSRF_TOKEN_LENGTH = 32;

    /**
     * Genera un token CSRF
     */
    public function generarCsrfToken(): string
    {
        $token = bin2hex(random_bytes(self::CSRF_TOKEN_LENGTH));

        $_SESSION['csrf_token'] = $token;
        $_SESSION['csrf_token_time'] = time();

        return $token;
    }

    /**
     * Obtiene el token CSRF actual o genera uno nuevo
     */
    public function getCsrfToken(): string
    {
        if (!isset($_SESSION['csrf_token']) || $this->csrfTokenExpirado()) {
            return $this->generarCsrfToken();
        }

        return $_SESSION['csrf_token'];
    }

    /**
     * Genera campo HTML de CSRF
     */
    public function csrfCampo(): string
    {
        $token = $this->getCsrfToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
    }

    /**
     * Verifica el token CSRF
     */
    public function verificarCsrf(?string $token = null): bool
    {
        if ($token === null) {
            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        }

        if (empty($token) || !isset($_SESSION['csrf_token'])) {
            return false;
        }

        if ($this->csrfTokenExpirado()) {
            return false;
        }

        return hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * Regenera el token CSRF
     */
    public function regenerarCsrf(): string
    {
        return $this->generarCsrfToken();
    }

    /**
     * Verifica si el token CSRF ha expirado
     */
    private function csrfTokenExpirado(): bool
    {
        $tokenTime = $_SESSION['csrf_token_time'] ?? 0;
        return (time() - $tokenTime) > self::CSRF_TOKEN_EXPIRY;
    }

    /**
     * Sanitiza una cadena para prevenir XSS
     */
    public function sanitizar(?string $dato): string
    {
        if ($dato === null) {
            return '';
        }

        return htmlspecialchars(trim($dato), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitiza un array recursivamente
     *
     * @param array<string, mixed> $datos
     * @return array<string, mixed>
     */
    public function sanitizarArray(array $datos): array
    {
        $resultado = [];

        foreach ($datos as $clave => $valor) {
            $clave = $this->sanitizar((string)$clave);

            if (is_array($valor)) {
                $resultado[$clave] = $this->sanitizarArray($valor);
            } elseif (is_string($valor)) {
                $resultado[$clave] = $this->sanitizar($valor);
            } else {
                $resultado[$clave] = $valor;
            }
        }

        return $resultado;
    }

    /**
     * Valida y sanitiza un email
     */
    public function sanitizarEmail(?string $email): ?string
    {
        if ($email === null || $email === '') {
            return null;
        }

        $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    }

    /**
     * Valida y sanitiza un NIF/NIE
     */
    public function validarNif(string $nif): bool
    {
        $nif = strtoupper(trim($nif));

        // NIF español (8 números + letra)
        if (preg_match('/^[0-9]{8}[A-Z]$/', $nif)) {
            $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
            $numero = (int)substr($nif, 0, 8);
            $letraEsperada = $letras[$numero % 23];
            return $letraEsperada === $nif[8];
        }

        // NIE (X/Y/Z + 7 números + letra)
        if (preg_match('/^[XYZ][0-9]{7}[A-Z]$/', $nif)) {
            $reemplazo = ['X' => '0', 'Y' => '1', 'Z' => '2'];
            $nifConvertido = $reemplazo[$nif[0]] . substr($nif, 1, 7);
            $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
            $numero = (int)$nifConvertido;
            $letraEsperada = $letras[$numero % 23];
            return $letraEsperada === $nif[8];
        }

        return false;
    }

    /**
     * Establece headers de seguridad HTTP
     */
    public function establecerHeadersSeguridad(): void
    {
        // Prevenir clickjacking
        header('X-Frame-Options: SAMEORIGIN');

        // Prevenir MIME-type sniffing
        header('X-Content-Type-Options: nosniff');

        // Habilitar filtro XSS del navegador
        header('X-XSS-Protection: 1; mode=block');

        // Referrer Policy
        header('Referrer-Policy: strict-origin-when-cross-origin');

        // Content Security Policy
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self';");

        // Cache control para páginas sensibles
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');

        // HSTS (solo si es HTTPS)
        if ($this->esHttps()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        // Permissions Policy
        header("Permissions-Policy: geolocation=(self), microphone=(), camera=()");
    }

    /**
     * Verifica si la conexión es HTTPS
     */
    public function esHttps(): bool
    {
        // Verificar directamente
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            return true;
        }

        // Verificar puerto
        if (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) {
            return true;
        }

        // Verificar header de proxy
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
            return true;
        }

        return false;
    }

    /**
     * Obtiene la IP del cliente de forma segura
     */
    public function obtenerIpCliente(): string
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (str_contains($ip, ',')) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Genera un token aleatorio seguro
     */
    public function generarToken(int $longitud = 32): string
    {
        return bin2hex(random_bytes($longitud));
    }

    /**
     * Genera una contraseña aleatoria segura
     */
    public function generarPassword(int $longitud = 12): string
    {
        $lower = 'abcdefghijklmnopqrstuvwxyz';
        $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $digits = '0123456789';
        $special = '!@#$%^&*';

        // Garantizar al menos uno de cada tipo
        $password = $lower[random_int(0, strlen($lower) - 1)];
        $password .= $upper[random_int(0, strlen($upper) - 1)];
        $password .= $digits[random_int(0, strlen($digits) - 1)];
        $password .= $special[random_int(0, strlen($special) - 1)];

        // Completar con caracteres aleatorios
        $todos = $lower . $upper . $digits . $special;
        for ($i = 4; $i < $longitud; $i++) {
            $password .= $todos[random_int(0, strlen($todos) - 1)];
        }

        // Mezclar
        return str_shuffle($password);
    }

    /**
     * Hash de contraseña usando bcrypt
     */
    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }

    /**
     * Verifica una contraseña contra su hash
     */
    public function verificarPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Previene inyección de caracteres en logs
     */
    public function sanitizarParaLog(string $texto): string
    {
        return preg_replace('/[\r\n]/', '', $texto) ?? $texto;
    }

    /**
     * Valida un archivo subido
     *
     * @param array<string, mixed> $archivo $_FILES['nombre']
     * @param array<string> $tiposPermitidos MIME types permitidos
     * @param int $maxSize Tamaño máximo en bytes
     * @return array{valido: bool, error: string|null}
     */
    public function validarArchivoSubido(
        array $archivo,
        array $tiposPermitidos = [],
        int $maxSize = 5242880 // 5MB
    ): array {
        // Verificar errores de subida
        if ($archivo['error'] !== UPLOAD_ERR_OK) {
            $errores = [
                UPLOAD_ERR_INI_SIZE => 'El archivo excede el tamaño máximo permitido',
                UPLOAD_ERR_FORM_SIZE => 'El archivo excede el tamaño máximo del formulario',
                UPLOAD_ERR_PARTIAL => 'El archivo se subió parcialmente',
                UPLOAD_ERR_NO_FILE => 'No se subió ningún archivo',
                UPLOAD_ERR_NO_TMP_DIR => 'Error de configuración del servidor',
                UPLOAD_ERR_CANT_WRITE => 'Error al escribir el archivo',
            ];

            return [
                'valido' => false,
                'error' => $errores[$archivo['error']] ?? 'Error desconocido',
            ];
        }

        // Verificar tamaño
        if ($archivo['size'] > $maxSize) {
            return [
                'valido' => false,
                'error' => 'El archivo excede el tamaño máximo permitido',
            ];
        }

        // Verificar tipo MIME
        if (!empty($tiposPermitidos)) {
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($archivo['tmp_name']);

            if (!in_array($mimeType, $tiposPermitidos, true)) {
                return [
                    'valido' => false,
                    'error' => 'Tipo de archivo no permitido',
                ];
            }
        }

        return ['valido' => true, 'error' => null];
    }
}
