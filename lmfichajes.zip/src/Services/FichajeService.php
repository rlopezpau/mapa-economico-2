<?php

declare(strict_types=1);

namespace LMFichajes\Services;

use LMFichajes\Core\Database;
use LMFichajes\Repositories\FichajeRepository;
use LMFichajes\Repositories\EmpleadoRepository;
use LMFichajes\DTO\FichajeResult;
use InvalidArgumentException;

/**
 * Servicio de Fichajes
 *
 * Lógica de negocio para el registro y gestión de fichajes.
 *
 * @package LMFichajes\Services
 */
class FichajeService
{
    private const TOLERANCIA_UBICACION_METROS = 100;
    private const TOLERANCIA_HORARIO_MINUTOS = 15;

    private Database $db;
    private FichajeRepository $fichajeRepo;
    private EmpleadoRepository $empleadoRepo;
    private AuditService $auditService;

    public function __construct(
        Database $db,
        FichajeRepository $fichajeRepo,
        EmpleadoRepository $empleadoRepo,
        AuditService $auditService
    ) {
        $this->db = $db;
        $this->fichajeRepo = $fichajeRepo;
        $this->empleadoRepo = $empleadoRepo;
        $this->auditService = $auditService;
    }

    /**
     * Registra un fichaje
     *
     * @param int $empleadoId
     * @param string $tipo entrada|salida|pausa_inicio|pausa_fin
     * @param array<string, mixed> $datos centro_id, modo, latitud, longitud, observacion
     * @return FichajeResult
     */
    public function registrar(int $empleadoId, string $tipo, array $datos = []): FichajeResult
    {
        // Validar tipo
        $tiposValidos = [
            FichajeRepository::TIPO_ENTRADA,
            FichajeRepository::TIPO_SALIDA,
            FichajeRepository::TIPO_PAUSA_INICIO,
            FichajeRepository::TIPO_PAUSA_FIN,
        ];

        if (!in_array($tipo, $tiposValidos, true)) {
            throw new InvalidArgumentException("Tipo de fichaje no válido: {$tipo}");
        }

        // Obtener empleado
        $empleado = $this->empleadoRepo->findWithRelations($empleadoId);
        if (!$empleado) {
            return new FichajeResult(
                success: false,
                error: 'Empleado no encontrado'
            );
        }

        // Validar secuencia de fichajes
        $validacionSecuencia = $this->validarSecuencia($empleadoId, $tipo);
        if (!$validacionSecuencia['valido']) {
            return new FichajeResult(
                success: false,
                error: $validacionSecuencia['mensaje']
            );
        }

        // Preparar datos del fichaje
        $incidencias = [];
        $incidenciaUbicacion = false;
        $incidenciaHorario = false;
        $estado = FichajeRepository::ESTADO_PENDIENTE;

        // Verificar ubicación si se proporciona
        if (isset($datos['latitud'], $datos['longitud']) && $datos['centro_id']) {
            $verificacionUbicacion = $this->verificarUbicacion(
                (float)$datos['latitud'],
                (float)$datos['longitud'],
                (int)$datos['centro_id']
            );

            if (!$verificacionUbicacion['dentro_rango']) {
                $incidenciaUbicacion = true;
                $incidencias[] = 'Fuera del rango del centro de trabajo';
            }
        }

        // Verificar horario si el empleado tiene horario asignado
        if ($empleado->horario_id && $tipo === FichajeRepository::TIPO_ENTRADA) {
            $verificacionHorario = $this->verificarHorario($empleado);
            if (!$verificacionHorario['en_horario']) {
                $incidenciaHorario = true;
                $incidencias[] = $verificacionHorario['mensaje'];
            }
        }

        // Auto-aprobar si no hay incidencias y la configuración lo permite
        if (!$incidenciaUbicacion && !$incidenciaHorario) {
            $autoAprobar = $this->obtenerConfiguracion('auto_aprobar_fichajes', true);
            if ($autoAprobar) {
                $estado = FichajeRepository::ESTADO_AUTO_APROBADO;
            }
        }

        // Crear el fichaje
        $fichajeData = [
            'empleado_id' => $empleadoId,
            'centro_id' => $datos['centro_id'] ?? null,
            'tipo' => $tipo,
            'fecha' => date('Y-m-d'),
            'hora' => date('H:i:s'),
            'modo' => $datos['modo'] ?? 'presencial',
            'latitud' => $datos['latitud'] ?? null,
            'longitud' => $datos['longitud'] ?? null,
            'observacion' => $datos['observacion'] ?? null,
            'estado' => $estado,
            'incidencia_ubicacion' => $incidenciaUbicacion ? 1 : 0,
            'incidencia_horario' => $incidenciaHorario ? 1 : 0,
            'ip_registro' => $datos['ip'] ?? null,
            'user_agent' => $datos['user_agent'] ?? null,
        ];

        try {
            $this->db->beginTransaction();

            $fichajeId = $this->fichajeRepo->create($fichajeData);

            // Actualizar resumen diario si el fichaje está aprobado
            if ($estado === FichajeRepository::ESTADO_AUTO_APROBADO) {
                $this->actualizarResumenDiario($empleadoId, date('Y-m-d'));
            }

            $this->db->commit();

            // Registrar en auditoría
            $this->auditService->log('fichaje_registrado', $empleadoId, [
                'fichaje_id' => $fichajeId,
                'tipo' => $tipo,
                'estado' => $estado,
                'incidencias' => $incidencias,
            ]);

            $mensaje = $this->getMensajeTipo($tipo);
            if (!empty($incidencias)) {
                $mensaje .= ' (con incidencias: ' . implode(', ', $incidencias) . ')';
            }

            return new FichajeResult(
                success: true,
                fichajeId: $fichajeId,
                message: $mensaje,
                incidencias: $incidencias,
                estado: $estado
            );

        } catch (\Throwable $e) {
            $this->db->rollBack();
            error_log('Error al registrar fichaje: ' . $e->getMessage());

            return new FichajeResult(
                success: false,
                error: 'Error al registrar el fichaje'
            );
        }
    }

    /**
     * Valida la secuencia de fichajes
     *
     * @return array{valido: bool, mensaje: string}
     */
    private function validarSecuencia(int $empleadoId, string $tipo): array
    {
        $hoy = date('Y-m-d');
        $ultimoFichaje = $this->fichajeRepo->findUltimoDelDia($empleadoId, $hoy);

        // Si no hay fichajes previos
        if (!$ultimoFichaje) {
            if ($tipo !== FichajeRepository::TIPO_ENTRADA) {
                return [
                    'valido' => false,
                    'mensaje' => 'Debe fichar entrada primero',
                ];
            }
            return ['valido' => true, 'mensaje' => ''];
        }

        // Validar secuencia según el último fichaje
        $secuenciasValidas = [
            FichajeRepository::TIPO_ENTRADA => [
                FichajeRepository::TIPO_PAUSA_INICIO,
                FichajeRepository::TIPO_SALIDA,
            ],
            FichajeRepository::TIPO_SALIDA => [
                FichajeRepository::TIPO_ENTRADA,
            ],
            FichajeRepository::TIPO_PAUSA_INICIO => [
                FichajeRepository::TIPO_PAUSA_FIN,
                FichajeRepository::TIPO_SALIDA,
            ],
            FichajeRepository::TIPO_PAUSA_FIN => [
                FichajeRepository::TIPO_PAUSA_INICIO,
                FichajeRepository::TIPO_SALIDA,
            ],
        ];

        $siguientesValidos = $secuenciasValidas[$ultimoFichaje->tipo] ?? [];

        if (!in_array($tipo, $siguientesValidos, true)) {
            return [
                'valido' => false,
                'mensaje' => "No puede fichar {$tipo} después de {$ultimoFichaje->tipo}",
            ];
        }

        return ['valido' => true, 'mensaje' => ''];
    }

    /**
     * Verifica si las coordenadas están dentro del rango del centro
     *
     * @return array{dentro_rango: bool, distancia: float}
     */
    private function verificarUbicacion(float $lat, float $lon, int $centroId): array
    {
        $centro = $this->db->fetchOne(
            "SELECT coordenadas, radio_metros FROM centros WHERE id = ?",
            [$centroId]
        );

        if (!$centro || !$centro->coordenadas) {
            return ['dentro_rango' => true, 'distancia' => 0];
        }

        // Parsear coordenadas del centro (formato: "lat,lon")
        $coords = explode(',', $centro->coordenadas);
        if (count($coords) !== 2) {
            return ['dentro_rango' => true, 'distancia' => 0];
        }

        $centroLat = (float)trim($coords[0]);
        $centroLon = (float)trim($coords[1]);
        $radioMetros = (int)($centro->radio_metros ?: self::TOLERANCIA_UBICACION_METROS);

        // Calcular distancia usando fórmula de Haversine
        $distancia = $this->calcularDistancia($lat, $lon, $centroLat, $centroLon);

        return [
            'dentro_rango' => $distancia <= $radioMetros,
            'distancia' => $distancia,
        ];
    }

    /**
     * Calcula la distancia en metros entre dos coordenadas
     */
    private function calcularDistancia(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        $radioTierra = 6371000; // metros

        $lat1Rad = deg2rad($lat1);
        $lat2Rad = deg2rad($lat2);
        $deltaLat = deg2rad($lat2 - $lat1);
        $deltaLon = deg2rad($lon2 - $lon1);

        $a = sin($deltaLat / 2) ** 2 +
             cos($lat1Rad) * cos($lat2Rad) * sin($deltaLon / 2) ** 2;

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $radioTierra * $c;
    }

    /**
     * Verifica si la entrada está dentro del horario
     *
     * @return array{en_horario: bool, mensaje: string}
     */
    private function verificarHorario(object $empleado): array
    {
        if (!$empleado->horario) {
            return ['en_horario' => true, 'mensaje' => ''];
        }

        $horario = $empleado->horario;
        $horaActual = date('H:i:s');
        $diaSemana = (int)date('N'); // 1=Lunes, 7=Domingo

        // Verificar si hoy es laborable
        $diaHorario = $this->db->fetchOne(
            "SELECT * FROM horarios_dias WHERE horario_id = ? AND dia_semana = ?",
            [$horario->id, $diaSemana]
        );

        if (!$diaHorario || !$diaHorario->es_laborable) {
            return [
                'en_horario' => false,
                'mensaje' => 'Hoy no es día laborable según su horario',
            ];
        }

        // Verificar hora de entrada con tolerancia
        if ($horario->hora_entrada) {
            $horaEntradaConTolerancia = date(
                'H:i:s',
                strtotime($horario->hora_entrada) + (self::TOLERANCIA_HORARIO_MINUTOS * 60)
            );

            if ($horaActual > $horaEntradaConTolerancia) {
                return [
                    'en_horario' => false,
                    'mensaje' => 'Entrada fuera de horario (tolerancia: ' . self::TOLERANCIA_HORARIO_MINUTOS . ' min)',
                ];
            }
        }

        return ['en_horario' => true, 'mensaje' => ''];
    }

    /**
     * Actualiza el resumen diario de horas
     */
    public function actualizarResumenDiario(int $empleadoId, string $fecha): void
    {
        $resumen = $this->fichajeRepo->getResumenDia($empleadoId, $fecha);

        if (!$resumen['primera_entrada'] || !$resumen['ultima_salida']) {
            return;
        }

        // Calcular horas trabajadas
        $entrada = new \DateTime($resumen['primera_entrada']);
        $salida = new \DateTime($resumen['ultima_salida']);
        $diff = $entrada->diff($salida);

        $minutosTrabajados = ($diff->h * 60) + $diff->i;

        // Restar pausas
        $pausas = $this->calcularMinutosPausa($empleadoId, $fecha);
        $minutosTrabajados -= $pausas;

        // Insertar o actualizar resumen
        $existe = $this->db->fetchOne(
            "SELECT id FROM resumen_diario WHERE empleado_id = ? AND fecha = ?",
            [$empleadoId, $fecha]
        );

        if ($existe) {
            $this->db->update(
                'resumen_diario',
                [
                    'primera_entrada' => $resumen['primera_entrada'],
                    'ultima_salida' => $resumen['ultima_salida'],
                    'minutos_trabajados' => $minutosTrabajados,
                    'minutos_pausa' => $pausas,
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                'id = ?',
                [$existe->id]
            );
        } else {
            $this->db->insert('resumen_diario', [
                'empleado_id' => $empleadoId,
                'fecha' => $fecha,
                'primera_entrada' => $resumen['primera_entrada'],
                'ultima_salida' => $resumen['ultima_salida'],
                'minutos_trabajados' => $minutosTrabajados,
                'minutos_pausa' => $pausas,
            ]);
        }
    }

    /**
     * Calcula los minutos de pausa de un día
     */
    private function calcularMinutosPausa(int $empleadoId, string $fecha): int
    {
        $fichajes = $this->fichajeRepo->findByEmpleadoFecha($empleadoId, $fecha);

        $minutosPausa = 0;
        $inicioPausa = null;

        foreach ($fichajes as $fichaje) {
            if ($fichaje->tipo === FichajeRepository::TIPO_PAUSA_INICIO) {
                $inicioPausa = new \DateTime($fichaje->hora);
            } elseif ($fichaje->tipo === FichajeRepository::TIPO_PAUSA_FIN && $inicioPausa) {
                $finPausa = new \DateTime($fichaje->hora);
                $diff = $inicioPausa->diff($finPausa);
                $minutosPausa += ($diff->h * 60) + $diff->i;
                $inicioPausa = null;
            }
        }

        return $minutosPausa;
    }

    /**
     * Obtiene mensaje según tipo de fichaje
     */
    private function getMensajeTipo(string $tipo): string
    {
        return match ($tipo) {
            FichajeRepository::TIPO_ENTRADA => 'Entrada registrada correctamente',
            FichajeRepository::TIPO_SALIDA => 'Salida registrada correctamente',
            FichajeRepository::TIPO_PAUSA_INICIO => 'Pausa iniciada',
            FichajeRepository::TIPO_PAUSA_FIN => 'Pausa finalizada',
            default => 'Fichaje registrado',
        };
    }

    /**
     * Obtiene configuración del sistema
     */
    private function obtenerConfiguracion(string $clave, mixed $default = null): mixed
    {
        $config = $this->db->fetchOne(
            "SELECT valor FROM configuracion WHERE clave = ?",
            [$clave]
        );

        return $config ? $config->valor : $default;
    }

    /**
     * Obtiene el estado actual del empleado (trabajando, en_pausa, sin_fichar)
     */
    public function getEstadoActual(int $empleadoId): string
    {
        $ultimoFichaje = $this->fichajeRepo->findUltimoDelDia($empleadoId, date('Y-m-d'));

        if (!$ultimoFichaje) {
            return 'sin_fichar';
        }

        return match ($ultimoFichaje->tipo) {
            FichajeRepository::TIPO_ENTRADA, FichajeRepository::TIPO_PAUSA_FIN => 'trabajando',
            FichajeRepository::TIPO_PAUSA_INICIO => 'en_pausa',
            FichajeRepository::TIPO_SALIDA => 'sin_fichar',
            default => 'sin_fichar',
        };
    }
}
