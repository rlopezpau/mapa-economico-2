<?php

declare(strict_types=1);

namespace LMFichajes\Services;

use LMFichajes\Core\Database;
use LMFichajes\Repositories\EmpleadoRepository;
use LMFichajes\DTO\LoginResult;
use RuntimeException;

/**
 * Servicio de Autenticación
 *
 * Maneja login, logout, verificación de sesión y seguridad.
 *
 * @package LMFichajes\Services
 */
class AuthService
{
    private const MAX_LOGIN_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 30;
    private const ATTEMPT_WINDOW_MINUTES = 15;
    private const SESSION_TIMEOUT_SECONDS = 1800; // 30 minutos
    private const PASSWORD_EXPIRY_DAYS = 90;

    private Database $db;
    private EmpleadoRepository $empleadoRepo;
    private AuditService $auditService;

    public function __construct(
        Database $db,
        EmpleadoRepository $empleadoRepo,
        AuditService $auditService
    ) {
        $this->db = $db;
        $this->empleadoRepo = $empleadoRepo;
        $this->auditService = $auditService;
    }

    /**
     * Intenta autenticar un usuario
     *
     * @param string $nif NIF del usuario
     * @param string $password Contraseña en texto plano
     * @param string $ip IP del cliente
     * @return LoginResult Resultado del login
     */
    public function login(string $nif, string $password, string $ip): LoginResult
    {
        // Verificar rate limiting
        if ($this->isLockedOut($nif, $ip)) {
            $this->auditService->log('login_bloqueado', null, [
                'nif' => $nif,
                'ip' => $ip,
                'motivo' => 'Demasiados intentos fallidos',
            ]);

            return new LoginResult(
                success: false,
                error: 'Cuenta bloqueada temporalmente. Intente de nuevo en ' . self::LOCKOUT_MINUTES . ' minutos.',
                errorCode: 'ACCOUNT_LOCKED'
            );
        }

        // Buscar empleado
        $empleado = $this->empleadoRepo->findByNif($nif);

        if (!$empleado) {
            $this->registrarIntentoFallido($nif, $ip);
            return new LoginResult(
                success: false,
                error: 'Credenciales incorrectas',
                errorCode: 'INVALID_CREDENTIALS'
            );
        }

        // Verificar que esté activo
        if (!$empleado->activo) {
            $this->auditService->log('login_usuario_inactivo', $empleado->id, ['ip' => $ip]);
            return new LoginResult(
                success: false,
                error: 'Su cuenta está desactivada. Contacte con el administrador.',
                errorCode: 'ACCOUNT_DISABLED'
            );
        }

        // Verificar contraseña
        if (!password_verify($password, $empleado->password)) {
            $this->registrarIntentoFallido($nif, $ip);
            return new LoginResult(
                success: false,
                error: 'Credenciales incorrectas',
                errorCode: 'INVALID_CREDENTIALS'
            );
        }

        // Limpiar intentos fallidos
        $this->limpiarIntentosFallidos($nif, $ip);

        // Verificar MFA
        if ($empleado->mfa_activo) {
            return new LoginResult(
                success: true,
                requiresMfa: true,
                empleadoId: $empleado->id
            );
        }

        // Login exitoso
        return $this->completarLogin($empleado, $ip);
    }

    /**
     * Verifica código MFA
     */
    public function verificarMfa(int $empleadoId, string $codigo, string $ip): LoginResult
    {
        $empleado = $this->empleadoRepo->find($empleadoId);

        if (!$empleado || !$empleado->mfa_activo) {
            return new LoginResult(
                success: false,
                error: 'Error de verificación',
                errorCode: 'MFA_ERROR'
            );
        }

        // Verificar código TOTP
        if (!$this->verificarCodigoTotp($empleado->mfa_secret, $codigo)) {
            // Verificar código de respaldo
            if (!$this->verificarCodigoRespaldo($empleadoId, $codigo)) {
                $this->auditService->log('mfa_fallido', $empleadoId, ['ip' => $ip]);
                return new LoginResult(
                    success: false,
                    error: 'Código incorrecto',
                    errorCode: 'INVALID_MFA_CODE'
                );
            }
        }

        return $this->completarLogin($empleado, $ip);
    }

    /**
     * Completa el proceso de login creando la sesión
     */
    private function completarLogin(object $empleado, string $ip): LoginResult
    {
        // Regenerar ID de sesión
        $this->regenerarSesion();

        // Establecer datos de sesión
        $_SESSION['usuario_id'] = $empleado->id;
        $_SESSION['usuario_nif'] = $empleado->nif;
        $_SESSION['usuario_rol'] = $empleado->rol;
        $_SESSION['usuario_nombre'] = $empleado->nombre . ' ' . $empleado->apellido1;
        $_SESSION['ip_login'] = $ip;
        $_SESSION['login_time'] = time();
        $_SESSION['ultimo_acceso'] = time();

        // Actualizar último acceso en BD
        $this->empleadoRepo->updateUltimoAcceso($empleado->id);

        // Registrar en auditoría
        $this->auditService->log('login_exitoso', $empleado->id, ['ip' => $ip]);

        // Verificar si debe cambiar contraseña
        $debeCambiarPassword = $this->debeCambiarPassword($empleado);

        return new LoginResult(
            success: true,
            empleadoId: $empleado->id,
            empleado: $empleado,
            requiresPasswordChange: $debeCambiarPassword
        );
    }

    /**
     * Cierra la sesión del usuario
     */
    public function logout(): void
    {
        $usuarioId = $_SESSION['usuario_id'] ?? null;

        if ($usuarioId) {
            $this->auditService->log('logout', $usuarioId);
        }

        // Destruir sesión
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    /**
     * Verifica si la sesión actual es válida
     */
    public function verificarSesion(): bool
    {
        if (!isset($_SESSION['usuario_id'])) {
            return false;
        }

        // Verificar timeout
        $ultimoAcceso = $_SESSION['ultimo_acceso'] ?? 0;
        if (time() - $ultimoAcceso > self::SESSION_TIMEOUT_SECONDS) {
            $this->logout();
            return false;
        }

        // Actualizar último acceso
        $_SESSION['ultimo_acceso'] = time();

        return true;
    }

    /**
     * Obtiene el usuario actual de la sesión
     */
    public function getUsuarioActual(): ?object
    {
        if (!$this->verificarSesion()) {
            return null;
        }

        $usuarioId = $_SESSION['usuario_id'] ?? null;
        if (!$usuarioId) {
            return null;
        }

        return $this->empleadoRepo->find($usuarioId);
    }

    /**
     * Verifica si tiene un rol específico o superior
     */
    public function tieneRol(string ...$roles): bool
    {
        $rolActual = $_SESSION['usuario_rol'] ?? null;
        return $rolActual && in_array($rolActual, $roles, true);
    }

    /**
     * Verifica si es administrador
     */
    public function esAdmin(): bool
    {
        return $this->tieneRol('admin', 'superadmin');
    }

    /**
     * Verifica si la cuenta está bloqueada por intentos fallidos
     */
    private function isLockedOut(string $nif, string $ip): bool
    {
        $tiempoVentana = date('Y-m-d H:i:s', strtotime("-" . self::ATTEMPT_WINDOW_MINUTES . " minutes"));

        $intentos = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM intentos_login
             WHERE (nif = ? OR ip = ?) AND fecha_intento > ? AND exitoso = 0",
            [$nif, $ip, $tiempoVentana]
        );

        return $intentos >= self::MAX_LOGIN_ATTEMPTS;
    }

    /**
     * Registra un intento de login fallido
     */
    private function registrarIntentoFallido(string $nif, string $ip): void
    {
        $this->db->insert('intentos_login', [
            'nif' => $nif,
            'ip' => $ip,
            'fecha_intento' => date('Y-m-d H:i:s'),
            'exitoso' => 0,
        ]);
    }

    /**
     * Limpia los intentos fallidos después de login exitoso
     */
    private function limpiarIntentosFallidos(string $nif, string $ip): void
    {
        $this->db->delete('intentos_login', 'nif = ? OR ip = ?', [$nif, $ip]);
    }

    /**
     * Verifica si el usuario debe cambiar su contraseña
     */
    private function debeCambiarPassword(object $empleado): bool
    {
        // Flag explícito
        if ($empleado->debe_cambiar_password ?? false) {
            return true;
        }

        // Contraseña expirada
        if ($empleado->password_changed_at) {
            $diasDesdeUltimoCambio = (time() - strtotime($empleado->password_changed_at)) / 86400;
            if ($diasDesdeUltimoCambio > self::PASSWORD_EXPIRY_DAYS) {
                return true;
            }
        }

        return false;
    }

    /**
     * Verifica un código TOTP
     */
    private function verificarCodigoTotp(string $secret, string $codigo): bool
    {
        // Implementación simplificada de TOTP
        $periodo = 30;
        $digitos = 6;
        $t = floor(time() / $periodo);

        // Verificar ventana de -1, 0, +1 periodos
        for ($i = -1; $i <= 1; $i++) {
            $codigoEsperado = $this->generarCodigoTotp($secret, $t + $i, $digitos);
            if (hash_equals($codigoEsperado, $codigo)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Genera un código TOTP
     */
    private function generarCodigoTotp(string $secret, int $counter, int $digitos): string
    {
        $secretDecoded = base64_decode($secret);
        $time = pack('N*', 0) . pack('N*', $counter);
        $hash = hash_hmac('sha1', $time, $secretDecoded, true);
        $offset = ord(substr($hash, -1)) & 0x0F;
        $code = (
            ((ord($hash[$offset]) & 0x7F) << 24) |
            ((ord($hash[$offset + 1]) & 0xFF) << 16) |
            ((ord($hash[$offset + 2]) & 0xFF) << 8) |
            (ord($hash[$offset + 3]) & 0xFF)
        ) % pow(10, $digitos);

        return str_pad((string)$code, $digitos, '0', STR_PAD_LEFT);
    }

    /**
     * Verifica un código de respaldo
     */
    private function verificarCodigoRespaldo(int $empleadoId, string $codigo): bool
    {
        $codigoHash = hash('sha256', $codigo);

        $codigoRespaldo = $this->db->fetchOne(
            "SELECT id FROM codigos_respaldo_mfa
             WHERE empleado_id = ? AND codigo_hash = ? AND usado = 0",
            [$empleadoId, $codigoHash]
        );

        if ($codigoRespaldo) {
            // Marcar como usado
            $this->db->update(
                'codigos_respaldo_mfa',
                ['usado' => 1, 'fecha_uso' => date('Y-m-d H:i:s')],
                'id = ?',
                [$codigoRespaldo->id]
            );
            return true;
        }

        return false;
    }

    /**
     * Regenera el ID de sesión de forma segura
     */
    private function regenerarSesion(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    /**
     * Hash de contraseña
     */
    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }

    /**
     * Genera contraseña aleatoria
     */
    public function generarPassword(int $longitud = 12): string
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        $password = '';

        for ($i = 0; $i < $longitud; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return $password;
    }

    /**
     * Valida política de contraseña
     *
     * @return array<string> Lista de errores (vacío si válida)
     */
    public function validarPoliticaPassword(string $password): array
    {
        $errores = [];

        if (strlen($password) < 8) {
            $errores[] = 'La contraseña debe tener al menos 8 caracteres';
        }

        if (!preg_match('/[A-Z]/', $password)) {
            $errores[] = 'La contraseña debe contener al menos una mayúscula';
        }

        if (!preg_match('/[a-z]/', $password)) {
            $errores[] = 'La contraseña debe contener al menos una minúscula';
        }

        if (!preg_match('/[0-9]/', $password)) {
            $errores[] = 'La contraseña debe contener al menos un número';
        }

        return $errores;
    }
}
