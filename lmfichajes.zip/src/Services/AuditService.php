<?php

declare(strict_types=1);

namespace LMFichajes\Services;

use LMFichajes\Core\Database;

/**
 * Servicio de Auditoría
 *
 * Registra todas las acciones relevantes del sistema según ENS.
 *
 * @package LMFichajes\Services
 */
class AuditService
{
    private Database $db;

    // Categorías de acciones
    public const CATEGORIA_AUTH = 'autenticacion';
    public const CATEGORIA_FICHAJE = 'fichaje';
    public const CATEGORIA_EMPLEADO = 'empleado';
    public const CATEGORIA_CENTRO = 'centro';
    public const CATEGORIA_CONFIG = 'configuracion';
    public const CATEGORIA_RGPD = 'rgpd';
    public const CATEGORIA_SISTEMA = 'sistema';

    // Niveles de severidad
    public const NIVEL_INFO = 'info';
    public const NIVEL_WARNING = 'warning';
    public const NIVEL_ERROR = 'error';
    public const NIVEL_CRITICAL = 'critical';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Registra una acción en el log de auditoría
     *
     * @param string $accion Nombre de la acción
     * @param int|null $usuarioId ID del usuario (null si es sistema)
     * @param array<string, mixed> $datos Datos adicionales
     * @param string $nivel Nivel de severidad
     * @param string|null $categoria Categoría de la acción
     * @return int ID del registro de auditoría
     */
    public function log(
        string $accion,
        ?int $usuarioId = null,
        array $datos = [],
        string $nivel = self::NIVEL_INFO,
        ?string $categoria = null
    ): int {
        // Autodetectar categoría si no se proporciona
        if ($categoria === null) {
            $categoria = $this->detectarCategoria($accion);
        }

        // Obtener usuario actual si no se proporciona
        if ($usuarioId === null && isset($_SESSION['usuario_id'])) {
            $usuarioId = (int)$_SESSION['usuario_id'];
        }

        // Obtener información del contexto
        $ip = $this->obtenerIpCliente();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

        // Preparar datos
        $datosJson = !empty($datos) ? json_encode($datos, JSON_UNESCAPED_UNICODE) : null;

        return $this->db->insert('audit_log', [
            'fecha' => date('Y-m-d H:i:s'),
            'usuario_id' => $usuarioId,
            'accion' => $accion,
            'categoria' => $categoria,
            'nivel' => $nivel,
            'ip' => $ip,
            'user_agent' => $userAgent,
            'datos' => $datosJson,
            'url' => $_SERVER['REQUEST_URI'] ?? null,
            'metodo' => $_SERVER['REQUEST_METHOD'] ?? null,
        ]);
    }

    /**
     * Registra un error
     */
    public function logError(
        string $accion,
        string $mensaje,
        ?int $usuarioId = null,
        array $datos = []
    ): int {
        $datos['error_mensaje'] = $mensaje;
        return $this->log($accion, $usuarioId, $datos, self::NIVEL_ERROR);
    }

    /**
     * Registra un acceso a datos RGPD
     */
    public function logAccesoRgpd(
        int $empleadoId,
        string $tipoAcceso,
        ?int $solicitadoPor = null
    ): int {
        return $this->log(
            "rgpd_{$tipoAcceso}",
            $solicitadoPor,
            ['empleado_afectado' => $empleadoId],
            self::NIVEL_INFO,
            self::CATEGORIA_RGPD
        );
    }

    /**
     * Registra un cambio de configuración
     */
    public function logCambioConfig(
        string $clave,
        mixed $valorAnterior,
        mixed $valorNuevo,
        ?int $usuarioId = null
    ): int {
        return $this->log(
            'configuracion_modificada',
            $usuarioId,
            [
                'clave' => $clave,
                'valor_anterior' => $valorAnterior,
                'valor_nuevo' => $valorNuevo,
            ],
            self::NIVEL_WARNING,
            self::CATEGORIA_CONFIG
        );
    }

    /**
     * Obtiene registros de auditoría con filtros
     *
     * @param array<string, mixed> $filtros
     * @param int $limite
     * @param int $offset
     * @return array{registros: array, total: int}
     */
    public function obtenerRegistros(array $filtros = [], int $limite = 50, int $offset = 0): array
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filtros['fecha_desde'])) {
            $where[] = "fecha >= ?";
            $params[] = $filtros['fecha_desde'] . ' 00:00:00';
        }

        if (!empty($filtros['fecha_hasta'])) {
            $where[] = "fecha <= ?";
            $params[] = $filtros['fecha_hasta'] . ' 23:59:59';
        }

        if (!empty($filtros['usuario_id'])) {
            $where[] = "usuario_id = ?";
            $params[] = $filtros['usuario_id'];
        }

        if (!empty($filtros['categoria'])) {
            $where[] = "categoria = ?";
            $params[] = $filtros['categoria'];
        }

        if (!empty($filtros['nivel'])) {
            $where[] = "nivel = ?";
            $params[] = $filtros['nivel'];
        }

        if (!empty($filtros['accion'])) {
            $where[] = "accion LIKE ?";
            $params[] = '%' . $filtros['accion'] . '%';
        }

        if (!empty($filtros['ip'])) {
            $where[] = "ip = ?";
            $params[] = $filtros['ip'];
        }

        $whereClause = implode(' AND ', $where);

        // Contar total
        $total = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM audit_log WHERE {$whereClause}",
            $params
        );

        // Obtener registros
        $registros = $this->db->fetchAll("
            SELECT a.*,
                   e.nombre, e.apellido1, e.nif
            FROM audit_log a
            LEFT JOIN empleados e ON a.usuario_id = e.id
            WHERE {$whereClause}
            ORDER BY a.fecha DESC
            LIMIT {$limite} OFFSET {$offset}
        ", $params);

        return [
            'registros' => $registros,
            'total' => $total,
        ];
    }

    /**
     * Obtiene resumen de actividad reciente
     *
     * @param int $dias Número de días hacia atrás
     * @return array<string, mixed>
     */
    public function obtenerResumenActividad(int $dias = 7): array
    {
        $fechaInicio = date('Y-m-d', strtotime("-{$dias} days"));

        // Acciones por categoría
        $porCategoria = $this->db->fetchAll("
            SELECT categoria, COUNT(*) as total
            FROM audit_log
            WHERE fecha >= ?
            GROUP BY categoria
            ORDER BY total DESC
        ", [$fechaInicio . ' 00:00:00']);

        // Errores recientes
        $errores = $this->db->fetchAll("
            SELECT * FROM audit_log
            WHERE nivel IN ('error', 'critical')
            AND fecha >= ?
            ORDER BY fecha DESC
            LIMIT 10
        ", [$fechaInicio . ' 00:00:00']);

        // Logins fallidos
        $loginsFallidos = (int)$this->db->fetchColumn("
            SELECT COUNT(*)
            FROM audit_log
            WHERE accion LIKE 'login_%' AND accion != 'login_exitoso'
            AND fecha >= ?
        ", [$fechaInicio . ' 00:00:00']);

        // Actividad por hora del día
        $porHora = $this->db->fetchAll("
            SELECT HOUR(fecha) as hora, COUNT(*) as total
            FROM audit_log
            WHERE fecha >= ?
            GROUP BY HOUR(fecha)
            ORDER BY hora
        ", [$fechaInicio . ' 00:00:00']);

        return [
            'por_categoria' => $porCategoria,
            'errores_recientes' => $errores,
            'logins_fallidos' => $loginsFallidos,
            'por_hora' => $porHora,
        ];
    }

    /**
     * Exporta registros de auditoría para cumplimiento
     *
     * @param string $fechaInicio
     * @param string $fechaFin
     * @return array<int, object>
     */
    public function exportarParaCumplimiento(string $fechaInicio, string $fechaFin): array
    {
        return $this->db->fetchAll("
            SELECT
                a.id,
                a.fecha,
                a.accion,
                a.categoria,
                a.nivel,
                a.ip,
                a.url,
                a.metodo,
                a.datos,
                e.nif as usuario_nif,
                CONCAT(e.nombre, ' ', e.apellido1) as usuario_nombre
            FROM audit_log a
            LEFT JOIN empleados e ON a.usuario_id = e.id
            WHERE a.fecha BETWEEN ? AND ?
            ORDER BY a.fecha ASC
        ", [$fechaInicio . ' 00:00:00', $fechaFin . ' 23:59:59']);
    }

    /**
     * Limpia registros antiguos (para mantenimiento)
     *
     * @param int $diasRetener Días a retener
     * @return int Registros eliminados
     */
    public function limpiarAntiguos(int $diasRetener = 365): int
    {
        $fechaLimite = date('Y-m-d', strtotime("-{$diasRetener} days"));

        // Registrar la limpieza antes de ejecutarla
        $this->log('audit_limpieza_iniciada', null, [
            'dias_retener' => $diasRetener,
            'fecha_limite' => $fechaLimite,
        ], self::NIVEL_WARNING, self::CATEGORIA_SISTEMA);

        $eliminados = $this->db->delete(
            'audit_log',
            'fecha < ? AND nivel NOT IN (?, ?)',
            [$fechaLimite . ' 00:00:00', self::NIVEL_ERROR, self::NIVEL_CRITICAL]
        );

        return $eliminados;
    }

    /**
     * Detecta la categoría automáticamente según la acción
     */
    private function detectarCategoria(string $accion): string
    {
        $prefijos = [
            'login' => self::CATEGORIA_AUTH,
            'logout' => self::CATEGORIA_AUTH,
            'mfa' => self::CATEGORIA_AUTH,
            'password' => self::CATEGORIA_AUTH,
            'fichaje' => self::CATEGORIA_FICHAJE,
            'empleado' => self::CATEGORIA_EMPLEADO,
            'centro' => self::CATEGORIA_CENTRO,
            'config' => self::CATEGORIA_CONFIG,
            'rgpd' => self::CATEGORIA_RGPD,
        ];

        foreach ($prefijos as $prefijo => $categoria) {
            if (str_starts_with($accion, $prefijo)) {
                return $categoria;
            }
        }

        return self::CATEGORIA_SISTEMA;
    }

    /**
     * Obtiene la IP del cliente
     */
    private function obtenerIpCliente(): string
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                // Si hay múltiples IPs, tomar la primera
                if (str_contains($ip, ',')) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                // Validar que sea una IP válida
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }
}
