<?php

declare(strict_types=1);

namespace LMFichajes\DTO;

/**
 * DTO para resultado de login
 *
 * @package LMFichajes\DTO
 */
readonly class LoginResult
{
    public function __construct(
        public bool $success,
        public ?string $error = null,
        public ?string $errorCode = null,
        public ?int $empleadoId = null,
        public ?object $empleado = null,
        public bool $requiresMfa = false,
        public bool $requiresPasswordChange = false,
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'success' => $this->success,
            'error' => $this->error,
            'error_code' => $this->errorCode,
            'empleado_id' => $this->empleadoId,
            'requires_mfa' => $this->requiresMfa,
            'requires_password_change' => $this->requiresPasswordChange,
        ];
    }
}
