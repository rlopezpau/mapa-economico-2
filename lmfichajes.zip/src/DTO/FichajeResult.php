<?php

declare(strict_types=1);

namespace LMFichajes\DTO;

/**
 * DTO para resultado de fichaje
 *
 * @package LMFichajes\DTO
 */
readonly class FichajeResult
{
    /**
     * @param bool $success
     * @param string|null $error
     * @param int|null $fichajeId
     * @param string|null $message
     * @param array<string> $incidencias
     * @param string|null $estado
     */
    public function __construct(
        public bool $success,
        public ?string $error = null,
        public ?int $fichajeId = null,
        public ?string $message = null,
        public array $incidencias = [],
        public ?string $estado = null,
    ) {
    }

    public function tieneIncidencias(): bool
    {
        return !empty($this->incidencias);
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'success' => $this->success,
            'error' => $this->error,
            'fichaje_id' => $this->fichajeId,
            'message' => $this->message,
            'incidencias' => $this->incidencias,
            'estado' => $this->estado,
        ];
    }
}
