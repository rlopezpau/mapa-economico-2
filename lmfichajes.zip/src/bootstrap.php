<?php

/**
 * LM Fichajes - Bootstrap
 *
 * Inicialización de la aplicación. Carga el autoloader,
 * configura el contenedor de dependencias y prepara el entorno.
 *
 * @package LMFichajes
 * @version 2.0.0
 */

declare(strict_types=1);

// Definir constante de acceso
if (!defined('LMFICHAJES')) {
    define('LMFICHAJES', true);
}

// Definir rutas base
define('ROOT_PATH', dirname(__DIR__));
define('SRC_PATH', __DIR__);
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');

// Cargar autoloader
require_once SRC_PATH . '/Core/Autoloader.php';

use LMFichajes\Core\Autoloader;
use LMFichajes\Core\Container;
use LMFichajes\Core\Database;
use LMFichajes\Repositories\EmpleadoRepository;
use LMFichajes\Repositories\FichajeRepository;
use LMFichajes\Services\AuthService;
use LMFichajes\Services\FichajeService;
use LMFichajes\Services\AuditService;
use LMFichajes\Services\SecurityService;

// Configurar autoloader
$autoloader = new Autoloader();
$autoloader->addNamespace('LMFichajes\\', SRC_PATH . '/');
$autoloader->register();

// Configuración desde variables de entorno
$config = [
    'app' => [
        'name' => getenv('APP_NAME') ?: 'LM Fichajes',
        'version' => '2.1.0',
        'url' => getenv('APP_URL') ?: '',
        'debug' => filter_var(getenv('DEV_MODE') ?: false, FILTER_VALIDATE_BOOLEAN),
        'timezone' => getenv('APP_TIMEZONE') ?: 'Europe/Madrid',
    ],
    'database' => [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'port' => (int)(getenv('DB_PORT') ?: 3306),
        'name' => getenv('DB_NAME') ?: 'lmfichajes',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
        'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
    ],
    'session' => [
        'timeout' => (int)(getenv('SESSION_TIMEOUT') ?: 1800),
        'name' => 'LMFICHAJES_SESSION',
    ],
    'security' => [
        'csrf_expiry' => 3600,
        'password_expiry_days' => 90,
        'max_login_attempts' => 5,
        'lockout_minutes' => 30,
    ],
];

// Configurar zona horaria
date_default_timezone_set($config['app']['timezone']);

// Configurar manejo de errores
if ($config['app']['debug']) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', LOGS_PATH . '/php_errors.log');
}

// Configurar sesión
ini_set('session.cookie_httponly', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.name', $config['session']['name']);

// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configurar contenedor de dependencias
$container = Container::getInstance();

// Registrar configuración
$container->instance('config', (object)$config);

// Registrar servicios como singletons
$container->singleton(Database::class, function () use ($config) {
    return Database::getInstance($config['database']);
});

$container->singleton(SecurityService::class);

$container->singleton(AuditService::class, function (Container $c) {
    return new AuditService($c->get(Database::class));
});

$container->singleton(EmpleadoRepository::class, function (Container $c) {
    return new EmpleadoRepository($c->get(Database::class));
});

$container->singleton(FichajeRepository::class, function (Container $c) {
    return new FichajeRepository($c->get(Database::class));
});

$container->singleton(AuthService::class, function (Container $c) {
    return new AuthService(
        $c->get(Database::class),
        $c->get(EmpleadoRepository::class),
        $c->get(AuditService::class)
    );
});

$container->singleton(FichajeService::class, function (Container $c) {
    return new FichajeService(
        $c->get(Database::class),
        $c->get(FichajeRepository::class),
        $c->get(EmpleadoRepository::class),
        $c->get(AuditService::class)
    );
});

/**
 * Función helper para obtener servicios del contenedor
 *
 * @template T
 * @param class-string<T> $service
 * @return T
 */
function app(string $service): mixed
{
    return Container::getInstance()->get($service);
}

/**
 * Función helper para obtener configuración
 *
 * @param string $key Clave con notación de punto (ej: 'app.name')
 * @param mixed $default Valor por defecto
 * @return mixed
 */
function config(string $key, mixed $default = null): mixed
{
    $config = Container::getInstance()->get('config');
    $keys = explode('.', $key);
    $value = $config;

    foreach ($keys as $k) {
        if (is_object($value) && isset($value->$k)) {
            $value = $value->$k;
        } elseif (is_array($value) && isset($value[$k])) {
            $value = $value[$k];
        } else {
            return $default;
        }
    }

    return $value;
}

/**
 * Función helper para sanitizar output
 */
function e(?string $string): string
{
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Función helper para obtener el usuario actual
 */
function usuario(): ?object
{
    return app(AuthService::class)->getUsuarioActual();
}

/**
 * Función helper para verificar autenticación
 */
function autenticado(): bool
{
    return app(AuthService::class)->verificarSesion();
}

/**
 * Función helper para verificar rol
 */
function tieneRol(string ...$roles): bool
{
    return app(AuthService::class)->tieneRol(...$roles);
}

/**
 * Función helper para generar campo CSRF
 */
function csrf_campo(): string
{
    return app(SecurityService::class)->csrfCampo();
}

/**
 * Función helper para verificar CSRF
 */
function verificar_csrf(): bool
{
    return app(SecurityService::class)->verificarCsrf();
}

/**
 * Función helper para establecer headers de seguridad
 */
function headers_seguridad(): void
{
    app(SecurityService::class)->establecerHeadersSeguridad();
}

/**
 * Función helper para redirección
 */
function redirect(string $url, int $code = 302): never
{
    header("Location: {$url}", true, $code);
    exit;
}

/**
 * Función helper para respuesta JSON
 *
 * @param array<string, mixed> $data
 */
function json(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Constantes de compatibilidad con código legacy
define('APP_NAME', $config['app']['name']);
define('APP_VERSION', $config['app']['version']);
define('APP_URL', $config['app']['url']);
define('DEV_MODE', $config['app']['debug']);

// Tipos de fichaje (compatibilidad)
define('FICHAJE_ENTRADA', 'entrada');
define('FICHAJE_SALIDA', 'salida');
define('FICHAJE_PAUSA_INICIO', 'pausa_inicio');
define('FICHAJE_PAUSA_FIN', 'pausa_fin');

// Exponer el PDO para compatibilidad con código legacy
$pdo = app(Database::class)->getConnection();

return $container;
