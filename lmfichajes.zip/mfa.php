<?php
/**
 * LM FICHAJES - Verificación MFA (Autenticación de dos factores)
 *
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();

// Verificar que hay MFA pendiente
if (!isset($_SESSION['mfa_pendiente']) || !$_SESSION['mfa_pendiente']) {
    header('Location: login.php');
    exit;
}

$usuarioId = $_SESSION['mfa_usuario_id'] ?? null;
if (!$usuarioId) {
    header('Location: login.php');
    exit;
}

// Obtener usuario
$stmt = $pdo->prepare("SELECT * FROM empleados WHERE id = ? AND activo = 1");
$stmt->execute([$usuarioId]);
$usuario = $stmt->fetch();

if (!$usuario) {
    unset($_SESSION['mfa_pendiente'], $_SESSION['mfa_usuario_id']);
    header('Location: login.php');
    exit;
}

$error = '';

// Procesar código MFA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf()) {
        $error = 'Error de seguridad. Recarga la página.';
    } else {
        $codigo = preg_replace('/[^0-9]/', '', $_POST['codigo'] ?? '');

        if (strlen($codigo) !== 6) {
            $error = 'El código debe tener 6 dígitos';
        } else {
            // Verificar código TOTP
            $codigoValido = false;

            if (function_exists('verificar_codigo_totp') && !empty($usuario->mfa_secret)) {
                $codigoValido = verificar_codigo_totp($usuario->mfa_secret, $codigo);
            } else {
                // Si no hay función TOTP, verificar código de respaldo
                $stmt = $pdo->prepare("
                    SELECT id FROM mfa_backup_codes
                    WHERE empleado_id = ? AND codigo = ? AND usado = 0
                ");
                $stmt->execute([$usuarioId, $codigo]);
                if ($stmt->fetch()) {
                    $codigoValido = true;
                    // Marcar código como usado
                    $pdo->prepare("UPDATE mfa_backup_codes SET usado = 1 WHERE empleado_id = ? AND codigo = ?")
                        ->execute([$usuarioId, $codigo]);
                }
            }

            if ($codigoValido) {
                // MFA exitoso - completar login
                completar_login($pdo, $usuario);
                header('Location: fichar.php');
                exit;
            } else {
                $error = 'Código incorrecto. Inténtalo de nuevo.';

                // Auditoría
                if (function_exists('audit_login_fail')) {
                    audit_login_fail($usuario->nif, 'Código MFA incorrecto');
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Verificación MFA - LM Fichajes</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 50%, #3d7ab5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container { width: 100%; max-width: 400px; }

        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #2d5a87 0%, #1a365d 100%);
            padding: 30px;
            text-align: center;
            color: white;
        }

        .header .icon { font-size: 48px; margin-bottom: 15px; }
        .header h1 { font-size: 22px; margin-bottom: 5px; }
        .header p { font-size: 14px; opacity: 0.9; }

        .body { padding: 30px; }

        .alert-error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 14px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .code-input {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin: 30px 0;
        }

        .code-input input {
            width: 45px;
            height: 55px;
            text-align: center;
            font-size: 24px;
            font-weight: 600;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            transition: all 0.3s;
        }

        .code-input input:focus {
            outline: none;
            border-color: #2d5a87;
            box-shadow: 0 0 0 4px rgba(45, 90, 135, 0.1);
        }

        .hidden-input { position: absolute; opacity: 0; }

        .btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #2d5a87 0%, #1a365d 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(45, 90, 135, 0.4);
        }

        .link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #64748b;
            text-decoration: none;
            font-size: 14px;
        }

        .link:hover { color: #2d5a87; }

        .footer {
            text-align: center;
            padding: 20px;
            border-top: 1px solid #f3f4f6;
            font-size: 12px;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <div class="icon">🔐</div>
                <h1>Verificación en dos pasos</h1>
                <p>Introduce el código de tu aplicación</p>
            </div>

            <div class="body">
                <?php if ($error): ?>
                    <div class="alert-error"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" id="mfaForm">
                    <?= csrf_campo() ?>
                    <input type="text" name="codigo" id="codigoInput" class="hidden-input"
                           maxlength="6" pattern="[0-9]{6}" autocomplete="one-time-code">

                    <div class="code-input">
                        <input type="text" maxlength="1" class="digit" data-index="0">
                        <input type="text" maxlength="1" class="digit" data-index="1">
                        <input type="text" maxlength="1" class="digit" data-index="2">
                        <input type="text" maxlength="1" class="digit" data-index="3">
                        <input type="text" maxlength="1" class="digit" data-index="4">
                        <input type="text" maxlength="1" class="digit" data-index="5">
                    </div>

                    <button type="submit" class="btn">Verificar</button>
                </form>

                <a href="login.php" class="link">← Volver al inicio de sesión</a>
            </div>

            <div class="footer">
                <p>Usa tu app de autenticación (Google Authenticator, Authy, etc.)</p>
            </div>
        </div>
    </div>

    <script>
        const digits = document.querySelectorAll('.digit');
        const hiddenInput = document.getElementById('codigoInput');

        digits.forEach((digit, index) => {
            digit.addEventListener('input', (e) => {
                const val = e.target.value.replace(/[^0-9]/g, '');
                e.target.value = val;

                if (val && index < 5) {
                    digits[index + 1].focus();
                }

                updateHidden();
            });

            digit.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && !e.target.value && index > 0) {
                    digits[index - 1].focus();
                }
            });

            digit.addEventListener('paste', (e) => {
                e.preventDefault();
                const paste = (e.clipboardData || window.clipboardData).getData('text');
                const nums = paste.replace(/[^0-9]/g, '').slice(0, 6);

                nums.split('').forEach((n, i) => {
                    if (digits[i]) digits[i].value = n;
                });

                updateHidden();
                if (nums.length === 6) {
                    document.getElementById('mfaForm').submit();
                }
            });
        });

        function updateHidden() {
            hiddenInput.value = Array.from(digits).map(d => d.value).join('');
        }

        digits[0].focus();
    </script>
</body>
</html>
