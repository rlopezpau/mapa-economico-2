<?php
/**
 * LM FICHAJES - Portal Principal
 *
 * Redirecciona al portal de fichaje o login.
 *
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();

// Si está logueado, ir al fichaje
if (esta_logueado()) {
    header('Location: fichar.php');
    exit;
}

// Si no, ir al login
header('Location: login.php');
exit;
