<?php
/**
 * LM FICHAJES - Política de Privacidad
 */
define('LMFICHAJES', true);
require_once 'config.php';

$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad - <?php echo $nombreEmpresa; ?></title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: system-ui, sans-serif; line-height: 1.7; color: #1f2937; background: #f9fafb; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        h1 { color: #1e40af; border-bottom: 3px solid #1e40af; padding-bottom: 15px; }
        h2 { color: #1e3a8a; margin-top: 30px; font-size: 1.3rem; }
        p, li { color: #374151; }
        ul { padding-left: 20px; }
        .fecha { color: #6b7280; font-size: 0.9rem; margin-bottom: 30px; }
        .btn-back { display: inline-block; padding: 10px 20px; background: #6b7280; color: white; text-decoration: none; border-radius: 8px; margin-bottom: 20px; }
        .btn-back:hover { background: #4b5563; }
        .highlight { background: #eff6ff; padding: 15px; border-radius: 8px; border-left: 4px solid #1e40af; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <a href="javascript:history.back()" class="btn-back">← Volver</a>
        
        <h1>🔐 Política de Privacidad</h1>
        <p class="fecha">Última actualización: <?php echo date('d/m/Y'); ?></p>
        
        <div class="highlight">
            <strong>Responsable del tratamiento:</strong> La entidad que gestiona este sistema de fichajes.
        </div>
        
        <h2>1. Datos que Recopilamos</h2>
        <p>Para el funcionamiento del sistema de control horario, tratamos:</p>
        <ul>
            <li><strong>Datos identificativos:</strong> Nombre, apellidos, NIF/NIE, email, teléfono</li>
            <li><strong>Datos laborales:</strong> Fecha de alta, centro de trabajo, horario asignado</li>
            <li><strong>Registros de jornada:</strong> Fecha, hora de entrada/salida, ubicación GPS (si aplica)</li>
            <li><strong>Ausencias:</strong> Solicitudes de vacaciones, permisos, bajas</li>
        </ul>
        
        <h2>2. Finalidad del Tratamiento</h2>
        <p>Sus datos son tratados para:</p>
        <ul>
            <li>Cumplimiento del Real Decreto 8/2019 de registro de jornada laboral</li>
            <li>Gestión de recursos humanos y control horario</li>
            <li>Tramitación de ausencias y vacaciones</li>
            <li>Cumplimiento de obligaciones legales y laborales</li>
        </ul>
        
        <h2>3. Base Legal</h2>
        <ul>
            <li><strong>Cumplimiento legal:</strong> RD 8/2019 (registro obligatorio de jornada)</li>
            <li><strong>Ejecución del contrato:</strong> Relación laboral con la entidad</li>
            <li><strong>Interés legítimo:</strong> Gestión organizativa interna</li>
        </ul>
        
        <h2>4. Conservación de Datos</h2>
        <ul>
            <li><strong>Registros de fichajes:</strong> 4 años (según RD 8/2019)</li>
            <li><strong>Datos laborales:</strong> Durante la relación laboral + plazo legal</li>
            <li><strong>Documentos:</strong> Según normativa de archivo aplicable</li>
        </ul>
        
        <h2>5. Sus Derechos (RGPD)</h2>
        <p>Puede ejercer sus derechos de:</p>
        <ul>
            <li><strong>Acceso:</strong> Conocer qué datos tratamos sobre usted</li>
            <li><strong>Rectificación:</strong> Corregir datos inexactos</li>
            <li><strong>Supresión:</strong> Eliminar datos (con limitaciones legales)</li>
            <li><strong>Portabilidad:</strong> Recibir sus datos en formato electrónico</li>
            <li><strong>Oposición:</strong> Oponerse a determinados tratamientos</li>
            <li><strong>Limitación:</strong> Solicitar restricción del tratamiento</li>
        </ul>
        
        <div class="highlight">
            Para ejercer sus derechos, acceda a <a href="mis-datos.php"><strong>Mis Datos RGPD</strong></a> en el portal del empleado.
        </div>
        
        <h2>6. Seguridad</h2>
        <p>Aplicamos medidas técnicas y organizativas para proteger sus datos:</p>
        <ul>
            <li>Conexión cifrada (HTTPS)</li>
            <li>Control de acceso por usuario y contraseña</li>
            <li>Registro de auditoría de accesos</li>
            <li>Copias de seguridad periódicas</li>
        </ul>
        
        <h2>7. Contacto</h2>
        <p>Para cualquier consulta sobre privacidad, contacte con el responsable de protección de datos de su organización.</p>
        
        <p style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 0.85rem;">
            Este sistema cumple con el Reglamento General de Protección de Datos (RGPD) y la Ley Orgánica 3/2018 de Protección de Datos (LOPDGDD).
        </p>
    </div>
</body>
</html>
