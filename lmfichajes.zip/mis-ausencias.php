<?php
/**
 * LM FICHAJES - Mis Ausencias
 * 
 * Gestión de vacaciones, permisos y ausencias del empleado.
 * - Ver saldo de días disponibles
 * - Solicitar ausencias
 * - Ver historial de solicitudes
 * - Cancelar solicitudes pendientes
 * 
 * @package     LMFichajes
 * @author      Roberto López Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/ausencias.php';

// Headers de seguridad
establecer_headers_seguridad();

// Requerir login
requerir_login();

// Obtener datos del usuario
$usuario = obtener_usuario_actual($pdo);
$anioActual = date('Y');

// Inicializar saldos si no existen
inicializar_saldos_empleado($pdo, $usuario->id, $anioActual);

// Obtener datos
$saldos = obtener_saldos_empleado($pdo, $usuario->id, $anioActual);
$tiposAusencia = obtener_tipos_ausencia_empleado($pdo, $usuario->id);
$solicitudes = obtener_solicitudes_empleado($pdo, $usuario->id, $anioActual);

// Determinar vista actual
$vista = $_GET['vista'] ?? 'solicitudes';
$accion = $_GET['accion'] ?? '';

// Variables para mensajes
$mensaje = '';
$tipoMensaje = '';

// Procesar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $mensaje = 'Error de seguridad. Recarga la página.';
        $tipoMensaje = 'error';
    } else {
        
        $accionPost = $_POST['accion'] ?? '';
        
        // Crear solicitud
        if ($accionPost === 'crear_solicitud') {
            $resultado = crear_solicitud_ausencia($pdo, [
                'empleado_id' => $usuario->id,
                'tipo_ausencia_id' => intval($_POST['tipo_ausencia_id'] ?? 0),
                'fecha_inicio' => sanitizar($_POST['fecha_inicio'] ?? ''),
                'fecha_fin' => sanitizar($_POST['fecha_fin'] ?? ''),
                'jornada_inicio' => sanitizar($_POST['jornada_inicio'] ?? 'completa'),
                'jornada_fin' => sanitizar($_POST['jornada_fin'] ?? 'completa'),
                'motivo' => sanitizar($_POST['motivo'] ?? ''),
                'guardar_borrador' => isset($_POST['guardar_borrador'])
            ]);
            
            $mensaje = $resultado['mensaje'];
            $tipoMensaje = $resultado['exito'] ? 'success' : 'error';
            
            if ($resultado['exito']) {
                // Recargar solicitudes
                $solicitudes = obtener_solicitudes_empleado($pdo, $usuario->id, $anioActual);
                $saldos = obtener_saldos_empleado($pdo, $usuario->id, $anioActual);
            }
        }
        
        // Cancelar solicitud
        if ($accionPost === 'cancelar_solicitud') {
            $solicitudId = intval($_POST['solicitud_id'] ?? 0);
            $resultado = cancelar_solicitud_ausencia($pdo, $solicitudId, $usuario->id);
            
            $mensaje = $resultado['mensaje'];
            $tipoMensaje = $resultado['exito'] ? 'success' : 'error';
            
            if ($resultado['exito']) {
                $solicitudes = obtener_solicitudes_empleado($pdo, $usuario->id, $anioActual);
            }
        }
        
        // Enviar borrador
        if ($accionPost === 'enviar_solicitud') {
            $solicitudId = intval($_POST['solicitud_id'] ?? 0);
            $resultado = enviar_solicitud_ausencia($pdo, $solicitudId, $usuario->id);
            
            $mensaje = $resultado['mensaje'];
            $tipoMensaje = $resultado['exito'] ? 'success' : 'error';
            
            if ($resultado['exito']) {
                $solicitudes = obtener_solicitudes_empleado($pdo, $usuario->id, $anioActual);
            }
        }
    }
}

// Generar token CSRF
$csrfToken = generar_csrf();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Ausencias - LM Fichajes</title>
    <style>
        :root {
            --primary: #2d5a87;
            --primary-dark: #1a365d;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-900: #111827;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            min-height: 100vh;
            color: var(--gray-900);
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 15px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-content {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .header-title h1 {
            font-size: 18px;
            font-weight: 600;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 13px;
        }
        
        .btn-back:hover { background: rgba(255,255,255,0.3); }
        
        /* Container */
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            margin-bottom: 16px;
            overflow: hidden;
        }
        
        .card-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-700);
        }
        
        .card-body { padding: 20px; }
        
        /* Mensajes */
        .mensaje {
            padding: 14px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        
        .mensaje.success { background: #d1fae5; color: #065f46; border-left: 4px solid var(--success); }
        .mensaje.error { background: #fee2e2; color: #991b1b; border-left: 4px solid var(--danger); }
        
        /* Tabs */
        .tabs {
            display: flex;
            gap: 5px;
            padding: 10px 20px;
            background: white;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .tab {
            padding: 10px 20px;
            border: none;
            background: var(--gray-100);
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .tab:hover { background: var(--gray-200); }
        .tab.active { background: var(--primary); color: white; }
        
        /* Saldos */
        .saldos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }
        
        .saldo-item {
            padding: 15px;
            border-radius: 10px;
            background: var(--gray-50);
            border-left: 4px solid var(--gray-300);
        }
        
        .saldo-item .tipo {
            font-size: 13px;
            font-weight: 500;
            color: var(--gray-700);
            margin-bottom: 8px;
        }
        
        .saldo-item .dias {
            display: flex;
            align-items: baseline;
            gap: 5px;
        }
        
        .saldo-item .disponible {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary);
        }
        
        .saldo-item .total {
            font-size: 14px;
            color: var(--gray-500);
        }
        
        .saldo-item .detalle {
            font-size: 11px;
            color: var(--gray-500);
            margin-top: 5px;
        }
        
        /* Formulario */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-group.full-width {
            grid-column: span 2;
        }
        
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            color: var(--gray-700);
            margin-bottom: 6px;
        }
        
        .form-group label .required { color: var(--danger); }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-size: 14px;
        }
        
        .form-group textarea {
            min-height: 80px;
            resize: vertical;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(45, 90, 135, 0.1);
        }
        
        .form-hint {
            font-size: 12px;
            color: var(--gray-500);
            margin-top: 4px;
        }
        
        .form-actions {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-200);
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        /* Botones */
        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-secondary { background: var(--gray-200); color: var(--gray-700); }
        .btn-secondary:hover { background: var(--gray-300); }
        .btn-success { background: var(--success); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        /* Tabla solicitudes */
        .solicitudes-list {
            overflow-x: auto;
        }
        
        .solicitud-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid var(--gray-100);
            gap: 15px;
        }
        
        .solicitud-item:last-child { border-bottom: none; }
        
        .solicitud-color {
            width: 6px;
            height: 50px;
            border-radius: 3px;
        }
        
        .solicitud-info {
            flex: 1;
        }
        
        .solicitud-tipo {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 4px;
        }
        
        .solicitud-fechas {
            font-size: 13px;
            color: var(--gray-600);
        }
        
        .solicitud-dias {
            font-size: 12px;
            color: var(--gray-500);
        }
        
        .solicitud-estado {
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .estado-borrador { background: var(--gray-200); color: var(--gray-700); }
        .estado-pendiente { background: #fef3c7; color: #92400e; }
        .estado-aprobada { background: #d1fae5; color: #065f46; }
        .estado-rechazada { background: #fee2e2; color: #991b1b; }
        .estado-cancelada { background: var(--gray-200); color: var(--gray-500); }
        
        .solicitud-acciones {
            display: flex;
            gap: 8px;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-500);
        }
        
        .empty-state .icon { font-size: 48px; margin-bottom: 15px; }
        
        /* Optgroup styling */
        optgroup {
            font-weight: 600;
            color: var(--gray-700);
        }
        
        option {
            font-weight: normal;
            padding: 5px;
        }
        
        /* Responsive */
        @media (max-width: 640px) {
            .form-grid { grid-template-columns: 1fr; }
            .form-group.full-width { grid-column: span 1; }
            
            .solicitud-item {
                flex-wrap: wrap;
            }
            
            .solicitud-acciones {
                width: 100%;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="header-title">
                <span>🏖️</span>
                <h1>Mis Ausencias</h1>
            </div>
            <div style="display: flex; align-items: center; gap: 1rem;">
                <span style="color: #64748b; font-size: 0.875rem;">👤 <?= sanitizar($usuario->nombre . ' ' . $usuario->apellido1) ?></span>
                <a href="portal.php" class="btn-back">← Volver al portal</a>
            </div>
        </div>
    </header>
    
    <!-- Tabs -->
    <div class="tabs">
        <a href="?vista=solicitudes" class="tab <?= $vista === 'solicitudes' ? 'active' : '' ?>">
            📋 Mis solicitudes
        </a>
        <a href="?vista=nueva" class="tab <?= $vista === 'nueva' ? 'active' : '' ?>">
            ➕ Nueva solicitud
        </a>
        <a href="?vista=saldos" class="tab <?= $vista === 'saldos' ? 'active' : '' ?>">
            📊 Saldos
        </a>
    </div>
    
    <div class="container">
        <!-- Mensajes -->
        <?php if ($mensaje): ?>
            <div class="mensaje <?= $tipoMensaje ?>">
                <?= $tipoMensaje === 'success' ? '✅' : '❌' ?> <?= sanitizar($mensaje) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($vista === 'saldos'): ?>
        <!-- Vista: Saldos -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">📊 Saldo de días <?= $anioActual ?></span>
            </div>
            <div class="card-body">
                <?php if (empty($saldos)): ?>
                    <div class="empty-state">
                        <div class="icon">📅</div>
                        <p>No hay saldos configurados para este año</p>
                    </div>
                <?php else: ?>
                    <div class="saldos-grid">
                        <?php foreach ($saldos as $saldo): ?>
                            <div class="saldo-item" style="border-color: <?= $saldo->color ?>">
                                <div class="tipo"><?= sanitizar($saldo->nombre) ?></div>
                                <div class="dias">
                                    <span class="disponible"><?= number_format($saldo->dias_disponibles, 1) ?></span>
                                    <span class="total">/ <?= number_format($saldo->dias_asignados, 1) ?> días</span>
                                </div>
                                <div class="detalle">
                                    Disfrutados: <?= number_format($saldo->dias_disfrutados, 1) ?> |
                                    Pendientes: <?= number_format($saldo->dias_pendientes, 1) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php elseif ($vista === 'nueva'): ?>
        <!-- Vista: Nueva solicitud -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">➕ Nueva solicitud de ausencia</span>
            </div>
            <div class="card-body">
                <form method="POST" id="formSolicitud">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    <input type="hidden" name="accion" value="crear_solicitud">
                    
                    <?php
                    // Info del convenio si tiene
                    $convenioEmpleado = $tiposAusencia['_convenio'] ?? null;
                    unset($tiposAusencia['_convenio']);
                    ?>
                    <?php if ($convenioEmpleado): ?>
                    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 10px 15px; margin-bottom: 15px; font-size: 0.9rem;">
                        📋 <strong>Tu convenio:</strong> <?= sanitizar($convenioEmpleado) ?>
                    </div>
                    <?php endif; ?>

                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label for="tipo_ausencia_id">Tipo de ausencia <span class="required">*</span></label>
                            <select name="tipo_ausencia_id" id="tipo_ausencia_id" required>
                                <option value="">Seleccione un tipo...</option>
                                <?php foreach ($tiposAusencia as $categoria => $datos): ?>
                                    <optgroup label="<?= sanitizar($datos['nombre']) ?>">
                                        <?php foreach ($datos['tipos'] as $tipo):
                                            // Construir texto de la opción con días
                                            $textoOpcion = $tipo->nombre;
                                            if ($tipo->dias_disponibles !== null && $tipo->dias_asignados !== null) {
                                                $disponibles = ($tipo->dias_disponibles == floor($tipo->dias_disponibles))
                                                    ? (int)$tipo->dias_disponibles
                                                    : number_format($tipo->dias_disponibles, 1);
                                                $asignados = ($tipo->dias_asignados == floor($tipo->dias_asignados))
                                                    ? (int)$tipo->dias_asignados
                                                    : number_format($tipo->dias_asignados, 1);
                                                $textoOpcion .= " ({$disponibles} de {$asignados} días)";
                                            } elseif ($tipo->dias_maximos) {
                                                $textoOpcion .= " (máx. {$tipo->dias_maximos} días)";
                                            }
                                        ?>
                                            <option value="<?= $tipo->id ?>"
                                                    data-disponibles="<?= $tipo->dias_disponibles ?? '' ?>"
                                                    data-asignados="<?= $tipo->dias_asignados ?? '' ?>"
                                                    data-preaviso="<?= $tipo->dias_preaviso ?? 0 ?>"
                                                    data-justificante="<?= $tipo->requiere_justificante ?? 0 ?>">
                                                <?= sanitizar($textoOpcion) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endforeach; ?>
                            </select>
                            <div id="infoTipoSeleccionado" style="margin-top: 8px; font-size: 0.85rem; color: var(--gray-500);"></div>
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_inicio">Fecha inicio <span class="required">*</span></label>
                            <input type="date" name="fecha_inicio" id="fecha_inicio" required
                                   min="<?= date('Y-m-d') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_fin">Fecha fin <span class="required">*</span></label>
                            <input type="date" name="fecha_fin" id="fecha_fin" required
                                   min="<?= date('Y-m-d') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="jornada_inicio">Jornada inicio</label>
                            <select name="jornada_inicio" id="jornada_inicio">
                                <option value="completa">Jornada completa</option>
                                <option value="mañana">Solo mañana</option>
                                <option value="tarde">Solo tarde</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="jornada_fin">Jornada fin</label>
                            <select name="jornada_fin" id="jornada_fin">
                                <option value="completa">Jornada completa</option>
                                <option value="mañana">Solo mañana</option>
                                <option value="tarde">Solo tarde</option>
                            </select>
                        </div>
                        
                        <div class="form-group full-width">
                            <label for="motivo">Motivo / Observaciones</label>
                            <textarea name="motivo" id="motivo" 
                                placeholder="Indique el motivo de la solicitud (opcional en la mayoría de casos)"></textarea>
                            <div class="form-hint" id="infoTipo"></div>
                        </div>
                    </div>
                    
                    <div id="resumenDias" style="display: none; margin-top: 15px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                        <strong>Días solicitados:</strong> <span id="numDias">0</span> días laborables
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="guardar_borrador" value="1" class="btn btn-secondary">
                            💾 Guardar borrador
                        </button>
                        <button type="submit" class="btn btn-primary">
                            📤 Enviar solicitud
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php else: ?>
        <!-- Vista: Lista de solicitudes -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">📋 Mis solicitudes <?= $anioActual ?></span>
                <a href="?vista=nueva" class="btn btn-primary btn-sm">➕ Nueva</a>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($solicitudes)): ?>
                    <div class="empty-state">
                        <div class="icon">📭</div>
                        <p>No tienes solicitudes de ausencia este año</p>
                        <a href="?vista=nueva" class="btn btn-primary" style="margin-top: 15px;">
                            ➕ Crear solicitud
                        </a>
                    </div>
                <?php else: ?>
                    <div class="solicitudes-list">
                        <?php foreach ($solicitudes as $sol): ?>
                            <?php $estadoInfo = traducir_estado_ausencia($sol->estado); ?>
                            <div class="solicitud-item">
                                <div class="solicitud-color" style="background: <?= $sol->color ?>"></div>
                                
                                <div class="solicitud-info">
                                    <div class="solicitud-tipo"><?= sanitizar($sol->tipo_nombre) ?></div>
                                    <div class="solicitud-fechas">
                                        📅 <?= formatear_rango_fechas($sol->fecha_inicio, $sol->fecha_fin) ?>
                                    </div>
                                    <div class="solicitud-dias">
                                        <?= number_format($sol->dias_solicitados, 1) ?> día(s)
                                        <?php if ($sol->motivo): ?>
                                            · <?= sanitizar(substr($sol->motivo, 0, 50)) ?>...
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <span class="solicitud-estado estado-<?= $sol->estado ?>">
                                    <?= $estadoInfo['texto'] ?>
                                </span>
                                
                                <div class="solicitud-acciones">
                                    <?php if ($sol->estado === 'borrador'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                            <input type="hidden" name="accion" value="enviar_solicitud">
                                            <input type="hidden" name="solicitud_id" value="<?= $sol->id ?>">
                                            <button type="submit" class="btn btn-success btn-sm">📤 Enviar</button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <?php if (in_array($sol->estado, ['borrador', 'pendiente'])): ?>
                                        <form method="POST" style="display: inline;" 
                                              onsubmit="return confirm('¿Seguro que quieres cancelar esta solicitud?')">
                                            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                            <input type="hidden" name="accion" value="cancelar_solicitud">
                                            <input type="hidden" name="solicitud_id" value="<?= $sol->id ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">✖ Cancelar</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        // Calcular días laborables
        function calcularDiasLaborables(fechaInicio, fechaFin) {
            const inicio = new Date(fechaInicio);
            const fin = new Date(fechaFin);
            let dias = 0;
            
            const actual = new Date(inicio);
            while (actual <= fin) {
                const diaSemana = actual.getDay();
                if (diaSemana !== 0 && diaSemana !== 6) {
                    dias++;
                }
                actual.setDate(actual.getDate() + 1);
            }
            
            return dias;
        }
        
        // Actualizar resumen de días
        function actualizarResumen() {
            const fechaInicio = document.getElementById('fecha_inicio').value;
            const fechaFin = document.getElementById('fecha_fin').value;
            const resumenDiv = document.getElementById('resumenDias');
            const numDiasSpan = document.getElementById('numDias');
            
            if (fechaInicio && fechaFin) {
                const dias = calcularDiasLaborables(fechaInicio, fechaFin);
                numDiasSpan.textContent = dias;
                resumenDiv.style.display = 'block';
            } else {
                resumenDiv.style.display = 'none';
            }
        }
        
        // Mostrar info del tipo seleccionado
        document.getElementById('tipo_ausencia_id')?.addEventListener('change', function() {
            const option = this.options[this.selectedIndex];
            const infoDiv = document.getElementById('infoTipoSeleccionado');

            if (!option.value) {
                infoDiv.innerHTML = '';
                return;
            }

            const disponibles = option.dataset.disponibles;
            const asignados = option.dataset.asignados;
            const preaviso = parseInt(option.dataset.preaviso) || 0;
            const justificante = option.dataset.justificante === '1';

            let html = [];

            if (disponibles !== '' && asignados !== '') {
                const disp = parseFloat(disponibles);
                const color = disp > 0 ? '#10b981' : '#ef4444';
                html.push(`<span style="color:${color};">📊 Disponibles: <strong>${disp}</strong> de ${asignados} días</span>`);
            }

            if (preaviso > 0) {
                html.push(`<span style="color:#f59e0b;">⏰ Requiere ${preaviso} días de preaviso</span>`);
            }

            if (justificante) {
                html.push('<span style="color:#3b82f6;">📎 Requiere justificante</span>');
            }

            infoDiv.innerHTML = html.join(' · ');
        });
        
        // Eventos de fechas
        document.getElementById('fecha_inicio')?.addEventListener('change', function() {
            document.getElementById('fecha_fin').min = this.value;
            if (document.getElementById('fecha_fin').value < this.value) {
                document.getElementById('fecha_fin').value = this.value;
            }
            actualizarResumen();
        });
        
        document.getElementById('fecha_fin')?.addEventListener('change', actualizarResumen);
    </script>
</body>
</html>
