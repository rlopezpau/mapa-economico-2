<?php
/**
 * LM FICHAJES - Procesamiento de fichajes del Portal
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

/**
 * Procesar solicitud de fichaje
 * 
 * @param PDO $pdo
 * @param object $usuario
 * @param string $hoy
 * @return array ['mensaje', 'tipoMensaje', 'mostrarModal', 'datosPendientes', 'recargar']
 */
function procesar_fichaje($pdo, $usuario, $hoy) {
    $resultado = [
        'mensaje' => '',
        'tipoMensaje' => '',
        'mostrarModal' => false,
        'datosPendientes' => null,
        'recargar' => false
    ];
    
    // Verificar CSRF
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $resultado['mensaje'] = 'Error de seguridad. Recarga la página.';
        $resultado['tipoMensaje'] = 'error';
        return $resultado;
    }
    
    $accion = $_POST['accion'] ?? '';
    
    // Si viene del modal de observación
    if ($accion === 'fichar_con_observacion') {
        return procesar_fichaje_con_observacion($pdo, $usuario);
    }
    
    // Fichaje normal
    if (in_array($accion, ['entrada', 'salida', 'pausa_inicio', 'pausa_fin'])) {
        return procesar_fichaje_normal($pdo, $usuario, $accion);
    }
    
    return $resultado;
}

/**
 * Procesar fichaje con observación (desde modal)
 */
function procesar_fichaje_con_observacion($pdo, $usuario) {
    $resultado = [
        'mensaje' => '',
        'tipoMensaje' => '',
        'mostrarModal' => false,
        'datosPendientes' => null,
        'recargar' => false
    ];
    
    $tipo = sanitizar($_POST['tipo_fichaje'] ?? '');
    $centroId = intval($_POST['centro_id'] ?? 0);
    $coordenadas = sanitizar($_POST['coordenadas'] ?? '');
    $modo = sanitizar($_POST['modo'] ?? 'presencial');
    $observacion = sanitizar($_POST['observacion'] ?? '');
    
    if (empty($observacion)) {
        $resultado['mensaje'] = 'Debe indicar el motivo de la incidencia';
        $resultado['tipoMensaje'] = 'error';
        return $resultado;
    }
    
    $res = registrar_fichaje($pdo, $usuario->id, $tipo, [
        'centro_id' => $centroId ?: null,
        'modo' => $modo,
        'coordenadas' => $coordenadas ?: null,
        'observacion' => $observacion
    ]);
    
    $resultado['mensaje'] = $res['mensaje'];
    $resultado['tipoMensaje'] = $res['exito'] ? 'success' : 'error';
    $resultado['recargar'] = $res['exito'];
    
    return $resultado;
}

/**
 * Procesar fichaje normal (verificar si hay incidencia)
 */
function procesar_fichaje_normal($pdo, $usuario, $accion) {
    $resultado = [
        'mensaje' => '',
        'tipoMensaje' => '',
        'mostrarModal' => false,
        'datosPendientes' => null,
        'recargar' => false
    ];
    
    $centroId = intval($_POST['centro_id'] ?? 0);
    $coordenadas = sanitizar($_POST['coordenadas'] ?? '');
    $modo = sanitizar($_POST['modo'] ?? 'presencial');
    
    // Verificar si habrá incidencia ANTES de fichar
    $incidencias = verificar_incidencias_fichaje($pdo, $usuario, $accion, $centroId, $coordenadas);
    
    // Si hay incidencia, mostrar modal para observación
    if (!empty($incidencias)) {
        $resultado['mostrarModal'] = true;
        $resultado['datosPendientes'] = [
            'tipo' => $accion,
            'centro_id' => $centroId,
            'coordenadas' => $coordenadas,
            'modo' => $modo,
            'incidencias' => $incidencias
        ];
        return $resultado;
    }
    
    // Sin incidencia, fichar directamente
    $res = registrar_fichaje($pdo, $usuario->id, $accion, [
        'centro_id' => $centroId ?: null,
        'modo' => $modo,
        'coordenadas' => $coordenadas ?: null
    ]);
    
    $resultado['mensaje'] = $res['mensaje'];
    $resultado['tipoMensaje'] = $res['exito'] ? 'success' : 'error';
    $resultado['recargar'] = $res['exito'];
    
    return $resultado;
}

/**
 * Verificar si el fichaje tendrá incidencias
 */
function verificar_incidencias_fichaje($pdo, $usuario, $accion, $centroId, $coordenadas) {
    $incidencias = [];
    
    // Verificar ubicación
    if ($centroId && $coordenadas) {
        $centro = obtener_centro($pdo, $centroId);
        if ($centro && $centro->coordenadas) {
            $distancia = calcular_distancia($coordenadas, $centro->coordenadas);
            if ($distancia > $centro->radio_metros) {
                $incidencias[] = "Ubicación: a {$distancia}m del centro (máx. {$centro->radio_metros}m)";
            }
        }
    }
    
    // Verificar horario (solo entrada/salida)
    if (in_array($accion, ['entrada', 'salida']) && $usuario->horario_id) {
        $empleadoConHorario = obtener_empleado_con_horario($pdo, $usuario->id);
        $verificacionHorario = verificar_horario_fichaje(date('H:i:s'), $accion, $empleadoConHorario);
        if ($verificacionHorario['fuera_horario']) {
            $incidencias[] = "Horario: " . $verificacionHorario['mensaje'];
        }
    }
    
    return $incidencias;
}
