<?php
/**
 * LM FICHAJES - Funciones de Seguridad
 * 
 * Funciones para sanitizaciÃ³n, CSRF, rate limiting y protecciÃ³n general.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      Roberto LÃ³pez Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// ============================================================================
// SANITIZACIÃ“N DE DATOS
// ============================================================================

/**
 * Sanitiza una cadena de texto para evitar XSS
 * 
 * @param string $dato Dato a sanitizar
 * @return string Dato sanitizado
 */
function sanitizar($dato) {
    if ($dato === null) {
        return '';
    }
    $dato = trim($dato);
    // Nota: stripslashes() eliminado - magic_quotes_gpc deprecado desde PHP 5.4
    $dato = htmlspecialchars($dato, ENT_QUOTES, 'UTF-8');
    return $dato;
}

/**
 * Sanitiza un email
 * 
 * @param string $email Email a sanitizar
 * @return string|false Email sanitizado o false si no es vÃ¡lido
 */
function sanitizar_email($email) {
    $email = trim($email);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return $email;
    }
    return false;
}

/**
 * Sanitiza un NIF/NIE
 * 
 * @param string $nif NIF a sanitizar
 * @return string NIF sanitizado (mayÃºsculas, sin espacios)
 */
function sanitizar_nif($nif) {
    $nif = trim($nif);
    $nif = strtoupper($nif);
    $nif = preg_replace('/[^A-Z0-9]/', '', $nif);
    return $nif;
}

/**
 * Valida formato de NIF/NIE espaÃ±ol
 * 
 * @param string $nif NIF a validar
 * @return bool True si es vÃ¡lido
 */
function validar_nif($nif) {
    $nif = sanitizar_nif($nif);
    
    // NIF: 8 nÃºmeros + letra
    // NIE: X/Y/Z + 7 nÃºmeros + letra
    $patron = '/^[0-9]{8}[A-Z]$|^[XYZ][0-9]{7}[A-Z]$/';
    
    if (!preg_match($patron, $nif)) {
        return false;
    }
    
    // Calcular letra correcta
    $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
    
    // Si es NIE, convertir primera letra a nÃºmero
    $numero = $nif;
    if (preg_match('/^[XYZ]/', $nif)) {
        $numero = str_replace(['X', 'Y', 'Z'], ['0', '1', '2'], $nif);
    }
    
    $numero = substr($numero, 0, -1);
    $letraCalculada = $letras[(int)$numero % 23];
    $letraProporcionada = substr($nif, -1);
    
    return $letraCalculada === $letraProporcionada;
}

/**
 * Sanitiza un nÃºmero entero
 * 
 * @param mixed $numero NÃºmero a sanitizar
 * @return int NÃºmero entero
 */
function sanitizar_int($numero) {
    return (int) filter_var($numero, FILTER_SANITIZE_NUMBER_INT);
}

/**
 * Sanitiza un nÃºmero decimal
 * 
 * @param mixed $numero NÃºmero a sanitizar
 * @return float NÃºmero decimal
 */
function sanitizar_float($numero) {
    return (float) filter_var($numero, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
}

// ============================================================================
// PROTECCIÃ“N CSRF
// ============================================================================

/**
 * Genera un token CSRF y lo guarda en sesiÃ³n
 * 
 * @return string Token CSRF
 */
function generar_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * Genera el campo HTML oculto con el token CSRF
 * 
 * @return string HTML del input hidden
 */
function csrf_campo() {
    $token = generar_csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * Verifica que el token CSRF sea vÃ¡lido
 * 
 * @param string $token Token a verificar (si no se pasa, se toma de POST)
 * @return bool True si es vÃ¡lido
 */
function verificar_csrf($token = null) {
    if ($token === null) {
        $token = $_POST['csrf_token'] ?? '';
    }
    
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    
    // Verificar que no haya expirado (1 hora)
    $tiempoToken = $_SESSION['csrf_token_time'] ?? 0;
    if (time() - $tiempoToken > 3600) {
        unset($_SESSION['csrf_token'], $_SESSION['csrf_token_time']);
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Regenera el token CSRF (usar despuÃ©s de acciones importantes)
 */
function regenerar_csrf() {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_time'] = time();
}

// ============================================================================
// RATE LIMITING (ProtecciÃ³n contra fuerza bruta)
// ============================================================================

/**
 * Verifica si una IP o NIF estÃ¡ bloqueado por demasiados intentos
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param string $nif NIF del usuario
 * @param string $ip DirecciÃ³n IP
 * @return array ['bloqueado' => bool, 'segundos_restantes' => int, 'intentos' => int]
 */
function verificar_rate_limit($pdo, $nif, $ip) {
    $resultado = [
        'bloqueado' => false,
        'segundos_restantes' => 0,
        'intentos' => 0
    ];
    
    // Tiempo de ventana (15 minutos)
    $ventana = 15 * 60;
    $limite = time() - $ventana;
    
    // Contar intentos fallidos por NIF
    $sql = "SELECT COUNT(*) as intentos FROM intentos_login 
            WHERE nif = ? AND exito = 0 AND created_at > FROM_UNIXTIME(?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nif, $limite]);
    $intentosNif = $stmt->fetch()->intentos;
    
    // Contar intentos fallidos por IP
    $sql = "SELECT COUNT(*) as intentos FROM intentos_login 
            WHERE ip_address = ? AND exito = 0 AND created_at > FROM_UNIXTIME(?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$ip, $limite]);
    $intentosIp = $stmt->fetch()->intentos;
    
    $resultado['intentos'] = max($intentosNif, $intentosIp);
    
    // MÃ¡ximo intentos permitidos
    $maxIntentos = defined('MAX_LOGIN_ATTEMPTS') ? MAX_LOGIN_ATTEMPTS : 5;
    
    if ($resultado['intentos'] >= $maxIntentos) {
        $resultado['bloqueado'] = true;
        
        // Calcular segundos restantes
        $sql = "SELECT MAX(created_at) as ultimo FROM intentos_login 
                WHERE (nif = ? OR ip_address = ?) AND exito = 0";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nif, $ip]);
        $ultimo = $stmt->fetch()->ultimo;
        
        if ($ultimo) {
            $tiempoBloqueo = defined('LOCKOUT_TIME') ? LOCKOUT_TIME : 1800;
            $desbloqueo = strtotime($ultimo) + $tiempoBloqueo;
            $resultado['segundos_restantes'] = max(0, $desbloqueo - time());
            
            // Si ya pasÃ³ el tiempo de bloqueo, no estÃ¡ bloqueado
            if ($resultado['segundos_restantes'] <= 0) {
                $resultado['bloqueado'] = false;
            }
        }
    }
    
    return $resultado;
}

/**
 * Registra un intento de login
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param string $nif NIF del usuario
 * @param bool $exito Si el login fue exitoso
 */
function registrar_intento_login($pdo, $nif, $exito = false) {
    $ip = obtener_ip_cliente();
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $sql = "INSERT INTO intentos_login (nif, ip_address, user_agent, exito) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([sanitizar_nif($nif), $ip, substr($userAgent, 0, 255), $exito ? 1 : 0]);
    
    // Limpiar intentos antiguos (mÃ¡s de 90 dÃ­as)
    $diasRetencion = 90;
    $sql = "DELETE FROM intentos_login WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$diasRetencion]);
}

/**
 * Limpia los intentos fallidos de un usuario (despuÃ©s de login exitoso)
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param string $nif NIF del usuario
 */
function limpiar_intentos_fallidos($pdo, $nif) {
    // No eliminamos los registros, solo marcamos que hubo Ã©xito
    // Esto mantiene el historial para auditorÃ­a
}

// ============================================================================
// UTILIDADES DE SEGURIDAD
// ============================================================================

/**
 * Obtiene la IP real del cliente
 * 
 * @return string DirecciÃ³n IP
 */
function obtener_ip_cliente() {
    $ip = '';
    
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Puede contener mÃºltiples IPs separadas por coma
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    // Validar que sea una IP vÃ¡lida
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = '0.0.0.0';
    }
    
    return $ip;
}

/**
 * Genera una contraseÃ±a aleatoria segura
 * 
 * @param int $longitud Longitud de la contraseÃ±a
 * @return string ContraseÃ±a generada
 */
function generar_password($longitud = 12) {
    $mayusculas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $minusculas = 'abcdefghijklmnopqrstuvwxyz';
    $numeros = '0123456789';
    $especiales = '!@#$%&*';
    
    $todos = $mayusculas . $minusculas . $numeros . $especiales;
    
    // Asegurar al menos uno de cada tipo
    $password = $mayusculas[random_int(0, strlen($mayusculas) - 1)];
    $password .= $minusculas[random_int(0, strlen($minusculas) - 1)];
    $password .= $numeros[random_int(0, strlen($numeros) - 1)];
    $password .= $especiales[random_int(0, strlen($especiales) - 1)];
    
    // Rellenar el resto
    for ($i = 4; $i < $longitud; $i++) {
        $password .= $todos[random_int(0, strlen($todos) - 1)];
    }
    
    // Mezclar
    return str_shuffle($password);
}

/**
 * Verifica fortaleza de una contraseÃ±a
 * 
 * @param string $password ContraseÃ±a a verificar
 * @return array ['valida' => bool, 'errores' => array]
 */
function verificar_fortaleza_password($password) {
    $errores = [];
    
    if (strlen($password) < 8) {
        $errores[] = 'MÃ­nimo 8 caracteres';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errores[] = 'Debe contener al menos una mayÃºscula';
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errores[] = 'Debe contener al menos una minÃºscula';
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errores[] = 'Debe contener al menos un nÃºmero';
    }
    
    return [
        'valida' => empty($errores),
        'errores' => $errores
    ];
}

/**
 * Hashea una contraseÃ±a de forma segura
 * 
 * @param string $password ContraseÃ±a en texto plano
 * @return string Hash de la contraseÃ±a
 */
function hashear_password($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verifica una contraseÃ±a contra su hash
 * 
 * @param string $password ContraseÃ±a en texto plano
 * @param string $hash Hash almacenado
 * @return bool True si coincide
 */
function verificar_password($password, $hash) {
    return password_verify($password, $hash);
}

// ============================================================================
// HEADERS DE SEGURIDAD
// ============================================================================

/**
 * Establece los headers de seguridad HTTP
 */
function establecer_headers_seguridad() {
    // Solo en producciÃ³n o si HTTPS estÃ¡ activo
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        // HSTS - Forzar HTTPS
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    
    // Prevenir clickjacking
    header('X-Frame-Options: DENY');
    
    // Prevenir sniffing de MIME type
    header('X-Content-Type-Options: nosniff');
    
    // Filtro XSS del navegador
    header('X-XSS-Protection: 1; mode=block');
    
    // Referrer policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Content Security Policy bÃ¡sica
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'");
}

// ============================================================================
// PROTECCIÃ“N DE SESIÃ“N
// ============================================================================

/**
 * Verifica que la sesiÃ³n sea vÃ¡lida y no haya expirado
 * 
 * @return bool True si la sesiÃ³n es vÃ¡lida
 */
function verificar_sesion_valida() {
    // Si no hay sesiÃ³n iniciada
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    
    // Si no hay usuario logueado
    if (empty($_SESSION['usuario_id'])) {
        return false;
    }
    
    // Verificar timeout
    $timeout = defined('SESSION_TIMEOUT') ? SESSION_TIMEOUT : 1800;
    if (isset($_SESSION['ultimo_acceso'])) {
        if (time() - $_SESSION['ultimo_acceso'] > $timeout) {
            // SesiÃ³n expirada
            session_unset();
            session_destroy();
            return false;
        }
    }
    
    // Actualizar Ãºltimo acceso
    $_SESSION['ultimo_acceso'] = time();
    
    return true;
}

/**
 * Regenera el ID de sesiÃ³n (usar en login y cambios de privilegios)
 */
function regenerar_sesion() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

/**
 * Destruye la sesiÃ³n completamente
 */
function destruir_sesion() {
    $_SESSION = [];
    
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    
    session_destroy();
}

// ============================================================================
// VALIDACIÃ“N DE FECHAS Y HORAS
// ============================================================================

/**
 * Valida formato de fecha
 * 
 * @param string $fecha Fecha a validar
 * @param string $formato Formato esperado (por defecto Y-m-d)
 * @return bool True si es vÃ¡lida
 */
function validar_fecha($fecha, $formato = 'Y-m-d') {
    $d = DateTime::createFromFormat($formato, $fecha);
    return $d && $d->format($formato) === $fecha;
}

/**
 * Valida formato de hora
 * 
 * @param string $hora Hora a validar
 * @param string $formato Formato esperado (por defecto H:i)
 * @return bool True si es vÃ¡lida
 */
function validar_hora($hora, $formato = 'H:i') {
    $h = DateTime::createFromFormat($formato, $hora);
    return $h && $h->format($formato) === $hora;
}

/**
 * Alias para generar_csrf_token (compatibilidad)
 */
function generar_csrf() {
    return generar_csrf_token();
}
