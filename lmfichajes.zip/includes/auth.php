<?php
/**
 * LM FICHAJES - Funciones de AutenticaciÃ³n
 * 
 * Funciones para login, logout, verificaciÃ³n de sesiÃ³n y gestiÃ³n de usuarios.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      Roberto LÃ³pez Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// Incluir seguridad si no estÃ¡ incluida
require_once __DIR__ . '/seguridad.php';

// Incluir sistema de auditoría ENS
if (file_exists(__DIR__ . '/auditoria.php')) {
    require_once __DIR__ . '/auditoria.php';
}

// ============================================================================
// FUNCIONES DE LOGIN
// ============================================================================

/**
 * Intenta autenticar a un usuario con NIF y contraseÃ±a
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param string $nif NIF del usuario
 * @param string $password ContraseÃ±a
 * @return array ['exito' => bool, 'mensaje' => string, 'usuario' => object|null]
 */
function intentar_login($pdo, $nif, $password) {
    $resultado = [
        'exito' => false,
        'mensaje' => '',
        'usuario' => null,
        'requiere_mfa' => false
    ];
    
    // Sanitizar NIF
    $nif = sanitizar_nif($nif);
    $ip = obtener_ip_cliente();
    
    // Verificar rate limiting
    $rateLimit = verificar_rate_limit($pdo, $nif, $ip);
    if ($rateLimit['bloqueado']) {
        $minutos = ceil($rateLimit['segundos_restantes'] / 60);
        $resultado['mensaje'] = "Demasiados intentos fallidos. Espera {$minutos} minutos.";
        return $resultado;
    }
    
    // Buscar usuario
    $sql = "SELECT * FROM empleados WHERE nif = ? AND activo = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nif]);
    $usuario = $stmt->fetch();
    
    if (!$usuario) {
        registrar_intento_login($pdo, $nif, false);
        $resultado['mensaje'] = 'NIF o contraseÃ±a incorrectos';
        
        // ========== AUDITORÍA ENS: Login fallido ==========
        if (function_exists('audit_login_fail')) {
            audit_login_fail($nif, 'Usuario no encontrado o inactivo');
        }
        // ==================================================
        
        return $resultado;
    }
    
    // Verificar si estÃ¡ bloqueado temporalmente
    if ($usuario->bloqueado_hasta && strtotime($usuario->bloqueado_hasta) > time()) {
        $minutos = ceil((strtotime($usuario->bloqueado_hasta) - time()) / 60);
        $resultado['mensaje'] = "Cuenta bloqueada temporalmente. Espera {$minutos} minutos.";
        return $resultado;
    }
    
    // Verificar contraseÃ±a
    if (!verificar_password($password, $usuario->password)) {
        registrar_intento_login($pdo, $nif, false);
        
        // Incrementar intentos fallidos del usuario
        $intentos = $usuario->intentos_fallidos + 1;
        $maxIntentos = defined('MAX_LOGIN_ATTEMPTS') ? MAX_LOGIN_ATTEMPTS : 5;
        
        if ($intentos >= $maxIntentos) {
            // Bloquear cuenta
            $tiempoBloqueo = defined('LOCKOUT_TIME') ? LOCKOUT_TIME : 1800;
            $bloqueadoHasta = date('Y-m-d H:i:s', time() + $tiempoBloqueo);
            
            $sql = "UPDATE empleados SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$intentos, $bloqueadoHasta, $usuario->id]);
            
            $resultado['mensaje'] = 'Cuenta bloqueada por demasiados intentos fallidos';
            
            // ========== AUDITORÍA ENS: Cuenta bloqueada ==========
            if (function_exists('audit_login_fail')) {
                audit_login_fail($nif, 'Cuenta bloqueada por intentos fallidos');
            }
            // =====================================================
        } else {
            $sql = "UPDATE empleados SET intentos_fallidos = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$intentos, $usuario->id]);
            
            $restantes = $maxIntentos - $intentos;
            $resultado['mensaje'] = "NIF o contraseÃ±a incorrectos. Te quedan {$restantes} intentos.";
            
            // ========== AUDITORÍA ENS: Contraseña incorrecta ==========
            if (function_exists('audit_login_fail')) {
                audit_login_fail($nif, "Contraseña incorrecta - Intento {$intentos}/{$maxIntentos}");
            }
            // ==========================================================
        }
        
        return $resultado;
    }
    
    // ========== VERIFICAR SI DEBE CAMBIAR CONTRASEÑA ==========
    if ($usuario->debe_cambiar_password) {
        // Guardar en sesión temporal para el cambio de contraseña
        $_SESSION['cambio_password_pendiente'] = true;
        $_SESSION['cambio_password_usuario_id'] = $usuario->id;
        $_SESSION['cambio_password_usuario_nombre'] = $usuario->nombre;
        
        $resultado['exito'] = true;
        $resultado['requiere_cambio_password'] = true;
        $resultado['mensaje'] = 'Debes cambiar tu contraseña';
        
        return $resultado;
    }
    // ==========================================================
    
    // Login correcto - Verificar si requiere MFA
    if ($usuario->mfa_activo) {
        $resultado['exito'] = true;
        $resultado['requiere_mfa'] = true;
        $resultado['usuario'] = $usuario;
        $resultado['mensaje'] = 'Se requiere verificaciÃ³n en dos pasos';
        
        // Guardar en sesiÃ³n temporal para MFA
        $_SESSION['mfa_pendiente'] = true;
        $_SESSION['mfa_usuario_id'] = $usuario->id;
        
        return $resultado;
    }
    
    // Login completo
    completar_login($pdo, $usuario);
    
    $resultado['exito'] = true;
    $resultado['usuario'] = $usuario;
    $resultado['mensaje'] = 'Login correcto';
    
    return $resultado;
}

/**
 * Completa el proceso de login (despuÃ©s de verificar MFA si aplica)
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param object $usuario Objeto usuario de la BD
 */
function completar_login($pdo, $usuario) {
    // Regenerar sesiÃ³n por seguridad
    regenerar_sesion();
    
    // Guardar datos en sesiÃ³n
    $_SESSION['usuario_id'] = $usuario->id;
    $_SESSION['usuario_nif'] = $usuario->nif;
    $_SESSION['usuario_nombre'] = $usuario->nombre . ' ' . $usuario->apellido1;
    $_SESSION['usuario_rol'] = $usuario->rol;
    $_SESSION['ultimo_acceso'] = time();
    $_SESSION['ip_login'] = obtener_ip_cliente();
    
    // Limpiar flags de MFA si existÃ­an
    unset($_SESSION['mfa_pendiente'], $_SESSION['mfa_usuario_id']);
    
    // Actualizar BD: Ãºltimo acceso, resetear intentos fallidos
    $sql = "UPDATE empleados SET 
            ultimo_acceso = NOW(), 
            intentos_fallidos = 0, 
            bloqueado_hasta = NULL 
            WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario->id]);
    
    // Registrar intento exitoso
    registrar_intento_login($pdo, $usuario->nif, true);
    
    // ========== AUDITORÍA ENS: Login exitoso ==========
    if (function_exists('audit_login_ok')) {
        audit_login_ok($usuario->id, $usuario->nif);
    }
    // ==================================================
}

/**
 * Cierra la sesiÃ³n del usuario
 */
function cerrar_sesion() {
    // ========== AUDITORÍA ENS: Logout ==========
    if (function_exists('audit_logout') && isset($_SESSION['usuario_id'])) {
        audit_logout($_SESSION['usuario_id']);
    }
    // ===========================================
    
    destruir_sesion();
}

// ============================================================================
// VERIFICACIÃ“N DE SESIÃ“N Y PERMISOS
// ============================================================================

/**
 * Verifica si el usuario estÃ¡ logueado
 * 
 * @return bool True si estÃ¡ logueado
 */
function esta_logueado() {
    return verificar_sesion_valida();
}

/**
 * Requiere que el usuario estÃ© logueado, si no redirige al login
 * 
 * @param string $redireccion URL de redirecciÃ³n (por defecto login.php)
 */
function requerir_login($redireccion = 'login.php') {
    if (!esta_logueado()) {
        header('Location: ' . $redireccion);
        exit;
    }
}

/**
 * Verifica si el usuario tiene un rol especÃ­fico
 * 
 * @param string|array $roles Rol o array de roles permitidos
 * @return bool True si tiene el rol
 */
function tiene_rol($roles) {
    if (!esta_logueado()) {
        return false;
    }
    
    if (!is_array($roles)) {
        $roles = [$roles];
    }
    
    return in_array($_SESSION['usuario_rol'] ?? '', $roles);
}

/**
 * Requiere que el usuario tenga un rol especÃ­fico
 * 
 * @param string|array $roles Rol o array de roles permitidos
 * @param string $redireccion URL si no tiene permisos
 */
function requerir_rol($roles, $redireccion = 'portal.php') {
    requerir_login();
    
    if (!tiene_rol($roles)) {
        $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta secciÃ³n';
        header('Location: ' . $redireccion);
        exit;
    }
}

/**
 * Verifica si el usuario es administrador
 * 
 * @return bool
 */
function es_admin() {
    return tiene_rol('admin');
}

/**
 * Verifica si el usuario es manager o superior
 * 
 * @return bool
 */
function es_manager() {
    return tiene_rol(['manager', 'admin']);
}

/**
 * Verifica si el usuario es supervisor o superior
 * 
 * @return bool
 */
function es_supervisor() {
    return tiene_rol(['supervisor', 'manager', 'admin']);
}

// ============================================================================
// OBTENER DATOS DEL USUARIO
// ============================================================================

/**
 * Obtiene el ID del usuario logueado
 * 
 * @return int|null ID del usuario o null si no estÃ¡ logueado
 */
function obtener_usuario_id() {
    return $_SESSION['usuario_id'] ?? null;
}

/**
 * Obtiene el nombre completo del usuario logueado
 * 
 * @return string|null Nombre o null si no estÃ¡ logueado
 */
function obtener_usuario_nombre() {
    return $_SESSION['usuario_nombre'] ?? null;
}

/**
 * Obtiene el rol del usuario logueado
 * 
 * @return string|null Rol o null si no estÃ¡ logueado
 */
function obtener_usuario_rol() {
    return $_SESSION['usuario_rol'] ?? null;
}

/**
 * Obtiene los datos completos del usuario logueado desde BD
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @return object|null Datos del usuario o null
 */
function obtener_usuario_actual($pdo) {
    $id = obtener_usuario_id();
    if (!$id) {
        return null;
    }
    
    $sql = "SELECT e.*, h.nombre as horario_nombre,
            h.hora_entrada, h.hora_salida, h.troncal_inicio, h.troncal_fin,
            h.tipo as horario_tipo
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE e.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    
    return $stmt->fetch();
}

/**
 * Obtiene los centros asignados al usuario
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param int $empleadoId ID del empleado (si no se pasa, usa el logueado)
 * @return array Array de centros
 */
function obtener_centros_usuario($pdo, $empleadoId = null) {
    if ($empleadoId === null) {
        $empleadoId = obtener_usuario_id();
    }
    
    if (!$empleadoId) {
        return [];
    }
    
    try {
        $sql = "SELECT c.*, ec.es_principal
                FROM centros c
                INNER JOIN empleados_centros ec ON c.id = ec.centro_id
                WHERE ec.empleado_id = ? AND ec.activo = 1 AND c.activo = 1
                ORDER BY ec.es_principal DESC, c.nombre ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$empleadoId]);
        
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        // Tabla empleados_centros puede no existir - devolver array vacío
        return [];
    }
}

// ============================================================================
// GESTIÃ“N DE CONTRASEÃ‘AS
// ============================================================================

/**
 * Cambia la contraseÃ±a de un usuario
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param int $usuarioId ID del usuario
 * @param string $passwordActual ContraseÃ±a actual
 * @param string $passwordNueva Nueva contraseÃ±a
 * @return array ['exito' => bool, 'mensaje' => string]
 */
function cambiar_password($pdo, $usuarioId, $passwordActual, $passwordNueva) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    
    // Obtener usuario
    $sql = "SELECT password FROM empleados WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuarioId]);
    $usuario = $stmt->fetch();
    
    if (!$usuario) {
        $resultado['mensaje'] = 'Usuario no encontrado';
        return $resultado;
    }
    
    // Verificar contraseÃ±a actual
    if (!verificar_password($passwordActual, $usuario->password)) {
        $resultado['mensaje'] = 'La contraseÃ±a actual no es correcta';
        return $resultado;
    }
    
    // Verificar fortaleza de la nueva
    $fortaleza = verificar_fortaleza_password($passwordNueva);
    if (!$fortaleza['valida']) {
        $resultado['mensaje'] = 'La nueva contraseÃ±a no es suficientemente segura: ' . implode(', ', $fortaleza['errores']);
        return $resultado;
    }
    
    // Actualizar contraseÃ±a
    $hash = hashear_password($passwordNueva);
    $sql = "UPDATE empleados SET password = ?, password_cambiado = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$hash, $usuarioId]);
    
    $resultado['exito'] = true;
    $resultado['mensaje'] = 'ContraseÃ±a actualizada correctamente';
    
    return $resultado;
}

/**
 * Resetea la contraseÃ±a de un usuario (admin)
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param int $usuarioId ID del usuario
 * @return array ['exito' => bool, 'mensaje' => string, 'password' => string]
 */
function resetear_password($pdo, $usuarioId) {
    $resultado = ['exito' => false, 'mensaje' => '', 'password' => ''];
    
    // Generar nueva contraseÃ±a
    $passwordNueva = generar_password(10);
    $hash = hashear_password($passwordNueva);
    
    // Actualizar
    $sql = "UPDATE empleados SET password = ?, password_cambiado = NULL, intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    
    try {
        $stmt->execute([$hash, $usuarioId]);
        $resultado['exito'] = true;
        $resultado['password'] = $passwordNueva;
        $resultado['mensaje'] = 'ContraseÃ±a reseteada correctamente';
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al resetear la contraseÃ±a';
    }
    
    return $resultado;
}

// ============================================================================
// TRADUCCIÃ“N DE ROLES
// ============================================================================

/**
 * Traduce el cÃ³digo de rol a texto legible
 * 
 * @param string $rol CÃ³digo del rol
 * @return string Nombre legible
 */
function traducir_rol($rol) {
    $roles = [
        'empleado' => 'Empleado',
        'supervisor' => 'Supervisor',
        'manager' => 'Manager',
        'admin' => 'Administrador'
    ];
    
    return $roles[$rol] ?? $rol;
}
