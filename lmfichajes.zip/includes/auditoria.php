<?php
/**
 * LM FICHAJES - Sistema de Auditoría ENS Profesional
 * 
 * Cumplimiento del Esquema Nacional de Seguridad (ENS)
 * Real Decreto 311/2022
 * 
 * MEJORAS v2.0:
 * - Nuevos tipos de eventos
 * - Auditoría de sesión expirada
 * - Auditoría de cambio de contraseña
 * - Auditoría de empleados (CRUD)
 * - Auditoría de horarios, centros, configuración
 * - Hash de integridad para registros críticos
 * - Funciones helper simplificadas
 * 
 * @package     LMFichajes
 * @subpackage  Core
 * @version     2.0.0
 * @date        2026-01-06
 */

defined('LMFICHAJES') or die('Acceso no permitido');

// ============================================================================
// TIPOS DE EVENTOS DE AUDITORÍA
// ============================================================================

// Accesos
if (!defined('AUDIT_LOGIN_OK')) define('AUDIT_LOGIN_OK', 'LOGIN_OK');
if (!defined('AUDIT_LOGIN_FAIL')) define('AUDIT_LOGIN_FAIL', 'LOGIN_FAIL');
if (!defined('AUDIT_LOGOUT')) define('AUDIT_LOGOUT', 'LOGOUT');
if (!defined('AUDIT_SESSION_EXPIRED')) define('AUDIT_SESSION_EXPIRED', 'SESSION_EXPIRED');
if (!defined('AUDIT_PASSWORD_CHANGED')) define('AUDIT_PASSWORD_CHANGED', 'PASSWORD_CHANGED');
if (!defined('AUDIT_PASSWORD_RESET')) define('AUDIT_PASSWORD_RESET', 'PASSWORD_RESET');

// CRUD genérico
if (!defined('AUDIT_CREATE')) define('AUDIT_CREATE', 'CREATE');
if (!defined('AUDIT_READ')) define('AUDIT_READ', 'READ');
if (!defined('AUDIT_UPDATE')) define('AUDIT_UPDATE', 'UPDATE');
if (!defined('AUDIT_DELETE')) define('AUDIT_DELETE', 'DELETE');

// Fichajes
if (!defined('AUDIT_FICHAJE')) define('AUDIT_FICHAJE', 'FICHAJE');
if (!defined('AUDIT_FICHAJE_MANUAL')) define('AUDIT_FICHAJE_MANUAL', 'FICHAJE_MANUAL');
if (!defined('AUDIT_FICHAJE_EDITADO')) define('AUDIT_FICHAJE_EDITADO', 'FICHAJE_EDITADO');
if (!defined('AUDIT_FICHAJE_ELIMINADO')) define('AUDIT_FICHAJE_ELIMINADO', 'FICHAJE_ELIMINADO');
if (!defined('AUDIT_VALIDACION')) define('AUDIT_VALIDACION', 'VALIDACION');

// Empleados
if (!defined('AUDIT_EMPLEADO_CREADO')) define('AUDIT_EMPLEADO_CREADO', 'EMPLEADO_CREADO');
if (!defined('AUDIT_EMPLEADO_EDITADO')) define('AUDIT_EMPLEADO_EDITADO', 'EMPLEADO_EDITADO');
if (!defined('AUDIT_EMPLEADO_BAJA')) define('AUDIT_EMPLEADO_BAJA', 'EMPLEADO_BAJA');
if (!defined('AUDIT_EMPLEADO_ALTA')) define('AUDIT_EMPLEADO_ALTA', 'EMPLEADO_ALTA');

// Ausencias
if (!defined('AUDIT_AUSENCIA')) define('AUDIT_AUSENCIA', 'AUSENCIA');
if (!defined('AUDIT_AUSENCIA_APROBADA')) define('AUDIT_AUSENCIA_APROBADA', 'AUSENCIA_APROBADA');
if (!defined('AUDIT_AUSENCIA_RECHAZADA')) define('AUDIT_AUSENCIA_RECHAZADA', 'AUSENCIA_RECHAZADA');

// Configuración y sistema
if (!defined('AUDIT_CONFIG_CHANGE')) define('AUDIT_CONFIG_CHANGE', 'CONFIG_CHANGE');
if (!defined('AUDIT_HORARIO_CHANGE')) define('AUDIT_HORARIO_CHANGE', 'HORARIO_CHANGE');
if (!defined('AUDIT_CENTRO_CHANGE')) define('AUDIT_CENTRO_CHANGE', 'CENTRO_CHANGE');

// Seguridad
if (!defined('AUDIT_PERMISSION_DENIED')) define('AUDIT_PERMISSION_DENIED', 'PERMISSION_DENIED');
if (!defined('AUDIT_SECURITY_ALERT')) define('AUDIT_SECURITY_ALERT', 'SECURITY_ALERT');
if (!defined('AUDIT_CSRF_FAIL')) define('AUDIT_CSRF_FAIL', 'CSRF_FAIL');

// Datos y exportación
if (!defined('AUDIT_EXPORT_DATA')) define('AUDIT_EXPORT_DATA', 'EXPORT_DATA');
if (!defined('AUDIT_RGPD_REQUEST')) define('AUDIT_RGPD_REQUEST', 'RGPD_REQUEST');
if (!defined('AUDIT_BACKUP')) define('AUDIT_BACKUP', 'BACKUP');

// ============================================================================
// NIVELES DE SEVERIDAD
// ============================================================================

if (!defined('AUDIT_LEVEL_INFO')) define('AUDIT_LEVEL_INFO', 'INFO');
if (!defined('AUDIT_LEVEL_WARNING')) define('AUDIT_LEVEL_WARNING', 'WARNING');
if (!defined('AUDIT_LEVEL_ERROR')) define('AUDIT_LEVEL_ERROR', 'ERROR');
if (!defined('AUDIT_LEVEL_CRITICAL')) define('AUDIT_LEVEL_CRITICAL', 'CRITICAL');

// ============================================================================
// FUNCIÓN PRINCIPAL DE REGISTRO
// ============================================================================

/**
 * Registra un evento de auditoría
 */
function registrar_auditoria($tipo, $descripcion, $datos = [], $nivel = AUDIT_LEVEL_INFO, $usuarioId = null, $entidad = null, $entidadId = null) {
    global $pdo;
    
    if (!isset($pdo)) {
        return false;
    }
    
    // Si no hay usuario, intentar obtenerlo de la sesión
    if ($usuarioId === null && isset($_SESSION['usuario_id'])) {
        $usuarioId = $_SESSION['usuario_id'];
    }
    
    // Datos de contexto
    $ip = obtener_ip_cliente_audit();
    $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'CLI', 0, 500);
    $url = substr($_SERVER['REQUEST_URI'] ?? 'CLI', 0, 500);
    $metodo = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
    
    // Serializar datos adicionales
    $datosJson = !empty($datos) ? json_encode($datos, JSON_UNESCAPED_UNICODE) : null;
    
    // Hash de integridad para eventos críticos
    $hash = null;
    if (in_array($nivel, [AUDIT_LEVEL_CRITICAL, AUDIT_LEVEL_ERROR]) || 
        in_array($tipo, [AUDIT_LOGIN_FAIL, AUDIT_SECURITY_ALERT, AUDIT_DELETE, AUDIT_EMPLEADO_BAJA])) {
        $hash = hash('sha256', $tipo . $descripcion . $datosJson . $ip . date('Y-m-d H:i:s'));
    }
    
    try {
        // Verificar si existe la columna hash_integridad
        $sql = "INSERT INTO audit_log 
                (tipo, nivel, descripcion, datos, usuario_id, entidad, entidad_id,
                 ip_address, user_agent, url, metodo_http, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $tipo,
            $nivel,
            $descripcion,
            $datosJson,
            $usuarioId,
            $entidad,
            $entidadId,
            $ip,
            $userAgent,
            $url,
            $metodo
        ]);
        
        return true;
        
    } catch (PDOException $e) {
        // Si falla la auditoría, registrar en archivo de emergencia
        $logFile = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/logs/audit_emergency.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0750, true);
        }
        
        $logLine = date('Y-m-d H:i:s') . " | {$tipo} | {$nivel} | {$descripcion} | " . 
                   json_encode($datos) . " | Usuario:{$usuarioId} | IP:{$ip} | Error BD:" . 
                   $e->getMessage() . PHP_EOL;
        
        @file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
        
        return false;
    }
}

// ============================================================================
// FUNCIONES DE ACCESO
// ============================================================================

function audit_login_ok($usuarioId, $nif) {
    return registrar_auditoria(
        AUDIT_LOGIN_OK,
        "Inicio de sesión exitoso: {$nif}",
        ['nif' => $nif],
        AUDIT_LEVEL_INFO,
        $usuarioId,
        'empleados',
        $usuarioId
    );
}

function audit_login_fail($nif, $motivo = 'Credenciales incorrectas') {
    return registrar_auditoria(
        AUDIT_LOGIN_FAIL,
        "Intento de acceso fallido: {$nif} - {$motivo}",
        ['nif' => $nif, 'motivo' => $motivo],
        AUDIT_LEVEL_WARNING,
        null,
        'empleados',
        null
    );
}

function audit_logout($usuarioId) {
    return registrar_auditoria(
        AUDIT_LOGOUT,
        "Cierre de sesión",
        [],
        AUDIT_LEVEL_INFO,
        $usuarioId
    );
}

function audit_session_expired($usuarioId = null) {
    return registrar_auditoria(
        AUDIT_SESSION_EXPIRED,
        "Sesión expirada por inactividad",
        [],
        AUDIT_LEVEL_INFO,
        $usuarioId
    );
}

function audit_password_changed($usuarioId, $nif) {
    return registrar_auditoria(
        AUDIT_PASSWORD_CHANGED,
        "Contraseña cambiada: {$nif}",
        ['nif' => $nif],
        AUDIT_LEVEL_INFO,
        $usuarioId,
        'empleados',
        $usuarioId
    );
}

function audit_password_reset($empleadoId, $nif, $adminId) {
    return registrar_auditoria(
        AUDIT_PASSWORD_RESET,
        "Contraseña reseteada por admin: {$nif}",
        ['nif' => $nif, 'admin_id' => $adminId],
        AUDIT_LEVEL_WARNING,
        $adminId,
        'empleados',
        $empleadoId
    );
}

// ============================================================================
// FUNCIONES DE FICHAJES
// ============================================================================

function audit_fichaje($empleadoId, $tipo, $datos = []) {
    $tiposLegibles = [
        'entrada' => 'Entrada',
        'salida' => 'Salida',
        'pausa_inicio' => 'Inicio pausa',
        'pausa_fin' => 'Fin pausa',
        'visita' => 'Visita'
    ];
    
    return registrar_auditoria(
        AUDIT_FICHAJE,
        "Fichaje registrado: " . ($tiposLegibles[$tipo] ?? $tipo),
        $datos,
        AUDIT_LEVEL_INFO,
        $empleadoId,
        'fichajes',
        $datos['fichaje_id'] ?? null
    );
}

function audit_fichaje_manual($empleadoId, $tipo, $datos, $adminId) {
    $tiposLegibles = [
        'entrada' => 'Entrada',
        'salida' => 'Salida',
        'pausa_inicio' => 'Inicio pausa',
        'pausa_fin' => 'Fin pausa'
    ];
    
    return registrar_auditoria(
        AUDIT_FICHAJE_MANUAL,
        "Fichaje manual añadido: " . ($tiposLegibles[$tipo] ?? $tipo),
        array_merge($datos, ['creado_por' => $adminId]),
        AUDIT_LEVEL_WARNING,
        $adminId,
        'fichajes',
        $datos['fichaje_id'] ?? null
    );
}

function audit_fichaje_editado($fichajeId, $datosAntes, $datosDespues, $editorId) {
    return registrar_auditoria(
        AUDIT_FICHAJE_EDITADO,
        "Fichaje editado: ID {$fichajeId}",
        ['antes' => $datosAntes, 'despues' => $datosDespues],
        AUDIT_LEVEL_WARNING,
        $editorId,
        'fichajes',
        $fichajeId
    );
}

function audit_fichaje_eliminado($fichajeId, $datos, $editorId) {
    return registrar_auditoria(
        AUDIT_FICHAJE_ELIMINADO,
        "Fichaje eliminado: ID {$fichajeId}",
        $datos,
        AUDIT_LEVEL_WARNING,
        $editorId,
        'fichajes',
        $fichajeId
    );
}

function audit_validacion($fichajeId, $accion, $validadorId, $datos = []) {
    $nivel = ($accion === 'rechazar') ? AUDIT_LEVEL_WARNING : AUDIT_LEVEL_INFO;
    $acciones = ['validar' => 'Validado', 'rechazar' => 'Rechazado', 'aprobar' => 'Aprobado'];
    
    return registrar_auditoria(
        AUDIT_VALIDACION,
        "Fichaje " . ($acciones[$accion] ?? $accion) . ": ID {$fichajeId}",
        $datos,
        $nivel,
        $validadorId,
        'fichajes',
        $fichajeId
    );
}

// ============================================================================
// FUNCIONES DE EMPLEADOS
// ============================================================================

function audit_empleado_creado($empleadoId, $datos, $adminId) {
    // No incluir password en los datos
    unset($datos['password']);
    
    return registrar_auditoria(
        AUDIT_EMPLEADO_CREADO,
        "Empleado creado: {$datos['nombre']} {$datos['apellido1']} ({$datos['nif']})",
        $datos,
        AUDIT_LEVEL_INFO,
        $adminId,
        'empleados',
        $empleadoId
    );
}

function audit_empleado_editado($empleadoId, $datosAntes, $datosDespues, $editorId) {
    // No incluir passwords
    unset($datosAntes['password'], $datosDespues['password']);
    
    return registrar_auditoria(
        AUDIT_EMPLEADO_EDITADO,
        "Empleado editado: ID {$empleadoId}",
        ['antes' => $datosAntes, 'despues' => $datosDespues],
        AUDIT_LEVEL_INFO,
        $editorId,
        'empleados',
        $empleadoId
    );
}

function audit_empleado_baja($empleadoId, $nif, $nombre, $adminId) {
    return registrar_auditoria(
        AUDIT_EMPLEADO_BAJA,
        "Empleado dado de baja: {$nombre} ({$nif})",
        ['nif' => $nif, 'nombre' => $nombre],
        AUDIT_LEVEL_WARNING,
        $adminId,
        'empleados',
        $empleadoId
    );
}

function audit_empleado_alta($empleadoId, $nif, $nombre, $adminId) {
    return registrar_auditoria(
        AUDIT_EMPLEADO_ALTA,
        "Empleado reactivado: {$nombre} ({$nif})",
        ['nif' => $nif, 'nombre' => $nombre],
        AUDIT_LEVEL_INFO,
        $adminId,
        'empleados',
        $empleadoId
    );
}

// ============================================================================
// FUNCIONES DE AUSENCIAS
// ============================================================================

function audit_ausencia_solicitada($ausenciaId, $empleadoId, $datos) {
    return registrar_auditoria(
        AUDIT_AUSENCIA,
        "Ausencia solicitada: {$datos['tipo']}",
        $datos,
        AUDIT_LEVEL_INFO,
        $empleadoId,
        'ausencias',
        $ausenciaId
    );
}

function audit_ausencia_aprobada($ausenciaId, $datos, $aprobadorId) {
    return registrar_auditoria(
        AUDIT_AUSENCIA_APROBADA,
        "Ausencia aprobada: ID {$ausenciaId}",
        $datos,
        AUDIT_LEVEL_INFO,
        $aprobadorId,
        'ausencias',
        $ausenciaId
    );
}

function audit_ausencia_rechazada($ausenciaId, $datos, $aprobadorId) {
    return registrar_auditoria(
        AUDIT_AUSENCIA_RECHAZADA,
        "Ausencia rechazada: ID {$ausenciaId}",
        $datos,
        AUDIT_LEVEL_WARNING,
        $aprobadorId,
        'ausencias',
        $ausenciaId
    );
}

// ============================================================================
// FUNCIONES CRUD GENÉRICAS
// ============================================================================

function audit_crear($entidad, $entidadId, $descripcion, $datos = []) {
    return registrar_auditoria(
        AUDIT_CREATE,
        $descripcion,
        $datos,
        AUDIT_LEVEL_INFO,
        null,
        $entidad,
        $entidadId
    );
}

function audit_actualizar($entidad, $entidadId, $descripcion, $datosAntes = [], $datosDespues = []) {
    return registrar_auditoria(
        AUDIT_UPDATE,
        $descripcion,
        ['antes' => $datosAntes, 'despues' => $datosDespues],
        AUDIT_LEVEL_INFO,
        null,
        $entidad,
        $entidadId
    );
}

function audit_eliminar($entidad, $entidadId, $descripcion, $datos = []) {
    return registrar_auditoria(
        AUDIT_DELETE,
        $descripcion,
        $datos,
        AUDIT_LEVEL_WARNING,
        null,
        $entidad,
        $entidadId
    );
}

// ============================================================================
// FUNCIONES DE CONFIGURACIÓN
// ============================================================================

function audit_config_change($clave, $valorAntes, $valorDespues) {
    return registrar_auditoria(
        AUDIT_CONFIG_CHANGE,
        "Configuración cambiada: {$clave}",
        ['clave' => $clave, 'antes' => $valorAntes, 'despues' => $valorDespues],
        AUDIT_LEVEL_INFO,
        null,
        'configuracion',
        null
    );
}

function audit_horario_change($horarioId, $accion, $datos = []) {
    return registrar_auditoria(
        AUDIT_HORARIO_CHANGE,
        "Horario {$accion}: ID {$horarioId}",
        $datos,
        AUDIT_LEVEL_INFO,
        null,
        'horarios',
        $horarioId
    );
}

function audit_centro_change($centroId, $accion, $datos = []) {
    return registrar_auditoria(
        AUDIT_CENTRO_CHANGE,
        "Centro {$accion}: ID {$centroId}",
        $datos,
        AUDIT_LEVEL_INFO,
        null,
        'centros',
        $centroId
    );
}

// ============================================================================
// FUNCIONES DE SEGURIDAD
// ============================================================================

function audit_permiso_denegado($recurso, $motivo = '') {
    return registrar_auditoria(
        AUDIT_PERMISSION_DENIED,
        "Acceso denegado a: {$recurso}",
        ['motivo' => $motivo],
        AUDIT_LEVEL_WARNING
    );
}

function audit_alerta_seguridad($descripcion, $datos = []) {
    return registrar_auditoria(
        AUDIT_SECURITY_ALERT,
        $descripcion,
        $datos,
        AUDIT_LEVEL_CRITICAL
    );
}

function audit_csrf_fail($url) {
    return registrar_auditoria(
        AUDIT_CSRF_FAIL,
        "Token CSRF inválido en: {$url}",
        ['url' => $url],
        AUDIT_LEVEL_WARNING
    );
}

// ============================================================================
// FUNCIONES DE EXPORTACIÓN Y DATOS
// ============================================================================

function audit_exportacion($tipo, $filtros = [], $cantidadRegistros = 0) {
    return registrar_auditoria(
        AUDIT_EXPORT_DATA,
        "Exportación de datos: {$tipo}",
        ['filtros' => $filtros, 'registros' => $cantidadRegistros],
        AUDIT_LEVEL_INFO
    );
}

function audit_rgpd($tipo, $empleadoId, $datos = []) {
    return registrar_auditoria(
        AUDIT_RGPD_REQUEST,
        "Solicitud RGPD: {$tipo}",
        $datos,
        AUDIT_LEVEL_INFO,
        null,
        'empleados',
        $empleadoId
    );
}

// ============================================================================
// FUNCIONES DE CONSULTA
// ============================================================================

function obtener_auditoria($filtros = [], $limite = 100, $offset = 0) {
    global $pdo;
    
    $where = ["1=1"];
    $params = [];
    
    if (!empty($filtros['tipo'])) {
        $where[] = "a.tipo = ?";
        $params[] = $filtros['tipo'];
    }
    
    if (!empty($filtros['nivel'])) {
        $where[] = "a.nivel = ?";
        $params[] = $filtros['nivel'];
    }
    
    if (!empty($filtros['usuario_id'])) {
        $where[] = "a.usuario_id = ?";
        $params[] = $filtros['usuario_id'];
    }
    
    if (!empty($filtros['entidad'])) {
        $where[] = "a.entidad = ?";
        $params[] = $filtros['entidad'];
    }
    
    if (!empty($filtros['fecha_desde'])) {
        $where[] = "DATE(a.created_at) >= ?";
        $params[] = $filtros['fecha_desde'];
    }
    
    if (!empty($filtros['fecha_hasta'])) {
        $where[] = "DATE(a.created_at) <= ?";
        $params[] = $filtros['fecha_hasta'];
    }
    
    if (!empty($filtros['ip'])) {
        $where[] = "a.ip_address LIKE ?";
        $params[] = '%' . $filtros['ip'] . '%';
    }
    
    if (!empty($filtros['busqueda'])) {
        $where[] = "(a.descripcion LIKE ? OR a.datos LIKE ?)";
        $params[] = '%' . $filtros['busqueda'] . '%';
        $params[] = '%' . $filtros['busqueda'] . '%';
    }
    
    $whereSQL = implode(' AND ', $where);
    
    // Contar total
    $sqlCount = "SELECT COUNT(*) FROM audit_log a WHERE {$whereSQL}";
    $stmt = $pdo->prepare($sqlCount);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // Obtener registros
    $sql = "SELECT a.*, e.nombre, e.apellido1, e.nif
            FROM audit_log a
            LEFT JOIN empleados e ON a.usuario_id = e.id
            WHERE {$whereSQL}
            ORDER BY a.created_at DESC
            LIMIT " . (int)$limite . " OFFSET " . (int)$offset;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return [
        'registros' => $stmt->fetchAll(),
        'total' => $total,
        'paginas' => ceil($total / $limite)
    ];
}

function obtener_resumen_auditoria($dias = 7) {
    global $pdo;
    
    $sql = "SELECT 
                tipo,
                nivel,
                COUNT(*) as total
            FROM audit_log
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY tipo, nivel
            ORDER BY total DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$dias]);
    
    return $stmt->fetchAll();
}

function obtener_estadisticas_auditoria($dias = 30) {
    global $pdo;
    
    $stats = [];
    
    // Total registros
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM audit_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->execute([$dias]);
    $stats['total'] = $stmt->fetchColumn();
    
    // Por nivel
    $stmt = $pdo->prepare("SELECT nivel, COUNT(*) as total FROM audit_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY nivel");
    $stmt->execute([$dias]);
    $stats['por_nivel'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Logins fallidos
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM audit_log WHERE tipo = 'LOGIN_FAIL' AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->execute([$dias]);
    $stats['logins_fallidos'] = $stmt->fetchColumn();
    
    // Alertas de seguridad
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM audit_log WHERE nivel = 'CRITICAL' AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->execute([$dias]);
    $stats['alertas_criticas'] = $stmt->fetchColumn();
    
    return $stats;
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

function obtener_ip_cliente_audit() {
    $headers = [
        'HTTP_CF_CONNECTING_IP',     // Cloudflare
        'HTTP_X_FORWARDED_FOR',      // Proxies
        'HTTP_X_REAL_IP',            // Nginx
        'REMOTE_ADDR'                // Directo
    ];
    
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = $_SERVER[$header];
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    
    return '0.0.0.0';
}

function limpiar_auditoria_antigua($diasRetencion = 1460) { // 4 años por defecto
    global $pdo;
    
    try {
        $sql = "DELETE FROM audit_log WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$diasRetencion]);
        
        $eliminados = $stmt->rowCount();
        
        if ($eliminados > 0) {
            registrar_auditoria(
                AUDIT_CONFIG_CHANGE,
                "Limpieza de auditoría: {$eliminados} registros eliminados",
                ['dias_retencion' => $diasRetencion, 'registros_eliminados' => $eliminados],
                AUDIT_LEVEL_INFO,
                null,
                'audit_log',
                null
            );
        }
        
        return $eliminados;
        
    } catch (PDOException $e) {
        error_log("Error limpiando auditoría: " . $e->getMessage());
        return false;
    }
}

/**
 * Traduce tipo de acción a texto legible para mostrar en UI
 */
function traducir_tipo_auditoria($tipo) {
    $traducciones = [
        'LOGIN_OK' => 'Inicio de sesión',
        'LOGIN_FAIL' => 'Login fallido',
        'LOGOUT' => 'Cierre de sesión',
        'SESSION_EXPIRED' => 'Sesión expirada',
        'PASSWORD_CHANGED' => 'Cambio de contraseña',
        'PASSWORD_RESET' => 'Reset de contraseña',
        'FICHAJE' => 'Fichaje',
        'FICHAJE_MANUAL' => 'Fichaje manual',
        'FICHAJE_EDITADO' => 'Fichaje editado',
        'FICHAJE_ELIMINADO' => 'Fichaje eliminado',
        'VALIDACION' => 'Validación',
        'EMPLEADO_CREADO' => 'Empleado creado',
        'EMPLEADO_EDITADO' => 'Empleado editado',
        'EMPLEADO_BAJA' => 'Empleado baja',
        'EMPLEADO_ALTA' => 'Empleado alta',
        'AUSENCIA' => 'Ausencia solicitada',
        'AUSENCIA_APROBADA' => 'Ausencia aprobada',
        'AUSENCIA_RECHAZADA' => 'Ausencia rechazada',
        'CONFIG_CHANGE' => 'Cambio configuración',
        'HORARIO_CHANGE' => 'Cambio horario',
        'CENTRO_CHANGE' => 'Cambio centro',
        'PERMISSION_DENIED' => 'Acceso denegado',
        'SECURITY_ALERT' => 'Alerta seguridad',
        'CSRF_FAIL' => 'Error CSRF',
        'EXPORT_DATA' => 'Exportación datos',
        'CREATE' => 'Creación',
        'UPDATE' => 'Actualización',
        'DELETE' => 'Eliminación',
        'READ' => 'Lectura'
    ];
    
    return $traducciones[$tipo] ?? $tipo;
}
