<?php
/**
 * LM FICHAJES - Funciones de Documentos
 * 
 * Gestión de nóminas, circulares y documentos personales.
 * 
 * CORREGIDO: Usa tabla documentos_empleado (singular) compatible con admin/documentos.php
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      Roberto López Miquel
 * @version     2.0.0
 * @date        2026-01-11
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// ============================================================================
// CONSTANTES DE DOCUMENTOS
// ============================================================================

define('DOCUMENTOS_PATH', __DIR__ . '/../uploads/documentos');
define('DOCUMENTOS_MAX_SIZE', 10 * 1024 * 1024); // 10 MB
define('DOCUMENTOS_TIPOS_PERMITIDOS', [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
    'image/gif'
]);

// ============================================================================
// FUNCIONES DE DOCUMENTOS PARA EMPLEADOS
// ============================================================================

/**
 * Obtiene documentos de un empleado
 * 
 * Busca documentos que:
 * - Están asignados al empleado específico
 * - O están asignados a NULL (para todos)
 * - O están asignados al centro del empleado
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param int|null $centroId Centro del empleado (opcional)
 * @param string|null $tipo Tipo de documento (nomina, circular, etc.)
 * @param int|null $anio Año del documento
 * @return array
 */
function obtener_documentos_empleado($pdo, $empleadoId, $centroId = null, $tipo = null, $anio = null) {
    $where = ["d.visible_empleado = 1"];
    $params = [];
    
    // Documentos del empleado, generales, o de su centro
    $condicionAcceso = "(d.empleado_id = ? OR d.empleado_id IS NULL";
    $params[] = $empleadoId;
    
    if ($centroId) {
        $condicionAcceso .= " OR (d.centro_id IS NOT NULL AND d.centro_id = ?)";
        $params[] = $centroId;
    }
    $condicionAcceso .= ")";
    $where[] = $condicionAcceso;
    
    // Filtrar por tipo si se especifica
    if ($tipo) {
        $where[] = "d.tipo_documento = ?";
        $params[] = $tipo;
    }
    
    // Filtrar por año si se especifica
    if ($anio) {
        $where[] = "d.anio = ?";
        $params[] = $anio;
    }
    
    // Añadir el empleado_id para la subquery de confirmaciones
    array_unshift($params, $empleadoId);
    
    $whereSQL = implode(' AND ', $where);
    
    $sql = "SELECT d.*, 
                   (SELECT COUNT(*) FROM documentos_confirmaciones dc 
                    WHERE dc.documento_id = d.id AND dc.empleado_id = ?) as confirmado
            FROM documentos_empleado d
            WHERE {$whereSQL}
            ORDER BY d.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Obtiene nóminas de un empleado
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param int|null $centroId
 * @param int|null $anio
 * @return array
 */
function obtener_nominas_empleado($pdo, $empleadoId, $centroId = null, $anio = null) {
    return obtener_documentos_empleado($pdo, $empleadoId, $centroId, 'nomina', $anio);
}

/**
 * Obtiene circulares (documentos generales para todos)
 * 
 * @param PDO $pdo
 * @param int $limite
 * @return array
 */
function obtener_circulares($pdo, $limite = 10) {
    $sql = "SELECT d.*
            FROM documentos_empleado d
            WHERE d.empleado_id IS NULL
            AND d.centro_id IS NULL
            AND d.visible_empleado = 1
            ORDER BY d.created_at DESC
            LIMIT ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$limite]);
    return $stmt->fetchAll();
}

/**
 * Obtiene un documento por ID (verificando acceso)
 * 
 * @param PDO $pdo
 * @param int $documentoId
 * @param int|null $empleadoId Si se especifica, verifica acceso
 * @param int|null $centroId Centro del empleado
 * @return object|false
 */
function obtener_documento($pdo, $documentoId, $empleadoId = null, $centroId = null) {
    $sql = "SELECT d.*,
                   (SELECT COUNT(*) FROM documentos_confirmaciones dc 
                    WHERE dc.documento_id = d.id AND dc.empleado_id = ?) as confirmado
            FROM documentos_empleado d
            WHERE d.id = ?";
    
    $params = [$empleadoId ?? 0, $documentoId];
    
    // Si se especifica empleado, verificar que tenga acceso
    if ($empleadoId) {
        $condicion = " AND (d.empleado_id = ? OR d.empleado_id IS NULL";
        $params[] = $empleadoId;
        
        if ($centroId) {
            $condicion .= " OR (d.centro_id IS NOT NULL AND d.centro_id = ?)";
            $params[] = $centroId;
        }
        $condicion .= ")";
        $sql .= $condicion;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch();
}

/**
 * Confirma lectura de un documento
 * 
 * @param PDO $pdo
 * @param int $documentoId
 * @param int $empleadoId
 * @return bool
 */
function confirmar_documento_leido($pdo, $documentoId, $empleadoId) {
    try {
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO documentos_confirmaciones 
            (documento_id, empleado_id, confirmado_fecha, ip_address) 
            VALUES (?, ?, NOW(), ?)
        ");
        $stmt->execute([$documentoId, $empleadoId, $_SERVER['REMOTE_ADDR'] ?? '']);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Alias para compatibilidad
 */
function marcar_documento_leido($pdo, $documentoId, $empleadoId) {
    return confirmar_documento_leido($pdo, $documentoId, $empleadoId);
}

/**
 * Cuenta documentos pendientes de confirmar
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param int|null $centroId
 * @return int
 */
function contar_documentos_no_leidos($pdo, $empleadoId, $centroId = null) {
    $where = ["d.visible_empleado = 1", "d.requiere_confirmacion = 1"];
    $params = [$empleadoId];
    
    // Condición de acceso
    $condicionAcceso = "(d.empleado_id = ? OR d.empleado_id IS NULL";
    $params[] = $empleadoId;
    
    if ($centroId) {
        $condicionAcceso .= " OR d.centro_id = ?";
        $params[] = $centroId;
    }
    $condicionAcceso .= ")";
    $where[] = $condicionAcceso;
    
    // No confirmados
    $where[] = "NOT EXISTS (SELECT 1 FROM documentos_confirmaciones dc WHERE dc.documento_id = d.id AND dc.empleado_id = ?)";
    $params[] = $empleadoId;
    
    $whereSQL = implode(' AND ', $where);
    
    $sql = "SELECT COUNT(*) FROM documentos_empleado d WHERE {$whereSQL}";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

/**
 * Obtiene resumen de documentos agrupados por tipo
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param int|null $centroId
 * @return array
 */
function obtener_resumen_documentos($pdo, $empleadoId, $centroId = null) {
    $params = [$empleadoId, $empleadoId];
    
    $condicionAcceso = "(d.empleado_id = ? OR d.empleado_id IS NULL";
    if ($centroId) {
        $condicionAcceso .= " OR d.centro_id = ?";
        $params[] = $centroId;
    }
    $condicionAcceso .= ")";
    
    // Añadir params para subquery
    $params[] = $empleadoId;
    
    $sql = "SELECT d.tipo_documento as tipo, 
            COUNT(*) as total,
            SUM(CASE WHEN d.requiere_confirmacion = 1 AND NOT EXISTS (
                SELECT 1 FROM documentos_confirmaciones dc 
                WHERE dc.documento_id = d.id AND dc.empleado_id = ?
            ) THEN 1 ELSE 0 END) as pendientes
            FROM documentos_empleado d
            WHERE d.visible_empleado = 1 AND {$condicionAcceso}
            GROUP BY d.tipo_documento
            ORDER BY d.tipo_documento";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// ============================================================================
// FUNCIONES DE DESCARGA
// ============================================================================

/**
 * Descarga un documento (con verificación de acceso)
 * 
 * @param PDO $pdo
 * @param int $documentoId
 * @param int $empleadoId
 * @param int|null $centroId
 * @return array
 */
function descargar_documento($pdo, $documentoId, $empleadoId, $centroId = null) {
    $documento = obtener_documento($pdo, $documentoId, $empleadoId, $centroId);
    
    if (!$documento) {
        return ['exito' => false, 'mensaje' => 'Documento no encontrado o sin acceso'];
    }
    
    // La ruta ya viene relativa desde la BD
    $rutaCompleta = __DIR__ . '/../uploads/documentos/' . $documento->ruta_archivo;
    
    if (!file_exists($rutaCompleta)) {
        return ['exito' => false, 'mensaje' => 'El archivo no existe en el servidor'];
    }
    
    // Preparar descarga
    return [
        'exito' => true,
        'ruta' => $rutaCompleta,
        'nombre' => $documento->nombre_archivo ?: $documento->nombre,
        'tipo' => $documento->mime_type,
        'tamano' => $documento->tamano_bytes
    ];
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/**
 * Formatea el tamaño de archivo
 */
function formatear_tamano_archivo($bytes) {
    if ($bytes === 0 || $bytes === null) return '0 B';
    
    $unidades = ['B', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes, 1024));
    
    return round($bytes / pow(1024, $i), 2) . ' ' . $unidades[$i];
}

/**
 * Obtiene el icono según tipo MIME
 */
function icono_tipo_archivo($tipoMime) {
    $iconos = [
        'application/pdf' => '📕',
        'application/msword' => '📘',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '📘',
        'application/vnd.ms-excel' => '📗',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => '📗',
        'image/jpeg' => '🖼️',
        'image/png' => '🖼️',
        'image/gif' => '🖼️',
    ];
    
    return $iconos[$tipoMime] ?? '📄';
}

/**
 * Icono según tipo de documento
 */
function icono_tipo_documento($tipo) {
    $iconos = [
        'nomina' => '💰',
        'contrato' => '📝',
        'certificado' => '🏆',
        'circular' => '📢',
        'formacion' => '🎓',
        'otro' => '📄',
    ];
    
    return $iconos[$tipo] ?? '📄';
}

/**
 * Nombre del mes
 */
function nombre_mes($numero) {
    $meses = [
        1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
        5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
        9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre'
    ];
    return $meses[$numero] ?? '';
}

/**
 * Formatea periodo (mes/año)
 */
function formatear_periodo($mes, $anio) {
    if (!$mes && !$anio) return '';
    if (!$mes) return $anio;
    return nombre_mes($mes) . ' ' . $anio;
}
