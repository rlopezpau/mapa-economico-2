<?php
/**
 * LM FICHAJES - Funciones auxiliares del Portal
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

/**
 * Formatear fecha en español
 * @param int|null $timestamp
 * @return string
 */
function formatear_fecha_espanol($timestamp = null) {
    if ($timestamp === null) {
        $timestamp = time();
    }
    
    $dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 
              'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    
    $diaSemana = $dias[date('w', $timestamp)];
    $dia = date('d', $timestamp);
    $mes = $meses[intval(date('n', $timestamp))];
    $anio = date('Y', $timestamp);
    
    return "$diaSemana, $dia de $mes de $anio";
}

/**
 * Formatear minutos a horas con signo
 * @param int|null $minutos
 * @return string
 */
function formatearBolsaHoras($minutos) {
    if ($minutos === null || $minutos == 0) return '0:00';
    $signo = $minutos < 0 ? '-' : '+';
    $minutos = abs($minutos);
    return $signo . floor($minutos / 60) . ':' . str_pad((int)$minutos % 60, 2, '0', STR_PAD_LEFT);
}

/**
 * Obtener nombre de empresa desde configuración
 * @param PDO $pdo
 * @return string
 */
function obtener_nombre_empresa($pdo) {
    $nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
    try {
        $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
        $config = $stmt->fetch();
        if ($config && !empty($config->valor)) {
            $nombreEmpresa = $config->valor;
        }
    } catch (Exception $e) {}
    return $nombreEmpresa;
}

/**
 * Obtener datos completos del empleado
 * @param PDO $pdo
 * @param int $empleadoId
 * @return object|null
 */
function obtener_datos_empleado_completos($pdo, $empleadoId) {
    try {
        $stmt = $pdo->prepare("
            SELECT e.*, 
                   h.nombre as horario_nombre,
                   tg.nombre as turno_nombre,
                   CONCAT(s1.nombre, ' ', s1.apellido1) as supervisor_nombre,
                   CONCAT(s2.nombre, ' ', s2.apellido1) as supervisor2_nombre
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            LEFT JOIN turnos_grupo tg ON e.turno_grupo_id = tg.id
            LEFT JOIN empleados s1 ON e.supervisor_id = s1.id
            LEFT JOIN empleados s2 ON e.supervisor2_id = s2.id
            WHERE e.id = ?
        ");
        $stmt->execute([$empleadoId]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * Calcular horas semanales del empleado
 * @param PDO $pdo
 * @param int|null $horarioId
 * @return float
 */
function calcular_horas_semanales($pdo, $horarioId) {
    $horasSemanales = 37.5;
    if ($horarioId) {
        try {
            $stmt = $pdo->prepare("SELECT SUM(horas_esperadas) as t FROM horarios_dias WHERE horario_id = ?");
            $stmt->execute([$horarioId]);
            $r = $stmt->fetch();
            if ($r && $r->t) $horasSemanales = $r->t;
        } catch (PDOException $e) {}
    }
    return $horasSemanales;
}

/**
 * Obtener bolsa de horas del empleado
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $hoy
 * @return array
 */
function obtener_bolsa_horas($pdo, $empleadoId, $hoy) {
    $bolsaHoras = ['hoy' => 0, 'semana' => 0, 'mes' => 0, 'acumulado' => 0];
    try {
        // Hoy
        $stmt = $pdo->prepare("SELECT minutos_balance FROM resumen_diario WHERE empleado_id = ? AND fecha = ?");
        $stmt->execute([$empleadoId, $hoy]);
        $r = $stmt->fetch();
        if ($r) $bolsaHoras['hoy'] = $r->minutos_balance;
        
        // Semana
        $inicioSemana = date('Y-m-d', strtotime('monday this week'));
        $stmt = $pdo->prepare("SELECT SUM(minutos_balance) as t FROM resumen_diario WHERE empleado_id = ? AND fecha >= ?");
        $stmt->execute([$empleadoId, $inicioSemana]);
        $r = $stmt->fetch();
        if ($r) $bolsaHoras['semana'] = $r->t ?? 0;
        
        // Mes y acumulado
        $stmt = $pdo->prepare("SELECT minutos_balance, saldo_acumulado FROM banco_horas WHERE empleado_id = ? AND periodo = ?");
        $stmt->execute([$empleadoId, date('Y-m')]);
        $r = $stmt->fetch();
        if ($r) {
            $bolsaHoras['mes'] = $r->minutos_balance;
            $bolsaHoras['acumulado'] = $r->saldo_acumulado;
        }
    } catch (PDOException $e) {}
    return $bolsaHoras;
}

/**
 * Contar ausencias pendientes
 * @param PDO $pdo
 * @param int $empleadoId
 * @return int
 */
function contar_ausencias_pendientes($pdo, $empleadoId) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM solicitudes_ausencia WHERE empleado_id = ? AND estado = 'pendiente'");
        $stmt->execute([$empleadoId]);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}
