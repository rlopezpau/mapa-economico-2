<?php
/**
 * LM Fichajes - Sistema de Licencias (Aplicación Cliente)
 * 
 * Valida la licencia contra la API de lmfichajes.es
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

// URL de la API de validación
define('LICENCIA_API_URL', 'https://lmfichajes.es/api/licencias/validar.php');

// Tiempo de cache en segundos (24 horas)
define('LICENCIA_CACHE_TIEMPO', 86400);

// Días de gracia si la API no responde
define('LICENCIA_DIAS_GRACIA', 7);

/**
 * Obtiene el dominio actual
 */
function obtener_dominio_actual() {
    $dominio = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
    return preg_replace('/^www\./', '', strtolower($dominio));
}

/**
 * Valida la licencia contra la API
 */
function validar_licencia_api($codigo) {
    $dominio = obtener_dominio_actual();
    
    $datos = json_encode([
        'codigo' => $codigo,
        'dominio' => $dominio
    ]);
    
    $ch = curl_init(LICENCIA_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $datos,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true
    ]);
    
    $respuesta = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error || $httpCode !== 200) {
        return [
            'ok' => false,
            'error' => $error ?: "Error HTTP: $httpCode",
            'api_no_disponible' => true
        ];
    }
    
    $resultado = json_decode($respuesta, true);
    return $resultado ?: ['ok' => false, 'error' => 'Respuesta inválida'];
}

/**
 * Guarda la licencia en caché local
 */
function guardar_cache_licencia($pdo, $resultado) {
    $datos = json_encode($resultado);
    $expira = date('Y-m-d H:i:s', time() + LICENCIA_CACHE_TIEMPO);
    
    try {
        // Guardar en configuración
        $stmt = $pdo->prepare("
            INSERT INTO configuracion (clave, valor, descripcion) 
            VALUES ('licencia_cache', ?, 'Cache de validación de licencia')
            ON DUPLICATE KEY UPDATE valor = ?
        ");
        $stmt->execute([$datos, $datos]);
        
        $stmt = $pdo->prepare("
            INSERT INTO configuracion (clave, valor, descripcion) 
            VALUES ('licencia_cache_expira', ?, 'Expiración del cache de licencia')
            ON DUPLICATE KEY UPDATE valor = ?
        ");
        $stmt->execute([$expira, $expira]);
        
    } catch (PDOException $e) {
        // Silenciar errores
    }
}

/**
 * Obtiene la licencia desde caché local
 */
function obtener_cache_licencia($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = 'licencia_cache'");
        $stmt->execute();
        $cache = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = 'licencia_cache_expira'");
        $stmt->execute();
        $expira = $stmt->fetchColumn();
        
        if ($cache && $expira) {
            $resultado = json_decode($cache, true);
            $resultado['desde_cache'] = true;
            $resultado['cache_expira'] = $expira;
            $resultado['cache_expirado'] = strtotime($expira) < time();
            
            // Calcular días en modo gracia
            if ($resultado['cache_expirado']) {
                $diasDesdeExpiracion = (time() - strtotime($expira)) / 86400;
                $resultado['dias_gracia_restantes'] = max(0, LICENCIA_DIAS_GRACIA - floor($diasDesdeExpiracion));
            }
            
            return $resultado;
        }
    } catch (PDOException $e) {
        // Silenciar errores
    }
    
    return null;
}

/**
 * Obtiene el código de licencia configurado
 */
function obtener_codigo_licencia($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = 'licencia_codigo'");
        $stmt->execute();
        return $stmt->fetchColumn() ?: null;
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * Guarda el código de licencia
 */
function guardar_codigo_licencia($pdo, $codigo) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO configuracion (clave, valor, descripcion) 
            VALUES ('licencia_codigo', ?, 'Código de licencia')
            ON DUPLICATE KEY UPDATE valor = ?
        ");
        $stmt->execute([$codigo, $codigo]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Obtiene la licencia activa (validando si es necesario)
 */
function obtener_licencia_activa($pdo, $forzarValidacion = false) {
    $codigo = obtener_codigo_licencia($pdo);
    
    if (empty($codigo)) {
        return [
            'ok' => false,
            'error' => 'No hay código de licencia configurado',
            'sin_licencia' => true
        ];
    }
    
    // Intentar obtener del cache primero
    $cache = obtener_cache_licencia($pdo);
    
    // Si hay cache válido y no se fuerza validación, usarlo
    if ($cache && !$cache['cache_expirado'] && !$forzarValidacion) {
        return $cache;
    }
    
    // Validar contra la API
    $resultado = validar_licencia_api($codigo);
    
    if ($resultado['ok']) {
        // API respondió correctamente, guardar en cache
        guardar_cache_licencia($pdo, $resultado);
        return $resultado;
    }
    
    // La API no está disponible
    if (!empty($resultado['api_no_disponible'])) {
        // Usar cache si existe (modo gracia)
        if ($cache) {
            if ($cache['cache_expirado']) {
                // Verificar días de gracia
                if (($cache['dias_gracia_restantes'] ?? 0) > 0) {
                    $cache['en_periodo_gracia'] = true;
                    return $cache;
                } else {
                    return [
                        'ok' => false,
                        'error' => 'No se puede validar la licencia. Verifique su conexión.',
                        'gracia_agotada' => true
                    ];
                }
            }
            return $cache;
        }
    }
    
    // Error de validación (código inválido, bloqueada, etc.)
    return $resultado;
}

/**
 * Verifica si la licencia está vigente
 */
function licencia_vigente($pdo) {
    $licencia = obtener_licencia_activa($pdo);
    return $licencia['ok'] ?? false;
}

/**
 * Obtiene los límites de la licencia
 */
function obtener_limites_licencia($pdo) {
    $licencia = obtener_licencia_activa($pdo);
    
    if (!($licencia['ok'] ?? false)) {
        return [
            'plan' => 'sin_licencia',
            'plan_nombre' => 'Sin Licencia',
            'max_empleados' => 0,
            'max_centros' => 0,
            'vigente' => false,
            'mensaje' => $licencia['error'] ?? 'Licencia no válida'
        ];
    }
    
    $datos = $licencia['licencia'] ?? $licencia;
    
    return [
        'plan' => $datos['plan'] ?? 'desconocido',
        'plan_nombre' => $datos['plan_nombre'] ?? $datos['plan'] ?? 'Desconocido',
        'max_empleados' => (int)($datos['max_empleados'] ?? 0),
        'max_centros' => (int)($datos['max_centros'] ?? 0),
        'vigente' => true,
        'dias_restantes' => $datos['dias_restantes'] ?? null,
        'perpetua' => $datos['perpetua'] ?? false,
        'desde_cache' => $licencia['desde_cache'] ?? false,
        'en_periodo_gracia' => $licencia['en_periodo_gracia'] ?? false
    ];
}

/**
 * Cuenta empleados activos
 */
function contar_empleados_activos($pdo) {
    $stmt = $pdo->query("SELECT COUNT(*) FROM empleados WHERE activo = 1");
    return (int)$stmt->fetchColumn();
}

/**
 * Cuenta centros activos
 */
function contar_centros_activos($pdo) {
    $stmt = $pdo->query("SELECT COUNT(*) FROM centros WHERE activo = 1");
    return (int)$stmt->fetchColumn();
}

/**
 * Verifica si se puede crear un nuevo empleado
 */
function puede_crear_empleado($pdo) {
    $limites = obtener_limites_licencia($pdo);
    
    if (!$limites['vigente']) {
        return [
            'permitido' => false,
            'mensaje' => $limites['mensaje'] ?? 'La licencia no está vigente'
        ];
    }
    
    $actuales = contar_empleados_activos($pdo);
    
    if ($actuales >= $limites['max_empleados']) {
        return [
            'permitido' => false,
            'mensaje' => "Has alcanzado el límite de {$limites['max_empleados']} empleados del plan {$limites['plan_nombre']}. Contacta con soporte para ampliar tu licencia.",
            'actuales' => $actuales,
            'maximo' => $limites['max_empleados']
        ];
    }
    
    return [
        'permitido' => true,
        'actuales' => $actuales,
        'maximo' => $limites['max_empleados'],
        'disponibles' => $limites['max_empleados'] - $actuales
    ];
}

/**
 * Verifica si se puede crear un nuevo centro
 */
function puede_crear_centro($pdo) {
    $limites = obtener_limites_licencia($pdo);
    
    if (!$limites['vigente']) {
        return [
            'permitido' => false,
            'mensaje' => $limites['mensaje'] ?? 'La licencia no está vigente'
        ];
    }
    
    $actuales = contar_centros_activos($pdo);
    
    if ($actuales >= $limites['max_centros']) {
        return [
            'permitido' => false,
            'mensaje' => "Has alcanzado el límite de {$limites['max_centros']} centros del plan {$limites['plan_nombre']}. Contacta con soporte para ampliar tu licencia.",
            'actuales' => $actuales,
            'maximo' => $limites['max_centros']
        ];
    }
    
    return [
        'permitido' => true,
        'actuales' => $actuales,
        'maximo' => $limites['max_centros'],
        'disponibles' => $limites['max_centros'] - $actuales
    ];
}

/**
 * Obtiene resumen de uso para mostrar en dashboard
 */
function obtener_uso_licencia($pdo) {
    $limites = obtener_limites_licencia($pdo);
    $empleados = contar_empleados_activos($pdo);
    $centros = contar_centros_activos($pdo);
    
    return [
        'plan' => $limites['plan_nombre'],
        'vigente' => $limites['vigente'],
        'dias_restantes' => $limites['dias_restantes'],
        'perpetua' => $limites['perpetua'] ?? false,
        'desde_cache' => $limites['desde_cache'] ?? false,
        'en_periodo_gracia' => $limites['en_periodo_gracia'] ?? false,
        'empleados' => [
            'actuales' => $empleados,
            'maximo' => $limites['max_empleados'],
            'porcentaje' => $limites['max_empleados'] > 0 ? round(($empleados / $limites['max_empleados']) * 100) : 0
        ],
        'centros' => [
            'actuales' => $centros,
            'maximo' => $limites['max_centros'],
            'porcentaje' => $limites['max_centros'] > 0 ? round(($centros / $limites['max_centros']) * 100) : 0
        ]
    ];
}

/**
 * Activa una nueva licencia (valida y guarda)
 */
function activar_licencia($pdo, $codigo) {
    // Validar contra la API
    $resultado = validar_licencia_api($codigo);
    
    if (!$resultado['ok']) {
        return $resultado;
    }
    
    // Guardar código y cache
    guardar_codigo_licencia($pdo, $codigo);
    guardar_cache_licencia($pdo, $resultado);
    
    return [
        'ok' => true,
        'mensaje' => 'Licencia activada correctamente',
        'licencia' => $resultado['licencia']
    ];
}
