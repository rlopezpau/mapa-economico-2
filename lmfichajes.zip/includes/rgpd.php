<?php
/**
 * LM FICHAJES - Funciones RGPD
 * @version 1.0.2
 */

if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

/**
 * Exporta todos los datos de un empleado
 */
function exportar_datos_empleado($pdo, $empleado_id) {
    $datos = [
        'fecha_exportacion' => date('Y-m-d H:i:s'),
        'datos_personales' => [],
        'fichajes' => [],
        'ausencias' => []
    ];
    
    try {
        // Datos personales
        $stmt = $pdo->prepare("SELECT * FROM empleados WHERE id = ?");
        $stmt->execute([$empleado_id]);
        $empleado = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($empleado) {
            unset($empleado['password']);
            $datos['datos_personales'] = $empleado;
        }
        
        // Fichajes - todos los campos
        $stmt = $pdo->prepare("SELECT * FROM fichajes WHERE empleado_id = ? ORDER BY fecha DESC");
        $stmt->execute([$empleado_id]);
        $datos['fichajes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Ausencias
        $stmt = $pdo->prepare("SELECT * FROM solicitudes_ausencia WHERE empleado_id = ? ORDER BY created_at DESC");
        $stmt->execute([$empleado_id]);
        $datos['ausencias'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("Error RGPD export: " . $e->getMessage());
    }
    
    return $datos;
}

/**
 * Exporta fichajes en CSV - detecta columnas automáticamente
 */
function exportar_fichajes_csv($pdo, $empleado_id) {
    $csv = "\xEF\xBB\xBF"; // BOM UTF-8 para Excel
    
    try {
        // Obtener todos los fichajes
        $stmt = $pdo->prepare("SELECT * FROM fichajes WHERE empleado_id = ? ORDER BY fecha DESC");
        $stmt->execute([$empleado_id]);
        $fichajes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($fichajes)) {
            $csv .= "No hay fichajes registrados\n";
            return $csv;
        }
        
        // Cabecera con nombres de columnas
        $columnas = array_keys($fichajes[0]);
        $csv .= implode(';', $columnas) . "\n";
        
        // Filas de datos
        foreach ($fichajes as $fichaje) {
            $fila = [];
            foreach ($fichaje as $valor) {
                // Limpiar valores para CSV
                $valor = str_replace(["\n", "\r", ";"], [" ", " ", ","], $valor ?? '');
                $fila[] = $valor;
            }
            $csv .= implode(';', $fila) . "\n";
        }
        
    } catch (Exception $e) {
        $csv .= "Error al exportar: " . $e->getMessage() . "\n";
    }
    
    return $csv;
}

/**
 * Registra solicitud RGPD
 */
function registrar_solicitud_rgpd($pdo, $empleado_id, $tipo_derecho, $descripcion = '') {
    try {
        asegurar_tabla_solicitudes_rgpd($pdo);
        
        $stmt = $pdo->prepare("INSERT INTO solicitudes_rgpd (empleado_id, tipo_derecho, descripcion, estado, created_at) VALUES (?, ?, ?, 'pendiente', NOW())");
        $stmt->execute([$empleado_id, $tipo_derecho, $descripcion]);
        
        return $pdo->lastInsertId();
    } catch (Exception $e) {
        error_log("Error RGPD solicitud: " . $e->getMessage());
        return false;
    }
}

/**
 * Obtiene solicitudes RGPD
 */
function obtener_solicitudes_rgpd($pdo, $empleado_id) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'solicitudes_rgpd'");
        if ($stmt->rowCount() === 0) return [];
        
        $stmt = $pdo->prepare("SELECT * FROM solicitudes_rgpd WHERE empleado_id = ? ORDER BY created_at DESC");
        $stmt->execute([$empleado_id]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Verifica si puede suprimir datos
 */
function puede_suprimir_datos($pdo, $empleado_id) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM fichajes WHERE empleado_id = ? AND fecha >= DATE_SUB(CURDATE(), INTERVAL 4 YEAR)");
        $stmt->execute([$empleado_id]);
        $r = $stmt->fetch();
        
        if ($r->total > 0) {
            return ['puede' => false, 'motivo' => 'Fichajes de los últimos 4 años deben conservarse (RD 8/2019).'];
        }
        return ['puede' => true, 'motivo' => ''];
    } catch (Exception $e) {
        return ['puede' => false, 'motivo' => 'Error'];
    }
}

function traducir_derecho_rgpd($tipo) {
    $t = ['acceso'=>'Acceso','rectificacion'=>'Rectificación','supresion'=>'Supresión','oposicion'=>'Oposición','portabilidad'=>'Portabilidad','limitacion'=>'Limitación'];
    return $t[$tipo] ?? $tipo;
}

function traducir_estado_rgpd($estado) {
    $t = ['pendiente'=>'Pendiente','en_proceso'=>'En Proceso','completada'=>'Completada','rechazada'=>'Rechazada'];
    return $t[$estado] ?? $estado;
}

function asegurar_tabla_solicitudes_rgpd($pdo) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS solicitudes_rgpd (
            id INT AUTO_INCREMENT PRIMARY KEY,
            empleado_id INT NOT NULL,
            tipo_derecho VARCHAR(50) NOT NULL,
            descripcion TEXT,
            estado ENUM('pendiente','en_proceso','completada','rechazada') DEFAULT 'pendiente',
            respuesta TEXT,
            created_at DATETIME NOT NULL,
            updated_at DATETIME DEFAULT NULL,
            INDEX idx_empleado (empleado_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {}
}
