<?php
/**
 * LM FICHAJES - Funciones de Ausencias
 * 
 * Gestión de vacaciones, permisos, bajas y otras ausencias.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      Roberto López Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// ============================================================================
// CONSTANTES DE AUSENCIAS
// ============================================================================

define('AUSENCIA_BORRADOR', 'borrador');
define('AUSENCIA_PENDIENTE', 'pendiente');
define('AUSENCIA_APROBADA', 'aprobada');
define('AUSENCIA_RECHAZADA', 'rechazada');
define('AUSENCIA_CANCELADA', 'cancelada');
define('AUSENCIA_ANULADA', 'anulada');

// ============================================================================
// FUNCIONES DE TIPOS DE AUSENCIA
// ============================================================================

/**
 * Obtiene todos los tipos de ausencia activos
 */
function obtener_tipos_ausencia($pdo, $soloActivos = true) {
    $sql = "SELECT * FROM tipos_ausencia" .
           ($soloActivos ? " WHERE activo = 1" : "") .
           " ORDER BY orden, nombre";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Obtiene tipos de ausencia agrupados por categoría
 */
function obtener_tipos_ausencia_agrupados($pdo) {
    $tipos = obtener_tipos_ausencia($pdo);
    $agrupados = [];
    
    $nombresCategorias = [
        'vacaciones' => '🏖️ Vacaciones',
        'asuntos_propios' => '📅 Asuntos Propios',
        'permiso_retribuido' => '✅ Permisos Retribuidos',
        'permiso_no_retribuido' => '⚪ Permisos No Retribuidos',
        'baja_medica' => '🏥 Bajas Médicas',
        'otros' => '📁 Otros'
    ];
    
    foreach ($tipos as $tipo) {
        $cat = $tipo->categoria;
        if (!isset($agrupados[$cat])) {
            $agrupados[$cat] = [
                'nombre' => $nombresCategorias[$cat] ?? $cat,
                'tipos' => []
            ];
        }
        $agrupados[$cat]['tipos'][] = $tipo;
    }
    
    return $agrupados;
}

/**
 * Obtiene tipos de ausencia disponibles para un empleado según su convenio
 * Incluye vacaciones y asuntos propios (siempre disponibles) + tipos del convenio
 * Ahora incluye los días disponibles del saldo del empleado
 * @param PDO $pdo
 * @param int $empleadoId
 * @return array Tipos agrupados por categoría con días disponibles
 */
function obtener_tipos_ausencia_empleado($pdo, $empleadoId) {
    $anio = date('Y');

    // Obtener datos del empleado (convenio y días personalizados)
    $stmt = $pdo->prepare("
        SELECT convenio_id, dias_vacaciones, dias_vacaciones_antiguedad,
               dias_libre_disposicion, dias_libre_disp_antiguedad
        FROM empleados WHERE id = ?
    ");
    $stmt->execute([$empleadoId]);
    $empleado = $stmt->fetch();
    $convenioId = $empleado ? $empleado->convenio_id : null;

    // Obtener saldos actuales del empleado
    $saldos = [];
    $stmt = $pdo->prepare("
        SELECT tipo_ausencia_id, dias_asignados, dias_disfrutados, dias_pendientes,
               (dias_asignados - dias_disfrutados - dias_pendientes) as dias_disponibles
        FROM saldo_ausencias
        WHERE empleado_id = ? AND anio = ?
    ");
    $stmt->execute([$empleadoId, $anio]);
    foreach ($stmt->fetchAll() as $s) {
        $saldos[$s->tipo_ausencia_id] = $s;
    }

    // Obtener nombre del convenio
    $convenioNombre = null;
    if ($convenioId) {
        $stmt = $pdo->prepare("SELECT nombre FROM convenios WHERE id = ?");
        $stmt->execute([$convenioId]);
        $conv = $stmt->fetch();
        $convenioNombre = $conv ? $conv->nombre : null;
    }

    // Obtener tipos de ausencia base (vacaciones y asuntos propios siempre disponibles)
    $tiposDisponibles = [];

    // Vacaciones y Asuntos propios siempre disponibles
    $stmt = $pdo->query("
        SELECT * FROM tipos_ausencia
        WHERE activo = 1 AND categoria IN ('vacaciones', 'asuntos_propios')
        ORDER BY orden, nombre
    ");
    foreach ($stmt->fetchAll() as $tipo) {
        // Añadir info de saldo
        $tipo->dias_disponibles = $saldos[$tipo->id]->dias_disponibles ?? null;
        $tipo->dias_asignados = $saldos[$tipo->id]->dias_asignados ?? null;
        $tiposDisponibles[$tipo->id] = $tipo;
    }

    // Añadir tipos del convenio
    if ($convenioId) {
        $stmt = $pdo->prepare("
            SELECT ta.*, ctd.dias as dias_convenio, ctd.dias_maximos as dias_max_convenio
            FROM tipos_ausencia ta
            INNER JOIN convenios_tipos_dias ctd ON ta.id = ctd.tipo_ausencia_id
            WHERE ctd.convenio_id = ? AND ta.activo = 1 AND ctd.activo = 1
            ORDER BY ta.orden, ta.nombre
        ");
        $stmt->execute([$convenioId]);
        foreach ($stmt->fetchAll() as $tipo) {
            // Añadir info de saldo
            $tipo->dias_disponibles = $saldos[$tipo->id]->dias_disponibles ?? null;
            $tipo->dias_asignados = $saldos[$tipo->id]->dias_asignados ?? $tipo->dias_convenio;
            $tiposDisponibles[$tipo->id] = $tipo;
        }
    } else {
        // Sin convenio: añadir todos los permisos retribuidos genéricos
        $stmt = $pdo->query("
            SELECT * FROM tipos_ausencia
            WHERE activo = 1
              AND categoria IN ('permiso_retribuido', 'baja_medica')
            ORDER BY orden, nombre
        ");
        foreach ($stmt->fetchAll() as $tipo) {
            $tipo->dias_disponibles = $saldos[$tipo->id]->dias_disponibles ?? null;
            $tipo->dias_asignados = $saldos[$tipo->id]->dias_asignados ?? $tipo->dias_maximos;
            $tiposDisponibles[$tipo->id] = $tipo;
        }
    }

    // Agrupar por categoría
    $agrupados = [];
    $nombresCategorias = [
        'vacaciones' => '🏖️ Vacaciones',
        'asuntos_propios' => '📅 Asuntos Propios / Libre Disposición',
        'permiso_retribuido' => '✅ Permisos Retribuidos',
        'permiso_no_retribuido' => '⚪ Permisos No Retribuidos',
        'baja_medica' => '🏥 Bajas Médicas',
        'otros' => '📁 Otros'
    ];

    foreach ($tiposDisponibles as $tipo) {
        $cat = $tipo->categoria ?? 'otros';
        if (!isset($agrupados[$cat])) {
            $agrupados[$cat] = [
                'nombre' => $nombresCategorias[$cat] ?? ucfirst($cat),
                'tipos' => []
            ];
        }
        $agrupados[$cat]['tipos'][] = $tipo;
    }

    // Añadir info del convenio al resultado
    if ($convenioNombre) {
        $agrupados['_convenio'] = $convenioNombre;
    }

    return $agrupados;
}

/**
 * Obtiene un tipo de ausencia por ID
 */
function obtener_tipo_ausencia($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM tipos_ausencia WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// ============================================================================
// FUNCIONES DE SALDO DE AUSENCIAS
// ============================================================================

/**
 * Obtiene el saldo de días disponibles de un empleado para un año
 */
function obtener_saldos_empleado($pdo, $empleadoId, $anio = null) {
    if ($anio === null) {
        $anio = date('Y');
    }
    
    $sql = "SELECT sa.*, 
            ta.codigo, ta.nombre, ta.categoria, ta.color, ta.dias_maximos,
            (sa.dias_asignados - sa.dias_disfrutados - sa.dias_pendientes) as dias_disponibles
            FROM saldo_ausencias sa
            INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
            WHERE sa.empleado_id = ? AND sa.anio = ?
            ORDER BY ta.orden";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $anio]);
    return $stmt->fetchAll();
}

/**
 * Obtiene el saldo de un tipo específico
 */
function obtener_saldo_tipo($pdo, $empleadoId, $tipoAusenciaId, $anio = null) {
    if ($anio === null) {
        $anio = date('Y');
    }
    
    $stmt = $pdo->prepare("
        SELECT sa.*, 
               (sa.dias_asignados - sa.dias_disfrutados - sa.dias_pendientes) as dias_disponibles
        FROM saldo_ausencias sa
        WHERE sa.empleado_id = ? AND sa.tipo_ausencia_id = ? AND sa.anio = ?
    ");
    $stmt->execute([$empleadoId, $tipoAusenciaId, $anio]);
    return $stmt->fetch();
}

/**
 * Inicializa saldos para un empleado en un año
 * Usa los días personalizados del empleado y su convenio
 */
function inicializar_saldos_empleado($pdo, $empleadoId, $anio = null) {
    if ($anio === null) {
        $anio = date('Y');
    }
    
    // Obtener datos del empleado (días personalizados y convenio)
    $stmt = $pdo->prepare("
        SELECT dias_vacaciones, dias_vacaciones_antiguedad, 
               dias_libre_disposicion, dias_libre_disp_antiguedad,
               convenio_id
        FROM empleados WHERE id = ?
    ");
    $stmt->execute([$empleadoId]);
    $empleado = $stmt->fetch();
    
    if (!$empleado) {
        return;
    }
    
    // Obtener IDs de los tipos principales (Vacaciones y Asuntos Propios)
    $tipoVacacionesId = null;
    $tipoAsuntosPropiosId = null;
    $stmt = $pdo->query("SELECT id, nombre FROM tipos_ausencia WHERE nombre IN ('Vacaciones', 'Asuntos Propios') AND activo = 1");
    foreach ($stmt->fetchAll() as $t) {
        if ($t->nombre === 'Vacaciones') $tipoVacacionesId = $t->id;
        if ($t->nombre === 'Asuntos Propios') $tipoAsuntosPropiosId = $t->id;
    }
    
    // Obtener tipos de ausencia activos
    $tipos = obtener_tipos_ausencia($pdo);
    
    // Obtener días del convenio si tiene
    $diasConvenio = [];
    if ($empleado->convenio_id) {
        $stmt = $pdo->prepare("
            SELECT tipo_ausencia_id, dias 
            FROM convenios_tipos_dias 
            WHERE convenio_id = ?
        ");
        $stmt->execute([$empleado->convenio_id]);
        foreach ($stmt->fetchAll() as $dc) {
            $diasConvenio[$dc->tipo_ausencia_id] = $dc->dias;
        }
    }
    
    foreach ($tipos as $tipo) {
        // Determinar días asignados según tipo específico
        $diasAsignados = null;
        
        if ($tipo->id == $tipoVacacionesId) {
            // Vacaciones: usar días del empleado
            $diasAsignados = ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0);
        } elseif ($tipo->id == $tipoAsuntosPropiosId) {
            // Asuntos propios / Libre disposición: usar días del empleado
            $diasAsignados = ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0);
        } elseif (isset($diasConvenio[$tipo->id])) {
            // Otros tipos: usar días del convenio si está configurado
            $diasAsignados = $diasConvenio[$tipo->id];
        } elseif ($tipo->dias_maximos !== null) {
            // Fallback: usar días máximos genéricos del tipo
            $diasAsignados = $tipo->dias_maximos;
        }
        
        // Solo crear saldo si hay días definidos
        if ($diasAsignados !== null && $diasAsignados > 0) {
            // Verificar si ya existe
            $saldo = obtener_saldo_tipo($pdo, $empleadoId, $tipo->id, $anio);
            
            if (!$saldo) {
                $stmt = $pdo->prepare("
                    INSERT INTO saldo_ausencias 
                    (empleado_id, tipo_ausencia_id, anio, dias_asignados)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$empleadoId, $tipo->id, $anio, $diasAsignados]);
            }
        }
    }
}

/**
 * Recalcula los saldos de un empleado para el año actual
 * Útil cuando se cambian los días asignados o el convenio
 * Solo actualiza si el saldo asignado es diferente (no afecta a días ya disfrutados)
 */
function recalcular_saldos_empleado($pdo, $empleadoId, $anio = null) {
    if ($anio === null) {
        $anio = date('Y');
    }
    
    // Obtener datos del empleado
    $stmt = $pdo->prepare("
        SELECT dias_vacaciones, dias_vacaciones_antiguedad, 
               dias_libre_disposicion, dias_libre_disp_antiguedad,
               convenio_id
        FROM empleados WHERE id = ?
    ");
    $stmt->execute([$empleadoId]);
    $empleado = $stmt->fetch();
    
    if (!$empleado) {
        return;
    }
    
    // Obtener IDs de los tipos principales (Vacaciones y Asuntos Propios)
    $tipoVacacionesId = null;
    $tipoAsuntosPropiosId = null;
    $stmt = $pdo->query("SELECT id, nombre FROM tipos_ausencia WHERE nombre IN ('Vacaciones', 'Asuntos Propios') AND activo = 1");
    foreach ($stmt->fetchAll() as $t) {
        if ($t->nombre === 'Vacaciones') $tipoVacacionesId = $t->id;
        if ($t->nombre === 'Asuntos Propios') $tipoAsuntosPropiosId = $t->id;
    }
    
    // Obtener tipos de ausencia activos
    $tipos = obtener_tipos_ausencia($pdo);
    
    // Obtener días del convenio
    $diasConvenio = [];
    if ($empleado->convenio_id) {
        $stmt = $pdo->prepare("SELECT tipo_ausencia_id, dias FROM convenios_tipos_dias WHERE convenio_id = ?");
        $stmt->execute([$empleado->convenio_id]);
        foreach ($stmt->fetchAll() as $dc) {
            $diasConvenio[$dc->tipo_ausencia_id] = $dc->dias;
        }
    }
    
    foreach ($tipos as $tipo) {
        $diasAsignados = null;
        
        // Identificar por ID específico para Vacaciones y Asuntos Propios
        if ($tipo->id == $tipoVacacionesId) {
            // Vacaciones: días del empleado
            $diasAsignados = ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0);
        } elseif ($tipo->id == $tipoAsuntosPropiosId) {
            // Asuntos Propios: días del empleado
            $diasAsignados = ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0);
        } elseif (isset($diasConvenio[$tipo->id])) {
            // Otros tipos: días del convenio
            $diasAsignados = $diasConvenio[$tipo->id];
        } elseif ($tipo->dias_maximos !== null) {
            // Fallback: días máximos genéricos
            $diasAsignados = $tipo->dias_maximos;
        }
        
        if ($diasAsignados !== null && $diasAsignados > 0) {
            $saldo = obtener_saldo_tipo($pdo, $empleadoId, $tipo->id, $anio);
            
            if ($saldo) {
                // Actualizar si el saldo asignado cambió
                if ($saldo->dias_asignados != $diasAsignados) {
                    $stmt = $pdo->prepare("
                        UPDATE saldo_ausencias 
                        SET dias_asignados = ?
                        WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
                    ");
                    $stmt->execute([$diasAsignados, $empleadoId, $tipo->id, $anio]);
                }
            } else {
                // Crear nuevo saldo
                $stmt = $pdo->prepare("
                    INSERT INTO saldo_ausencias 
                    (empleado_id, tipo_ausencia_id, anio, dias_asignados)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$empleadoId, $tipo->id, $anio, $diasAsignados]);
            }
        }
    }
}

/**
 * Actualiza el saldo tras aprobar/cancelar una ausencia
 */
function actualizar_saldo_ausencia($pdo, $solicitudId, $accion = 'aprobar') {
    $stmt = $pdo->prepare("
        SELECT sa.*, ta.dias_maximos 
        FROM solicitudes_ausencia sa
        INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
        WHERE sa.id = ?
    ");
    $stmt->execute([$solicitudId]);
    $solicitud = $stmt->fetch();
    
    if (!$solicitud) {
        return false;
    }
    
    $anio = date('Y', strtotime($solicitud->fecha_inicio));
    
    // Asegurar que existe el registro de saldo
    $saldo = obtener_saldo_tipo($pdo, $solicitud->empleado_id, $solicitud->tipo_ausencia_id, $anio);
    
    if (!$saldo) {
        // Inicializar TODOS los saldos del empleado correctamente (usando su convenio)
        inicializar_saldos_empleado($pdo, $solicitud->empleado_id, $anio);
        
        // Volver a obtener el saldo (ahora debería existir)
        $saldo = obtener_saldo_tipo($pdo, $solicitud->empleado_id, $solicitud->tipo_ausencia_id, $anio);
        
        // Si aún no existe (tipo de ausencia sin días asignados), crear con 0
        if (!$saldo) {
            $stmt = $pdo->prepare("
                INSERT INTO saldo_ausencias 
                (empleado_id, tipo_ausencia_id, anio, dias_asignados)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $solicitud->empleado_id, 
                $solicitud->tipo_ausencia_id, 
                $anio, 
                $solicitud->dias_maximos ?? 0
            ]);
        }
    }
    
    if ($accion === 'aprobar') {
        // Sumar a días pendientes
        $stmt = $pdo->prepare("
            UPDATE saldo_ausencias 
            SET dias_pendientes = dias_pendientes + ?
            WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
        ");
        $stmt->execute([
            $solicitud->dias_solicitados,
            $solicitud->empleado_id,
            $solicitud->tipo_ausencia_id,
            $anio
        ]);
    } elseif ($accion === 'cancelar' || $accion === 'rechazar') {
        // Restar de días pendientes
        $stmt = $pdo->prepare("
            UPDATE saldo_ausencias 
            SET dias_pendientes = GREATEST(0, dias_pendientes - ?)
            WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
        ");
        $stmt->execute([
            $solicitud->dias_solicitados,
            $solicitud->empleado_id,
            $solicitud->tipo_ausencia_id,
            $anio
        ]);
    } elseif ($accion === 'disfrutar') {
        // Pasar de pendientes a disfrutados
        $stmt = $pdo->prepare("
            UPDATE saldo_ausencias 
            SET dias_pendientes = GREATEST(0, dias_pendientes - ?),
                dias_disfrutados = dias_disfrutados + ?
            WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
        ");
        $stmt->execute([
            $solicitud->dias_solicitados,
            $solicitud->dias_solicitados,
            $solicitud->empleado_id,
            $solicitud->tipo_ausencia_id,
            $anio
        ]);
    } elseif ($accion === 'aprobar_directo') {
        // Sumar directamente a disfrutados (sin pasar por pendientes)
        // Usado cuando se aprueba directamente sin reserva previa
        $stmt = $pdo->prepare("
            UPDATE saldo_ausencias 
            SET dias_disfrutados = dias_disfrutados + ?
            WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
        ");
        $stmt->execute([
            $solicitud->dias_solicitados,
            $solicitud->empleado_id,
            $solicitud->tipo_ausencia_id,
            $anio
        ]);
    }
    
    return true;
}

// ============================================================================
// FUNCIONES DE SOLICITUDES
// ============================================================================

/**
 * Crea una nueva solicitud de ausencia
 */
function crear_solicitud_ausencia($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    
    // Validaciones
    if (empty($datos['tipo_ausencia_id'])) {
        $resultado['mensaje'] = 'Debe seleccionar un tipo de ausencia';
        return $resultado;
    }
    
    if (empty($datos['fecha_inicio']) || empty($datos['fecha_fin'])) {
        $resultado['mensaje'] = 'Debe indicar las fechas de inicio y fin';
        return $resultado;
    }
    
    $fechaInicio = strtotime($datos['fecha_inicio']);
    $fechaFin = strtotime($datos['fecha_fin']);
    
    if ($fechaFin < $fechaInicio) {
        $resultado['mensaje'] = 'La fecha de fin no puede ser anterior a la de inicio';
        return $resultado;
    }
    
    // Obtener tipo de ausencia
    $tipo = obtener_tipo_ausencia($pdo, $datos['tipo_ausencia_id']);
    if (!$tipo) {
        $resultado['mensaje'] = 'Tipo de ausencia no válido';
        return $resultado;
    }
    
    // Calcular días solicitados (excluyendo fines de semana)
    $diasSolicitados = calcular_dias_laborables($datos['fecha_inicio'], $datos['fecha_fin']);
    
    // Ajustar si son medios días
    if (($datos['jornada_inicio'] ?? 'completa') !== 'completa') {
        $diasSolicitados -= 0.5;
    }
    if (($datos['jornada_fin'] ?? 'completa') !== 'completa' && $datos['fecha_inicio'] !== $datos['fecha_fin']) {
        $diasSolicitados -= 0.5;
    }
    
    if ($diasSolicitados <= 0) {
        $resultado['mensaje'] = 'Debe solicitar al menos medio día';
        return $resultado;
    }
    
    // Verificar saldo disponible si aplica
    if ($tipo->dias_maximos !== null) {
        $anio = date('Y', $fechaInicio);
        $saldo = obtener_saldo_tipo($pdo, $datos['empleado_id'], $tipo->id, $anio);
        
        if ($saldo && ($saldo->dias_disponibles ?? 0) < $diasSolicitados) {
            $resultado['mensaje'] = "No tiene suficientes días disponibles. Disponible: {$saldo->dias_disponibles}, Solicitado: {$diasSolicitados}";
            return $resultado;
        }
    }
    
    // Verificar días de preaviso
    if ($tipo->dias_preaviso > 0) {
        $diasHastaInicio = floor(($fechaInicio - time()) / 86400);
        if ($diasHastaInicio < $tipo->dias_preaviso) {
            $resultado['mensaje'] = "Este tipo de ausencia requiere {$tipo->dias_preaviso} días de preaviso";
            return $resultado;
        }
    }
    
    // Verificar solapamiento con otras solicitudes
    $solapamiento = verificar_solapamiento_ausencias($pdo, $datos['empleado_id'], $datos['fecha_inicio'], $datos['fecha_fin']);
    if ($solapamiento) {
        $resultado['mensaje'] = 'Ya tiene una solicitud para esas fechas';
        return $resultado;
    }
    
    try {
        $sql = "INSERT INTO solicitudes_ausencia 
                (empleado_id, tipo_ausencia_id, fecha_inicio, fecha_fin, 
                 dias_solicitados, jornada_inicio, jornada_fin, motivo,
                 estado, justificante_requerido, ip_solicitud)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $estado = ($datos['guardar_borrador'] ?? false) ? AUSENCIA_BORRADOR : AUSENCIA_PENDIENTE;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $datos['empleado_id'],
            $datos['tipo_ausencia_id'],
            $datos['fecha_inicio'],
            $datos['fecha_fin'],
            $diasSolicitados,
            $datos['jornada_inicio'] ?? 'completa',
            $datos['jornada_fin'] ?? 'completa',
            $datos['motivo'] ?? null,
            $estado,
            $tipo->requiere_justificante,
            obtener_ip_cliente()
        ]);
        
        $resultado['exito'] = true;
        $resultado['id'] = $pdo->lastInsertId();
        $resultado['dias'] = $diasSolicitados;
        $resultado['mensaje'] = $estado === AUSENCIA_BORRADOR 
            ? 'Solicitud guardada como borrador'
            : 'Solicitud enviada correctamente';
            
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al crear la solicitud';
        error_log('Error crear solicitud ausencia: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Calcula días laborables entre dos fechas (excluye sábados y domingos)
 */
function calcular_dias_laborables($fechaInicio, $fechaFin) {
    $inicio = new DateTime($fechaInicio);
    $fin = new DateTime($fechaFin);
    $fin->modify('+1 day'); // Incluir el día final
    
    $dias = 0;
    $periodo = new DatePeriod($inicio, new DateInterval('P1D'), $fin);
    
    foreach ($periodo as $fecha) {
        $diaSemana = $fecha->format('N');
        if ($diaSemana < 6) { // 1-5 = Lunes-Viernes
            $dias++;
        }
    }
    
    return $dias;
}

/**
 * Verifica solapamiento con otras solicitudes
 */
function verificar_solapamiento_ausencias($pdo, $empleadoId, $fechaInicio, $fechaFin, $excluirId = null) {
    $sql = "SELECT COUNT(*) FROM solicitudes_ausencia 
            WHERE empleado_id = ? 
            AND estado NOT IN ('cancelada', 'rechazada', 'anulada')
            AND ((fecha_inicio BETWEEN ? AND ?) OR (fecha_fin BETWEEN ? AND ?)
                 OR (fecha_inicio <= ? AND fecha_fin >= ?))";
    
    $params = [$empleadoId, $fechaInicio, $fechaFin, $fechaInicio, $fechaFin, $fechaInicio, $fechaFin];
    
    if ($excluirId) {
        $sql .= " AND id != ?";
        $params[] = $excluirId;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchColumn() > 0;
}

/**
 * Obtiene solicitudes de un empleado
 */
function obtener_solicitudes_empleado($pdo, $empleadoId, $anio = null, $estado = null) {
    $where = ["sa.empleado_id = ?"];
    $params = [$empleadoId];
    
    if ($anio) {
        $where[] = "YEAR(sa.fecha_inicio) = ?";
        $params[] = $anio;
    }
    
    if ($estado) {
        $where[] = "sa.estado = ?";
        $params[] = $estado;
    }
    
    $whereSQL = implode(' AND ', $where);
    
    $sql = "SELECT sa.*, ta.nombre as tipo_nombre, ta.codigo as tipo_codigo, 
            ta.categoria, ta.color
            FROM solicitudes_ausencia sa
            INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
            WHERE {$whereSQL}
            ORDER BY sa.fecha_inicio DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Obtiene una solicitud por ID
 */
function obtener_solicitud_ausencia($pdo, $id) {
    $sql = "SELECT sa.*, ta.nombre as tipo_nombre, ta.codigo as tipo_codigo,
            ta.categoria, ta.color, ta.requiere_justificante,
            e.nombre as empleado_nombre, e.apellido1, e.apellido2
            FROM solicitudes_ausencia sa
            INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
            INNER JOIN empleados e ON sa.empleado_id = e.id
            WHERE sa.id = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Cancela una solicitud (solo el empleado, solo si está pendiente o borrador)
 */
function cancelar_solicitud_ausencia($pdo, $solicitudId, $empleadoId) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    
    $solicitud = obtener_solicitud_ausencia($pdo, $solicitudId);
    
    if (!$solicitud || $solicitud->empleado_id != $empleadoId) {
        $resultado['mensaje'] = 'Solicitud no encontrada';
        return $resultado;
    }
    
    if (!in_array($solicitud->estado, [AUSENCIA_BORRADOR, AUSENCIA_PENDIENTE])) {
        $resultado['mensaje'] = 'Solo puede cancelar solicitudes pendientes o en borrador';
        return $resultado;
    }
    
    try {
        $stmt = $pdo->prepare("UPDATE solicitudes_ausencia SET estado = 'cancelada' WHERE id = ?");
        $stmt->execute([$solicitudId]);
        
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Solicitud cancelada correctamente';
        
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al cancelar la solicitud';
        error_log('Error cancelar solicitud: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Envía un borrador (cambia de borrador a pendiente)
 */
function enviar_solicitud_ausencia($pdo, $solicitudId, $empleadoId) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    
    $solicitud = obtener_solicitud_ausencia($pdo, $solicitudId);
    
    if (!$solicitud || $solicitud->empleado_id != $empleadoId) {
        $resultado['mensaje'] = 'Solicitud no encontrada';
        return $resultado;
    }
    
    if ($solicitud->estado !== AUSENCIA_BORRADOR) {
        $resultado['mensaje'] = 'Solo puede enviar solicitudes en borrador';
        return $resultado;
    }
    
    try {
        $stmt = $pdo->prepare("UPDATE solicitudes_ausencia SET estado = 'pendiente' WHERE id = ?");
        $stmt->execute([$solicitudId]);
        
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Solicitud enviada correctamente';
        
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al enviar la solicitud';
        error_log('Error enviar solicitud: ' . $e->getMessage());
    }
    
    return $resultado;
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/**
 * Traduce el estado de una solicitud
 */
function traducir_estado_ausencia($estado) {
    $estados = [
        'borrador' => ['texto' => '📝 Borrador', 'clase' => 'secondary', 'color' => '#6b7280'],
        'pendiente' => ['texto' => '⏳ Pendiente', 'clase' => 'warning', 'color' => '#f59e0b'],
        'aprobada' => ['texto' => '✅ Aprobada', 'clase' => 'success', 'color' => '#10b981'],
        'rechazada' => ['texto' => '❌ Rechazada', 'clase' => 'danger', 'color' => '#ef4444'],
        'cancelada' => ['texto' => '🚫 Cancelada', 'clase' => 'secondary', 'color' => '#9ca3af'],
        'anulada' => ['texto' => '⛔ Anulada', 'clase' => 'dark', 'color' => '#374151']
    ];
    
    return $estados[$estado] ?? ['texto' => $estado, 'clase' => 'secondary', 'color' => '#6b7280'];
}

/**
 * Traduce la categoría de ausencia
 */
function traducir_categoria_ausencia($categoria) {
    $categorias = [
        'vacaciones' => '🏖️ Vacaciones',
        'asuntos_propios' => '📅 Asuntos Propios',
        'permiso_retribuido' => '✅ Permiso Retribuido',
        'permiso_no_retribuido' => '⚪ No Retribuido',
        'baja_medica' => '🏥 Baja Médica',
        'otros' => '📁 Otros'
    ];
    
    return $categorias[$categoria] ?? $categoria;
}

/**
 * Formatea rango de fechas
 */
function formatear_rango_fechas($fechaInicio, $fechaFin) {
    $inicio = strtotime($fechaInicio);
    $fin = strtotime($fechaFin);
    
    if ($fechaInicio === $fechaFin) {
        return date('d/m/Y', $inicio);
    }
    
    // Mismo mes y año
    if (date('m/Y', $inicio) === date('m/Y', $fin)) {
        return date('d', $inicio) . '-' . date('d/m/Y', $fin);
    }
    
    // Mismo año
    if (date('Y', $inicio) === date('Y', $fin)) {
        return date('d/m', $inicio) . ' - ' . date('d/m/Y', $fin);
    }
    
    return date('d/m/Y', $inicio) . ' - ' . date('d/m/Y', $fin);
}

/**
 * Obtiene el calendario de ausencias de un mes
 */
function obtener_calendario_ausencias($pdo, $empleadoId, $mes, $anio) {
    $primerDia = "$anio-$mes-01";
    $ultimoDia = date('Y-m-t', strtotime($primerDia));
    
    $sql = "SELECT sa.*, ta.nombre as tipo_nombre, ta.color
            FROM solicitudes_ausencia sa
            INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
            WHERE sa.empleado_id = ?
            AND sa.estado IN ('aprobada', 'pendiente')
            AND ((sa.fecha_inicio BETWEEN ? AND ?) 
                 OR (sa.fecha_fin BETWEEN ? AND ?)
                 OR (sa.fecha_inicio <= ? AND sa.fecha_fin >= ?))
            ORDER BY sa.fecha_inicio";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $primerDia, $ultimoDia, $primerDia, $ultimoDia, $primerDia, $ultimoDia]);
    
    return $stmt->fetchAll();
}

/**
 * Cuenta solicitudes pendientes de validación para un supervisor
 */
function contar_ausencias_pendientes_supervisor($pdo, $supervisorId) {
    $sql = "SELECT COUNT(*) FROM solicitudes_ausencia sa
            INNER JOIN empleados e ON sa.empleado_id = e.id
            WHERE sa.estado = 'pendiente'
            AND (e.supervisor_id = ? OR e.supervisor2_id = ?)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$supervisorId, $supervisorId]);
    
    return $stmt->fetchColumn();
}
