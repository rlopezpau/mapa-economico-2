<?php
/**
 * LM FICHAJES - Sistema de Notificaciones Internas
 * 
 * Gestiona las notificaciones para empleados dentro del portal.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

/**
 * Crear una nueva notificación para un empleado
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $empleadoId ID del empleado
 * @param string $tipo Tipo de notificación
 * @param string $titulo Título corto
 * @param string $mensaje Mensaje completo (opcional)
 * @param string $enlace URL relativa (opcional)
 * @return int|false ID de la notificación o false si falla
 */
function crear_notificacion($pdo, $empleadoId, $tipo, $titulo, $mensaje = '', $enlace = null) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notificaciones (empleado_id, tipo, titulo, mensaje, enlace, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$empleadoId, $tipo, $titulo, $mensaje, $enlace]);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Error creando notificación: " . $e->getMessage());
        return false;
    }
}

/**
 * Obtener notificaciones de un empleado
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $empleadoId ID del empleado
 * @param bool $soloNoLeidas Solo mostrar no leídas
 * @param int $limite Número máximo de notificaciones
 * @return array Lista de notificaciones
 */
function obtener_notificaciones($pdo, $empleadoId, $soloNoLeidas = false, $limite = 20) {
    try {
        $sql = "SELECT * FROM notificaciones WHERE empleado_id = ?";
        if ($soloNoLeidas) {
            $sql .= " AND leida = 0";
        }
        $sql .= " ORDER BY created_at DESC LIMIT ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$empleadoId, $limite]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Error obteniendo notificaciones: " . $e->getMessage());
        return [];
    }
}

/**
 * Contar notificaciones no leídas
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $empleadoId ID del empleado
 * @return int Número de notificaciones sin leer
 */
function contar_notificaciones_no_leidas($pdo, $empleadoId) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notificaciones WHERE empleado_id = ? AND leida = 0");
        $stmt->execute([$empleadoId]);
        return (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Marcar notificación como leída
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $notificacionId ID de la notificación
 * @param int $empleadoId ID del empleado (verificación de seguridad)
 * @return bool Éxito
 */
function marcar_notificacion_leida($pdo, $notificacionId, $empleadoId) {
    try {
        $stmt = $pdo->prepare("
            UPDATE notificaciones 
            SET leida = 1, read_at = NOW() 
            WHERE id = ? AND empleado_id = ?
        ");
        $stmt->execute([$notificacionId, $empleadoId]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Marcar todas las notificaciones como leídas
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $empleadoId ID del empleado
 * @return int Número de notificaciones marcadas
 */
function marcar_todas_leidas($pdo, $empleadoId) {
    try {
        $stmt = $pdo->prepare("
            UPDATE notificaciones 
            SET leida = 1, read_at = NOW() 
            WHERE empleado_id = ? AND leida = 0
        ");
        $stmt->execute([$empleadoId]);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Eliminar notificaciones antiguas (más de 90 días)
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $dias Días de antigüedad
 * @return int Número de notificaciones eliminadas
 */
function limpiar_notificaciones_antiguas($pdo, $dias = 90) {
    try {
        $stmt = $pdo->prepare("
            DELETE FROM notificaciones 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        $stmt->execute([$dias]);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        return 0;
    }
}

// ============================================================================
// FUNCIONES DE NOTIFICACIÓN ESPECÍFICAS
// ============================================================================

/**
 * Notificar ausencia aprobada
 */
function notificar_ausencia_aprobada($pdo, $empleadoId, $tipoAusencia, $fechaInicio, $fechaFin, $solicitudId = null) {
    $titulo = "✅ Ausencia aprobada";
    $mensaje = "Tu solicitud de {$tipoAusencia} del {$fechaInicio} al {$fechaFin} ha sido aprobada.";
    $enlace = '/mis-gestiones.php?seccion=ausencias';
    if ($solicitudId) {
        $enlace .= '&ver=' . $solicitudId;
    }
    return crear_notificacion($pdo, $empleadoId, 'ausencia_aprobada', $titulo, $mensaje, $enlace);
}

/**
 * Notificar ausencia rechazada
 */
function notificar_ausencia_rechazada($pdo, $empleadoId, $tipoAusencia, $fechaInicio, $fechaFin, $motivo = '', $solicitudId = null) {
    $titulo = "❌ Ausencia rechazada";
    $mensaje = "Tu solicitud de {$tipoAusencia} del {$fechaInicio} al {$fechaFin} ha sido rechazada.";
    if ($motivo) {
        $mensaje .= " Motivo: {$motivo}";
    }
    $enlace = '/mis-gestiones.php?seccion=ausencias';
    if ($solicitudId) {
        $enlace .= '&ver=' . $solicitudId;
    }
    return crear_notificacion($pdo, $empleadoId, 'ausencia_rechazada', $titulo, $mensaje, $enlace);
}

/**
 * Notificar fichaje validado
 */
function notificar_fichaje_validado($pdo, $empleadoId, $fecha, $fechaDB = null) {
    $titulo = "✅ Fichaje validado";
    $mensaje = "Tu fichaje del día {$fecha} ha sido validado.";
    $enlace = '/mis-gestiones.php?seccion=historial';
    if ($fechaDB) {
        $enlace .= '&ver=' . $fechaDB;
    }
    return crear_notificacion($pdo, $empleadoId, 'fichaje_validado', $titulo, $mensaje, $enlace);
}

/**
 * Notificar fichaje rechazado
 */
function notificar_fichaje_rechazado($pdo, $empleadoId, $fecha, $motivo = '', $fechaDB = null) {
    $titulo = "❌ Fichaje rechazado";
    $mensaje = "Tu fichaje del día {$fecha} ha sido rechazado.";
    if ($motivo) {
        $mensaje .= " Motivo: {$motivo}";
    }
    $enlace = '/mis-gestiones.php?seccion=historial';
    if ($fechaDB) {
        $enlace .= '&ver=' . $fechaDB;
    }
    return crear_notificacion($pdo, $empleadoId, 'fichaje_rechazado', $titulo, $mensaje, $enlace);
}

/**
 * Notificar respuesta RGPD completada
 */
function notificar_rgpd_completada($pdo, $empleadoId, $tipoSolicitud) {
    $titulo = "✅ Solicitud RGPD atendida";
    $mensaje = "Tu solicitud de {$tipoSolicitud} ha sido procesada.";
    return crear_notificacion($pdo, $empleadoId, 'rgpd_completada', $titulo, $mensaje, '/mis-datos.php');
}

/**
 * Notificar respuesta RGPD rechazada
 */
function notificar_rgpd_rechazada($pdo, $empleadoId, $tipoSolicitud, $motivo = '') {
    $titulo = "❌ Solicitud RGPD rechazada";
    $mensaje = "Tu solicitud de {$tipoSolicitud} no ha podido ser atendida.";
    if ($motivo) {
        $mensaje .= " Motivo: {$motivo}";
    }
    return crear_notificacion($pdo, $empleadoId, 'rgpd_rechazada', $titulo, $mensaje, '/mis-datos.php');
}

/**
 * Notificar nuevo documento disponible
 */
function notificar_documento_nuevo($pdo, $empleadoId, $nombreDocumento) {
    $titulo = "📄 Nuevo documento";
    $mensaje = "Tienes un nuevo documento disponible: {$nombreDocumento}";
    return crear_notificacion($pdo, $empleadoId, 'documento_nuevo', $titulo, $mensaje, '/mis-gestiones.php?seccion=documentos');
}

/**
 * Notificación del sistema (genérica)
 */
function notificar_sistema($pdo, $empleadoId, $titulo, $mensaje, $enlace = null) {
    return crear_notificacion($pdo, $empleadoId, 'sistema', $titulo, $mensaje, $enlace);
}

// ============================================================================
// FUNCIÓN PARA OBTENER ICONO POR TIPO
// ============================================================================

function obtener_icono_notificacion($tipo) {
    $iconos = [
        'ausencia_aprobada' => '✅',
        'ausencia_rechazada' => '❌',
        'fichaje_validado' => '✅',
        'fichaje_rechazado' => '❌',
        'rgpd_completada' => '✅',
        'rgpd_rechazada' => '❌',
        'documento_nuevo' => '📄',
        'sistema' => '🔔'
    ];
    return $iconos[$tipo] ?? '🔔';
}

function obtener_color_notificacion($tipo) {
    if (strpos($tipo, 'aprobada') !== false || strpos($tipo, 'validado') !== false || strpos($tipo, 'completada') !== false) {
        return '#059669'; // Verde
    }
    if (strpos($tipo, 'rechazada') !== false || strpos($tipo, 'rechazado') !== false) {
        return '#dc2626'; // Rojo
    }
    return '#3b82f6'; // Azul
}
