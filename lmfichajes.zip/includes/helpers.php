<?php
/**
 * LM FICHAJES - Funciones Helper para Templates
 * 
 * Incluir en config.php o al inicio de cada archivo.
 * 
 * @package LMFichajes
 * @version 2.0.0
 */

// Evitar doble inclusión
if (defined('LMFICHAJES_HELPERS')) {
    return;
}
define('LMFICHAJES_HELPERS', true);

/**
 * Incluye un template con variables
 * 
 * @param string $template Ruta del template (ej: 'portal/header', 'components/alerts')
 * @param array $data Variables a pasar al template
 */
function template(string $template, array $data = []): void {
    // Extraer variables de forma segura con prefijo para evitar colisiones
    // Solo se permiten claves alfanuméricas
    foreach ($data as $__key => $__value) {
        if (preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $__key)) {
            $$__key = $__value;
        }
    }
    unset($__key, $__value);

    $templatePath = __DIR__ . '/../templates/' . $template . '.php';

    if (file_exists($templatePath)) {
        require $templatePath;
    } else {
        error_log("Template no encontrado: $template");
    }
}

/**
 * Escapa HTML para output seguro (alias corto)
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Genera URL absoluta
 */
function url(string $path = ''): string {
    $base = defined('APP_URL') ? APP_URL : '';
    return $base . '/' . ltrim($path, '/');
}

/**
 * Genera URL para assets
 */
function asset(string $path): string {
    return '/assets/' . ltrim($path, '/');
}

/**
 * Redirige a una URL
 */
function redirect(string $url, int $code = 302): void {
    header('Location: ' . $url, true, $code);
    exit;
}

/**
 * Verifica si es una petición AJAX
 */
function isAjax(): bool {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Devuelve respuesta JSON y termina
 */
function json(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Obtiene un valor de sesión flash y lo elimina
 */
function flash(string $key): ?string {
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    return null;
}

/**
 * Establece un mensaje flash en sesión
 */
function setFlash(string $key, string $message): void {
    $_SESSION['flash'][$key] = $message;
}

/**
 * Formatea fecha en español
 */
function fechaEspanol(?int $timestamp = null): string {
    if ($timestamp === null) {
        $timestamp = time();
    }
    
    $dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 
              'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    
    $diaSemana = $dias[date('w', $timestamp)];
    $dia = date('d', $timestamp);
    $mes = $meses[intval(date('n', $timestamp))];
    $anio = date('Y', $timestamp);
    
    return "$diaSemana, $dia de $mes de $anio";
}

/**
 * Formatea horas:minutos
 */
function formatoHoras(int $minutos): string {
    $signo = $minutos < 0 ? '-' : '';
    $minutos = abs($minutos);
    $horas = floor($minutos / 60);
    $mins = $minutos % 60;
    return $signo . $horas . ':' . str_pad($mins, 2, '0', STR_PAD_LEFT);
}

/**
 * Obtiene nombre de la empresa desde configuración
 */
function getNombreEmpresa(PDO $pdo): string {
    static $nombreEmpresa = null;
    
    if ($nombreEmpresa === null) {
        $nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
        try {
            $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
            $config = $stmt->fetch();
            if ($config && !empty($config->valor)) {
                $nombreEmpresa = $config->valor;
            }
        } catch (Exception $e) {
            // Tabla no existe, usar valor por defecto
        }
    }
    
    return $nombreEmpresa;
}

/**
 * Formatea minutos como bolsa de horas (hh:mm con signo)
 */
function formatearBolsaHoras(int $minutos): string {
    $signo = $minutos < 0 ? '-' : '+';
    $minutos = abs($minutos);
    $horas = floor($minutos / 60);
    $mins = $minutos % 60;
    return $signo . $horas . ':' . str_pad($mins, 2, '0', STR_PAD_LEFT);
}
