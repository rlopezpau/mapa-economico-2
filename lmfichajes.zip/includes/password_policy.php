<?php
/**
 * LM FICHAJES - Política de Contraseñas
 * 
 * Funciones para gestión de expiración y complejidad de contraseñas.
 * Cumple con ISO 27001 y políticas de seguridad ENS.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      LM Fichajes
 * @version     1.0.0
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

/**
 * Verifica si la contraseña del usuario ha expirado
 * 
 * @param PDO $pdo Conexión a base de datos
 * @param int $usuario_id ID del usuario
 * @return bool True si la contraseña ha expirado
 */
function password_expirada($pdo, $usuario_id) {
    // Si no está definido PASSWORD_EXPIRY_DAYS, no hay expiración
    if (!defined('PASSWORD_EXPIRY_DAYS') || PASSWORD_EXPIRY_DAYS <= 0) {
        return false;
    }
    
    try {
        // Verificar si existe la columna password_updated_at
        $stmt = $pdo->prepare("SHOW COLUMNS FROM empleados LIKE 'password_updated_at'");
        $stmt->execute();
        if ($stmt->rowCount() === 0) {
            // La columna no existe, no podemos verificar expiración
            return false;
        }
        
        $stmt = $pdo->prepare("
            SELECT password_updated_at 
            FROM empleados 
            WHERE id = ?
        ");
        $stmt->execute([$usuario_id]);
        $resultado = $stmt->fetch();
        
        if (!$resultado || !$resultado->password_updated_at) {
            // Si no hay fecha, considerar que necesita cambio
            return true;
        }
        
        $fecha_cambio = new DateTime($resultado->password_updated_at);
        $ahora = new DateTime();
        $dias = $ahora->diff($fecha_cambio)->days;
        
        return $dias >= PASSWORD_EXPIRY_DAYS;
        
    } catch (Exception $e) {
        error_log("Error verificando expiración de contraseña: " . $e->getMessage());
        return false;
    }
}

/**
 * Calcula los días restantes hasta que expire la contraseña
 * 
 * @param PDO $pdo Conexión a base de datos
 * @param int $usuario_id ID del usuario
 * @return int|null Días restantes o null si no aplica
 */
function dias_para_expirar_password($pdo, $usuario_id) {
    if (!defined('PASSWORD_EXPIRY_DAYS') || PASSWORD_EXPIRY_DAYS <= 0) {
        return null;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT password_updated_at 
            FROM empleados 
            WHERE id = ?
        ");
        $stmt->execute([$usuario_id]);
        $resultado = $stmt->fetch();
        
        if (!$resultado || !$resultado->password_updated_at) {
            return 0;
        }
        
        $fecha_cambio = new DateTime($resultado->password_updated_at);
        $fecha_expiracion = $fecha_cambio->modify('+' . PASSWORD_EXPIRY_DAYS . ' days');
        $ahora = new DateTime();
        
        if ($ahora >= $fecha_expiracion) {
            return 0;
        }
        
        return $ahora->diff($fecha_expiracion)->days;
        
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Valida la complejidad de una contraseña
 * 
 * Requisitos:
 * - Mínimo 8 caracteres (o PASSWORD_MIN_LENGTH si está definido)
 * - Al menos una mayúscula
 * - Al menos una minúscula
 * - Al menos un número
 * 
 * @param string $password Contraseña a validar
 * @return array ['valido' => bool, 'errores' => array]
 */
function validar_complejidad_password($password) {
    $errores = [];
    $min_length = defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8;
    
    if (strlen($password) < $min_length) {
        $errores[] = "La contraseña debe tener al menos $min_length caracteres";
    }
    
    if (!preg_match('/[A-Z]/', $password)) {
        $errores[] = "La contraseña debe contener al menos una letra mayúscula";
    }
    
    if (!preg_match('/[a-z]/', $password)) {
        $errores[] = "La contraseña debe contener al menos una letra minúscula";
    }
    
    if (!preg_match('/[0-9]/', $password)) {
        $errores[] = "La contraseña debe contener al menos un número";
    }
    
    return [
        'valido' => empty($errores),
        'errores' => $errores
    ];
}

/**
 * Verifica si la contraseña está en el historial reciente
 * 
 * @param PDO $pdo Conexión a base de datos
 * @param int $usuario_id ID del usuario
 * @param string $password Contraseña a verificar
 * @return bool True si la contraseña ya fue usada recientemente
 */
function password_en_historial($pdo, $usuario_id, $password) {
    // Si no está definido PASSWORD_HISTORY, no verificamos
    if (!defined('PASSWORD_HISTORY') || PASSWORD_HISTORY <= 0) {
        return false;
    }
    
    try {
        // Verificar si existe la tabla password_history
        $stmt = $pdo->query("SHOW TABLES LIKE 'password_history'");
        if ($stmt->rowCount() === 0) {
            return false;
        }
        
        $stmt = $pdo->prepare("
            SELECT password_hash 
            FROM password_history 
            WHERE empleado_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$usuario_id, PASSWORD_HISTORY]);
        $historial = $stmt->fetchAll();
        
        foreach ($historial as $registro) {
            if (password_verify($password, $registro->password_hash)) {
                return true;
            }
        }
        
        return false;
        
    } catch (Exception $e) {
        error_log("Error verificando historial de contraseñas: " . $e->getMessage());
        return false;
    }
}

/**
 * Registra una contraseña en el historial
 * 
 * @param PDO $pdo Conexión a base de datos
 * @param int $usuario_id ID del usuario
 * @param string $password_hash Hash de la contraseña
 * @return bool True si se registró correctamente
 */
function registrar_password_historial($pdo, $usuario_id, $password_hash) {
    if (!defined('PASSWORD_HISTORY') || PASSWORD_HISTORY <= 0) {
        return true;
    }
    
    try {
        // Asegurar que existe la tabla
        asegurar_tabla_historial($pdo);
        
        // Insertar nuevo registro
        $stmt = $pdo->prepare("
            INSERT INTO password_history (empleado_id, password_hash, created_at) 
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$usuario_id, $password_hash]);
        
        // Eliminar registros antiguos (mantener solo PASSWORD_HISTORY)
        $stmt = $pdo->prepare("
            DELETE FROM password_history 
            WHERE empleado_id = ? 
            AND id NOT IN (
                SELECT id FROM (
                    SELECT id FROM password_history 
                    WHERE empleado_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ) AS subquery
            )
        ");
        $stmt->execute([$usuario_id, $usuario_id, PASSWORD_HISTORY]);
        
        return true;
        
    } catch (Exception $e) {
        error_log("Error registrando historial de contraseña: " . $e->getMessage());
        return false;
    }
}

/**
 * Actualiza la fecha de cambio de contraseña
 * 
 * @param PDO $pdo Conexión a base de datos
 * @param int $usuario_id ID del usuario
 * @return bool True si se actualizó correctamente
 */
function actualizar_fecha_password($pdo, $usuario_id) {
    try {
        // Asegurar que existe la columna
        asegurar_columnas_password($pdo);
        
        $stmt = $pdo->prepare("
            UPDATE empleados 
            SET password_updated_at = NOW() 
            WHERE id = ?
        ");
        return $stmt->execute([$usuario_id]);
        
    } catch (Exception $e) {
        error_log("Error actualizando fecha de contraseña: " . $e->getMessage());
        return false;
    }
}

/**
 * Verifica si la sesión ha expirado por inactividad
 * 
 * @return bool True si la sesión ha expirado
 */
function sesion_expirada_por_inactividad() {
    if (!defined('SESSION_TIMEOUT') || SESSION_TIMEOUT <= 0) {
        return false;
    }
    
    if (!isset($_SESSION['ultima_actividad'])) {
        $_SESSION['ultima_actividad'] = time();
        return false;
    }
    
    $inactividad = time() - $_SESSION['ultima_actividad'];
    
    if ($inactividad > SESSION_TIMEOUT) {
        return true;
    }
    
    // Actualizar tiempo de última actividad
    $_SESSION['ultima_actividad'] = time();
    return false;
}

/**
 * Asegura que existen las columnas necesarias en la tabla empleados
 * 
 * @param PDO $pdo Conexión a base de datos
 */
function asegurar_columnas_password($pdo) {
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM empleados LIKE 'password_updated_at'");
        if ($stmt->rowCount() === 0) {
            $pdo->exec("
                ALTER TABLE empleados 
                ADD COLUMN password_updated_at DATETIME DEFAULT NULL
            ");
        }
    } catch (Exception $e) {
        error_log("Error creando columna password_updated_at: " . $e->getMessage());
    }
}

/**
 * Asegura que existe la tabla de historial de contraseñas
 * 
 * @param PDO $pdo Conexión a base de datos
 */
function asegurar_tabla_historial($pdo) {
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS password_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                empleado_id INT NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                created_at DATETIME NOT NULL,
                INDEX idx_empleado (empleado_id),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    } catch (Exception $e) {
        error_log("Error creando tabla password_history: " . $e->getMessage());
    }
}
