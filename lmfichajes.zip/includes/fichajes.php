<?php
/**
 * LM FICHAJES - Funciones de Fichajes
 * 
 * LÃ³gica para registrar entrada, salida, pausas y gestiÃ³n de fichajes.
 * 
 * @package     LMFichajes
 * @subpackage  Includes
 * @author      Roberto LÃ³pez Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// ============================================================================
// CONSTANTES DE FICHAJES
// ============================================================================

define('FICHAJE_ENTRADA', 'entrada');
define('FICHAJE_SALIDA', 'salida');
define('FICHAJE_PAUSA_INICIO', 'pausa_inicio');
define('FICHAJE_PAUSA_FIN', 'pausa_fin');
define('FICHAJE_VISITA', 'visita');

define('MODO_PRESENCIAL', 'presencial');
define('MODO_TELETRABAJO', 'teletrabajo');
define('MODO_VISITA', 'visita');
define('MODO_FORMACION', 'formacion');

define('ESTADO_AUTO_APROBADO', 'auto_aprobado');
define('ESTADO_PENDIENTE', 'pendiente');
define('ESTADO_VALIDADO', 'validado');
define('ESTADO_AUTORIZADO', 'autorizado');
define('ESTADO_RECHAZADO', 'rechazado');

// ============================================================================
// FUNCIONES PRINCIPALES DE FICHAJE
// ============================================================================

/**
 * Cierra automáticamente fichajes abiertos de días anteriores
 * 
 * @param PDO $pdo Conexión a BD
 * @param int $empleadoId ID del empleado
 * @return array Información de fichajes cerrados
 */
function cerrar_fichajes_dias_anteriores($pdo, $empleadoId) {
    $resultado = [
        'cerrados' => 0,
        'fichajes' => []
    ];
    
    $hoy = date('Y-m-d');
    
    // Buscar entradas sin salida de días anteriores
    $sql = "SELECT f.id, f.fecha, f.hora, f.centro_id
            FROM fichajes f
            WHERE f.empleado_id = ?
              AND f.fecha < ?
              AND f.tipo = 'entrada'
              AND f.estado != 'rechazado'
              AND NOT EXISTS (
                  SELECT 1 FROM fichajes f2 
                  WHERE f2.empleado_id = f.empleado_id 
                    AND f2.fecha = f.fecha 
                    AND f2.tipo = 'salida'
                    AND f2.estado != 'rechazado'
                    AND f2.hora > f.hora
              )
            ORDER BY f.fecha ASC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $hoy]);
    $fichajesAbiertos = $stmt->fetchAll();
    
    foreach ($fichajesAbiertos as $fichaje) {
        // Crear salida automática a las 23:59:59 del mismo día
        try {
            $sqlInsert = "INSERT INTO fichajes (
                empleado_id, centro_id, fecha, hora, tipo, modo,
                estado, observacion, ip_address
            ) VALUES (
                ?, ?, ?, '23:59:59', 'salida', 'presencial',
                'auto_aprobado', 'Cierre automático - Fichaje no cerrado', ?
            )";
            
            $stmtInsert = $pdo->prepare($sqlInsert);
            $stmtInsert->execute([
                $empleadoId,
                $fichaje->centro_id,
                $fichaje->fecha,
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);
            
            // Actualizar resumen diario de ese día
            actualizar_resumen_diario($pdo, $empleadoId, $fichaje->fecha);
            
            $resultado['cerrados']++;
            $resultado['fichajes'][] = $fichaje->fecha;
            
        } catch (PDOException $e) {
            error_log("Error cerrando fichaje {$fichaje->id}: " . $e->getMessage());
        }
    }
    
    return $resultado;
}

/**
 * Registra un fichaje (entrada, salida, pausa, etc.)
 * 
 * @param PDO $pdo ConexiÃ³n a BD
 * @param int $empleadoId ID del empleado
 * @param string $tipo Tipo de fichaje (entrada, salida, pausa_inicio, pausa_fin, visita)
 * @param array $datos Datos adicionales (centro_id, modo, coordenadas, observacion)
 * @return array ['exito' => bool, 'mensaje' => string, 'fichaje_id' => int|null]
 */
function registrar_fichaje($pdo, $empleadoId, $tipo, $datos = []) {
    $resultado = [
        'exito' => false,
        'mensaje' => '',
        'fichaje_id' => null,
        'incidencias' => []
    ];
    
    // Validar tipo
    $tiposValidos = [FICHAJE_ENTRADA, FICHAJE_SALIDA, FICHAJE_PAUSA_INICIO, FICHAJE_PAUSA_FIN, FICHAJE_VISITA];
    if (!in_array($tipo, $tiposValidos)) {
        $resultado['mensaje'] = 'Tipo de fichaje no vÃ¡lido';
        return $resultado;
    }
    
    // Si es una entrada, cerrar automáticamente fichajes abiertos de días anteriores
    if ($tipo === FICHAJE_ENTRADA) {
        $cierreAuto = cerrar_fichajes_dias_anteriores($pdo, $empleadoId);
        if ($cierreAuto['cerrados'] > 0) {
            $resultado['incidencias'][] = 'Se cerraron automáticamente ' . $cierreAuto['cerrados'] . 
                ' fichaje(s) de días anteriores: ' . implode(', ', $cierreAuto['fichajes']);
        }
    }
    
    // Obtener datos del empleado con su horario
    $empleado = obtener_empleado_con_horario($pdo, $empleadoId);
    if (!$empleado) {
        $resultado['mensaje'] = 'Empleado no encontrado';
        return $resultado;
    }
    
    // Fecha y hora actuales
    $fecha = date('Y-m-d');
    $hora = date('H:i:s');
    
    // Datos del fichaje
    $centroId = $datos['centro_id'] ?? null;
    $modo = $datos['modo'] ?? MODO_PRESENCIAL;
    $coordenadas = $datos['coordenadas'] ?? null;
    $observacion = $datos['observacion'] ?? null;
    
    // Verificar si puede fichar este tipo
    $verificacion = verificar_puede_fichar($pdo, $empleadoId, $tipo, $fecha);
    if (!$verificacion['puede']) {
        $resultado['mensaje'] = $verificacion['mensaje'];
        return $resultado;
    }
    
    // Calcular distancia si hay coordenadas y centro
    $distanciaMetros = null;
    $fueraUbicacion = 0;
    
    if ($coordenadas && $centroId) {
        $centro = obtener_centro($pdo, $centroId);
        if ($centro && $centro->coordenadas) {
            $distanciaMetros = calcular_distancia($coordenadas, $centro->coordenadas);
            $fueraUbicacion = ($distanciaMetros > $centro->radio_metros) ? 1 : 0;
            
            if ($fueraUbicacion) {
                $resultado['incidencias'][] = "Fuera de ubicaciÃ³n ({$distanciaMetros}m del centro)";
            }
        }
    }
    
    // Verificar horario (solo para entrada/salida, no pausas ni visitas)
    $fueraHorario = 0;
    if (in_array($tipo, [FICHAJE_ENTRADA, FICHAJE_SALIDA]) && $empleado->horario_id) {
        $verificacionHorario = verificar_horario_fichaje($hora, $tipo, $empleado);
        $fueraHorario = $verificacionHorario['fuera_horario'] ? 1 : 0;
        
        if ($fueraHorario && !empty($verificacionHorario['mensaje'])) {
            $resultado['incidencias'][] = $verificacionHorario['mensaje'];
        }
    }
    
    // Determinar estado inicial
    $estado = ESTADO_AUTO_APROBADO;
    if ($fueraUbicacion || $fueraHorario) {
        $estado = ESTADO_PENDIENTE; // Requiere validaciÃ³n
    }
    
    // Insertar fichaje
    try {
        $sql = "INSERT INTO fichajes (
                    empleado_id, centro_id, fecha, hora, tipo, modo,
                    coordenadas, distancia_metros, fuera_ubicacion, fuera_horario,
                    estado, observacion, ip_address, user_agent
                ) VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?
                )";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $empleadoId,
            $centroId,
            $fecha,
            $hora,
            $tipo,
            $modo,
            $coordenadas,
            $distanciaMetros,
            $fueraUbicacion,
            $fueraHorario,
            $estado,
            $observacion,
            obtener_ip_cliente(),
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        ]);
        
        $fichajeId = $pdo->lastInsertId();
        
        // Actualizar resumen diario si es entrada o salida
        if (in_array($tipo, [FICHAJE_ENTRADA, FICHAJE_SALIDA])) {
            actualizar_resumen_diario($pdo, $empleadoId, $fecha);
        }
        
        $resultado['exito'] = true;
        $resultado['fichaje_id'] = $fichajeId;
        
        // Mensaje segÃºn estado
        if ($estado === ESTADO_PENDIENTE) {
            $resultado['mensaje'] = 'Fichaje registrado. Pendiente de validaciÃ³n.';
        } else {
            $resultado['mensaje'] = ucfirst($tipo) . ' registrada correctamente';
        }
        
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al registrar fichaje';
        error_log('Error fichaje: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Verifica si el empleado puede realizar un tipo de fichaje
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $tipo
 * @param string $fecha
 * @return array ['puede' => bool, 'mensaje' => string]
 */
function verificar_puede_fichar($pdo, $empleadoId, $tipo, $fecha) {
    $resultado = ['puede' => true, 'mensaje' => ''];
    
    // Obtener estado actual del empleado
    $estado = obtener_estado_empleado($pdo, $empleadoId, $fecha);
    
    switch ($tipo) {
        case FICHAJE_ENTRADA:
            if ($estado['estado'] === 'trabajando') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'Ya has fichado entrada hoy. Debes fichar salida primero.';
            } elseif ($estado['estado'] === 'pausa') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'EstÃ¡s en pausa. Debes reanudar primero.';
            }
            break;
            
        case FICHAJE_SALIDA:
            if ($estado['estado'] === 'fuera') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'No has fichado entrada hoy.';
            } elseif ($estado['estado'] === 'pausa') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'EstÃ¡s en pausa. Debes reanudar antes de salir.';
            }
            break;
            
        case FICHAJE_PAUSA_INICIO:
            if ($estado['estado'] !== 'trabajando') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'Solo puedes pausar si estÃ¡s trabajando.';
            }
            break;
            
        case FICHAJE_PAUSA_FIN:
            if ($estado['estado'] !== 'pausa') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'No estÃ¡s en pausa.';
            }
            break;
            
        case FICHAJE_VISITA:
            // Las visitas siempre se pueden registrar si estÃ¡ trabajando
            if ($estado['estado'] !== 'trabajando') {
                $resultado['puede'] = false;
                $resultado['mensaje'] = 'Solo puedes registrar visitas si estÃ¡s trabajando.';
            }
            break;
    }
    
    return $resultado;
}

/**
 * Obtiene el estado actual del empleado (fuera, trabajando, pausa)
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $fecha
 * @return array ['estado' => string, 'ultimo_fichaje' => object|null]
 */
function obtener_estado_empleado($pdo, $empleadoId, $fecha = null) {
    if ($fecha === null) {
        $fecha = date('Y-m-d');
    }
    
    $resultado = [
        'estado' => 'fuera',
        'ultimo_fichaje' => null,
        'hora_entrada' => null,
        'en_pausa_desde' => null,
        'modo_entrada' => null,      // Modo de la entrada activa
        'centro_entrada' => null     // Centro de la entrada activa
    ];
    
    // Obtener fichajes del dÃ­a ordenados por hora
    $sql = "SELECT * FROM fichajes 
            WHERE empleado_id = ? AND fecha = ? AND estado != 'rechazado'
            ORDER BY hora DESC 
            LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $fecha]);
    $ultimoFichaje = $stmt->fetch();
    
    if (!$ultimoFichaje) {
        return $resultado;
    }
    
    $resultado['ultimo_fichaje'] = $ultimoFichaje;
    
    switch ($ultimoFichaje->tipo) {
        case FICHAJE_ENTRADA:
        case FICHAJE_PAUSA_FIN:
            $resultado['estado'] = 'trabajando';
            break;
            
        case FICHAJE_SALIDA:
            $resultado['estado'] = 'fuera';
            break;
            
        case FICHAJE_PAUSA_INICIO:
            $resultado['estado'] = 'pausa';
            $resultado['en_pausa_desde'] = $ultimoFichaje->hora;
            break;
            
        case FICHAJE_VISITA:
            // Las visitas no cambian el estado
            // Buscar el fichaje anterior que no sea visita
            $sql = "SELECT * FROM fichajes 
                    WHERE empleado_id = ? AND fecha = ? AND tipo != 'visita' AND estado != 'rechazado'
                    ORDER BY hora DESC 
                    LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$empleadoId, $fecha]);
            $fichajeAnterior = $stmt->fetch();
            
            if ($fichajeAnterior) {
                if (in_array($fichajeAnterior->tipo, [FICHAJE_ENTRADA, FICHAJE_PAUSA_FIN])) {
                    $resultado['estado'] = 'trabajando';
                } elseif ($fichajeAnterior->tipo === FICHAJE_PAUSA_INICIO) {
                    $resultado['estado'] = 'pausa';
                }
            }
            break;
    }
    
    // Obtener hora, modo y centro de primera entrada del dÃ­a
    $sql = "SELECT hora, modo, centro_id FROM fichajes 
            WHERE empleado_id = ? AND fecha = ? AND tipo = 'entrada' AND estado != 'rechazado'
            ORDER BY hora ASC 
            LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $fecha]);
    $primeraEntrada = $stmt->fetch();
    if ($primeraEntrada) {
        $resultado['hora_entrada'] = $primeraEntrada->hora;
        $resultado['modo_entrada'] = $primeraEntrada->modo;
        $resultado['centro_entrada'] = $primeraEntrada->centro_id;
    }
    
    return $resultado;
}

// ============================================================================
// FUNCIONES DE CONSULTA DE FICHAJES
// ============================================================================

/**
 * Obtiene los fichajes del dÃ­a de un empleado
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $fecha (opcional, por defecto hoy)
 * @return array
 */
function obtener_fichajes_dia($pdo, $empleadoId, $fecha = null) {
    if ($fecha === null) {
        $fecha = date('Y-m-d');
    }
    
    $sql = "SELECT f.*, c.nombre as centro_nombre
            FROM fichajes f
            LEFT JOIN centros c ON f.centro_id = c.id
            WHERE f.empleado_id = ? AND f.fecha = ?
            ORDER BY f.hora ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId, $fecha]);
    
    return $stmt->fetchAll();
}

/**
 * Calcula las horas trabajadas de un dÃ­a
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $fecha
 * @return array ['minutos' => int, 'formateado' => string]
 */
function calcular_horas_trabajadas_dia($pdo, $empleadoId, $fecha = null) {
    if ($fecha === null) {
        $fecha = date('Y-m-d');
    }
    
    $fichajes = obtener_fichajes_dia($pdo, $empleadoId, $fecha);
    
    $minutosTrabajados = 0;
    $entradaActual = null;
    $pausaInicio = null;
    $minutosPausa = 0;
    
    foreach ($fichajes as $fichaje) {
        // Solo contar fichajes aprobados
        if ($fichaje->estado === ESTADO_RECHAZADO) {
            continue;
        }
        
        $horaFichaje = strtotime($fichaje->hora);
        
        switch ($fichaje->tipo) {
            case FICHAJE_ENTRADA:
                $entradaActual = $horaFichaje;
                break;
                
            case FICHAJE_SALIDA:
                if ($entradaActual !== null) {
                    $minutosTrabajados += ($horaFichaje - $entradaActual) / 60;
                    $minutosTrabajados -= $minutosPausa;
                    $entradaActual = null;
                    $minutosPausa = 0;
                }
                break;
                
            case FICHAJE_PAUSA_INICIO:
                $pausaInicio = $horaFichaje;
                break;
                
            case FICHAJE_PAUSA_FIN:
                if ($pausaInicio !== null) {
                    $minutosPausa += ($horaFichaje - $pausaInicio) / 60;
                    $pausaInicio = null;
                }
                break;
        }
    }
    
    // Si todavÃ­a estÃ¡ trabajando (sin salida), calcular hasta ahora
    if ($entradaActual !== null && $fecha === date('Y-m-d')) {
        $ahora = time();
        $minutosTrabajados += ($ahora - $entradaActual) / 60;
        $minutosTrabajados -= $minutosPausa;
        
        // Si estÃ¡ en pausa ahora, descontar tiempo de pausa actual
        if ($pausaInicio !== null) {
            $minutosTrabajados -= ($ahora - $pausaInicio) / 60;
        }
    }
    
    $minutosTrabajados = max(0, round($minutosTrabajados));
    
    return [
        'minutos' => $minutosTrabajados,
        'formateado' => formato_horas_minutos($minutosTrabajados)
    ];
}

/**
 * Actualiza el resumen diario de un empleado
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $fecha
 */
function actualizar_resumen_diario($pdo, $empleadoId, $fecha) {
    $horasTrabajadas = calcular_horas_trabajadas_dia($pdo, $empleadoId, $fecha);
    $fichajes = obtener_fichajes_dia($pdo, $empleadoId, $fecha);
    
    // Obtener primera entrada y Ãºltima salida
    $primeraEntrada = null;
    $ultimaSalida = null;
    $modo = MODO_PRESENCIAL;
    
    foreach ($fichajes as $fichaje) {
        if ($fichaje->estado === ESTADO_RECHAZADO) continue;
        
        if ($fichaje->tipo === FICHAJE_ENTRADA && $primeraEntrada === null) {
            $primeraEntrada = $fichaje->hora;
            $modo = $fichaje->modo;
        }
        if ($fichaje->tipo === FICHAJE_SALIDA) {
            $ultimaSalida = $fichaje->hora;
        }
    }
    
    // Obtener horas esperadas del horario del empleado
    $empleado = obtener_empleado_con_horario($pdo, $empleadoId);
    $minutosEsperados = 0;
    if ($empleado && $empleado->horas_diarias) {
        $minutosEsperados = $empleado->horas_diarias * 60;
    }
    
    // Calcular balance
    $balance = $horasTrabajadas['minutos'] - $minutosEsperados;
    
    // Insertar o actualizar
    $sql = "INSERT INTO resumen_diario 
            (empleado_id, fecha, modo_trabajo, minutos_esperados, minutos_trabajados, minutos_balance, primera_entrada, ultima_salida)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            modo_trabajo = VALUES(modo_trabajo),
            minutos_esperados = VALUES(minutos_esperados),
            minutos_trabajados = VALUES(minutos_trabajados),
            minutos_balance = VALUES(minutos_balance),
            primera_entrada = VALUES(primera_entrada),
            ultima_salida = VALUES(ultima_salida),
            updated_at = NOW()";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $empleadoId,
        $fecha,
        $modo,
        $minutosEsperados,
        $horasTrabajadas['minutos'],
        $balance,
        $primeraEntrada,
        $ultimaSalida
    ]);
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/**
 * Obtiene un empleado con datos de su horario
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @return object|null
 */
function obtener_empleado_con_horario($pdo, $empleadoId) {
    $sql = "SELECT e.*, 
            h.nombre as horario_nombre,
            h.tipo as horario_tipo,
            h.horas_diarias,
            h.hora_entrada,
            h.hora_salida,
            h.hora_entrada_tarde,
            h.hora_salida_tarde,
            h.troncal_inicio,
            h.troncal_fin,
            h.troncal_tarde_inicio,
            h.troncal_tarde_fin,
            h.cortesia_entrada,
            h.cortesia_salida,
            h.tolerancia_minutos
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE e.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId]);
    return $stmt->fetch();
}

/**
 * Obtiene un centro por ID
 * 
 * @param PDO $pdo
 * @param int $centroId
 * @return object|null
 */
function obtener_centro($pdo, $centroId) {
    $sql = "SELECT * FROM centros WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$centroId]);
    return $stmt->fetch();
}

/**
 * Calcula la distancia en metros entre dos puntos GPS
 * 
 * @param string $coord1 "lat,lng"
 * @param string $coord2 "lat,lng"
 * @return int Distancia en metros
 */
function calcular_distancia($coord1, $coord2) {
    $partes1 = explode(',', $coord1);
    $partes2 = explode(',', $coord2);
    
    if (count($partes1) !== 2 || count($partes2) !== 2) {
        return 0;
    }
    
    $lat1 = floatval(trim($partes1[0]));
    $lon1 = floatval(trim($partes1[1]));
    $lat2 = floatval(trim($partes2[0]));
    $lon2 = floatval(trim($partes2[1]));
    
    // FÃ³rmula de Haversine
    $radioTierra = 6371000; // metros
    
    $lat1Rad = deg2rad($lat1);
    $lat2Rad = deg2rad($lat2);
    $deltaLat = deg2rad($lat2 - $lat1);
    $deltaLon = deg2rad($lon2 - $lon1);
    
    $a = sin($deltaLat / 2) * sin($deltaLat / 2) +
         cos($lat1Rad) * cos($lat2Rad) *
         sin($deltaLon / 2) * sin($deltaLon / 2);
    
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    
    return (int)round($radioTierra * $c);
}

/**
 * Verifica si el fichaje estÃ¡ dentro del horario
 * 
 * @param string $hora "H:i:s"
 * @param string $tipo entrada/salida
 * @param object $empleado Con datos de horario
 * @return array ['fuera_horario' => bool, 'mensaje' => string]
 */
function verificar_horario_fichaje($hora, $tipo, $empleado) {
    $resultado = ['fuera_horario' => false, 'mensaje' => ''];
    
    if (!$empleado->hora_entrada) {
        return $resultado; // Sin horario definido
    }
    
    $horaActual = strtotime($hora);
    $cortesiaEntrada = ($empleado->cortesia_entrada ?? 5) * 60; // segundos
    $cortesiaSalida = ($empleado->cortesia_salida ?? 5) * 60;
    
    if ($tipo === FICHAJE_ENTRADA) {
        $horaEntrada = strtotime($empleado->hora_entrada);
        $tolerancia = ($empleado->tolerancia_minutos ?? 15) * 60;
        
        // Si tiene troncal, verificar contra troncal
        if ($empleado->troncal_inicio) {
            $troncalInicio = strtotime($empleado->troncal_inicio);
            
            // Si entra despuÃ©s del inicio del troncal
            if ($horaActual > $troncalInicio + $cortesiaEntrada) {
                $resultado['fuera_horario'] = true;
                $resultado['mensaje'] = 'Entrada despuÃ©s del horario troncal (' . 
                    substr($empleado->troncal_inicio, 0, 5) . ')';
            }
        } else {
            // Sin troncal, verificar contra hora de entrada + tolerancia
            if ($horaActual > $horaEntrada + $tolerancia + $cortesiaEntrada) {
                $resultado['fuera_horario'] = true;
                $resultado['mensaje'] = 'Entrada fuera del horario permitido';
            }
        }
    }
    
    if ($tipo === FICHAJE_SALIDA) {
        $horaSalida = strtotime($empleado->hora_salida);
        
        // Si tiene troncal, verificar contra troncal
        if ($empleado->troncal_fin) {
            $troncalFin = strtotime($empleado->troncal_fin);
            
            // Si sale antes del fin del troncal
            if ($horaActual < $troncalFin - $cortesiaSalida) {
                $resultado['fuera_horario'] = true;
                $resultado['mensaje'] = 'Salida antes del horario troncal (' . 
                    substr($empleado->troncal_fin, 0, 5) . ')';
            }
        }
    }
    
    return $resultado;
}

/**
 * Formatea minutos a formato legible (H:MM)
 * 
 * @param int $minutos
 * @return string
 */
function formato_horas_minutos($minutos) {
    $signo = $minutos < 0 ? '-' : '';
    $minutos = (int)abs($minutos);
    $horas = floor($minutos / 60);
    $mins = (int)$minutos % 60;
    return $signo . $horas . ':' . str_pad($mins, 2, '0', STR_PAD_LEFT);
}

/**
 * Genera enlace a Google Maps para unas coordenadas
 * 
 * @param string $coordenadas "lat,lng"
 * @return string URL de Google Maps
 */
function google_maps_link($coordenadas) {
    if (empty($coordenadas)) {
        return '';
    }
    
    $partes = explode(',', $coordenadas);
    if (count($partes) !== 2) {
        return '';
    }
    
    $lat = trim($partes[0]);
    $lng = trim($partes[1]);
    
    return "https://www.google.com/maps?q={$lat},{$lng}";
}

/**
 * Traduce el tipo de fichaje a texto legible
 * 
 * @param string $tipo
 * @return string
 */
function traducir_tipo_fichaje($tipo) {
    $tipos = [
        'entrada' => '&#9658; Entrada',
        'salida' => '&#9632; Salida',
        'pausa_inicio' => '&#10074;&#10074; Pausa',
        'pausa_fin' => '&#9658; Reanudar',
        'visita' => '&#128205; Visita'
    ];
    return $tipos[$tipo] ?? $tipo;
}

/**
 * Traduce el modo de trabajo a texto legible
 * 
 * @param string $modo
 * @return string
 */
function traducir_modo_trabajo($modo) {
    $modos = [
        'presencial' => '&#127970; Presencial',
        'teletrabajo' => '&#127968; Teletrabajo',
        'visita' => '&#128663; Visita',
        'formacion' => '&#128218; Formacion'
    ];
    return $modos[$modo] ?? $modo;
}

/**
 * Traduce el estado del fichaje a texto legible
 * 
 * @param string $estado
 * @return array ['texto' => string, 'clase' => string]
 */
function traducir_estado_fichaje($estado) {
    $estados = [
        'auto_aprobado' => ['texto' => '&#10004; Aprobado', 'clase' => 'success'],
        'pendiente' => ['texto' => '&#9203; Pendiente', 'clase' => 'warning'],
        'validado' => ['texto' => '&#10004; Validado', 'clase' => 'info'],
        'autorizado' => ['texto' => '&#10004; Autorizado', 'clase' => 'success'],
        'rechazado' => ['texto' => '&#10008; Rechazado', 'clase' => 'danger']
    ];
    return $estados[$estado] ?? ['texto' => $estado, 'clase' => 'secondary'];
}

/**
 * Obtiene el resumen del día de un empleado
 * 
 * @param PDO $pdo
 * @param int $empleadoId
 * @param string $fecha
 * @return object
 */
function obtener_resumen_dia($pdo, $empleadoId, $fecha = null) {
    if ($fecha === null) {
        $fecha = date('Y-m-d');
    }
    
    // Calcular horas trabajadas del día
    $horasTrabajadas = calcular_horas_trabajadas_dia($pdo, $empleadoId, $fecha);
    
    // Obtener horas esperadas del horario del empleado
    $empleado = obtener_empleado_con_horario($pdo, $empleadoId);
    $minutosEsperados = 0;
    
    if ($empleado) {
        // Si tiene porcentaje de jornada, aplicarlo
        $porcentaje = $empleado->porcentaje_jornada ?? 100;
        
        if (isset($empleado->horas_diarias)) {
            $minutosEsperados = (int)($empleado->horas_diarias * 60 * ($porcentaje / 100));
        } elseif (isset($empleado->horas_semanales)) {
            // Asumir 5 días laborables
            $minutosEsperados = (int)(($empleado->horas_semanales / 5) * 60 * ($porcentaje / 100));
        } else {
            // Por defecto 7.5 horas
            $minutosEsperados = (int)(7.5 * 60 * ($porcentaje / 100));
        }
    }
    
    // Calcular balance
    $balance = $horasTrabajadas['minutos'] - $minutosEsperados;
    
    return (object)[
        'empleado_id' => $empleadoId,
        'fecha' => $fecha,
        'minutos_trabajados' => $horasTrabajadas['minutos'],
        'minutos_esperados' => $minutosEsperados,
        'minutos_balance' => $balance
    ];
}
