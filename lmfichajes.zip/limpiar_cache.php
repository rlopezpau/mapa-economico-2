<?php
/**
 * LIMPIAR CACHÉ - SOLO ADMINISTRADORES
 * 
 * Limpia archivos temporales y caché del sistema.
 * Requiere autenticación de administrador.
 */

require_once 'config.php';
require_once 'includes/auth.php';

// REQUIERE LOGIN DE ADMINISTRADOR
requerir_login();
if (!es_admin()) {
    header('HTTP/1.1 403 Forbidden');
    die('Acceso denegado. Solo administradores.');
}

require_once 'includes/auditoria.php';

$mensaje = '';
$tipo = '';

// Procesar limpieza
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    
    // Verificar CSRF
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $mensaje = 'Token de seguridad inválido';
        $tipo = 'error';
    } else {
        $accion = $_POST['accion'];
        
        switch ($accion) {
            case 'limpiar_logs':
                // Limpiar logs antiguos (más de 30 días)
                $archivos_eliminados = 0;
                $log_dir = __DIR__ . '/logs/';
                if (is_dir($log_dir)) {
                    $archivos = glob($log_dir . '*.log');
                    foreach ($archivos as $archivo) {
                        if (filemtime($archivo) < strtotime('-30 days')) {
                            unlink($archivo);
                            $archivos_eliminados++;
                        }
                    }
                }
                $mensaje = "Logs antiguos limpiados: $archivos_eliminados archivos";
                $tipo = 'ok';
                
                registrar_auditoria($pdo, 'CACHE_LIMPIADA', 'Limpieza de logs antiguos', [
                    'archivos_eliminados' => $archivos_eliminados
                ]);
                break;
                
            case 'limpiar_sesiones_expiradas':
                // Esto lo maneja PHP automáticamente, pero podemos forzarlo
                $session_path = session_save_path();
                $mensaje = "Las sesiones expiradas se limpian automáticamente por PHP";
                $tipo = 'warning';
                break;
                
            case 'limpiar_temporales':
                // Limpiar archivos temporales de uploads
                $temp_eliminados = 0;
                $temp_dir = __DIR__ . '/uploads/temp/';
                if (is_dir($temp_dir)) {
                    $archivos = glob($temp_dir . '*');
                    foreach ($archivos as $archivo) {
                        if (is_file($archivo) && filemtime($archivo) < strtotime('-1 day')) {
                            unlink($archivo);
                            $temp_eliminados++;
                        }
                    }
                }
                $mensaje = "Archivos temporales limpiados: $temp_eliminados";
                $tipo = 'ok';
                
                registrar_auditoria($pdo, 'CACHE_LIMPIADA', 'Limpieza de temporales', [
                    'archivos_eliminados' => $temp_eliminados
                ]);
                break;
                
            default:
                $mensaje = 'Acción no reconocida';
                $tipo = 'error';
        }
    }
}

// Generar token CSRF
$csrf_token = generar_csrf();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Limpiar Caché - LM Fichajes</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
        .card { background: white; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #1e40af; }
        .btn { display: inline-block; padding: 10px 20px; background: #1e40af; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 1rem; }
        .btn:hover { background: #1e3a8a; }
        .btn-warning { background: #d97706; }
        .btn-warning:hover { background: #b45309; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6b7280; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .mensaje { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .mensaje.ok { background: #d1fae5; color: #065f46; }
        .mensaje.error { background: #fee2e2; color: #991b1b; }
        .mensaje.warning { background: #fef3c7; color: #92400e; }
        .accion-item { display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #e5e7eb; }
        .accion-item:last-child { border-bottom: none; }
        .accion-info h3 { margin: 0 0 5px 0; }
        .accion-info p { margin: 0; color: #6b7280; font-size: 0.875rem; }
    </style>
</head>
<body>
    <a href="admin/" class="back-btn">← Volver al Admin</a>
    <h1>🧹 Limpiar Caché del Sistema</h1>
    <p>Usuario: <strong><?php echo htmlspecialchars(obtener_usuario_nombre()); ?></strong></p>

    <?php if ($mensaje): ?>
    <div class="mensaje <?php echo $tipo; ?>">
        <?php echo htmlspecialchars($mensaje); ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="accion-item">
            <div class="accion-info">
                <h3>🗑️ Limpiar logs antiguos</h3>
                <p>Elimina archivos de log con más de 30 días</p>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="accion" value="limpiar_logs">
                <button type="submit" class="btn">Limpiar</button>
            </form>
        </div>

        <div class="accion-item">
            <div class="accion-info">
                <h3>📁 Limpiar archivos temporales</h3>
                <p>Elimina archivos temporales de uploads con más de 1 día</p>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="accion" value="limpiar_temporales">
                <button type="submit" class="btn">Limpiar</button>
            </form>
        </div>

        <div class="accion-item">
            <div class="accion-info">
                <h3>🔐 Sesiones expiradas</h3>
                <p>PHP limpia automáticamente las sesiones expiradas</p>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="accion" value="limpiar_sesiones_expiradas">
                <button type="submit" class="btn btn-warning">Info</button>
            </form>
        </div>
    </div>

    <p style="color: #6b7280; font-size: 0.875rem;">
        ⚠️ Todas las acciones quedan registradas en auditoría.
    </p>
</body>
</html>
