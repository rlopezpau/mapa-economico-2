<?php
/**
 * Vista: Formulario de empleados (nuevo/editar)
 */
defined('LMFICHAJES') or die('Acceso no permitido');
?>
<!-- FORMULARIO -->
    <div class="page-header">
        <div>
            <h1 class="page-title"><?= $accion === 'nuevo' ? '➕ Nuevo Empleado' : '✏️ Editar Empleado' ?></h1>
        </div>
        <a href="?accion=listar" class="btn btn-outline">← Volver</a>
    </div>
    
    <form method="POST">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="guardar">
        <?php if ($empleado): ?><input type="hidden" name="empleado_id" value="<?= $empleado->id ?>"><?php endif; ?>
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
            <div>
                <!-- Datos Personales -->
                <div class="card">
                    <div class="card-header"><span class="card-title">📋 Datos Personales</span></div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">NIF/NIE <span class="required">*</span></label>
                                <input type="text" name="nif" value="<?= htmlspecialchars($empleado->nif ?? '') ?>" required class="form-control" maxlength="15" style="text-transform: uppercase;">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nombre <span class="required">*</span></label>
                                <input type="text" name="nombre" value="<?= htmlspecialchars($empleado->nombre ?? '') ?>" required class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Primer Apellido <span class="required">*</span></label>
                                <input type="text" name="apellido1" value="<?= htmlspecialchars($empleado->apellido1 ?? '') ?>" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Segundo Apellido</label>
                                <input type="text" name="apellido2" value="<?= htmlspecialchars($empleado->apellido2 ?? '') ?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" value="<?= htmlspecialchars($empleado->email ?? '') ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Teléfono personal</label>
                                <input type="tel" name="telefono" value="<?= htmlspecialchars($empleado->telefono ?? '') ?>" class="form-control" placeholder="Personal/Móvil">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Teléfono trabajo</label>
                                <input type="tel" name="telefono_trabajo" value="<?= htmlspecialchars($empleado->telefono_trabajo ?? '') ?>" class="form-control" placeholder="Extensión o directo">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Domicilio (Teletrabajo) -->
                <div class="card">
                    <div class="card-header"><span class="card-title">🏠 Domicilio (para Teletrabajo)</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Dirección completa</label>
                            <input type="text" name="direccion" id="direccion" value="<?= htmlspecialchars($empleado->direccion ?? '') ?>" class="form-control" placeholder="Calle, número, ciudad...">
                        </div>
                        
                        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem;">
                            <strong>📍 ¿Cómo obtener las coordenadas?</strong>
                            <ol style="margin: 0.5rem 0 0.5rem 1.25rem; padding: 0; font-size: 0.875rem; color: #1e40af;">
                                <li>Abre Google Maps → <a href="https://www.google.com/maps" target="_blank" class="btn btn-sm btn-primary" style="margin-left: 0.5rem;">🗺️ Abrir Google Maps</a></li>
                                <li>Busca la dirección del domicilio</li>
                                <li>Haz clic derecho sobre el punto exacto</li>
                                <li>Copia las coordenadas (ej: 39.469907, -0.376288)</li>
                                <li>Pégalas en el campo de abajo</li>
                            </ol>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Coordenadas (lat,lng)</label>
                                <input type="text" name="coordenadas_domicilio" id="coordenadas_domicilio" value="<?= htmlspecialchars($empleado->coordenadas_domicilio ?? '') ?>" class="form-control" placeholder="39.469907, -0.376288" onchange="actualizarMapa()">
                                <div class="form-hint">Formato: latitud, longitud</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Radio permitido (metros)</label>
                                <input type="number" name="radio_domicilio" value="<?= $empleado->radio_domicilio ?? 50 ?>" class="form-control" min="10" max="500">
                                <div class="form-hint">Distancia máxima para fichar en teletrabajo</div>
                            </div>
                        </div>
                        
                        <div id="mapa_domicilio" style="height: 150px; background: #f1f5f9; border-radius: 0.5rem; overflow: hidden; display: flex; align-items: center; justify-content: center;">
                            <?php if (!empty($empleado->coordenadas_domicilio)): ?>
                                <div style="text-align: center;">
                                    <p style="margin-bottom: 0.5rem; color: #64748b;">📍 <?= htmlspecialchars($empleado->coordenadas_domicilio) ?></p>
                                    <a href="https://www.google.com/maps?q=<?= urlencode($empleado->coordenadas_domicilio) ?>" target="_blank" class="btn btn-sm btn-primary">🗺️ Ver en Maps</a>
                                </div>
                            <?php else: ?>
                                <div style="text-align: center; color: #64748b;">
                                    El mapa aparecerá al introducir las coordenadas
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Rol y Horario -->
                <div class="card">
                    <div class="card-header"><span class="card-title">🔐 Rol y Horario</span></div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Rol <span class="required">*</span></label>
                                <select name="rol" class="form-control" required>
                                    <option value="empleado" <?= ($empleado->rol ?? '') === 'empleado' ? 'selected' : '' ?>>Empleado</option>
                                    <option value="supervisor" <?= ($empleado->rol ?? '') === 'supervisor' ? 'selected' : '' ?>>Supervisor</option>
                                    <?php if (es_admin()): ?>
                                    <option value="manager" <?= ($empleado->rol ?? '') === 'manager' ? 'selected' : '' ?>>Manager</option>
                                    <option value="admin" <?= ($empleado->rol ?? '') === 'admin' ? 'selected' : '' ?>>Administrador</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Convenio Colectivo</label>
                                <select name="convenio_id" class="form-control">
                                    <option value="">-- Sin convenio --</option>
                                    <?php foreach ($convenios as $conv): ?>
                                    <option value="<?= $conv->id ?>" <?= ($empleado->convenio_id ?? 0) == $conv->id ? 'selected' : '' ?>>📋 <?= htmlspecialchars($conv->nombre) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-hint">Define los días de ausencia según convenio</div>
                            </div>
                        </div>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label class="form-label">Horario Fijo</label>
                                <select name="horario_id" id="horario_id" class="form-control">
                                    <option value="">-- Sin horario fijo --</option>
                                    <?php foreach ($horarios as $h): ?>
                                    <option value="<?= $h->id ?>" <?= ($empleado->horario_id ?? 0) == $h->id ? 'selected' : '' ?>><?= htmlspecialchars($h->nombre) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">% Jornada</label>
                                <div style="display: flex; gap: 0.5rem; align-items: center;">
                                    <input type="number" name="porcentaje_jornada" class="form-control" style="width: 100px;"
                                           value="<?= ($empleado->porcentaje_jornada ?? 100) ?>" 
                                           min="0" max="100" step="0.5">
                                    <span style="color: #64748b;">%</span>
                                    <div class="btn-group" style="margin-left: auto;">
                                        <button type="button" class="btn btn-sm btn-outline" onclick="document.querySelector('input[name=porcentaje_jornada]').value='50'">50%</button>
                                        <button type="button" class="btn btn-sm btn-outline" onclick="document.querySelector('input[name=porcentaje_jornada]').value='75'">75%</button>
                                        <button type="button" class="btn btn-sm btn-outline" onclick="document.querySelector('input[name=porcentaje_jornada]').value='100'">100%</button>
                                    </div>
                                </div>
                                <div class="form-hint">Porcentaje de jornada laboral (ej: 50% = media jornada)</div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Turno Rotativo</label>
                                <select name="turno_grupo_id" id="turno_grupo_id" class="form-control">
                                    <option value="">-- Sin turno rotativo --</option>
                                    <?php foreach ($turnos as $t): ?>
                                    <option value="<?= $t->id ?>" <?= ($empleado->turno_grupo_id ?? 0) == $t->id ? 'selected' : '' ?>>🔄 <?= htmlspecialchars($t->nombre) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-hint">Si seleccionas turno, el horario fijo se ignora</div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Supervisor Principal</label>
                                <select name="supervisor_id" class="form-control">
                                    <option value="">-- Sin supervisor --</option>
                                    <?php foreach ($supervisores as $s): ?>
                                    <option value="<?= $s->id ?>" <?= ($empleado->supervisor_id ?? 0) == $s->id ? 'selected' : '' ?>><?= htmlspecialchars($s->apellido1 . ', ' . $s->nombre) ?> (<?= $s->rol ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Supervisor Secundario</label>
                                <select name="supervisor2_id" class="form-control">
                                    <option value="">-- Sin supervisor secundario --</option>
                                    <?php foreach ($supervisores as $s): ?>
                                    <option value="<?= $s->id ?>" <?= ($empleado->supervisor2_id ?? 0) == $s->id ? 'selected' : '' ?>><?= htmlspecialchars($s->apellido1 . ', ' . $s->nombre) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-check">
                                <input type="checkbox" name="requiere_doble_validacion" <?= ($empleado->requiere_doble_validacion ?? 0) ? 'checked' : '' ?>>
                                Requiere doble validación (aprobación de ambos supervisores)
                            </label>
                        </div>
                    </div>
                </div>
                
                <!-- Centros -->
                <div class="card">
                    <div class="card-header"><span class="card-title">🏛️ Centros de Trabajo</span></div>
                    <div class="card-body">
                        <p style="color: #64748b; margin-bottom: 1rem;">Selecciona los centros donde puede fichar:</p>
                        <?php 
                        $centrosAsignados = [];
                        $centroPrincipalId = 0;
                        if ($empleado && !empty($empleado->centros)) {
                            foreach ($empleado->centros as $c) {
                                $centrosAsignados[] = $c->centro_id;
                                if ($c->es_principal) $centroPrincipalId = $c->centro_id;
                            }
                        }
                        ?>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 0.75rem;">
                            <?php foreach ($centros as $c): ?>
                            <div style="display: flex; align-items: center; gap: 0.5rem; padding: 0.75rem; background: #f8fafc; border-radius: 0.5rem;">
                                <input type="checkbox" name="centros[]" value="<?= $c->id ?>" id="centro_<?= $c->id ?>" <?= in_array($c->id, $centrosAsignados) ? 'checked' : '' ?>>
                                <label for="centro_<?= $c->id ?>" style="flex: 1; cursor: pointer;"><?= htmlspecialchars($c->nombre) ?></label>
                                <label style="font-size: 0.75rem; color: #64748b; display: flex; align-items: center; gap: 0.25rem;">
                                    <input type="radio" name="centro_principal" value="<?= $c->id ?>" <?= $c->id == $centroPrincipalId ? 'checked' : '' ?>>
                                    Principal
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if (empty($centros)): ?>
                        <p style="color: #94a3b8;">No hay centros. <a href="centros.php?accion=nuevo">Crear centro</a></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div>
                <!-- Vacaciones y Permisos -->
                <div class="card">
                    <div class="card-header"><span class="card-title">🏖️ Vacaciones</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Días base</label>
                            <input type="number" name="dias_vacaciones" value="<?= $empleado->dias_vacaciones ?? 22 ?>" class="form-control" min="0" max="60">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Días por antigüedad</label>
                            <input type="number" name="dias_vacaciones_antiguedad" value="<?= $empleado->dias_vacaciones_antiguedad ?? 0 ?>" class="form-control" min="0" max="30">
                        </div>
                        <div style="padding: 0.75rem; background: #dcfce7; border-radius: 0.5rem; text-align: center;">
                            <strong>Total: <span id="total_vacaciones"><?= ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0) ?></span> días</strong>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">📋 Libre Disposición</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Días base</label>
                            <input type="number" name="dias_libre_disposicion" value="<?= $empleado->dias_libre_disposicion ?? 6 ?>" class="form-control" min="0" max="30">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Días por antigüedad</label>
                            <input type="number" name="dias_libre_disp_antiguedad" value="<?= $empleado->dias_libre_disp_antiguedad ?? 0 ?>" class="form-control" min="0" max="15">
                        </div>
                        <div style="padding: 0.75rem; background: #e0f2fe; border-radius: 0.5rem; text-align: center;">
                            <strong>Total: <span id="total_permisos"><?= ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0) ?></span> días</strong>
                        </div>
                    </div>
                </div>
                
                <!-- Fechas -->
                <div class="card">
                    <div class="card-header"><span class="card-title">📅 Fechas</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Fecha de alta</label>
                            <input type="date" name="fecha_alta" value="<?= $empleado->fecha_alta ?? date('Y-m-d') ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Antigüedad desde</label>
                            <input type="date" name="fecha_antiguedad" value="<?= $empleado->fecha_antiguedad ?? '' ?>" class="form-control">
                            <div class="form-hint">Para cálculo de trienios y días extra</div>
                        </div>
                    </div>
                </div>
                
                <?php if ($empleado): ?>
                <!-- Estado y Seguridad -->
                <div class="card">
                    <div class="card-header"><span class="card-title">🔒 Estado y Seguridad</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-check">
                                <input type="checkbox" name="activo" <?= $empleado->activo ? 'checked' : '' ?>>
                                Empleado activo
                            </label>
                        </div>
                        
                        <?php if ($empleado->debe_cambiar_password ?? 0): ?>
                        <div style="padding: 0.5rem 0.75rem; background: #fef3c7; border-radius: 0.5rem; margin: 0.75rem 0; font-size: 0.875rem;">
                            ⚠️ Debe cambiar contraseña en próximo acceso
                        </div>
                        <?php endif; ?>
                        
                        <hr style="margin: 1rem 0; border: none; border-top: 1px solid #e2e8f0;">
                        
                        <!-- Establecer contraseña manual -->
                        <div style="margin-bottom: 1rem;">
                            <label class="form-label" style="font-weight: 600;">Establecer contraseña</label>
                            <div style="display: flex; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <input type="password" id="nueva_password" placeholder="Mínimo 6 caracteres" class="form-control" style="flex: 1;">
                                <button type="button" onclick="mostrarPassword()" class="btn btn-outline btn-sm" title="Ver/ocultar">👁️</button>
                            </div>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 0.75rem;">
                                <label class="form-check" style="font-size: 0.8rem;">
                                    <input type="checkbox" id="forzar_cambio_manual" checked>
                                    Forzar cambio en primer acceso
                                </label>
                                <?php if (!empty($empleado->email)): ?>
                                <label class="form-check" style="font-size: 0.8rem;">
                                    <input type="checkbox" id="enviar_email_manual">
                                    Enviar por email
                                </label>
                                <?php endif; ?>
                            </div>
                            <button type="button" onclick="establecerPassword()" class="btn btn-primary btn-sm">🔑 Establecer</button>
                        </div>
                        
                        <hr style="margin: 1rem 0; border: none; border-top: 1px solid #e2e8f0;">
                        
                        <!-- Generar contraseña aleatoria -->
                        <div>
                            <label class="form-label" style="font-weight: 600;">Generar contraseña aleatoria</label>
                            <?php if (!empty($empleado->email)): ?>
                            <label class="form-check" style="font-size: 0.8rem; margin-bottom: 0.5rem;">
                                <input type="checkbox" id="enviar_email_reset" checked>
                                Enviar por email a <?= htmlspecialchars($empleado->email) ?>
                            </label>
                            <?php else: ?>
                            <p style="font-size: 0.75rem; color: #94a3b8; margin-bottom: 0.5rem;">
                                ⚠️ El empleado no tiene email configurado
                            </p>
                            <?php endif; ?>
                            <button type="button" onclick="resetearPassword()" class="btn btn-warning btn-sm">🔄 Generar Nueva</button>
                        </div>
                    </div>
                </div>
                
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-actions" style="display: flex; justify-content: center; gap: 1rem; margin-top: 1.5rem; padding: 1.5rem; background: #f8fafc; border-radius: 0.5rem;">
            <a href="?accion=listar" class="btn btn-outline">Cancelar</a>
            <button type="submit" class="btn btn-success">💾 Guardar Empleado</button>
        </div>
    </form>
    
    <?php if ($empleado): ?>
    <!-- Formularios ocultos para acciones de contraseña (FUERA del formulario principal) -->
    <form id="form_resetear" method="POST" action="?accion=editar&id=<?= $empleado->id ?>" style="display: none;">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="resetear_password">
        <input type="hidden" name="empleado_id" value="<?= $empleado->id ?>">
        <input type="hidden" name="enviar_email" id="reset_enviar_email" value="">
    </form>
    
    <form id="form_establecer" method="POST" action="?accion=editar&id=<?= $empleado->id ?>" style="display: none;">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="establecer_password">
        <input type="hidden" name="empleado_id" value="<?= $empleado->id ?>">
        <input type="hidden" name="nueva_password" id="form_nueva_password">
        <input type="hidden" name="forzar_cambio" id="form_forzar_cambio" value="">
        <input type="hidden" name="enviar_email" id="form_enviar_email" value="">
    </form>
    <?php endif; ?>
    
<script>
// Actualizar mapa cuando se pegan coordenadas
function actualizarMapa() {
    var coords = document.getElementById('coordenadas_domicilio').value.trim();
    var mapaDiv = document.getElementById('mapa_domicilio');
    
    if (coords && coords.includes(',')) {
        coords = coords.replace(/\s/g, '');
        document.getElementById('coordenadas_domicilio').value = coords;
        mapaDiv.innerHTML = '<div style="text-align:center;"><p style="margin-bottom:0.5rem;color:#64748b;">📍 ' + coords + '</p><a href="https://www.google.com/maps?q=' + encodeURIComponent(coords) + '" target="_blank" class="btn btn-sm btn-primary">🗺️ Ver en Maps</a></div>';
    } else {
        mapaDiv.innerHTML = '<div style="text-align:center;color:#64748b;">El mapa aparecerá al introducir las coordenadas</div>';
    }
}

function mostrarPassword() {
    var input = document.getElementById('nueva_password');
    input.type = input.type === 'password' ? 'text' : 'password';
}

function establecerPassword() {
    var pass = document.getElementById('nueva_password').value;
    if (pass.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
    }
    if (!confirm('¿Establecer esta contraseña para el empleado?')) return;
    
    document.getElementById('form_nueva_password').value = pass;
    document.getElementById('form_forzar_cambio').value = document.getElementById('forzar_cambio_manual').checked ? '1' : '';
    var emailCheck = document.getElementById('enviar_email_manual');
    document.getElementById('form_enviar_email').value = emailCheck && emailCheck.checked ? '1' : '';
    document.getElementById('form_establecer').submit();
}

function resetearPassword() {
    if (!confirm('¿Generar nueva contraseña aleatoria?')) return;
    var emailCheck = document.getElementById('enviar_email_reset');
    document.getElementById('reset_enviar_email').value = emailCheck && emailCheck.checked ? '1' : '';
    document.getElementById('form_resetear').submit();
}

// Calcular totales dinámicamente
document.querySelectorAll('input[name="dias_vacaciones"], input[name="dias_vacaciones_antiguedad"]').forEach(function(input) {
    input.addEventListener('input', function() {
        var base = parseInt(document.querySelector('input[name="dias_vacaciones"]').value) || 0;
        var ant = parseInt(document.querySelector('input[name="dias_vacaciones_antiguedad"]').value) || 0;
        var total = document.getElementById('total_vacaciones');
        if (total) total.textContent = base + ant;
    });
});

document.querySelectorAll('input[name="dias_libre_disposicion"], input[name="dias_libre_disp_antiguedad"]').forEach(function(input) {
    input.addEventListener('input', function() {
        var base = parseInt(document.querySelector('input[name="dias_libre_disposicion"]').value) || 0;
        var ant = parseInt(document.querySelector('input[name="dias_libre_disp_antiguedad"]').value) || 0;
        var total = document.getElementById('total_permisos');
        if (total) total.textContent = base + ant;
    });
});

// Si selecciona turno rotativo, deshabilitar horario fijo
var turnoSelect = document.getElementById('turno_grupo_id');
if (turnoSelect) {
    turnoSelect.addEventListener('change', function() {
        var horarioSelect = document.getElementById('horario_id');
        if (this.value) {
            horarioSelect.value = '';
            horarioSelect.style.opacity = '0.5';
        } else {
            horarioSelect.style.opacity = '1';
        }
    });
}
</script>
