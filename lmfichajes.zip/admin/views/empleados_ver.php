<?php
/**
 * Vista: Ficha de empleado (solo lectura)
 */
defined('LMFICHAJES') or die('Acceso no permitido');
?>
<!-- VER FICHA (Solo lectura) -->
    <div class="page-header">
        <div>
            <h1 class="page-title">👤 <?= htmlspecialchars($empleado->nombre . ' ' . $empleado->apellido1) ?></h1>
            <p class="page-subtitle">Ficha del empleado</p>
        </div>
        <div class="btn-group">
            <a href="?accion=editar&id=<?= $empleado->id ?>" class="btn btn-primary">✏️ Editar</a>
            <a href="?accion=listar" class="btn btn-outline">← Volver</a>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
        <div>
            <!-- Datos Personales -->
            <div class="card">
                <div class="card-header"><span class="card-title">📋 Datos Personales</span></div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item"><div class="info-label">NIF</div><div class="info-value"><?= htmlspecialchars($empleado->nif) ?></div></div>
                        <div class="info-item"><div class="info-label">Nombre</div><div class="info-value"><?= htmlspecialchars($empleado->nombre) ?></div></div>
                        <div class="info-item"><div class="info-label">Apellidos</div><div class="info-value"><?= htmlspecialchars($empleado->apellido1 . ' ' . ($empleado->apellido2 ?? '')) ?></div></div>
                        <div class="info-item"><div class="info-label">Email</div><div class="info-value"><?= htmlspecialchars($empleado->email ?: '-') ?></div></div>
                        <div class="info-item"><div class="info-label">Teléfono</div><div class="info-value"><?= htmlspecialchars($empleado->telefono ?: '-') ?></div></div>
                        <div class="info-item"><div class="info-label">Estado</div><div class="info-value"><?= $empleado->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>' ?></div></div>
                    </div>
                </div>
            </div>
            
            <!-- Domicilio (Teletrabajo) -->
            <div class="card">
                <div class="card-header"><span class="card-title">🏠 Domicilio (Teletrabajo)</span></div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item" style="grid-column: span 2;"><div class="info-label">Dirección</div><div class="info-value"><?= htmlspecialchars($empleado->direccion ?: 'No configurada') ?></div></div>
                        <div class="info-item"><div class="info-label">Coordenadas</div><div class="info-value"><?= $empleado->coordenadas_domicilio ? '<a href="https://www.google.com/maps?q=' . htmlspecialchars($empleado->coordenadas_domicilio) . '" target="_blank">📍 Ver mapa</a>' : '-' ?></div></div>
                        <div class="info-item"><div class="info-label">Radio permitido</div><div class="info-value"><?= $empleado->radio_domicilio ?? 50 ?> metros</div></div>
                    </div>
                </div>
            </div>
            
            <!-- Rol y Horario -->
            <div class="card">
                <div class="card-header"><span class="card-title">🔐 Rol y Horario</span></div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item"><div class="info-label">Rol</div><div class="info-value"><span class="badge badge-info"><?= ucfirst($empleado->rol) ?></span></div></div>
                        <div class="info-item"><div class="info-label">Convenio</div><div class="info-value"><?= $empleado->convenio_nombre ? '<span class="badge badge-primary">📋 ' . htmlspecialchars($empleado->convenio_nombre) . '</span>' : '<span style="color:#94a3b8">Sin convenio</span>' ?></div></div>
                        <div class="info-item"><div class="info-label">Horario</div><div class="info-value"><?= $empleado->turno_nombre ? '🔄 ' . htmlspecialchars($empleado->turno_nombre) : ($empleado->horario_nombre ? '🕐 ' . htmlspecialchars($empleado->horario_nombre) : '-') ?></div></div>
                        <div class="info-item"><div class="info-label">Supervisor 1</div><div class="info-value"><?= htmlspecialchars($empleado->supervisor_nombre ?: '-') ?></div></div>
                        <div class="info-item"><div class="info-label">Supervisor 2</div><div class="info-value"><?= htmlspecialchars($empleado->supervisor2_nombre ?: '-') ?></div></div>
                        <div class="info-item"><div class="info-label">Doble validación</div><div class="info-value"><?= $empleado->requiere_doble_validacion ? 'Sí' : 'No' ?></div></div>
                    </div>
                </div>
            </div>
            
            <!-- Centros -->
            <div class="card">
                <div class="card-header"><span class="card-title">🏛️ Centros Asignados</span></div>
                <div class="card-body">
                    <?php if (empty($empleado->centros)): ?>
                        <p style="color: #64748b;">Sin centros asignados</p>
                    <?php else: ?>
                        <?php foreach ($empleado->centros as $c): ?>
                            <div class="list-item">
                                <span><?= htmlspecialchars($c->nombre) ?></span>
                                <?php if ($c->es_principal): ?><span class="badge badge-info">Principal</span><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div>
            <!-- Vacaciones y Permisos -->
            <div class="card">
                <div class="card-header"><span class="card-title">🏖️ Vacaciones y Permisos</span></div>
                <div class="card-body">
                    <div style="margin-bottom: 1rem;">
                        <strong>Vacaciones</strong>
                        <div style="display: flex; justify-content: space-between; font-size: 0.875rem; color: #64748b;">
                            <span>Base: <?= $empleado->dias_vacaciones ?? 22 ?> días</span>
                            <span>Antigüedad: +<?= $empleado->dias_vacaciones_antiguedad ?? 0 ?></span>
                        </div>
                        <div style="font-size: 1.25rem; font-weight: 600; color: #059669;">Total: <?= ($empleado->dias_vacaciones ?? 22) + ($empleado->dias_vacaciones_antiguedad ?? 0) ?> días</div>
                    </div>
                    <div>
                        <strong>Libre Disposición</strong>
                        <div style="display: flex; justify-content: space-between; font-size: 0.875rem; color: #64748b;">
                            <span>Base: <?= $empleado->dias_libre_disposicion ?? 6 ?> días</span>
                            <span>Antigüedad: +<?= $empleado->dias_libre_disp_antiguedad ?? 0 ?></span>
                        </div>
                        <div style="font-size: 1.25rem; font-weight: 600; color: #0369a1;">Total: <?= ($empleado->dias_libre_disposicion ?? 6) + ($empleado->dias_libre_disp_antiguedad ?? 0) ?> días</div>
                    </div>
                </div>
            </div>
            
            <!-- Horas -->
            <div class="card">
                <div class="card-header"><span class="card-title">⏱️ Jornada</span></div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">% Jornada</div>
                            <div class="info-value">
                                <span style="display: inline-flex; align-items: center; gap: 0.5rem;">
                                    <strong style="font-size: 1.25rem; color: <?= ($empleado->porcentaje_jornada ?? 100) == 100 ? '#10b981' : '#f59e0b' ?>;">
                                        <?= ($empleado->porcentaje_jornada ?? 100) ?>%
                                    </strong>
                                    <?php if (($empleado->porcentaje_jornada ?? 100) < 100): ?>
                                        <span style="font-size: 0.75rem; padding: 0.125rem 0.375rem; background: #fef3c7; color: #92400e; border-radius: 4px;">Parcial</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <div class="info-item"><div class="info-label">Horas/semana</div><div class="info-value"><?= number_format($empleado->horas_semanales * (($empleado->porcentaje_jornada ?? 100) / 100), 1) ?>h</div></div>
                        <div class="info-item"><div class="info-label">Horas/año</div><div class="info-value"><?= number_format($empleado->horas_anuales * (($empleado->porcentaje_jornada ?? 100) / 100), 0) ?>h</div></div>
                    </div>
                </div>
            </div>
            
            <!-- Bolsa de Horas -->
            <div class="card">
                <div class="card-header"><span class="card-title">💰 Bolsa de Horas</span></div>
                <div class="card-body">
                    <div style="display: grid; gap: 0.75rem;">
                        <div style="display: flex; justify-content: space-between; padding: 0.5rem; background: #f8fafc; border-radius: 0.375rem;">
                            <span>Hoy</span>
                            <strong style="color: <?= $empleado->bolsa['hoy'] >= 0 ? '#059669' : '#dc2626' ?>"><?= formatoHoras($empleado->bolsa['hoy']) ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 0.5rem; background: #f8fafc; border-radius: 0.375rem;">
                            <span>Esta semana</span>
                            <strong style="color: <?= $empleado->bolsa['semana'] >= 0 ? '#059669' : '#dc2626' ?>"><?= formatoHoras($empleado->bolsa['semana']) ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 0.5rem; background: #f8fafc; border-radius: 0.375rem;">
                            <span>Este mes</span>
                            <strong style="color: <?= $empleado->bolsa['mes'] >= 0 ? '#059669' : '#dc2626' ?>"><?= formatoHoras($empleado->bolsa['mes']) ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 0.75rem; background: <?= $empleado->bolsa['acumulado'] >= 0 ? '#dcfce7' : '#fef2f2' ?>; border-radius: 0.375rem; margin-top: 0.5rem;">
                            <strong>ACUMULADO</strong>
                            <strong style="font-size: 1.125rem; color: <?= $empleado->bolsa['acumulado'] >= 0 ? '#059669' : '#dc2626' ?>"><?= formatoHoras($empleado->bolsa['acumulado']) ?></strong>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Fechas -->
            <div class="card">
                <div class="card-header"><span class="card-title">📅 Fechas</span></div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item"><div class="info-label">Fecha alta</div><div class="info-value"><?= $empleado->fecha_alta ? date('d/m/Y', strtotime($empleado->fecha_alta)) : '-' ?></div></div>
                        <div class="info-item"><div class="info-label">Antigüedad desde</div><div class="info-value"><?= $empleado->fecha_antiguedad ? date('d/m/Y', strtotime($empleado->fecha_antiguedad)) : '-' ?></div></div>
                        <div class="info-item"><div class="info-label">Último acceso</div><div class="info-value"><?= $empleado->ultimo_acceso ? date('d/m/Y H:i', strtotime($empleado->ultimo_acceso)) : 'Nunca' ?></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
