<?php
/**
 * LM FICHAJES - Procesamiento de acciones de empleados
 * 
 * @package     LMFichajes
 * @subpackage  Admin/Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

/**
 * Procesar acciones POST de empleados
 * @param PDO $pdo
 * @param object $usuario
 * @return array ['mensaje', 'error', 'accion']
 */
function procesarAccionEmpleado($pdo, $usuario) {
    $resultado = ['mensaje' => '', 'error' => '', 'accion' => null];
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return $resultado;
    }
    
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $resultado['error'] = 'Error de seguridad. Recarga la página.';
        return $resultado;
    }
    
    $act = $_POST['accion'] ?? '';
    
    switch ($act) {
        case 'guardar':
            $resultado = procesarGuardarEmpleado($pdo);
            break;
            
        case 'resetear_password':
            $resultado = procesarResetearPassword($pdo);
            break;
            
        case 'establecer_password':
            $resultado = procesarEstablecerPassword($pdo);
            break;
            
        case 'toggle_activo':
            $resultado = procesarToggleActivo($pdo, $usuario);
            break;
    }
    
    return $resultado;
}

/**
 * Procesar guardado de empleado
 */
function procesarGuardarEmpleado($pdo) {
    $resultado = ['mensaje' => '', 'error' => '', 'accion' => null];
    
    $datos = [
        'nif' => strtoupper(trim($_POST['nif'] ?? '')),
        'nombre' => trim($_POST['nombre'] ?? ''),
        'apellido1' => trim($_POST['apellido1'] ?? ''),
        'apellido2' => trim($_POST['apellido2'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'telefono' => trim($_POST['telefono'] ?? ''),
        'direccion' => trim($_POST['direccion'] ?? ''),
        'coordenadas_domicilio' => trim($_POST['coordenadas_domicilio'] ?? ''),
        'radio_domicilio' => (int)($_POST['radio_domicilio'] ?? 50),
        'rol' => $_POST['rol'] ?? 'empleado',
        'convenio_id' => (int)($_POST['convenio_id'] ?? 0) ?: null,
        'horario_id' => (int)($_POST['horario_id'] ?? 0) ?: null,
        'porcentaje_jornada' => (float)($_POST['porcentaje_jornada'] ?? 100),
        'turno_grupo_id' => (int)($_POST['turno_grupo_id'] ?? 0) ?: null,
        'supervisor_id' => (int)($_POST['supervisor_id'] ?? 0) ?: null,
        'supervisor2_id' => (int)($_POST['supervisor2_id'] ?? 0) ?: null,
        'requiere_doble_validacion' => isset($_POST['requiere_doble_validacion']) ? 1 : 0,
        'dias_vacaciones' => (int)($_POST['dias_vacaciones'] ?? 22),
        'dias_vacaciones_antiguedad' => (int)($_POST['dias_vacaciones_antiguedad'] ?? 0),
        'dias_libre_disposicion' => (int)($_POST['dias_libre_disposicion'] ?? 6),
        'dias_libre_disp_antiguedad' => (int)($_POST['dias_libre_disp_antiguedad'] ?? 0),
        'fecha_alta' => $_POST['fecha_alta'] ?: null,
        'fecha_antiguedad' => $_POST['fecha_antiguedad'] ?: null,
        'activo' => isset($_POST['activo']) ? 1 : 1
    ];
    
    if ($datos['turno_grupo_id']) {
        $datos['horario_id'] = null;
    }
    
    if (empty($datos['nif']) || empty($datos['nombre']) || empty($datos['apellido1'])) {
        $resultado['error'] = 'NIF, nombre y primer apellido son obligatorios';
        return $resultado;
    }
    
    $idEdit = (int)($_POST['empleado_id'] ?? 0);
    $res = guardarEmpleado($pdo, $datos, $idEdit ?: null);
    
    if ($res['ok']) {
        guardarCentros($pdo, $res['id'], $_POST['centros'] ?? [], (int)($_POST['centro_principal'] ?? 0));
        $resultado['mensaje'] = $res['msg'];
        $resultado['accion'] = 'listar';
        
        if (function_exists('registrar_auditoria')) {
            $tipoAccion = $idEdit ? 'UPDATE' : 'CREATE';
            $desc = $idEdit ? "Empleado actualizado: {$datos['nombre']} {$datos['apellido1']}" : "Empleado creado: {$datos['nombre']} {$datos['apellido1']}";
            registrar_auditoria($tipoAccion, $desc, ['nif' => $datos['nif']], 'INFO', $_SESSION['usuario_id'] ?? null, 'empleados', $res['id']);
        }
    } else {
        $resultado['error'] = $res['msg'];
    }
    
    return $resultado;
}

/**
 * Procesar reseteo de contraseña
 */
function procesarResetearPassword($pdo) {
    $resultado = ['mensaje' => '', 'error' => '', 'accion' => 'editar'];
    
    $idEmp = (int)($_POST['empleado_id'] ?? 0);
    $enviarEmail = !empty($_POST['enviar_email']);
    
    if ($idEmp <= 0) {
        $resultado['error'] = 'Empleado no especificado';
        return $resultado;
    }
    
    $stmt = $pdo->prepare("SELECT id, nif, nombre, apellido1, email FROM empleados WHERE id = ?");
    $stmt->execute([$idEmp]);
    $emp = $stmt->fetch();
    
    if (!$emp) {
        $resultado['error'] = 'Empleado no encontrado';
        return $resultado;
    }
    
    $pass = generarPassword();
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE empleados SET password=?, debe_cambiar_password=1, password_temporal=1 WHERE id=?")
        ->execute([$hash, $idEmp]);
    
    $resultado['mensaje'] = "✅ Nueva contraseña generada: <strong style='font-size: 1.1em; background: #fef3c7; padding: 2px 8px; border-radius: 4px;'>$pass</strong>";
    
    if ($enviarEmail && !empty($emp->email)) {
        $resEmail = enviarEmailPassword($pdo, $emp, $pass, false);
        $resultado['mensaje'] .= $resEmail['ok'] 
            ? '<br><span style="color: #059669;">✓ Email enviado a ' . htmlspecialchars($emp->email) . '</span>'
            : '<br><span style="color: #dc2626;">✗ ' . $resEmail['msg'] . '</span>';
    }
    
    $resultado['mensaje'] .= '<br><small style="color: #64748b;">El empleado deberá cambiar la contraseña en su primer acceso.</small>';
    
    if (function_exists('registrar_auditoria')) {
        registrar_auditoria('PASSWORD_RESET', "Contraseña reseteada: {$emp->nombre} {$emp->apellido1}", 
            ['nif' => $emp->nif], 'WARNING', $_SESSION['usuario_id'] ?? null, 'empleados', $idEmp);
    }
    
    return $resultado;
}

/**
 * Procesar establecimiento de contraseña manual
 */
function procesarEstablecerPassword($pdo) {
    $resultado = ['mensaje' => '', 'error' => '', 'accion' => 'editar'];
    
    $idEmp = (int)($_POST['empleado_id'] ?? 0);
    $nuevaPass = $_POST['nueva_password'] ?? '';
    $enviarEmail = !empty($_POST['enviar_email']);
    $forzarCambio = !empty($_POST['forzar_cambio']);
    
    if ($idEmp <= 0 || strlen($nuevaPass) < 6) {
        $resultado['error'] = 'La contraseña debe tener al menos 6 caracteres';
        return $resultado;
    }
    
    $stmt = $pdo->prepare("SELECT id, nif, nombre, apellido1, email FROM empleados WHERE id = ?");
    $stmt->execute([$idEmp]);
    $emp = $stmt->fetch();
    
    if (!$emp) {
        $resultado['error'] = 'Empleado no encontrado';
        return $resultado;
    }
    
    $hash = password_hash($nuevaPass, PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE empleados SET password=?, debe_cambiar_password=?, password_temporal=? WHERE id=?")
        ->execute([$hash, $forzarCambio ? 1 : 0, $forzarCambio ? 1 : 0, $idEmp]);
    
    $resultado['mensaje'] = '✅ Contraseña establecida correctamente';
    
    if ($enviarEmail && !empty($emp->email)) {
        $resEmail = enviarEmailPassword($pdo, $emp, $nuevaPass, false);
        $resultado['mensaje'] .= $resEmail['ok'] 
            ? '<br><span style="color: #059669;">✓ Email enviado</span>'
            : '<br><span style="color: #dc2626;">✗ ' . $resEmail['msg'] . '</span>';
    }
    
    if (function_exists('registrar_auditoria')) {
        registrar_auditoria('PASSWORD_SET', "Contraseña establecida: {$emp->nombre} {$emp->apellido1}", 
            ['nif' => $emp->nif], 'WARNING', $_SESSION['usuario_id'] ?? null, 'empleados', $idEmp);
    }
    
    return $resultado;
}

/**
 * Procesar activar/desactivar empleado
 */
function procesarToggleActivo($pdo, $usuario) {
    $resultado = ['mensaje' => '', 'error' => '', 'accion' => null];
    
    $idEmp = (int)($_POST['empleado_id'] ?? 0);
    $nuevo = (int)($_POST['nuevo_estado'] ?? 0);
    
    if ($idEmp <= 0 || $idEmp == $usuario->id) {
        return $resultado;
    }
    
    $pdo->prepare("UPDATE empleados SET activo=? WHERE id=?")->execute([$nuevo, $idEmp]);
    $resultado['mensaje'] = $nuevo ? 'Empleado activado' : 'Empleado desactivado';
    
    if (function_exists('registrar_auditoria')) {
        $accion = $nuevo ? 'ACTIVAR' : 'DESACTIVAR';
        registrar_auditoria($accion, "Empleado {$accion}: ID {$idEmp}", 
            ['empleado_id' => $idEmp], 'WARNING', $_SESSION['usuario_id'] ?? null, 'empleados', $idEmp);
    }
    
    return $resultado;
}
