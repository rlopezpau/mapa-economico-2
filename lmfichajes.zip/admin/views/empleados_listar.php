<?php
/**
 * Vista: Listado de empleados
 */
defined('LMFICHAJES') or die('Acceso no permitido');
?>
<!-- LISTADO -->
<div class="page-header">
    <div>
        <h1 class="page-title">&#128101; Empleados</h1>
        <p class="page-subtitle"><?= count($empleados) ?> empleado(s)</p>
    </div>
    <a href="?accion=nuevo" class="btn btn-primary">&#10133; Nuevo Empleado</a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom: 1rem;">
    <div class="card-body" style="padding: 0.75rem;">
        <form method="GET" style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
            <input type="text" name="busqueda" value="<?= htmlspecialchars($filtroBusqueda ?? '') ?>" 
                   placeholder="Buscar por nombre, apellido o NIF..." class="form-control" style="max-width: 300px;">
            <select name="activo" class="form-control" style="width: auto;">
                <option value="1" <?= ($filtroActivo ?? '1') === '1' ? 'selected' : '' ?>>Activos</option>
                <option value="0" <?= ($filtroActivo ?? '') === '0' ? 'selected' : '' ?>>Inactivos</option>
                <option value="" <?= ($filtroActivo ?? '') === '' ? 'selected' : '' ?>>Todos</option>
            </select>
            <button type="submit" class="btn btn-outline">&#128269; Filtrar</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th>Empleado</th>
                    <th>NIF</th>
                    <th>Rol</th>
                    <th>Horario/Turno</th>
                    <th>Estado</th>
                    <th style="width: 150px;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($empleados)): ?>
                    <tr><td colspan="6" style="text-align: center; padding: 2rem; color: #64748b;">No hay empleados</td></tr>
                <?php else: ?>
                    <?php foreach ($empleados as $e): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($e->apellido1 . ' ' . ($e->apellido2 ?? '') . ', ' . $e->nombre) ?></strong>
                                <?php if ($e->email): ?><br><small style="color: #64748b;"><?= htmlspecialchars($e->email) ?></small><?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($e->nif) ?></td>
                            <td>
                                <span class="badge badge-<?= $e->rol === 'admin' ? 'danger' : ($e->rol === 'manager' ? 'warning' : ($e->rol === 'supervisor' ? 'info' : 'neutral')) ?>">
                                    <?= ucfirst($e->rol) ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($e->turno_nombre)): ?>
                                    &#128260; <?= htmlspecialchars($e->turno_nombre) ?>
                                <?php elseif (!empty($e->horario_nombre)): ?>
                                    &#128336; <?= htmlspecialchars($e->horario_nombre) ?>
                                <?php else: ?>
                                    <span style="color: #94a3b8;">Sin asignar</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($e->activo): ?>
                                    <span class="badge badge-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="?accion=ver&id=<?= $e->id ?>" class="btn btn-sm btn-outline" title="Ver">&#128065;</a>
                                    <a href="?accion=editar&id=<?= $e->id ?>" class="btn btn-sm btn-primary" title="Editar">&#9998;</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
