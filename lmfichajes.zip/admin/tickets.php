<?php
/**
 * LM FICHAJES - Panel Admin: Gestión de Tickets/Incidencias
 * Sistema para gestionar tickets de soporte de clientes
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once __DIR__ . '/includes/admin_functions.php';

requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'Solo administradores pueden gestionar tickets';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';

// Obtener datos de la empresa desde configuración
$configEmpresa = [];
$stmtConfig = $pdo->query("SELECT clave, valor FROM configuracion WHERE clave IN ('nombre_empresa', 'email', 'telefono')");
while ($row = $stmtConfig->fetch()) {
    $configEmpresa[$row->clave] = $row->valor;
}
$nombreEmpresa = $configEmpresa['nombre_empresa'] ?? '';
$emailEmpresa = $configEmpresa['email'] ?? '';
$telefonoEmpresa = $configEmpresa['telefono'] ?? '';

// Generar número de ticket único
function generarNumeroTicket($pdo) {
    do {
        $numero = '#' . rand(100000, 999999);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE numero = ?");
        $stmt->execute([$numero]);
    } while ($stmt->fetchColumn() > 0);
    return $numero;
}

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf()) {
    $accion = $_POST['accion'] ?? '';
    
    // Crear ticket (desde admin)
    if ($accion === 'crear_ticket') {
        $numero = generarNumeroTicket($pdo);
        $stmt = $pdo->prepare("INSERT INTO tickets (numero, cliente_nombre, cliente_email, cliente_empresa, departamento, prioridad, asunto, mensaje, asignado_a) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $numero,
            sanitizar($_POST['cliente_nombre']),
            sanitizar($_POST['cliente_email']),
            sanitizar($_POST['cliente_empresa'] ?? ''),
            $_POST['departamento'],
            $_POST['prioridad'],
            sanitizar($_POST['asunto']),
            sanitizar($_POST['mensaje']),
            $usuario->id
        ]);
        $mensaje = "Ticket $numero creado correctamente";
    }
    
    // Responder ticket
    if ($accion === 'responder') {
        $ticketId = (int)$_POST['ticket_id'];
        $esInterno = isset($_POST['es_interno']) ? 1 : 0;
        
        $stmt = $pdo->prepare("INSERT INTO tickets_respuestas (ticket_id, autor_tipo, autor_id, autor_nombre, mensaje, es_interno) VALUES (?, 'admin', ?, ?, ?, ?)");
        $stmt->execute([
            $ticketId,
            $usuario->id,
            $usuario->nombre . ' ' . $usuario->apellido1,
            sanitizar($_POST['mensaje']),
            $esInterno
        ]);
        
        // Cambiar estado a contestado (si no es nota interna)
        if (!$esInterno) {
            $pdo->prepare("UPDATE tickets SET estado = 'contestado' WHERE id = ?")->execute([$ticketId]);
        }
        
        $mensaje = "Respuesta enviada";
        header("Location: tickets.php?ver=" . $ticketId . "&msg=respondido");
        exit;
    }
    
    // Cambiar estado
    if ($accion === 'cambiar_estado') {
        $ticketId = (int)$_POST['ticket_id'];
        $estado = $_POST['estado'];
        
        $sql = "UPDATE tickets SET estado = ?";
        $params = [$estado];
        
        if ($estado === 'cerrado') {
            $sql .= ", cerrado_at = NOW()";
        }
        $sql .= " WHERE id = ?";
        $params[] = $ticketId;
        
        $pdo->prepare($sql)->execute($params);
        $mensaje = "Estado actualizado";
    }
    
    // Cambiar prioridad
    if ($accion === 'cambiar_prioridad') {
        $ticketId = (int)$_POST['ticket_id'];
        $pdo->prepare("UPDATE tickets SET prioridad = ? WHERE id = ?")->execute([$_POST['prioridad'], $ticketId]);
        $mensaje = "Prioridad actualizada";
    }
    
    // Asignar
    if ($accion === 'asignar') {
        $ticketId = (int)$_POST['ticket_id'];
        $pdo->prepare("UPDATE tickets SET asignado_a = ?, estado = 'en_proceso' WHERE id = ?")->execute([$usuario->id, $ticketId]);
        $mensaje = "Ticket asignado";
    }
    
    regenerar_csrf();
}

// Ver ticket individual
$verTicket = null;
if (isset($_GET['ver'])) {
    $stmt = $pdo->prepare("SELECT t.*, e.nombre as asignado_nombre FROM tickets t LEFT JOIN empleados e ON t.asignado_a = e.id WHERE t.id = ?");
    $stmt->execute([(int)$_GET['ver']]);
    $verTicket = $stmt->fetch();
    
    if ($verTicket) {
        $stmtResp = $pdo->prepare("SELECT * FROM tickets_respuestas WHERE ticket_id = ? ORDER BY created_at ASC");
        $stmtResp->execute([$verTicket->id]);
        $respuestas = $stmtResp->fetchAll();
    }
}

// Filtros
$filtroEstado = $_GET['estado'] ?? '';
$filtroPrioridad = $_GET['prioridad'] ?? '';
$filtroDepartamento = $_GET['departamento'] ?? '';
$buscar = $_GET['buscar'] ?? '';

// Obtener tickets
$sql = "SELECT t.*, e.nombre as asignado_nombre 
        FROM tickets t 
        LEFT JOIN empleados e ON t.asignado_a = e.id 
        WHERE 1=1";
$params = [];

if ($filtroEstado) {
    $sql .= " AND t.estado = ?";
    $params[] = $filtroEstado;
}
if ($filtroPrioridad) {
    $sql .= " AND t.prioridad = ?";
    $params[] = $filtroPrioridad;
}
if ($filtroDepartamento) {
    $sql .= " AND t.departamento = ?";
    $params[] = $filtroDepartamento;
}
if ($buscar) {
    $sql .= " AND (t.numero LIKE ? OR t.asunto LIKE ? OR t.cliente_nombre LIKE ? OR t.cliente_email LIKE ?)";
    $buscarLike = "%$buscar%";
    $params = array_merge($params, [$buscarLike, $buscarLike, $buscarLike, $buscarLike]);
}

$sql .= " ORDER BY 
    CASE t.prioridad WHEN 'urgente' THEN 1 WHEN 'alta' THEN 2 WHEN 'media' THEN 3 ELSE 4 END,
    t.updated_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();

// Contadores
$contadores = [
    'abierto' => 0, 'en_proceso' => 0, 'contestado' => 0, 
    'respuesta_cliente' => 0, 'cerrado' => 0, 'total' => 0
];
$stmtCount = $pdo->query("SELECT estado, COUNT(*) as total FROM tickets GROUP BY estado");
while ($row = $stmtCount->fetch()) {
    $contadores[$row->estado] = $row->total;
    $contadores['total'] += $row->total;
}

$paginaActual = 'tickets';
$titulo = 'Gestión de Tickets';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.tickets-stats { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1.5rem; }
.stat-badge { padding: 0.5rem 1rem; border-radius: 8px; font-size: 0.85rem; font-weight: 500; cursor: pointer; text-decoration: none; transition: all 0.2s; }
.stat-badge:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.stat-badge.abierto { background: #fef3c7; color: #92400e; }
.stat-badge.en_proceso { background: #dbeafe; color: #1e40af; }
.stat-badge.contestado { background: #d1fae5; color: #065f46; }
.stat-badge.respuesta_cliente { background: #fce7f3; color: #9d174d; }
.stat-badge.cerrado { background: #f3f4f6; color: #374151; }
.stat-badge.active { box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.4); }

.ticket-filters { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1.5rem; align-items: flex-end; }
.ticket-filters .form-group { margin: 0; min-width: 150px; }

.tickets-table { width: 100%; border-collapse: collapse; }
.tickets-table th { background: #f8fafc; padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 600; border-bottom: 2px solid #e2e8f0; }
.tickets-table td { padding: 1rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.tickets-table tr:hover { background: #f8fafc; }

.ticket-numero { font-weight: 600; color: #4f46e5; }
.ticket-asunto { font-weight: 500; color: #1e293b; }
.ticket-cliente { font-size: 0.85rem; color: #64748b; }

.prioridad-badge { padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
.prioridad-baja { background: #f3f4f6; color: #6b7280; }
.prioridad-media { background: #dbeafe; color: #1d4ed8; }
.prioridad-alta { background: #fef3c7; color: #d97706; }
.prioridad-urgente { background: #fee2e2; color: #dc2626; }

.estado-badge { padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: 500; }
.estado-abierto { background: #fef3c7; color: #92400e; }
.estado-en_proceso { background: #dbeafe; color: #1e40af; }
.estado-contestado { background: #d1fae5; color: #065f46; }
.estado-respuesta_cliente { background: #fce7f3; color: #9d174d; }
.estado-cerrado { background: #f3f4f6; color: #6b7280; }

.ticket-detail { max-width: 900px; }
.ticket-header { background: linear-gradient(135deg, #4f46e5, #6366f1); color: white; padding: 1.5rem; border-radius: 12px 12px 0 0; }
.ticket-header h2 { margin: 0 0 0.5rem; font-size: 1.25rem; }
.ticket-meta { display: flex; gap: 2rem; flex-wrap: wrap; margin-top: 1rem; font-size: 0.9rem; opacity: 0.9; }

.ticket-messages { background: #f8fafc; padding: 1.5rem; border-left: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; }
.message { background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
.message.admin { border-left: 4px solid #4f46e5; }
.message.cliente { border-left: 4px solid #10b981; }
.message.interno { border-left: 4px solid #f59e0b; background: #fffbeb; }
.message-header { display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.85rem; }
.message-author { font-weight: 600; }
.message-date { color: #64748b; }
.message-body { color: #334155; line-height: 1.6; white-space: pre-wrap; }
.message-internal-badge { background: #fef3c7; color: #92400e; padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }

.ticket-reply { background: white; padding: 1.5rem; border: 1px solid #e2e8f0; border-radius: 0 0 12px 12px; }
.ticket-actions { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">🎫 Gestión de Tickets</h1>
        <p class="page-subtitle">Sistema de soporte e incidencias</p>
    </div>
    <div>
        <button onclick="document.getElementById('modalNuevo').style.display='flex'" class="btn btn-primary">➕ Nuevo Ticket</button>
    </div>
</div>

<?php if ($mensaje): ?><div class="alert alert-success">✅ <?= sanitizar($mensaje) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger">❌ <?= sanitizar($error) ?></div><?php endif; ?>
<?php if (isset($_GET['msg']) && $_GET['msg'] === 'respondido'): ?><div class="alert alert-success">✅ Respuesta enviada correctamente</div><?php endif; ?>

<?php if ($verTicket): ?>
<!-- ===== VER TICKET ===== -->
<div class="ticket-detail">
    <a href="tickets.php" class="btn btn-secondary" style="margin-bottom: 1rem;">← Volver a la lista</a>
    
    <div class="ticket-header">
        <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 1rem;">
            <div>
                <h2><?= sanitizar($verTicket->numero) ?> - <?= sanitizar($verTicket->asunto) ?></h2>
                <div><?= sanitizar($verTicket->cliente_nombre) ?> &lt;<?= sanitizar($verTicket->cliente_email) ?>&gt;</div>
                <?php if ($verTicket->cliente_empresa): ?>
                <div style="opacity: 0.8;"><?= sanitizar($verTicket->cliente_empresa) ?></div>
                <?php endif; ?>
            </div>
            <div style="text-align: right;">
                <span class="estado-badge estado-<?= $verTicket->estado ?>"><?= ucfirst(str_replace('_', ' ', $verTicket->estado)) ?></span>
                <span class="prioridad-badge prioridad-<?= $verTicket->prioridad ?>"><?= ucfirst($verTicket->prioridad) ?></span>
            </div>
        </div>
        <div class="ticket-meta">
            <div>📁 <?= ucfirst(str_replace('_', ' ', $verTicket->departamento)) ?></div>
            <div>📅 <?= date('d/m/Y H:i', strtotime($verTicket->created_at)) ?></div>
            <div>👤 <?= $verTicket->asignado_nombre ? sanitizar($verTicket->asignado_nombre) : 'Sin asignar' ?></div>
        </div>
    </div>
    
    <div class="ticket-messages">
        <!-- Mensaje original -->
        <div class="message cliente">
            <div class="message-header">
                <span class="message-author">👤 <?= sanitizar($verTicket->cliente_nombre) ?></span>
                <span class="message-date"><?= date('d/m/Y H:i', strtotime($verTicket->created_at)) ?></span>
            </div>
            <div class="message-body"><?= nl2br(sanitizar($verTicket->mensaje)) ?></div>
        </div>
        
        <!-- Respuestas -->
        <?php foreach ($respuestas as $resp): ?>
        <div class="message <?= $resp->autor_tipo ?> <?= $resp->es_interno ? 'interno' : '' ?>">
            <div class="message-header">
                <span class="message-author">
                    <?= $resp->autor_tipo === 'admin' ? '🛠️' : '👤' ?> <?= sanitizar($resp->autor_nombre) ?>
                    <?php if ($resp->es_interno): ?><span class="message-internal-badge">Nota interna</span><?php endif; ?>
                </span>
                <span class="message-date"><?= date('d/m/Y H:i', strtotime($resp->created_at)) ?></span>
            </div>
            <div class="message-body"><?= nl2br(sanitizar($resp->mensaje)) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="ticket-reply">
        <div class="ticket-actions">
            <!-- Cambiar estado -->
            <form method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="cambiar_estado">
                <input type="hidden" name="ticket_id" value="<?= $verTicket->id ?>">
                <select name="estado" class="form-control" style="width: auto;">
                    <option value="abierto" <?= $verTicket->estado === 'abierto' ? 'selected' : '' ?>>Abierto</option>
                    <option value="en_proceso" <?= $verTicket->estado === 'en_proceso' ? 'selected' : '' ?>>En proceso</option>
                    <option value="contestado" <?= $verTicket->estado === 'contestado' ? 'selected' : '' ?>>Contestado</option>
                    <option value="respuesta_cliente" <?= $verTicket->estado === 'respuesta_cliente' ? 'selected' : '' ?>>Respuesta cliente</option>
                    <option value="cerrado" <?= $verTicket->estado === 'cerrado' ? 'selected' : '' ?>>Cerrado</option>
                </select>
                <button type="submit" class="btn btn-secondary">Cambiar estado</button>
            </form>
            
            <!-- Cambiar prioridad -->
            <form method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="cambiar_prioridad">
                <input type="hidden" name="ticket_id" value="<?= $verTicket->id ?>">
                <select name="prioridad" class="form-control" style="width: auto;">
                    <option value="baja" <?= $verTicket->prioridad === 'baja' ? 'selected' : '' ?>>Baja</option>
                    <option value="media" <?= $verTicket->prioridad === 'media' ? 'selected' : '' ?>>Media</option>
                    <option value="alta" <?= $verTicket->prioridad === 'alta' ? 'selected' : '' ?>>Alta</option>
                    <option value="urgente" <?= $verTicket->prioridad === 'urgente' ? 'selected' : '' ?>>Urgente</option>
                </select>
                <button type="submit" class="btn btn-secondary">Cambiar prioridad</button>
            </form>
            
            <?php if (!$verTicket->asignado_a): ?>
            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="asignar">
                <input type="hidden" name="ticket_id" value="<?= $verTicket->id ?>">
                <button type="submit" class="btn btn-primary">🙋 Asignarme este ticket</button>
            </form>
            <?php endif; ?>
        </div>
        
        <?php if ($verTicket->estado !== 'cerrado'): ?>
        <form method="POST">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="responder">
            <input type="hidden" name="ticket_id" value="<?= $verTicket->id ?>">
            
            <div class="form-group">
                <label class="form-label">Responder al cliente</label>
                <textarea name="mensaje" class="form-control" rows="5" required placeholder="Escribe tu respuesta..."></textarea>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                    <input type="checkbox" name="es_interno" value="1">
                    <span style="font-size: 0.9rem; color: #64748b;">📝 Nota interna (no visible para el cliente)</span>
                </label>
                <button type="submit" class="btn btn-primary">📤 Enviar respuesta</button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>

<?php else: ?>
<!-- ===== LISTA DE TICKETS ===== -->

<!-- Stats -->
<div class="tickets-stats">
    <a href="tickets.php" class="stat-badge <?= !$filtroEstado ? 'active' : '' ?>" style="background: #e0e7ff; color: #3730a3;">
        📋 Todos <strong><?= $contadores['total'] ?></strong>
    </a>
    <a href="?estado=abierto" class="stat-badge abierto <?= $filtroEstado === 'abierto' ? 'active' : '' ?>">
        🆕 Abiertos <strong><?= $contadores['abierto'] ?></strong>
    </a>
    <a href="?estado=en_proceso" class="stat-badge en_proceso <?= $filtroEstado === 'en_proceso' ? 'active' : '' ?>">
        🔄 En proceso <strong><?= $contadores['en_proceso'] ?></strong>
    </a>
    <a href="?estado=contestado" class="stat-badge contestado <?= $filtroEstado === 'contestado' ? 'active' : '' ?>">
        ✅ Contestados <strong><?= $contadores['contestado'] ?></strong>
    </a>
    <a href="?estado=respuesta_cliente" class="stat-badge respuesta_cliente <?= $filtroEstado === 'respuesta_cliente' ? 'active' : '' ?>">
        💬 Resp. Cliente <strong><?= $contadores['respuesta_cliente'] ?></strong>
    </a>
    <a href="?estado=cerrado" class="stat-badge cerrado <?= $filtroEstado === 'cerrado' ? 'active' : '' ?>">
        🔒 Cerrados <strong><?= $contadores['cerrado'] ?></strong>
    </a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" class="ticket-filters">
            <div class="form-group">
                <label class="form-label">🔍 Buscar</label>
                <input type="text" name="buscar" class="form-control" value="<?= sanitizar($buscar) ?>" placeholder="Nº, asunto, cliente...">
            </div>
            <div class="form-group">
                <label class="form-label">Departamento</label>
                <select name="departamento" class="form-control">
                    <option value="">Todos</option>
                    <option value="soporte_tecnico" <?= $filtroDepartamento === 'soporte_tecnico' ? 'selected' : '' ?>>Soporte Técnico</option>
                    <option value="facturacion" <?= $filtroDepartamento === 'facturacion' ? 'selected' : '' ?>>Facturación</option>
                    <option value="comercial" <?= $filtroDepartamento === 'comercial' ? 'selected' : '' ?>>Comercial</option>
                    <option value="otros" <?= $filtroDepartamento === 'otros' ? 'selected' : '' ?>>Otros</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Prioridad</label>
                <select name="prioridad" class="form-control">
                    <option value="">Todas</option>
                    <option value="urgente" <?= $filtroPrioridad === 'urgente' ? 'selected' : '' ?>>🔴 Urgente</option>
                    <option value="alta" <?= $filtroPrioridad === 'alta' ? 'selected' : '' ?>>🟠 Alta</option>
                    <option value="media" <?= $filtroPrioridad === 'media' ? 'selected' : '' ?>>🔵 Media</option>
                    <option value="baja" <?= $filtroPrioridad === 'baja' ? 'selected' : '' ?>>⚪ Baja</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
            <a href="tickets.php" class="btn btn-secondary">Limpiar</a>
        </form>
    </div>
</div>

<!-- Tabla de tickets -->
<div class="card">
    <div class="card-body" style="padding: 0;">
        <?php if (empty($tickets)): ?>
        <div style="padding: 3rem; text-align: center; color: #64748b;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🎫</div>
            <p>No hay tickets <?= $filtroEstado ? "con estado '$filtroEstado'" : '' ?></p>
        </div>
        <?php else: ?>
        <table class="tickets-table">
            <thead>
                <tr>
                    <th>Departamento</th>
                    <th>Asunto</th>
                    <th>Estado</th>
                    <th>Prioridad</th>
                    <th>Última actualización</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tickets as $t): ?>
                <tr onclick="location.href='tickets.php?ver=<?= $t->id ?>'" style="cursor: pointer;">
                    <td><?= ucfirst(str_replace('_', ' ', $t->departamento)) ?></td>
                    <td>
                        <div class="ticket-numero"><?= sanitizar($t->numero) ?></div>
                        <div class="ticket-asunto"><?= sanitizar($t->asunto) ?></div>
                        <div class="ticket-cliente"><?= sanitizar($t->cliente_nombre) ?> - <?= sanitizar($t->cliente_empresa ?: $t->cliente_email) ?></div>
                    </td>
                    <td><span class="estado-badge estado-<?= $t->estado ?>"><?= ucfirst(str_replace('_', ' ', $t->estado)) ?></span></td>
                    <td><span class="prioridad-badge prioridad-<?= $t->prioridad ?>"><?= ucfirst($t->prioridad) ?></span></td>
                    <td><?= date('d/m/Y (H:i)', strtotime($t->updated_at)) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>

<!-- Modal Nuevo Ticket -->
<div id="modalNuevo" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
    <div style="background: white; border-radius: 12px; width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
        <div style="padding: 1.5rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0;">➕ Nuevo Ticket</h3>
            <button onclick="document.getElementById('modalNuevo').style.display='none'" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">×</button>
        </div>
        <form method="POST" style="padding: 1.5rem;">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="crear_ticket">
            
            <?php if ($nombreEmpresa): ?>
            <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                <strong style="color: #166534;">📋 Datos de la empresa (desde Configuración)</strong>
            </div>
            <?php endif; ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Nombre del cliente *</label>
                    <input type="text" name="cliente_nombre" class="form-control" required value="<?= sanitizar($usuario->nombre . ' ' . $usuario->apellido1) ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="cliente_email" class="form-control" required value="<?= sanitizar($emailEmpresa ?: $usuario->email) ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Empresa</label>
                <input type="text" name="cliente_empresa" class="form-control" value="<?= sanitizar($nombreEmpresa) ?>">
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Departamento</label>
                    <select name="departamento" class="form-control">
                        <option value="soporte_tecnico">Soporte Técnico</option>
                        <option value="facturacion">Facturación</option>
                        <option value="comercial">Comercial</option>
                        <option value="otros">Otros</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Prioridad</label>
                    <select name="prioridad" class="form-control">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                        <option value="urgente">Urgente</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Asunto *</label>
                <input type="text" name="asunto" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Mensaje *</label>
                <textarea name="mensaje" class="form-control" rows="5" required></textarea>
            </div>
            
            <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                <button type="button" onclick="document.getElementById('modalNuevo').style.display='none'" class="btn btn-secondary">Cancelar</button>
                <button type="submit" class="btn btn-primary">Crear Ticket</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
