<?php
/**
 * LM FICHAJES - Panel de Administración: Gestión de Empleados
 * 
 * VERSIÓN REFACTORIZADA - Archivos separados
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     3.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';
require_once __DIR__ . '/includes/empleados_functions.php';
require_once __DIR__ . '/includes/empleados_process.php';

// ============================================================================
// SEGURIDAD
// ============================================================================
requerir_login('../login.php');
if (!es_manager()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para gestionar empleados';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$accion = $_GET['accion'] ?? 'listar';
$empleadoId = (int)($_GET['id'] ?? 0);
$mensaje = '';
$error = '';

// ============================================================================
// PROCESAR POST
// ============================================================================
$resultado = procesarAccionEmpleado($pdo, $usuario);
if ($resultado['mensaje']) $mensaje = $resultado['mensaje'];
if ($resultado['error']) $error = $resultado['error'];
if ($resultado['accion']) $accion = $resultado['accion'];

// ============================================================================
// OBTENER DATOS
// ============================================================================
$empleado = null;
$empleados = [];

// Selectores para formularios
$horarios = $pdo->query("SELECT id, nombre FROM horarios WHERE activo=1 ORDER BY nombre")->fetchAll();
$turnos = [];
try { $turnos = $pdo->query("SELECT id, nombre FROM turnos_grupo WHERE activo=1 ORDER BY nombre")->fetchAll(); } catch (PDOException $e) {}
$centros = $pdo->query("SELECT id, nombre FROM centros WHERE activo=1 ORDER BY nombre")->fetchAll();
$supervisores = $pdo->query("SELECT id, nombre, apellido1, rol FROM empleados WHERE activo=1 AND rol IN ('supervisor','manager','admin') ORDER BY apellido1")->fetchAll();
$convenios = [];
try { $convenios = $pdo->query("SELECT id, codigo, nombre FROM convenios WHERE activo=1 ORDER BY nombre")->fetchAll(); } catch (PDOException $e) {}

// Stats para sidebar
$stats = ['fichajes_pendientes' => 0];
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM fichajes WHERE estado='pendiente'");
    $stats['fichajes_pendientes'] = $stmt->fetchColumn();
} catch (PDOException $e) {}

// Cargar empleado si es edición/ver
if (($accion === 'editar' || $accion === 'ver') && $empleadoId > 0) {
    $empleado = obtenerEmpleadoCompleto($pdo, $empleadoId);
    if (!$empleado) {
        $error = 'Empleado no encontrado';
        $accion = 'listar';
    }
}

// Cargar listado
if ($accion === 'listar') {
    $filtroActivo = $_GET['activo'] ?? '1';
    $filtroBusqueda = trim($_GET['busqueda'] ?? '');
    $filtros = [
        'activo' => $filtroActivo,
        'buscar' => $filtroBusqueda
    ];
    $empleados = obtenerListadoEmpleados($pdo, $filtros);
}

// ============================================================================
// CONFIG PÁGINA
// ============================================================================
$titulo = 'Gestión de Empleados';
$paginaActual = 'empleados';

// ============================================================================
// RENDERIZAR - Cargar vistas
// ============================================================================
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';

// Alertas
if ($mensaje): ?>
    <div class="alert alert-success"><?= $mensaje ?></div>
<?php endif;
if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif;

// Incluir vista según acción
$vistaFile = __DIR__ . '/views/empleados_' . $accion . '.php';
if (file_exists($vistaFile)) {
    require_once $vistaFile;
} else {
    // Vista por defecto (listado integrado)
    require_once __DIR__ . '/views/empleados_listar.php';
}

require_once __DIR__ . '/includes/layout_footer.php';
