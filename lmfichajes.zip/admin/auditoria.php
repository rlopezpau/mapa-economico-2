<?php
/**
 * LM FICHAJES - Panel Admin: Auditoría Profesional
 * 
 * Visualización del log de auditoría (ENS)
 * Con estadísticas, filtros avanzados y exportación
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     2.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/auditoria.php';
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos - solo admin
requerir_login('../login.php');
if (!es_admin()) {
    if (function_exists('audit_permiso_denegado')) {
        audit_permiso_denegado('admin/auditoria.php', 'Rol insuficiente');
    }
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);

// Exportar a CSV
if (isset($_GET['exportar']) && $_GET['exportar'] === 'csv') {
    $filtrosExport = [
        'fecha_desde' => $_GET['fecha_desde'] ?? date('Y-m-d', strtotime('-30 days')),
        'fecha_hasta' => $_GET['fecha_hasta'] ?? date('Y-m-d'),
        'usuario_id' => (int)($_GET['usuario_id'] ?? 0),
        'tipo' => $_GET['tipo'] ?? '',
        'nivel' => $_GET['nivel'] ?? ''
    ];
    
    $resultado = obtener_auditoria($filtrosExport, 10000, 0);
    
    // Registrar exportación
    if (function_exists('audit_exportacion')) {
        audit_exportacion('auditoria_csv', $filtrosExport, count($resultado['registros']));
    }
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="auditoria_' . date('Y-m-d_His') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8
    
    fputcsv($output, ['Fecha/Hora', 'Usuario', 'NIF', 'Tipo', 'Nivel', 'Descripción', 'IP', 'Entidad', 'Detalles']);
    
    foreach ($resultado['registros'] as $reg) {
        fputcsv($output, [
            $reg->created_at,
            $reg->nombre ? $reg->nombre . ' ' . $reg->apellido1 : 'Sistema',
            $reg->nif ?? '-',
            $reg->tipo,
            $reg->nivel,
            $reg->descripcion,
            $reg->ip_address,
            $reg->entidad ?? '-',
            $reg->datos ?? ''
        ]);
    }
    
    fclose($output);
    exit;
}

// Filtros
$filtros = [
    'fecha_desde' => $_GET['fecha_desde'] ?? date('Y-m-d', strtotime('-7 days')),
    'fecha_hasta' => $_GET['fecha_hasta'] ?? date('Y-m-d'),
    'usuario_id' => (int)($_GET['usuario_id'] ?? 0),
    'tipo' => $_GET['tipo'] ?? '',
    'nivel' => $_GET['nivel'] ?? '',
    'busqueda' => $_GET['busqueda'] ?? ''
];

// Paginación
$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$porPagina = 50;
$offset = ($pagina - 1) * $porPagina;

// Construir consulta
$where = ["DATE(a.created_at) BETWEEN ? AND ?"];
$params = [$filtros['fecha_desde'], $filtros['fecha_hasta']];

if ($filtros['usuario_id']) {
    $where[] = "a.usuario_id = ?";
    $params[] = $filtros['usuario_id'];
}
if ($filtros['tipo']) {
    $where[] = "a.tipo = ?";
    $params[] = $filtros['tipo'];
}
if ($filtros['nivel']) {
    $where[] = "a.nivel = ?";
    $params[] = $filtros['nivel'];
}
if ($filtros['busqueda']) {
    $where[] = "(a.descripcion LIKE ? OR a.datos LIKE ?)";
    $params[] = '%' . $filtros['busqueda'] . '%';
    $params[] = '%' . $filtros['busqueda'] . '%';
}

$whereSQL = implode(' AND ', $where);

// Contar total
$sqlCount = "SELECT COUNT(*) FROM audit_log a WHERE {$whereSQL}";
$stmtCount = $pdo->prepare($sqlCount);
$stmtCount->execute($params);
$total = $stmtCount->fetchColumn();
$totalPaginas = ceil($total / $porPagina);

// Obtener registros
$sql = "SELECT a.*, e.nombre as usuario_nombre, e.apellido1 as usuario_apellido, e.nif as usuario_nif
        FROM audit_log a
        LEFT JOIN empleados e ON a.usuario_id = e.id
        WHERE {$whereSQL}
        ORDER BY a.created_at DESC
        LIMIT {$porPagina} OFFSET {$offset}";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$registros = $stmt->fetchAll();

// Datos para filtros
$usuarios = $pdo->query("SELECT DISTINCT e.id, e.nombre, e.apellido1 
                         FROM empleados e 
                         INNER JOIN audit_log a ON e.id = a.usuario_id 
                         ORDER BY e.apellido1")->fetchAll();

$tipos = $pdo->query("SELECT DISTINCT tipo FROM audit_log ORDER BY tipo")->fetchAll(PDO::FETCH_COLUMN);

// Estadísticas rápidas del período
$statsSQL = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN tipo = 'LOGIN_OK' THEN 1 ELSE 0 END) as logins,
    SUM(CASE WHEN tipo = 'LOGIN_FAIL' THEN 1 ELSE 0 END) as logins_fallidos,
    SUM(CASE WHEN tipo = 'FICHAJE' THEN 1 ELSE 0 END) as fichajes,
    SUM(CASE WHEN nivel = 'CRITICAL' THEN 1 ELSE 0 END) as criticos,
    SUM(CASE WHEN nivel = 'WARNING' THEN 1 ELSE 0 END) as warnings
    FROM audit_log a WHERE {$whereSQL}";
$stmtStats = $pdo->prepare($statsSQL);
$stmtStats->execute($params);
$statsAudit = $stmtStats->fetch();

// Variables para layout
$paginaActual = 'auditoria';
$titulo = 'Auditoría';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.audit-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
.audit-stat { background: white; padding: 1rem; border-radius: 0.5rem; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.audit-stat .numero { font-size: 1.5rem; font-weight: 700; color: #1e3a5f; }
.audit-stat .label { font-size: 0.75rem; color: #64748b; text-transform: uppercase; }
.audit-stat.warning .numero { color: #f59e0b; }
.audit-stat.danger .numero { color: #ef4444; }
.audit-stat.success .numero { color: #10b981; }

.nivel-badge { padding: 0.25rem 0.5rem; border-radius: 0.25rem; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; }
.nivel-INFO { background: #e0f2fe; color: #0369a1; }
.nivel-WARNING { background: #fef3c7; color: #92400e; }
.nivel-ERROR { background: #fee2e2; color: #991b1b; }
.nivel-CRITICAL { background: #7c3aed; color: white; }

.tipo-badge { padding: 0.25rem 0.5rem; border-radius: 0.25rem; font-size: 0.75rem; font-weight: 500; background: #f1f5f9; }
.tipo-LOGIN_OK { background: #d1fae5; color: #065f46; }
.tipo-LOGIN_FAIL { background: #fee2e2; color: #991b1b; }
.tipo-LOGOUT { background: #e0e7ff; color: #3730a3; }
.tipo-FICHAJE { background: #dbeafe; color: #1e40af; }
.tipo-FICHAJE_MANUAL { background: #fef3c7; color: #92400e; }
.tipo-CREATE, .tipo-EMPLEADO_CREADO { background: #d1fae5; color: #065f46; }
.tipo-UPDATE, .tipo-EMPLEADO_EDITADO { background: #dbeafe; color: #1e40af; }
.tipo-DELETE, .tipo-EMPLEADO_BAJA { background: #fee2e2; color: #991b1b; }
.tipo-CONFIG_CHANGE { background: #f3e8ff; color: #6b21a8; }
.tipo-SECURITY_ALERT, .tipo-PERMISSION_DENIED { background: #fee2e2; color: #991b1b; }
.tipo-VALIDACION { background: #ccfbf1; color: #0f766e; }

.log-detalles { font-family: monospace; font-size: 0.75rem; background: #f1f5f9; padding: 0.5rem; border-radius: 0.25rem; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; cursor: pointer; }
.log-detalles:hover { white-space: normal; word-break: break-all; position: relative; z-index: 10; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

.paginacion { display: flex; justify-content: center; gap: 0.25rem; margin-top: 1.5rem; flex-wrap: wrap; }
.paginacion a, .paginacion span { padding: 0.5rem 0.875rem; border-radius: 0.375rem; font-size: 0.875rem; text-decoration: none; }
.paginacion a { background: white; border: 1px solid #e2e8f0; color: #475569; }
.paginacion a:hover { background: #f1f5f9; }
.paginacion .active { background: #0ea5e9; color: white; border: 1px solid #0ea5e9; }

.filtros-avanzados { display: none; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; }
.filtros-avanzados.visible { display: block; }

.export-btn { background: #059669; color: white; }
.export-btn:hover { background: #047857; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">🔍 Auditoría del Sistema</h1>
        <p class="page-subtitle">Registro de actividad conforme al ENS - Real Decreto 311/2022</p>
    </div>
    <div>
        <a href="?<?= http_build_query(array_merge($filtros, ['exportar' => 'csv'])) ?>" class="btn export-btn">
            📥 Exportar CSV
        </a>
    </div>
</div>

<!-- Estadísticas rápidas -->
<div class="audit-stats">
    <div class="audit-stat">
        <div class="numero"><?= number_format($statsAudit->total ?? 0) ?></div>
        <div class="label">Total Registros</div>
    </div>
    <div class="audit-stat success">
        <div class="numero"><?= number_format($statsAudit->logins ?? 0) ?></div>
        <div class="label">Logins OK</div>
    </div>
    <div class="audit-stat warning">
        <div class="numero"><?= number_format($statsAudit->logins_fallidos ?? 0) ?></div>
        <div class="label">Logins Fallidos</div>
    </div>
    <div class="audit-stat">
        <div class="numero"><?= number_format($statsAudit->fichajes ?? 0) ?></div>
        <div class="label">Fichajes</div>
    </div>
    <div class="audit-stat warning">
        <div class="numero"><?= number_format($statsAudit->warnings ?? 0) ?></div>
        <div class="label">Warnings</div>
    </div>
    <div class="audit-stat danger">
        <div class="numero"><?= number_format($statsAudit->criticos ?? 0) ?></div>
        <div class="label">Críticos</div>
    </div>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET">
            <div style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
                <div class="form-group" style="margin: 0;">
                    <label class="form-label">Desde</label>
                    <input type="date" name="fecha_desde" class="form-control" value="<?= $filtros['fecha_desde'] ?>">
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label class="form-label">Hasta</label>
                    <input type="date" name="fecha_hasta" class="form-control" value="<?= $filtros['fecha_hasta'] ?>">
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label class="form-label">Usuario</label>
                    <select name="usuario_id" class="form-control">
                        <option value="">Todos</option>
                        <?php foreach ($usuarios as $u): ?>
                        <option value="<?= $u->id ?>" <?= $filtros['usuario_id'] == $u->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u->apellido1 . ', ' . $u->nombre) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label class="form-label">Tipo</label>
                    <select name="tipo" class="form-control">
                        <option value="">Todos</option>
                        <?php foreach ($tipos as $t): ?>
                        <option value="<?= htmlspecialchars($t) ?>" <?= $filtros['tipo'] === $t ? 'selected' : '' ?>>
                            <?= function_exists('traducir_tipo_auditoria') ? traducir_tipo_auditoria($t) : $t ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label class="form-label">Nivel</label>
                    <select name="nivel" class="form-control">
                        <option value="">Todos</option>
                        <option value="INFO" <?= $filtros['nivel'] === 'INFO' ? 'selected' : '' ?>>Info</option>
                        <option value="WARNING" <?= $filtros['nivel'] === 'WARNING' ? 'selected' : '' ?>>Warning</option>
                        <option value="ERROR" <?= $filtros['nivel'] === 'ERROR' ? 'selected' : '' ?>>Error</option>
                        <option value="CRITICAL" <?= $filtros['nivel'] === 'CRITICAL' ? 'selected' : '' ?>>Crítico</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
                <a href="auditoria.php" class="btn btn-outline">Limpiar</a>
                <button type="button" onclick="document.getElementById('filtrosAvanzados').classList.toggle('visible')" class="btn btn-outline">⚙️ Más filtros</button>
            </div>
            
            <div id="filtrosAvanzados" class="filtros-avanzados <?= $filtros['busqueda'] ? 'visible' : '' ?>">
                <div class="form-group" style="max-width: 400px;">
                    <label class="form-label">Buscar en descripción/datos</label>
                    <input type="text" name="busqueda" class="form-control" placeholder="Buscar..." value="<?= htmlspecialchars($filtros['busqueda']) ?>">
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Info del período -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
    <div style="font-size: 0.875rem; color: #64748b;">
        📋 <strong><?= number_format($total) ?></strong> registros encontrados
        &nbsp;|&nbsp;
        📅 <?= date('d/m/Y', strtotime($filtros['fecha_desde'])) ?> - <?= date('d/m/Y', strtotime($filtros['fecha_hasta'])) ?>
    </div>
</div>

<!-- Tabla de auditoría -->
<div class="card">
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 140px;">Fecha/Hora</th>
                    <th>Usuario</th>
                    <th>Tipo</th>
                    <th style="width: 80px;">Nivel</th>
                    <th>Descripción</th>
                    <th style="width: 120px;">IP</th>
                    <th>Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($registros)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 3rem; color: #64748b;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📭</div>
                        No se encontraron registros con los filtros seleccionados
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($registros as $reg): ?>
                    <tr>
                        <td style="white-space: nowrap;">
                            <?= date('d/m/Y', strtotime($reg->created_at)) ?><br>
                            <small style="color: #64748b;"><?= date('H:i:s', strtotime($reg->created_at)) ?></small>
                        </td>
                        <td>
                            <?php if ($reg->usuario_nombre): ?>
                                <strong><?= htmlspecialchars($reg->usuario_nombre . ' ' . $reg->usuario_apellido) ?></strong><br>
                                <small style="color: #64748b;"><?= htmlspecialchars($reg->usuario_nif ?? '') ?></small>
                            <?php else: ?>
                                <span style="color: #64748b;">Sistema</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="tipo-badge tipo-<?= htmlspecialchars($reg->tipo ?? '') ?>">
                                <?= function_exists('traducir_tipo_auditoria') ? traducir_tipo_auditoria($reg->tipo) : htmlspecialchars($reg->tipo ?? '-') ?>
                            </span>
                        </td>
                        <td>
                            <span class="nivel-badge nivel-<?= htmlspecialchars($reg->nivel ?? 'INFO') ?>">
                                <?= htmlspecialchars($reg->nivel ?? '-') ?>
                            </span>
                        </td>
                        <td style="max-width: 250px;">
                            <span title="<?= htmlspecialchars($reg->descripcion ?? '') ?>">
                                <?= htmlspecialchars(substr($reg->descripcion ?? '', 0, 60)) ?><?= strlen($reg->descripcion ?? '') > 60 ? '...' : '' ?>
                            </span>
                        </td>
                        <td style="font-family: monospace; font-size: 0.8rem;"><?= htmlspecialchars($reg->ip_address ?? '-') ?></td>
                        <td>
                            <?php if ($reg->datos): ?>
                            <div class="log-detalles" title="Click para expandir">
                                <?= htmlspecialchars(substr($reg->datos, 0, 50)) ?><?= strlen($reg->datos) > 50 ? '...' : '' ?>
                            </div>
                            <?php else: ?>
                            <span style="color: #94a3b8;">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Paginación -->
<?php if ($totalPaginas > 1): ?>
<div class="paginacion">
    <?php if ($pagina > 1): ?>
        <a href="?<?= http_build_query(array_merge($filtros, ['pagina' => 1])) ?>">« Primera</a>
        <a href="?<?= http_build_query(array_merge($filtros, ['pagina' => $pagina - 1])) ?>">‹ Anterior</a>
    <?php endif; ?>
    
    <?php 
    $inicio = max(1, $pagina - 2);
    $fin = min($totalPaginas, $pagina + 2);
    
    if ($inicio > 1) echo '<span style="padding: 0.5rem;">...</span>';
    
    for ($i = $inicio; $i <= $fin; $i++): ?>
        <?php if ($i == $pagina): ?>
            <span class="active"><?= $i ?></span>
        <?php else: ?>
            <a href="?<?= http_build_query(array_merge($filtros, ['pagina' => $i])) ?>"><?= $i ?></a>
        <?php endif; ?>
    <?php endfor; 
    
    if ($fin < $totalPaginas) echo '<span style="padding: 0.5rem;">...</span>';
    ?>
    
    <?php if ($pagina < $totalPaginas): ?>
        <a href="?<?= http_build_query(array_merge($filtros, ['pagina' => $pagina + 1])) ?>">Siguiente ›</a>
        <a href="?<?= http_build_query(array_merge($filtros, ['pagina' => $totalPaginas])) ?>">Última »</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Info ENS -->
<div style="margin-top: 2rem; padding: 1rem; background: #f0f9ff; border-radius: 0.5rem; border-left: 4px solid #0284c7;">
    <p style="margin: 0; font-size: 0.875rem; color: #0369a1;">
        <strong>ℹ️ Información ENS:</strong> Este registro de auditoría cumple con los requisitos del 
        <strong>Esquema Nacional de Seguridad (ENS)</strong> - Real Decreto 311/2022 - para el registro 
        de actividad de usuarios en sistemas de información de las Administraciones Públicas.
        <br><br>
        <strong>Retención de datos:</strong> Los registros se conservan durante 4 años conforme a la normativa RGPD y ENS.
    </p>
</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
