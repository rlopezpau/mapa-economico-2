<?php
/**
 * LM FICHAJES - Panel Admin: Mantenimiento de Datos
 * 
 * Gestión de backups y borrado completo de datos.
 * ACCESO RESTRINGIDO: Solo administradores.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos - SOLO ADMIN
requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'Acceso denegado. Solo administradores.';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';
$backupGenerado = null;

// ============================================================================
// FUNCIONES DE BACKUP Y BORRADO
// ============================================================================

/**
 * Genera backup SQL completo de la base de datos
 */
function generarBackupSQL($pdo) {
    $backup = "-- ============================================================\n";
    $backup .= "-- BACKUP LM FICHAJES - " . date('Y-m-d H:i:s') . "\n";
    $backup .= "-- Base de datos: " . DB_NAME . "\n";
    $backup .= "-- ============================================================\n\n";
    $backup .= "SET FOREIGN_KEY_CHECKS = 0;\n";
    $backup .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n\n";
    
    // Obtener todas las tablas
    $tablas = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tablas as $tabla) {
        // Estructura de la tabla
        $backup .= "-- ============================================================\n";
        $backup .= "-- Tabla: {$tabla}\n";
        $backup .= "-- ============================================================\n\n";
        
        $createStmt = $pdo->query("SHOW CREATE TABLE `{$tabla}`")->fetch(PDO::FETCH_ASSOC);
        $backup .= "DROP TABLE IF EXISTS `{$tabla}`;\n";
        $backup .= $createStmt['Create Table'] . ";\n\n";
        
        // Datos de la tabla
        $rows = $pdo->query("SELECT * FROM `{$tabla}`")->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($rows)) {
            $columnas = array_keys($rows[0]);
            $columnasSQL = '`' . implode('`, `', $columnas) . '`';
            
            $backup .= "INSERT INTO `{$tabla}` ({$columnasSQL}) VALUES\n";
            
            $valores = [];
            foreach ($rows as $row) {
                $rowValues = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $rowValues[] = 'NULL';
                    } else {
                        $rowValues[] = $pdo->quote($value);
                    }
                }
                $valores[] = '(' . implode(', ', $rowValues) . ')';
            }
            
            $backup .= implode(",\n", $valores) . ";\n\n";
        }
    }
    
    $backup .= "SET FOREIGN_KEY_CHECKS = 1;\n";
    $backup .= "\n-- FIN DEL BACKUP --\n";
    
    return $backup;
}

/**
 * Cuenta todos los registros de la base de datos
 */
function contarTodosLosRegistros($pdo) {
    $stats = [];
    $tablas = [
        'empleados' => 'Empleados',
        'fichajes' => 'Fichajes',
        'solicitudes_ausencia' => 'Solicitudes Ausencia',
        'centros' => 'Centros',
        'horarios' => 'Horarios',
        'turnos' => 'Turnos',
        'convenios' => 'Convenios',
        'documentos' => 'Documentos',
        'tickets' => 'Tickets',
        'audit_log' => 'Registros Auditoría'
    ];
    
    foreach ($tablas as $tabla => $nombre) {
        try {
            $count = $pdo->query("SELECT COUNT(*) FROM `{$tabla}`")->fetchColumn();
            $stats[$tabla] = ['nombre' => $nombre, 'total' => (int)$count];
        } catch (PDOException $e) {
            // Tabla no existe
        }
    }
    
    return $stats;
}

/**
 * Borra TODOS los datos (excepto configuración y tipos base)
 */
function borrarTodosLosDatos($pdo, $usuarioId) {
    $resultado = ['exito' => false, 'mensaje' => '', 'borrados' => []];
    
    try {
        $pdo->beginTransaction();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        // Orden de borrado (por dependencias)
        $tablasABorrar = [
            'fichajes' => 'Fichajes',
            'solicitudes_ausencia' => 'Solicitudes de ausencia',
            'saldo_ausencias' => 'Saldos de ausencias',
            'resumen_diario' => 'Resúmenes diarios',
            'empleados_centros' => 'Asignaciones empleado-centro',
            'horarios_dias' => 'Configuración días horarios',
            'turnos_rotaciones' => 'Rotaciones de turnos',
            'turnos_empleados' => 'Asignaciones turno-empleado',
            'convenios_tipos_dias' => 'Días por convenio',
            'documentos' => 'Documentos',
            'tickets' => 'Tickets',
            'login_attempts' => 'Intentos de login',
            'inspeccion_accesos' => 'Accesos inspección',
            'empleados' => 'Empleados',
            'centros' => 'Centros',
            'horarios' => 'Horarios',
            'turnos' => 'Turnos',
            'convenios' => 'Convenios'
        ];
        
        foreach ($tablasABorrar as $tabla => $nombre) {
            try {
                $count = $pdo->query("SELECT COUNT(*) FROM `{$tabla}`")->fetchColumn();
                if ($count > 0) {
                    $pdo->exec("DELETE FROM `{$tabla}`");
                    $resultado['borrados'][$tabla] = ['nombre' => $nombre, 'registros' => $count];
                }
            } catch (PDOException $e) {
                // Tabla no existe, continuar
            }
        }
        
        // Resetear auto_increment
        foreach (array_keys($tablasABorrar) as $tabla) {
            try {
                $pdo->exec("ALTER TABLE `{$tabla}` AUTO_INCREMENT = 1");
            } catch (PDOException $e) {}
        }
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->commit();
        
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Todos los datos han sido eliminados correctamente';
        
        // Auditoría (en nueva transacción ya que borramos audit_log)
        if (function_exists('registrar_auditoria')) {
            registrar_auditoria('DATOS_BORRADOS_TOTAL', 'Se han borrado TODOS los datos del sistema', 
                ['tablas_afectadas' => array_keys($resultado['borrados'])], 
                'CRITICAL', $usuarioId, null, null);
        }
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error al borrar datos: ' . $e->getMessage();
    }
    
    return $resultado;
}

// ============================================================================
// PROCESAR ACCIONES
// ============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // GENERAR BACKUP
    if (isset($_POST['accion']) && $_POST['accion'] === 'generar_backup' && verificar_csrf($_POST['csrf_token'] ?? '')) {
        $backup = generarBackupSQL($pdo);
        $filename = 'backup_lmfichajes_' . date('Y-m-d_His') . '.sql';
        
        // Guardar temporalmente
        $backupPath = sys_get_temp_dir() . '/' . $filename;
        file_put_contents($backupPath, $backup);
        
        // Descargar
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($backup));
        echo $backup;
        exit;
    }
    
    // BORRAR TODOS LOS DATOS - Paso 1: Primera confirmación
    if (isset($_POST['accion']) && $_POST['accion'] === 'confirmar_borrado_1' && verificar_csrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['borrado_confirmacion_1'] = true;
        $_SESSION['borrado_timestamp'] = time();
    }
    
    // BORRAR TODOS LOS DATOS - Paso 2: Segunda confirmación con código
    if (isset($_POST['accion']) && $_POST['accion'] === 'ejecutar_borrado' && verificar_csrf($_POST['csrf_token'] ?? '')) {
        $codigoIngresado = trim($_POST['codigo_confirmacion'] ?? '');
        $codigoEsperado = 'BORRAR-TODO-' . date('Ymd');
        
        // Verificar que pasó la primera confirmación (máx 5 minutos)
        if (!isset($_SESSION['borrado_confirmacion_1']) || 
            !isset($_SESSION['borrado_timestamp']) || 
            (time() - $_SESSION['borrado_timestamp']) > 300) {
            $error = 'Sesión de confirmación expirada. Vuelva a iniciar el proceso.';
            unset($_SESSION['borrado_confirmacion_1'], $_SESSION['borrado_timestamp']);
        } elseif ($codigoIngresado !== $codigoEsperado) {
            $error = "Código incorrecto. El código de hoy es: {$codigoEsperado}";
        } else {
            // Ejecutar borrado
            $resultado = borrarTodosLosDatos($pdo, $usuario->id);
            
            if ($resultado['exito']) {
                $totalBorrados = array_sum(array_column($resultado['borrados'], 'registros'));
                $mensaje = "✅ {$totalBorrados} registros eliminados de " . count($resultado['borrados']) . " tablas.";
            } else {
                $error = $resultado['mensaje'];
            }
            
            unset($_SESSION['borrado_confirmacion_1'], $_SESSION['borrado_timestamp']);
        }
    }
    
    // CANCELAR BORRADO
    if (isset($_POST['accion']) && $_POST['accion'] === 'cancelar_borrado') {
        unset($_SESSION['borrado_confirmacion_1'], $_SESSION['borrado_timestamp']);
        $mensaje = 'Proceso de borrado cancelado';
    }
}

// Estado del proceso de borrado
$enProcesoBorrado = isset($_SESSION['borrado_confirmacion_1']) && 
                    isset($_SESSION['borrado_timestamp']) && 
                    (time() - $_SESSION['borrado_timestamp']) <= 300;

// Obtener estadísticas
$statsRegistros = contarTodosLosRegistros($pdo);
$totalRegistros = array_sum(array_column($statsRegistros, 'total'));

// Variables para layout
$paginaActual = 'mantenimiento';
$titulo = 'Mantenimiento de Datos';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.maint-header { background: linear-gradient(135deg, #dc2626, #ef4444); color: white; padding: 2rem; border-radius: 1rem; margin-bottom: 2rem; }
.maint-header h1 { margin: 0 0 0.5rem; }
.maint-header p { opacity: 0.9; margin: 0; }

.section-card { background: white; border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.section-card h3 { margin: 0 0 1rem; display: flex; align-items: center; gap: 0.5rem; }
.section-card.danger { border: 2px solid #fee2e2; background: #fef2f2; }
.section-card.danger h3 { color: #dc2626; }

.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 0.75rem; margin-bottom: 1.5rem; }
.stat-item { background: #f8fafc; padding: 0.75rem; border-radius: 0.5rem; text-align: center; }
.stat-item .value { font-size: 1.5rem; font-weight: 700; color: #1e3a5f; }
.stat-item .label { font-size: 0.7rem; color: #64748b; text-transform: uppercase; }

.warning-box { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1.5rem; }
.warning-box strong { color: #92400e; }

.danger-box { background: #fee2e2; border: 2px solid #dc2626; border-radius: 0.5rem; padding: 1.5rem; margin-bottom: 1.5rem; }
.danger-box h4 { color: #dc2626; margin: 0 0 1rem; }
.danger-box ul { margin: 0; padding-left: 1.5rem; color: #991b1b; }

.confirm-step { background: #fff7ed; border: 2px solid #f97316; border-radius: 0.75rem; padding: 1.5rem; margin-top: 1rem; }
.confirm-step h4 { color: #c2410c; margin: 0 0 1rem; }
.confirm-step code { background: #ffedd5; padding: 0.25rem 0.5rem; border-radius: 0.25rem; font-size: 1.1rem; color: #c2410c; }

.btn-danger-lg { background: #dc2626; color: white; padding: 1rem 2rem; font-size: 1rem; font-weight: 600; border-radius: 0.5rem; border: none; cursor: pointer; }
.btn-danger-lg:hover { background: #b91c1c; }
.btn-danger-lg:disabled { background: #9ca3af; cursor: not-allowed; }

.countdown { font-size: 0.85rem; color: #f97316; margin-top: 0.5rem; }
</style>

<div class="maint-header">
    <h1>⚠️ Mantenimiento de Datos</h1>
    <p>Backup y gestión avanzada de la base de datos - USE CON PRECAUCIÓN</p>
</div>

<?php if ($mensaje): ?>
<div class="alert alert-success">✅ <?= $mensaje ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- ESTADÍSTICAS ACTUALES -->
<div class="section-card">
    <h3>📊 Estado Actual de la Base de Datos</h3>
    <div class="stats-grid">
        <?php foreach ($statsRegistros as $tabla => $info): ?>
        <div class="stat-item">
            <div class="value"><?= number_format($info['total']) ?></div>
            <div class="label"><?= $info['nombre'] ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <p style="text-align: center; color: #64748b; font-size: 0.9rem;">
        <strong>Total: <?= number_format($totalRegistros) ?> registros</strong> en la base de datos
    </p>
</div>

<!-- BACKUP -->
<div class="section-card">
    <h3>💾 Copia de Seguridad</h3>
    <p style="color: #64748b; margin-bottom: 1rem;">
        Descarga una copia completa de todos los datos en formato SQL. 
        Este archivo puede usarse para restaurar el sistema completo.
    </p>
    
    <form method="POST">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="generar_backup">
        <button type="submit" class="btn btn-primary">
            📥 Descargar Backup SQL Completo
        </button>
    </form>
    
    <div class="warning-box" style="margin-top: 1rem;">
        <strong>💡 Recomendación:</strong> Descargue siempre un backup ANTES de realizar cualquier borrado de datos.
    </div>
</div>

<!-- BORRADO TOTAL -->
<div class="section-card danger">
    <h3>🗑️ Borrar TODOS los Datos</h3>
    
    <div class="danger-box">
        <h4>⚠️ ADVERTENCIA: Esta acción es IRREVERSIBLE</h4>
        <ul>
            <li>Se borrarán TODOS los empleados, fichajes, ausencias, centros, horarios, etc.</li>
            <li>Se perderá TODO el historial y registros de auditoría</li>
            <li>Solo se mantendrán los tipos de ausencia y configuración base</li>
            <li>El sistema quedará como una instalación nueva</li>
        </ul>
    </div>
    
    <?php if (!$enProcesoBorrado): ?>
    <!-- PASO 1: Primera confirmación -->
    <p style="color: #64748b; margin-bottom: 1rem;">
        Para borrar todos los datos, debe completar un proceso de doble confirmación.
    </p>
    
    <form method="POST" onsubmit="return confirm('¿Está SEGURO de que desea iniciar el proceso de borrado total?');">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="confirmar_borrado_1">
        <button type="submit" class="btn btn-danger">
            🔓 Iniciar Proceso de Borrado
        </button>
    </form>
    
    <?php else: ?>
    <!-- PASO 2: Segunda confirmación con código -->
    <div class="confirm-step">
        <h4>✋ Paso 2: Confirmación Final</h4>
        <p>
            Para confirmar el borrado de <strong><?= number_format($totalRegistros) ?> registros</strong>, 
            escriba exactamente el siguiente código:
        </p>
        <p style="text-align: center; margin: 1rem 0;">
            <code>BORRAR-TODO-<?= date('Ymd') ?></code>
        </p>
        
        <form method="POST" style="display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap;">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="ejecutar_borrado">
            
            <div class="form-group" style="flex: 1; min-width: 200px; margin: 0;">
                <label class="form-label">Código de confirmación</label>
                <input type="text" name="codigo_confirmacion" class="form-control" 
                       placeholder="BORRAR-TODO-YYYYMMDD" required 
                       pattern="BORRAR-TODO-[0-9]{8}" autocomplete="off">
            </div>
            
            <button type="submit" class="btn-danger-lg" 
                    onclick="return confirm('ÚLTIMA ADVERTENCIA: ¿Realmente desea BORRAR TODO?');">
                🗑️ CONFIRMAR BORRADO TOTAL
            </button>
        </form>
        
        <form method="POST" style="margin-top: 1rem;">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="cancelar_borrado">
            <button type="submit" class="btn btn-outline">❌ Cancelar</button>
        </form>
        
        <p class="countdown">
            ⏱️ Tiempo restante: <?= 300 - (time() - $_SESSION['borrado_timestamp']) ?> segundos antes de que expire esta confirmación
        </p>
    </div>
    <?php endif; ?>
</div>

<!-- INFORMACIÓN ADICIONAL -->
<div class="section-card">
    <h3>ℹ️ Información</h3>
    <ul style="color: #64748b; line-height: 1.8;">
        <li><strong>Datos Demo:</strong> Use la sección "Datos Demo" para crear/eliminar solo datos de prueba (prefijo DEMO_)</li>
        <li><strong>Backup automático:</strong> Se recomienda configurar backups automáticos en el servidor</li>
        <li><strong>Auditoría:</strong> Todas las acciones de borrado quedan registradas en el log de auditoría</li>
        <li><strong>Restauración:</strong> Para restaurar un backup, use phpMyAdmin o línea de comandos MySQL</li>
    </ul>
</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
