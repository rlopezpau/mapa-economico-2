<?php
/**
 * LM FICHAJES - Funciones Administrativas
 * 
 * Funciones específicas para el panel de administración.
 * Incluye: Dashboard, Validación, Empleados, Centros, Horarios.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @author      Roberto López Miquel
 * @version     1.0.0
 * @date        2025-01-04
 */

// Evitar acceso directo
if (!defined('LMFICHAJES')) {
    die('Acceso no permitido');
}

// Cargar módulo de notificaciones (una sola vez)
if (file_exists(INCLUDES_PATH . '/notificaciones.php')) {
    require_once INCLUDES_PATH . '/notificaciones.php';
}

// Cargar sistema de licencias
require_once dirname(dirname(__DIR__)) . '/includes/licencias.php';

// ============================================================================
// ESTADÍSTICAS PARA DASHBOARD
// ============================================================================

/**
 * Obtiene estadísticas generales para el dashboard
 */
function obtener_estadisticas_dashboard($pdo) {
    $stats = [];
    
    // Total empleados activos
    $stmt = $pdo->query("SELECT COUNT(*) FROM empleados WHERE activo = 1");
    $stats['total_empleados'] = $stmt->fetchColumn();
    $stats['empleados_activos'] = $stats['total_empleados']; // Alias para compatibilidad
    
    // Empleados fichados hoy
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT empleado_id) 
        FROM fichajes 
        WHERE fecha = CURDATE() AND tipo = 'entrada'
    ");
    $stmt->execute();
    $stats['fichados_hoy'] = $stmt->fetchColumn();
    $stats['fichajes_hoy'] = $stats['fichados_hoy']; // Alias para compatibilidad
    
    // Empleados trabajando ahora
    $stmt = $pdo->query("
        SELECT COUNT(DISTINCT f1.empleado_id)
        FROM fichajes f1
        WHERE f1.fecha = CURDATE()
        AND f1.tipo = 'entrada'
        AND NOT EXISTS (
            SELECT 1 FROM fichajes f2 
            WHERE f2.empleado_id = f1.empleado_id 
            AND f2.fecha = f1.fecha 
            AND f2.tipo = 'salida'
            AND f2.hora > f1.hora
        )
    ");
    $stats['trabajando_ahora'] = $stmt->fetchColumn();
    
    // Fichajes pendientes de validación
    $stmt = $pdo->query("SELECT COUNT(*) FROM fichajes WHERE estado = 'pendiente'");
    $stats['fichajes_pendientes'] = $stmt->fetchColumn();
    
    // Fichajes pendientes hoy
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM fichajes 
        WHERE estado = 'pendiente' AND fecha = CURDATE()
    ");
    $stmt->execute();
    $stats['pendientes_hoy'] = $stmt->fetchColumn();
    
    // Total centros activos
    $stmt = $pdo->query("SELECT COUNT(*) FROM centros WHERE activo = 1");
    $stats['total_centros'] = $stmt->fetchColumn();
    
    // Total horarios
    $stmt = $pdo->query("SELECT COUNT(*) FROM horarios WHERE activo = 1");
    $stats['total_horarios'] = $stmt->fetchColumn();
    
    return $stats;
}

// ============================================================================
// VALIDACIÓN DE FICHAJES
// ============================================================================

/**
 * Obtiene fichajes pendientes de validación con paginación y filtros
 */
function obtener_fichajes_pendientes($pdo, $limite = 20, $offset = 0, $filtros = []) {
    $where = ["f.estado = 'pendiente'"];
    $params = [];
    
    // Filtro por fecha desde
    if (!empty($filtros['fecha_desde'])) {
        $where[] = "f.fecha >= ?";
        $params[] = $filtros['fecha_desde'];
    }
    
    // Filtro por fecha hasta
    if (!empty($filtros['fecha_hasta'])) {
        $where[] = "f.fecha <= ?";
        $params[] = $filtros['fecha_hasta'];
    }
    
    // Filtro por empleado
    if (!empty($filtros['empleado_id'])) {
        $where[] = "f.empleado_id = ?";
        $params[] = $filtros['empleado_id'];
    }
    
    // Filtro por centro
    if (!empty($filtros['centro_id'])) {
        $where[] = "f.centro_id = ?";
        $params[] = $filtros['centro_id'];
    }
    
    // Filtro por tipo de incidencia
    if (!empty($filtros['incidencia'])) {
        if ($filtros['incidencia'] === 'ubicacion') {
            $where[] = "f.incidencia_ubicacion = 1";
        } elseif ($filtros['incidencia'] === 'horario') {
            $where[] = "f.incidencia_horario = 1";
        }
    }
    
    $whereSQL = implode(' AND ', $where);
    
    // Contar total
    $sqlCount = "SELECT COUNT(*) FROM fichajes f WHERE {$whereSQL}";
    $stmtCount = $pdo->prepare($sqlCount);
    $stmtCount->execute($params);
    $total = $stmtCount->fetchColumn();
    
    // Obtener fichajes
    $sql = "SELECT f.*, 
            e.nif, e.nombre, e.apellido1, e.apellido2,
            c.nombre as centro_nombre
            FROM fichajes f
            INNER JOIN empleados e ON f.empleado_id = e.id
            LEFT JOIN centros c ON f.centro_id = c.id
            WHERE {$whereSQL}
            ORDER BY f.fecha DESC, f.hora DESC
            LIMIT {$limite} OFFSET {$offset}";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return [
        'fichajes' => $stmt->fetchAll(),
        'total' => $total,
        'paginas' => ceil($total / $limite)
    ];
}

/**
 * Valida un fichaje individual
 */
function validar_fichaje($pdo, $fichajeId, $validadorId, $accion, $horaCorregida = null, $observacion = null) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    
    try {
        // Obtener datos del fichaje ANTES de validar
        $stmtFichaje = $pdo->prepare("SELECT empleado_id, fecha FROM fichajes WHERE id = ?");
        $stmtFichaje->execute([$fichajeId]);
        $datosFichaje = $stmtFichaje->fetch();
        
        $estado = ($accion === 'aprobar') ? 'validado' : 'rechazado';
        
        $sql = "UPDATE fichajes SET 
                estado = ?,
                validado_por = ?,
                validado_fecha = NOW(),
                hora_corregida = ?,
                observacion_validador = ?
                WHERE id = ? AND estado = 'pendiente'";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$estado, $validadorId, $horaCorregida, $observacion, $fichajeId]);
        
        if ($stmt->rowCount() > 0) {
            $resultado['exito'] = true;
            $resultado['mensaje'] = 'Fichaje ' . ($accion === 'aprobar' ? 'aprobado' : 'rechazado') . ' correctamente';
            
            // Si se aprobó, actualizar resumen diario
            if ($accion === 'aprobar') {
                actualizar_resumen_tras_validacion($pdo, $fichajeId);
            }
            
            // NOTIFICACIÓN AL EMPLEADO
            if ($datosFichaje) {
                $fechaFormateada = date('d/m/Y', strtotime($datosFichaje->fecha));
                if ($accion === 'aprobar' && function_exists('notificar_fichaje_validado')) {
                    notificar_fichaje_validado($pdo, $datosFichaje->empleado_id, $fechaFormateada, $datosFichaje->fecha);
                } elseif ($accion !== 'aprobar' && function_exists('notificar_fichaje_rechazado')) {
                    notificar_fichaje_rechazado($pdo, $datosFichaje->empleado_id, $fechaFormateada, $observacion, $datosFichaje->fecha);
                }
            }
        } else {
            $resultado['mensaje'] = 'El fichaje no existe o ya fue procesado';
        }
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al validar el fichaje';
        error_log('Error validar fichaje: ' . $e->getMessage());
    }
    
    return $resultado;
}
/**
 * Validación masiva de fichajes
 */
function validar_fichajes_masivo($pdo, $fichajesIds, $validadorId, $accion) {
    $resultado = ['exito' => false, 'mensaje' => '', 'procesados' => 0];
    
    try {
        $pdo->beginTransaction();
        $estado = ($accion === 'aprobar') ? 'validado' : 'rechazado';
        $procesados = 0;
        
        foreach ($fichajesIds as $fichajeId) {
            $sql = "UPDATE fichajes SET 
                    estado = ?,
                    validado_por = ?,
                    validado_fecha = NOW()
                    WHERE id = ? AND estado = 'pendiente'";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$estado, $validadorId, $fichajeId]);
            
            if ($stmt->rowCount() > 0) {
                $procesados++;
                if ($accion === 'aprobar') {
                    actualizar_resumen_tras_validacion($pdo, $fichajeId);
                }
            }
        }
        
        $pdo->commit();
        
        $resultado['exito'] = true;
        $resultado['procesados'] = $procesados;
        $resultado['mensaje'] = "{$procesados} fichaje(s) " . ($accion === 'aprobar' ? 'aprobado(s)' : 'rechazado(s)');
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error en la validación masiva';
        error_log('Error validación masiva: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Actualiza el resumen diario tras validar un fichaje
 */
function actualizar_resumen_tras_validacion($pdo, $fichajeId) {
    $stmt = $pdo->prepare("SELECT empleado_id, fecha FROM fichajes WHERE id = ?");
    $stmt->execute([$fichajeId]);
    $fichaje = $stmt->fetch();
    
    if ($fichaje) {
        // Recalcular horas del día
        $sql = "SELECT 
                MIN(CASE WHEN tipo = 'entrada' THEN COALESCE(hora_corregida, hora) END) as primera_entrada,
                MAX(CASE WHEN tipo = 'salida' THEN COALESCE(hora_corregida, hora) END) as ultima_salida
                FROM fichajes 
                WHERE empleado_id = ? AND fecha = ? AND estado IN ('auto_aprobado', 'validado', 'autorizado')";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$fichaje->empleado_id, $fichaje->fecha]);
        $tiempos = $stmt->fetch();
        
        if ($tiempos && $tiempos->primera_entrada && $tiempos->ultima_salida) {
            $entrada = new DateTime($tiempos->primera_entrada);
            $salida = new DateTime($tiempos->ultima_salida);
            $diff = $entrada->diff($salida);
            $horasTrabajadas = $diff->h + ($diff->i / 60);
            
            // Actualizar o insertar en resumen_diario
            $sql = "INSERT INTO resumen_diario (empleado_id, fecha, horas_trabajadas, primera_entrada, ultima_salida, updated_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE 
                    horas_trabajadas = ?, primera_entrada = ?, ultima_salida = ?, updated_at = NOW()";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $fichaje->empleado_id, $fichaje->fecha, $horasTrabajadas,
                $tiempos->primera_entrada, $tiempos->ultima_salida,
                $horasTrabajadas, $tiempos->primera_entrada, $tiempos->ultima_salida
            ]);
        }
    }
}

// ============================================================================
// GESTIÓN DE EMPLEADOS
// ============================================================================

/**
 * Obtiene lista de empleados con paginación y filtros
 */
function obtener_empleados($pdo, $limite = 25, $offset = 0, $filtros = []) {
    $where = ["1=1"];
    $params = [];
    
    // Búsqueda por texto
    if (!empty($filtros['busqueda'])) {
        $busqueda = '%' . $filtros['busqueda'] . '%';
        $where[] = "(e.nif LIKE ? OR e.nombre LIKE ? OR e.apellido1 LIKE ? OR e.apellido2 LIKE ? OR e.email LIKE ?)";
        $params = array_merge($params, [$busqueda, $busqueda, $busqueda, $busqueda, $busqueda]);
    }
    
    // Filtro por estado
    if (isset($filtros['activo']) && $filtros['activo'] !== '') {
        $where[] = "e.activo = ?";
        $params[] = $filtros['activo'];
    }
    
    // Filtro por rol
    if (!empty($filtros['rol'])) {
        $where[] = "e.rol = ?";
        $params[] = $filtros['rol'];
    }
    
    // Filtro por centro
    if (!empty($filtros['centro_id'])) {
        $where[] = "EXISTS (SELECT 1 FROM empleados_centros ec WHERE ec.empleado_id = e.id AND ec.centro_id = ? AND ec.activo = 1)";
        $params[] = $filtros['centro_id'];
    }
    
    $whereSQL = implode(' AND ', $where);
    
    // Contar total
    $sqlCount = "SELECT COUNT(*) FROM empleados e WHERE {$whereSQL}";
    $stmtCount = $pdo->prepare($sqlCount);
    $stmtCount->execute($params);
    $total = $stmtCount->fetchColumn();
    
    // Obtener empleados
    $sql = "SELECT e.*, h.nombre as horario_nombre,
            (SELECT GROUP_CONCAT(c.nombre SEPARATOR ', ') 
             FROM empleados_centros ec 
             INNER JOIN centros c ON ec.centro_id = c.id 
             WHERE ec.empleado_id = e.id AND ec.activo = 1) as centros
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE {$whereSQL}
            ORDER BY e.apellido1, e.apellido2, e.nombre
            LIMIT {$limite} OFFSET {$offset}";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return [
        'empleados' => $stmt->fetchAll(),
        'total' => $total,
        'paginas' => ceil($total / $limite)
    ];
}

/**
 * Obtiene un empleado por ID con info adicional
 */
function obtener_empleado_admin($pdo, $id) {
    $sql = "SELECT e.*, h.nombre as horario_nombre
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE e.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $empleado = $stmt->fetch();
    
    if ($empleado) {
        // Obtener centros asignados
        $stmt = $pdo->prepare("
            SELECT ec.*, c.nombre as centro_nombre
            FROM empleados_centros ec
            INNER JOIN centros c ON ec.centro_id = c.id
            WHERE ec.empleado_id = ? AND ec.activo = 1
            ORDER BY ec.es_principal DESC, c.nombre
        ");
        $stmt->execute([$id]);
        $empleado->centros = $stmt->fetchAll();
    }
    
    return $empleado;
}

/**
 * Guarda un empleado (crear o actualizar)
 */
function guardar_empleado($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    $id = $datos['id'] ?? null;
    
    // Validar NIF único
    $sql = "SELECT id FROM empleados WHERE nif = ?" . ($id ? " AND id != ?" : "");
    $params = [$datos['nif']];
    if ($id) $params[] = $id;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    if ($stmt->fetch()) {
        $resultado['mensaje'] = 'Ya existe un empleado con ese NIF';
        return $resultado;
    }
    
    // Si tiene turno rotativo, limpiar horario fijo
    $horarioId = $datos['horario_id'] ?: null;
    $turnoGrupoId = $datos['turno_grupo_id'] ?? null;
    if ($turnoGrupoId) {
        $horarioId = null; // El turno rotativo tiene prioridad
    }
    
    try {
        if ($id) {
            // Actualizar
            $sql = "UPDATE empleados SET
                    nif = ?, nombre = ?, apellido1 = ?, apellido2 = ?,
                    email = ?, telefono = ?, rol = ?, horario_id = ?,
                    turno_grupo_id = ?, centro_id = ?, convenio_id = ?,
                    supervisor_id = ?, supervisor2_id = ?,
                    fecha_alta = ?, dias_vacaciones = ?,
                    dias_vacaciones_antiguedad = ?, dias_libre_disposicion = ?,
                    dias_libre_disp_antiguedad = ?, activo = ?,
                    updated_at = NOW()
                    WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nif'], $datos['nombre'], $datos['apellido1'],
                $datos['apellido2'] ?? null, $datos['email'] ?? null,
                $datos['telefono'] ?? null, $datos['rol'],
                $horarioId, $turnoGrupoId,
                $datos['centro_id'] ?: null,
                $datos['convenio_id'] ?: null,
                $datos['supervisor_id'] ?: null,
                $datos['supervisor2_id'] ?: null,
                $datos['fecha_alta'] ?: null,
                $datos['dias_vacaciones'] ?? 22,
                $datos['dias_vacaciones_antiguedad'] ?? 0,
                $datos['dias_libre_disposicion'] ?? 6,
                $datos['dias_libre_disp_antiguedad'] ?? 0,
                $datos['activo'] ?? 1, $id
            ]);
            $resultado['id'] = $id;
            $resultado['mensaje'] = 'Empleado actualizado correctamente';
        } else {
            // Crear
            $passwordTemporal = generar_password(10);
            $passwordHash = hashear_password($passwordTemporal);

            $sql = "INSERT INTO empleados
                    (nif, nombre, apellido1, apellido2, email, telefono,
                     rol, horario_id, turno_grupo_id, centro_id, convenio_id,
                     supervisor_id, supervisor2_id, password, fecha_alta,
                     dias_vacaciones, dias_vacaciones_antiguedad,
                     dias_libre_disposicion, dias_libre_disp_antiguedad, activo)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nif'], $datos['nombre'], $datos['apellido1'],
                $datos['apellido2'] ?? null, $datos['email'] ?? null,
                $datos['telefono'] ?? null, $datos['rol'],
                $horarioId, $turnoGrupoId,
                $datos['centro_id'] ?: null,
                $datos['convenio_id'] ?: null,
                $datos['supervisor_id'] ?: null,
                $datos['supervisor2_id'] ?: null, $passwordHash,
                $datos['fecha_alta'] ?: date('Y-m-d'),
                $datos['dias_vacaciones'] ?? 22,
                $datos['dias_vacaciones_antiguedad'] ?? 0,
                $datos['dias_libre_disposicion'] ?? 6,
                $datos['dias_libre_disp_antiguedad'] ?? 0
            ]);
            $resultado['id'] = $pdo->lastInsertId();
            $resultado['mensaje'] = 'Empleado creado correctamente. Contraseña temporal: ' . $passwordTemporal;
            $resultado['password_temporal'] = $passwordTemporal;
        }
        $resultado['exito'] = true;
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al guardar el empleado';
        error_log('Error guardar empleado: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Asigna centros a un empleado
 */
function asignar_centros_empleado($pdo, $empleadoId, $centrosIds, $centroPrincipalId = null) {
    try {
        // Desactivar asignaciones actuales
        $stmt = $pdo->prepare("UPDATE empleados_centros SET activo = 0 WHERE empleado_id = ?");
        $stmt->execute([$empleadoId]);
        
        // Asignar nuevos centros
        foreach ($centrosIds as $centroId) {
            $esPrincipal = ($centroId == $centroPrincipalId) ? 1 : 0;
            
            $stmt = $pdo->prepare("
                INSERT INTO empleados_centros (empleado_id, centro_id, es_principal, activo)
                VALUES (?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE es_principal = ?, activo = 1
            ");
            $stmt->execute([$empleadoId, $centroId, $esPrincipal, $esPrincipal]);
        }
        
        return ['exito' => true, 'mensaje' => 'Centros asignados correctamente'];
    } catch (PDOException $e) {
        error_log('Error asignar centros: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al asignar centros'];
    }
}

/**
 * Activa o desactiva un empleado
 */
function toggle_empleado_activo($pdo, $empleadoId) {
    try {
        $stmt = $pdo->prepare("UPDATE empleados SET activo = NOT activo, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$empleadoId]);
        
        // Obtener nuevo estado
        $stmt = $pdo->prepare("SELECT activo FROM empleados WHERE id = ?");
        $stmt->execute([$empleadoId]);
        $nuevoEstado = $stmt->fetchColumn();
        
        return [
            'exito' => true, 
            'mensaje' => 'Empleado ' . ($nuevoEstado ? 'activado' : 'desactivado') . ' correctamente',
            'activo' => $nuevoEstado
        ];
    } catch (PDOException $e) {
        error_log('Error toggle empleado: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al cambiar estado del empleado'];
    }
}

/**
 * Resetea la contraseña de un empleado
 */
function resetear_password_empleado($pdo, $empleadoId) {
    try {
        $passwordTemporal = generar_password(10);
        $passwordHash = hashear_password($passwordTemporal);
        
        $stmt = $pdo->prepare("UPDATE empleados SET password = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$passwordHash, $empleadoId]);
        
        return [
            'exito' => true,
            'mensaje' => 'Contraseña reseteada. Nueva contraseña: ' . $passwordTemporal,
            'password_temporal' => $passwordTemporal
        ];
    } catch (PDOException $e) {
        error_log('Error resetear password: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al resetear contraseña'];
    }
}

// ============================================================================
// GESTIÓN DE CENTROS
// ============================================================================

/**
 * Obtiene lista de centros
 */
function obtener_centros_admin($pdo, $soloActivos = false) {
    $sql = "SELECT c.*, 
            (SELECT COUNT(*) FROM empleados_centros ec WHERE ec.centro_id = c.id AND ec.activo = 1) as num_empleados
            FROM centros c" .
            ($soloActivos ? " WHERE c.activo = 1" : "") .
            " ORDER BY c.nombre";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Obtiene un centro por ID con información adicional
 */
function obtener_centro_admin($pdo, $id) {
    $stmt = $pdo->prepare("
        SELECT c.*,
        (SELECT COUNT(*) FROM empleados_centros ec WHERE ec.centro_id = c.id AND ec.activo = 1) as num_empleados
        FROM centros c 
        WHERE c.id = ?
    ");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Obtiene empleados asignados a un centro
 */
function obtener_empleados_centro($pdo, $centroId) {
    $sql = "SELECT e.*, ec.es_principal, h.nombre as horario_nombre
            FROM empleados e
            INNER JOIN empleados_centros ec ON e.id = ec.empleado_id
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE ec.centro_id = ? AND ec.activo = 1 AND e.activo = 1
            ORDER BY ec.es_principal DESC, e.apellido1, e.nombre";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$centroId]);
    return $stmt->fetchAll();
}

/**
 * Guarda un centro (crear o actualizar)
 */
function guardar_centro($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    $id = $datos['id'] ?? null;
    
    // Validar límite de licencia (solo para nuevos centros)
    if (!$id) {
        $checkLicencia = puede_crear_centro($pdo);
        if (!$checkLicencia['permitido']) {
            $resultado['mensaje'] = $checkLicencia['mensaje'];
            return $resultado;
        }
    }
    
    // Validar código único si se proporciona
    if (!empty($datos['codigo'])) {
        $sql = "SELECT id FROM centros WHERE codigo = ?" . ($id ? " AND id != ?" : "");
        $params = [$datos['codigo']];
        if ($id) $params[] = $id;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        if ($stmt->fetch()) {
            $resultado['mensaje'] = 'Ya existe un centro con ese código';
            return $resultado;
        }
    }
    
    try {
        if ($id) {
            $sql = "UPDATE centros SET 
                    codigo = ?, nombre = ?, direccion = ?, coordenadas = ?, 
                    radio_metros = ?, activo = ?, updated_at = NOW()
                    WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['codigo'] ?? null, $datos['nombre'], 
                $datos['direccion'] ?? null, $datos['coordenadas'] ?? null, 
                $datos['radio_metros'] ?? 100, $datos['activo'] ?? 1, $id
            ]);
            $resultado['id'] = $id;
            $resultado['mensaje'] = 'Centro actualizado correctamente';
        } else {
            $sql = "INSERT INTO centros (codigo, nombre, direccion, coordenadas, radio_metros, activo)
                    VALUES (?, ?, ?, ?, ?, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['codigo'] ?? null, $datos['nombre'],
                $datos['direccion'] ?? null, $datos['coordenadas'] ?? null,
                $datos['radio_metros'] ?? 100
            ]);
            $resultado['id'] = $pdo->lastInsertId();
            $resultado['mensaje'] = 'Centro creado correctamente';
        }
        $resultado['exito'] = true;
    } catch (PDOException $e) {
        $resultado['mensaje'] = 'Error al guardar el centro';
        error_log('Error guardar centro: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Elimina un centro (si no tiene empleados asignados)
 */
function eliminar_centro($pdo, $centroId) {
    // Verificar si tiene empleados asignados
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM empleados_centros WHERE centro_id = ? AND activo = 1");
    $stmt->execute([$centroId]);
    if ($stmt->fetchColumn() > 0) {
        return ['exito' => false, 'mensaje' => 'No se puede eliminar: hay empleados asignados a este centro'];
    }
    
    // Verificar si tiene fichajes
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM fichajes WHERE centro_id = ?");
    $stmt->execute([$centroId]);
    if ($stmt->fetchColumn() > 0) {
        return ['exito' => false, 'mensaje' => 'No se puede eliminar: hay fichajes registrados en este centro'];
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM centros WHERE id = ?");
        $stmt->execute([$centroId]);
        return ['exito' => true, 'mensaje' => 'Centro eliminado correctamente'];
    } catch (PDOException $e) {
        error_log('Error eliminar centro: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al eliminar el centro'];
    }
}

/**
 * Activa o desactiva un centro
 */
function toggle_centro_activo($pdo, $centroId) {
    try {
        $stmt = $pdo->prepare("UPDATE centros SET activo = NOT activo, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$centroId]);
        
        $stmt = $pdo->prepare("SELECT activo FROM centros WHERE id = ?");
        $stmt->execute([$centroId]);
        $nuevoEstado = $stmt->fetchColumn();
        
        return [
            'exito' => true,
            'mensaje' => 'Centro ' . ($nuevoEstado ? 'activado' : 'desactivado') . ' correctamente',
            'activo' => $nuevoEstado
        ];
    } catch (PDOException $e) {
        error_log('Error toggle centro: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al cambiar estado del centro'];
    }
}

// ============================================================================
// GESTIÓN DE HORARIOS
// ============================================================================

/**
 * Obtiene lista de horarios
 */
function obtener_horarios_admin($pdo, $soloActivos = false) {
    $sql = "SELECT h.*, 
            (SELECT COUNT(*) FROM empleados e WHERE e.horario_id = h.id AND e.activo = 1) as num_empleados
            FROM horarios h" .
            ($soloActivos ? " WHERE h.activo = 1" : "") .
            " ORDER BY h.nombre";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Obtiene un horario por ID con sus días
 */
function obtener_horario_admin($pdo, $id) {
    $stmt = $pdo->prepare("
        SELECT h.*,
        (SELECT COUNT(*) FROM empleados e WHERE e.horario_id = h.id AND e.activo = 1) as num_empleados
        FROM horarios h 
        WHERE h.id = ?
    ");
    $stmt->execute([$id]);
    $horario = $stmt->fetch();
    
    if ($horario) {
        $stmt = $pdo->prepare("SELECT * FROM horarios_dias WHERE horario_id = ? ORDER BY dia_semana");
        $stmt->execute([$id]);
        $horario->dias = $stmt->fetchAll();
    }
    
    return $horario;
}

/**
 * Obtiene empleados con un horario específico
 */
function obtener_empleados_horario($pdo, $horarioId) {
    $sql = "SELECT e.*, 
            (SELECT GROUP_CONCAT(c.nombre SEPARATOR ', ') 
             FROM empleados_centros ec 
             INNER JOIN centros c ON ec.centro_id = c.id 
             WHERE ec.empleado_id = e.id AND ec.activo = 1) as centros
            FROM empleados e
            WHERE e.horario_id = ? AND e.activo = 1
            ORDER BY e.apellido1, e.nombre";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$horarioId]);
    return $stmt->fetchAll();
}

/**
 * Guarda un horario con sus días de la semana
 */
function guardar_horario($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    $id = $datos['id'] ?? null;
    
    try {
        $pdo->beginTransaction();
        
        if ($id) {
            $sql = "UPDATE horarios SET 
                    nombre = ?, tipo = ?, horas_diarias = ?, horas_semanales = ?,
                    hora_entrada = ?, hora_salida = ?,
                    hora_entrada_tarde = ?, hora_salida_tarde = ?,
                    troncal_inicio = ?, troncal_fin = ?,
                    troncal_tarde_inicio = ?, troncal_tarde_fin = ?,
                    cortesia_entrada = ?, cortesia_salida = ?,
                    tolerancia_minutos = ?, activo = ?, updated_at = NOW()
                    WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'], $datos['tipo'] ?? 'continua',
                $datos['horas_diarias'] ?? 7.5, $datos['horas_semanales'] ?? 37.5,
                $datos['hora_entrada'] ?? null, $datos['hora_salida'] ?? null,
                $datos['hora_entrada_tarde'] ?? null, $datos['hora_salida_tarde'] ?? null,
                $datos['troncal_inicio'] ?? null, $datos['troncal_fin'] ?? null,
                $datos['troncal_tarde_inicio'] ?? null, $datos['troncal_tarde_fin'] ?? null,
                $datos['cortesia_entrada'] ?? 5, $datos['cortesia_salida'] ?? 5,
                $datos['tolerancia_minutos'] ?? 15, $datos['activo'] ?? 1, $id
            ]);
            $resultado['id'] = $id;
            $resultado['mensaje'] = 'Horario actualizado correctamente';
        } else {
            $sql = "INSERT INTO horarios 
                    (nombre, tipo, horas_diarias, horas_semanales,
                     hora_entrada, hora_salida,
                     hora_entrada_tarde, hora_salida_tarde,
                     troncal_inicio, troncal_fin,
                     troncal_tarde_inicio, troncal_tarde_fin,
                     cortesia_entrada, cortesia_salida, tolerancia_minutos, activo)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'], $datos['tipo'] ?? 'continua',
                $datos['horas_diarias'] ?? 7.5, $datos['horas_semanales'] ?? 37.5,
                $datos['hora_entrada'] ?? null, $datos['hora_salida'] ?? null,
                $datos['hora_entrada_tarde'] ?? null, $datos['hora_salida_tarde'] ?? null,
                $datos['troncal_inicio'] ?? null, $datos['troncal_fin'] ?? null,
                $datos['troncal_tarde_inicio'] ?? null, $datos['troncal_tarde_fin'] ?? null,
                $datos['cortesia_entrada'] ?? 5, $datos['cortesia_salida'] ?? 5,
                $datos['tolerancia_minutos'] ?? 15
            ]);
            $resultado['id'] = $pdo->lastInsertId();
            $id = $resultado['id'];
            $resultado['mensaje'] = 'Horario creado correctamente';
        }
        
        // Actualizar días de la semana si se proporcionan
        if (isset($datos['dias']) && is_array($datos['dias'])) {
            // Eliminar días existentes
            $stmt = $pdo->prepare("DELETE FROM horarios_dias WHERE horario_id = ?");
            $stmt->execute([$id]);
            
            // Insertar nuevos días
            $stmt = $pdo->prepare("
                INSERT INTO horarios_dias (horario_id, dia_semana, es_laborable, horas_esperadas)
                VALUES (?, ?, ?, ?)
            ");
            
            foreach ($datos['dias'] as $diaSemana => $diaInfo) {
                $esLaborable = is_array($diaInfo) ? ($diaInfo['es_laborable'] ?? 0) : $diaInfo;
                $horasEsperadas = is_array($diaInfo) ? ($diaInfo['horas_esperadas'] ?? $datos['horas_diarias'] ?? 7.5) : ($datos['horas_diarias'] ?? 7.5);
                
                $stmt->execute([
                    $id,
                    $diaSemana,
                    $esLaborable ? 1 : 0,
                    $esLaborable ? $horasEsperadas : 0
                ]);
            }
        }
        
        $pdo->commit();
        $resultado['exito'] = true;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error al guardar el horario';
        error_log('Error guardar horario: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Elimina un horario (si no tiene empleados asignados)
 */
function eliminar_horario($pdo, $horarioId) {
    // Verificar si tiene empleados asignados
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM empleados WHERE horario_id = ? AND activo = 1");
    $stmt->execute([$horarioId]);
    if ($stmt->fetchColumn() > 0) {
        return ['exito' => false, 'mensaje' => 'No se puede eliminar: hay empleados con este horario asignado'];
    }
    
    try {
        $pdo->beginTransaction();
        
        // Eliminar días del horario
        $stmt = $pdo->prepare("DELETE FROM horarios_dias WHERE horario_id = ?");
        $stmt->execute([$horarioId]);
        
        // Eliminar horario
        $stmt = $pdo->prepare("DELETE FROM horarios WHERE id = ?");
        $stmt->execute([$horarioId]);
        
        $pdo->commit();
        return ['exito' => true, 'mensaje' => 'Horario eliminado correctamente'];
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Error eliminar horario: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al eliminar el horario'];
    }
}

/**
 * Activa o desactiva un horario
 */
function toggle_horario_activo($pdo, $horarioId) {
    try {
        $stmt = $pdo->prepare("UPDATE horarios SET activo = NOT activo, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$horarioId]);
        
        $stmt = $pdo->prepare("SELECT activo FROM horarios WHERE id = ?");
        $stmt->execute([$horarioId]);
        $nuevoEstado = $stmt->fetchColumn();
        
        return [
            'exito' => true,
            'mensaje' => 'Horario ' . ($nuevoEstado ? 'activado' : 'desactivado') . ' correctamente',
            'activo' => $nuevoEstado
        ];
    } catch (PDOException $e) {
        error_log('Error toggle horario: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al cambiar estado del horario'];
    }
}

/**
 * Duplica un horario existente
 */
function duplicar_horario($pdo, $horarioId) {
    try {
        $pdo->beginTransaction();
        
        // Obtener horario original
        $horarioOriginal = obtener_horario_admin($pdo, $horarioId);
        if (!$horarioOriginal) {
            return ['exito' => false, 'mensaje' => 'Horario no encontrado'];
        }
        
        // Crear nuevo horario
        $sql = "INSERT INTO horarios 
                (nombre, tipo, horas_diarias, horas_semanales,
                 hora_entrada, hora_salida,
                 hora_entrada_tarde, hora_salida_tarde,
                 troncal_inicio, troncal_fin,
                 troncal_tarde_inicio, troncal_tarde_fin,
                 cortesia_entrada, cortesia_salida, tolerancia_minutos, activo)
                SELECT 
                CONCAT(nombre, ' (copia)'), tipo, horas_diarias, horas_semanales,
                hora_entrada, hora_salida,
                hora_entrada_tarde, hora_salida_tarde,
                troncal_inicio, troncal_fin,
                troncal_tarde_inicio, troncal_tarde_fin,
                cortesia_entrada, cortesia_salida, tolerancia_minutos, 1
                FROM horarios WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$horarioId]);
        $nuevoId = $pdo->lastInsertId();
        
        // Copiar días
        $sql = "INSERT INTO horarios_dias (horario_id, dia_semana, es_laborable, horas_esperadas)
                SELECT ?, dia_semana, es_laborable, horas_esperadas
                FROM horarios_dias WHERE horario_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nuevoId, $horarioId]);
        
        $pdo->commit();
        return [
            'exito' => true,
            'mensaje' => 'Horario duplicado correctamente',
            'id' => $nuevoId
        ];
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Error duplicar horario: ' . $e->getMessage());
        return ['exito' => false, 'mensaje' => 'Error al duplicar el horario'];
    }
}

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/**
 * Obtiene lista de empleados para selectores
 */
function obtener_empleados_selector($pdo, $soloActivos = true, $excluirId = null) {
    $sql = "SELECT id, nif, nombre, apellido1, apellido2, rol
            FROM empleados
            WHERE 1=1" .
            ($soloActivos ? " AND activo = 1" : "") .
            ($excluirId ? " AND id != ?" : "") .
            " ORDER BY apellido1, apellido2, nombre";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($excluirId ? [$excluirId] : []);
    return $stmt->fetchAll();
}

/**
 * Formatea nombre completo de empleado
 */
function nombre_completo_empleado($empleado) {
    $nombre = $empleado->nombre . ' ' . $empleado->apellido1;
    if (!empty($empleado->apellido2)) {
        $nombre .= ' ' . $empleado->apellido2;
    }
    return $nombre;
}

/**
 * Genera ítem de navegación del admin
 */
function admin_nav_item($url, $icono, $texto, $activo = false, $badge = null) {
    $clase = $activo ? 'nav-item active' : 'nav-item';
    $badgeHTML = $badge ? "<span class=\"badge\">{$badge}</span>" : '';
    return "<a href=\"{$url}\" class=\"{$clase}\"><span class=\"icon\">{$icono}</span>{$texto}{$badgeHTML}</a>";
}

/**
 * Formatea hora para mostrar
 */
function formatear_hora($hora) {
    if (empty($hora)) return '-';
    return date('H:i', strtotime($hora));
}

/**
 * Nombres de días de la semana
 */
function nombre_dia_semana($numero) {
    $dias = [
        1 => 'Lunes',
        2 => 'Martes',
        3 => 'Miércoles',
        4 => 'Jueves',
        5 => 'Viernes',
        6 => 'Sábado',
        7 => 'Domingo'
    ];
    return $dias[$numero] ?? '';
}
