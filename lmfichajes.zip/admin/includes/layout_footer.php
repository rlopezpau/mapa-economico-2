<?php
/**
 * LM FICHAJES - Layout Footer
 * 
 * Cierre HTML compartido para todo el panel de administración.
 * Incluye JavaScript común y cierre de tags.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');
?>
        </main>
    </div>
    
    <!-- JavaScript común -->
    <script>
    /**
     * Confirmar acción peligrosa
     */
    function confirmar(mensaje) {
        return confirm(mensaje || '¿Estás seguro de realizar esta acción?');
    }
    
    /**
     * Mostrar/ocultar elemento
     */
    function toggleElement(id) {
        var el = document.getElementById(id);
        if (el) {
            el.style.display = el.style.display === 'none' ? 'block' : 'none';
        }
    }
    
    /**
     * Cerrar alertas automáticamente después de 5 segundos
     */
    document.addEventListener('DOMContentLoaded', function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            setTimeout(function() {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            }, 5000);
        });
    });
    
    /**
     * Prevenir envío doble de formularios
     */
    document.addEventListener('DOMContentLoaded', function() {
        var forms = document.querySelectorAll('form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                var submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn && !submitBtn.disabled) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<span class="spinner"></span> Procesando...';

                    // Re-habilitar después de 10 segundos por si hay error
                    setTimeout(function() {
                        submitBtn.disabled = false;
                    }, 10000);
                }
            });
        });
    });

    /**
     * Menú móvil toggle
     */
    document.addEventListener('DOMContentLoaded', function() {
        var menuToggle = document.getElementById('menuToggle');
        var sidebar = document.querySelector('.sidebar');
        var overlay = document.getElementById('sidebarOverlay');

        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', function() {
                var isOpen = sidebar.classList.toggle('open');
                overlay.classList.toggle('visible', isOpen);
                menuToggle.setAttribute('aria-expanded', isOpen);
                menuToggle.innerHTML = isOpen ? '✕' : '☰';
            });

            // Cerrar al hacer clic en overlay
            if (overlay) {
                overlay.addEventListener('click', function() {
                    sidebar.classList.remove('open');
                    overlay.classList.remove('visible');
                    menuToggle.setAttribute('aria-expanded', 'false');
                    menuToggle.innerHTML = '☰';
                });
            }

            // Cerrar con tecla Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && sidebar.classList.contains('open')) {
                    sidebar.classList.remove('open');
                    overlay.classList.remove('visible');
                    menuToggle.setAttribute('aria-expanded', 'false');
                    menuToggle.innerHTML = '☰';
                }
            });
        }
    });
    </script>
</body>
</html>
