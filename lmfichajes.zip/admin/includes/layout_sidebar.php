<?php
/**
 * LM FICHAJES - Layout Sidebar
 * 
 * Menú lateral compartido para todo el panel de administración.
 * UN SOLO ARCHIVO - Cambios aquí se reflejan en todo el admin.
 * 
 * Variables esperadas:
 * - $paginaActual (string): Identificador de la página actual para marcar como activa
 * - $stats (array): Estadísticas para badges (fichajes_pendientes, etc.)
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

// Asegurar variables
$paginaActual = $paginaActual ?? '';
$stats = $stats ?? ['fichajes_pendientes' => 0, 'ausencias_pendientes' => 0];

// Función auxiliar para marcar item activo
function nav_active($pagina, $actual) {
    return $pagina === $actual ? ' active' : '';
}
?>
        <!-- Sidebar -->
        <nav class="sidebar">
            <!-- Principal -->
            <div class="nav-section">
                <div class="nav-section-title">Principal</div>
                
                <a href="index.php" class="nav-item<?php echo nav_active('dashboard', $paginaActual); ?>">
                    <span class="icon">📊</span>
                    Dashboard
                </a>
                
                <a href="fichajes.php" class="nav-item<?php echo nav_active('fichajes', $paginaActual); ?>">
                    <span class="icon">✅</span>
                    Validar Fichajes
                    <?php if ($stats['fichajes_pendientes'] > 0): ?>
                        <span class="badge"><?php echo $stats['fichajes_pendientes']; ?></span>
                    <?php endif; ?>
                </a>
                
                <a href="incidencias_fichajes.php" class="nav-item<?php echo nav_active('incidencias', $paginaActual); ?>">
                    <span class="icon">⚠️</span>
                    Incidencias Fichajes
                    <?php if (($stats['fichajes_sin_cerrar'] ?? 0) > 0): ?>
                        <span class="badge" style="background:#ef4444"><?php echo $stats['fichajes_sin_cerrar']; ?></span>
                    <?php endif; ?>
                </a>
                
                <a href="ausencias.php" class="nav-item<?php echo nav_active('ausencias', $paginaActual); ?>">
                    <span class="icon">📅</span>
                    Ausencias
                    <?php if (($stats['ausencias_pendientes'] ?? 0) > 0): ?>
                        <span class="badge"><?php echo $stats['ausencias_pendientes']; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            
            <!-- Gestión -->
            <div class="nav-section">
                <div class="nav-section-title">Gestión</div>
                
                <a href="empleados.php" class="nav-item<?php echo nav_active('empleados', $paginaActual); ?>">
                    <span class="icon">👥</span>
                    Empleados
                </a>
                
                <a href="centros.php" class="nav-item<?php echo nav_active('centros', $paginaActual); ?>">
                    <span class="icon">🏛️</span>
                    Centros
                </a>
                
                <a href="convenios.php" class="nav-item<?php echo nav_active('convenios', $paginaActual); ?>">
                    <span class="icon">📋</span>
                    Convenios
                </a>
                
                <a href="horarios.php" class="nav-item<?php echo nav_active('horarios', $paginaActual); ?>">
                    <span class="icon">🕐</span>
                    Horarios
                </a>
                
                <a href="turnos.php" class="nav-item<?php echo nav_active('turnos', $paginaActual); ?>">
                    <span class="icon">🔄</span>
                    Turnos
                </a>
                
                <a href="documentos.php" class="nav-item<?php echo nav_active('documentos', $paginaActual); ?>">
                    <span class="icon">📁</span>
                    Documentos
                </a>
            </div>
            
            <!-- Sistema (solo admin) -->
            <?php if (function_exists('es_admin') && es_admin()): ?>
            <div class="nav-section">
                <div class="nav-section-title">Sistema</div>
                
                <a href="tickets.php" class="nav-item<?php echo nav_active('tickets', $paginaActual); ?>">
                    <span class="icon">🎫</span>
                    Tickets
                </a>
                
                <a href="informes.php" class="nav-item<?php echo nav_active('informes', $paginaActual); ?>">
                    <span class="icon">📈</span>
                    Informes
                </a>
                
                <a href="auditoria.php" class="nav-item<?php echo nav_active('auditoria', $paginaActual); ?>">
                    <span class="icon">📋</span>
                    Auditoría
                </a>
                
                <a href="configuracion_email.php" class="nav-item<?php echo nav_active('configuracion_email', $paginaActual); ?>">
                    <span class="icon">📧</span>
                    Email
                </a>
                
                <a href="configuracion.php" class="nav-item<?php echo nav_active('configuracion', $paginaActual); ?>">
                    <span class="icon">⚙️</span>
                    Configuración
                </a>
                
                <a href="datos_demo.php" class="nav-item<?php echo nav_active('datos_demo', $paginaActual); ?>">
                    <span class="icon">🎭</span>
                    Datos Demo
                </a>
                
                <a href="inspeccion_trabajo.php" class="nav-item<?php echo nav_active('inspeccion', $paginaActual); ?>">
                    <span class="icon">🔐</span>
                    Inspección Trabajo
                </a>
                <a href="rgpd.php" class="nav-item<?php echo nav_active('rgpd', $paginaActual); ?>">
                 <span class="icon">⚖️</span>
                Solicitudes RGPD
                </a>
                <a href="mantenimiento.php" class="nav-item<?php echo nav_active('mantenimiento', $paginaActual); ?>">
                    <span class="icon">🔧</span>
                    Mantenimiento
                </a>
            </div>
            <?php endif; ?>
            
            <!-- Info versión -->
            <div class="nav-section" style="margin-top: auto; padding-top: 1rem; border-top: 1px solid #e2e8f0;">
                <div style="padding: 0 1rem; font-size: 0.7rem; color: #94a3b8;">
                    <?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?><br>
                    © <?php echo date('Y'); ?>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="main">
