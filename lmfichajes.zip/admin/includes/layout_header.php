<?php
/**
 * LM FICHAJES - Layout Header
 * 
 * Cabecera HTML compartida para todo el panel de administración.
 * Incluye DOCTYPE, meta tags, CSS y header visual.
 * 
 * Variables esperadas:
 * - $titulo (string): Título de la página
 * - $usuario (object): Usuario actual con nombre, apellido1, rol
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

// Asegurar que tenemos las variables necesarias
$titulo = $titulo ?? 'Panel de Administración';
$usuario = $usuario ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta name="author" content="LM Fichajes">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Seguridad -->
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: https:;">
    
    <title><?php echo htmlspecialchars($titulo); ?> - <?php echo APP_NAME; ?></title>
    
    <!-- CSS Principal -->
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/admin.css?v=<?php echo APP_VERSION; ?>">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/responsive-enhancements.css?v=<?php echo APP_VERSION; ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo APP_URL; ?>/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo APP_URL; ?>/assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo APP_URL; ?>/assets/img/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo APP_URL; ?>/apple-touch-icon.png">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-left">
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="Abrir menú" aria-expanded="false">
                ☰
            </button>
            <a href="<?php echo APP_URL; ?>/admin/" class="logo">
                <img src="<?php echo APP_URL; ?>/assets/img/logo-header.png" alt="LMF" style="height:32px;vertical-align:middle;margin-right:8px;border-radius:4px;">
                <?php echo APP_NAME; ?>
            </a>
            <span class="admin-badge">ADMIN</span>
        </div>
        <div class="header-right">
            <?php if ($usuario): ?>
            <div class="user-info">
                <div class="name"><?php echo htmlspecialchars($usuario->nombre . ' ' . $usuario->apellido1); ?></div>
                <div class="role"><?php echo ucfirst($usuario->rol); ?></div>
            </div>
            <?php endif; ?>
            <a href="<?php echo APP_URL; ?>/fichar.php" class="btn-header">
                👤 Mi Portal
            </a>
            <a href="<?php echo APP_URL; ?>/login.php?logout=1" class="btn-header">
                🚪 Salir
            </a>
        </div>
    </header>
    
    <!-- Overlay para menú móvil -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="layout">
