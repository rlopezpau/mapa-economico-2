<?php
/**
 * LM FICHAJES - Funciones de gestión de empleados
 * 
 * @package     LMFichajes
 * @subpackage  Admin/Includes
 * @version     1.0.0
 */

defined('LMFICHAJES') or die('Acceso no permitido');

// Cargar sistema de licencias
require_once dirname(dirname(__DIR__)) . '/includes/licencias.php';

// Cargar funciones de ausencias para inicializar saldos
if (file_exists(dirname(dirname(__DIR__)) . '/includes/ausencias.php')) {
    require_once dirname(dirname(__DIR__)) . '/includes/ausencias.php';
}

/**
 * Generar contraseña aleatoria
 * @param int $len Longitud
 * @return string
 */
function generarPassword($len = 10) {
    return substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'), 0, $len);
}

/**
 * Formatear minutos a horas
 * @param int|null $minutos
 * @return string
 */
function formatoHoras($minutos) {
    if ($minutos === null) return '0:00';
    $signo = $minutos < 0 ? '-' : '';
    $minutos = abs($minutos);
    return $signo . floor($minutos / 60) . ':' . str_pad((int)$minutos % 60, 2, '0', STR_PAD_LEFT);
}

/**
 * Enviar email con credenciales
 * @param PDO $pdo
 * @param object $empleado
 * @param string $password
 * @param bool $esNuevo
 * @return array
 */
function enviarEmailPassword($pdo, $empleado, $password, $esNuevo = false) {
    try {
        $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = ?");
        $stmt->execute(['email_activo']);
        $activo = $stmt->fetchColumn();
        if (!$activo || $activo === '0') {
            return ['ok' => false, 'msg' => 'El envío de email no está activado'];
        }
        
        // Obtener configuración SMTP
        $config = [];
        $claves = ['smtp_host', 'smtp_puerto', 'smtp_usuario', 'smtp_password', 'smtp_cifrado', 'smtp_from_email', 'smtp_from_nombre'];
        foreach ($claves as $clave) {
            $stmt->execute([$clave]);
            $config[$clave] = $stmt->fetchColumn() ?: '';
        }
        
        if (empty($config['smtp_host']) || empty($empleado->email)) {
            return ['ok' => false, 'msg' => 'Configuración SMTP incompleta o empleado sin email'];
        }
        
        // Preparar email
        $asunto = $esNuevo ? 'Bienvenido a LM Fichajes - Tus credenciales de acceso' : 'LM Fichajes - Nueva contraseña';
        $nombreCompleto = $empleado->nombre . ' ' . $empleado->apellido1;
        
        $cuerpo = generarCuerpoEmail($nombreCompleto, $empleado->nif, $password, $esNuevo);
        
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$config['smtp_from_nombre']} <{$config['smtp_from_email']}>\r\n";
        
        if (mail($empleado->email, $asunto, $cuerpo, $headers)) {
            return ['ok' => true, 'msg' => 'Email enviado correctamente'];
        } else {
            return ['ok' => false, 'msg' => 'Error al enviar email'];
        }
    } catch (Exception $e) {
        return ['ok' => false, 'msg' => 'Error: ' . $e->getMessage()];
    }
}

/**
 * Generar cuerpo HTML del email
 */
function generarCuerpoEmail($nombre, $nif, $password, $esNuevo) {
    $mensaje = $esNuevo ? 
        "<p>Se ha creado tu cuenta en el sistema de fichajes. A continuación encontrarás tus credenciales de acceso:</p>" :
        "<p>Se ha restablecido tu contraseña. A continuación encontrarás tus nuevas credenciales:</p>";
    
    return "
    <html>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='background: #1a365d; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;'>
                <h1 style='margin: 0;'>🕐 LM Fichajes</h1>
            </div>
            <div style='background: #f8fafc; padding: 30px; border: 1px solid #e2e8f0; border-radius: 0 0 8px 8px;'>
                <p>Hola <strong>$nombre</strong>,</p>
                $mensaje
                <div style='background: white; padding: 20px; border-radius: 8px; border: 2px solid #e2e8f0; margin: 20px 0;'>
                    <p style='margin: 0 0 10px;'><strong>Usuario:</strong> $nif</p>
                    <p style='margin: 0;'><strong>Contraseña:</strong> <code style='background: #fef3c7; padding: 2px 8px; border-radius: 4px;'>$password</code></p>
                </div>
                <p style='color: #dc2626;'><strong>⚠️ Importante:</strong> Deberás cambiar esta contraseña en tu primer acceso.</p>
                <p style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b;'>
                    Este es un mensaje automático. Por favor, no respondas a este correo.
                </p>
            </div>
        </div>
    </body>
    </html>";
}

/**
 * Obtener empleado completo con todos sus datos relacionados
 * @param PDO $pdo
 * @param int $id
 * @return object|null
 */
function obtenerEmpleadoCompleto($pdo, $id) {
    $sql = "SELECT e.*, h.nombre as horario_nombre, tg.nombre as turno_nombre,
                   c.nombre as convenio_nombre, c.codigo as convenio_codigo,
                   CONCAT(s1.nombre, ' ', s1.apellido1) as supervisor_nombre,
                   CONCAT(s2.nombre, ' ', s2.apellido1) as supervisor2_nombre
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            LEFT JOIN turnos_grupo tg ON e.turno_grupo_id = tg.id
            LEFT JOIN convenios c ON e.convenio_id = c.id
            LEFT JOIN empleados s1 ON e.supervisor_id = s1.id
            LEFT JOIN empleados s2 ON e.supervisor2_id = s2.id
            WHERE e.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $emp = $stmt->fetch();
    
    if ($emp) {
        // Centros
        $stmt = $pdo->prepare("SELECT ec.centro_id, ec.es_principal, c.nombre FROM empleados_centros ec JOIN centros c ON ec.centro_id = c.id WHERE ec.empleado_id = ? AND ec.activo = 1");
        $stmt->execute([$id]);
        $emp->centros = $stmt->fetchAll();
        
        // Horas semanales
        $emp->horas_semanales = calcularHorasSemanalesEmpleado($pdo, $emp->horario_id);
        $emp->horas_anuales = round($emp->horas_semanales * 46.5, 0);
        
        // Bolsa de horas
        $emp->bolsa = obtenerBolsaHorasEmpleado($pdo, $id);
    }
    return $emp;
}

/**
 * Calcular horas semanales de un empleado
 */
function calcularHorasSemanalesEmpleado($pdo, $horarioId) {
    $horas = 37.5;
    if ($horarioId) {
        try {
            $stmt = $pdo->prepare("SELECT SUM(horas_esperadas) as t FROM horarios_dias WHERE horario_id = ?");
            $stmt->execute([$horarioId]);
            $r = $stmt->fetch();
            if ($r && $r->t) $horas = $r->t;
        } catch (PDOException $e) {}
    }
    return $horas;
}

/**
 * Obtener bolsa de horas de un empleado
 */
function obtenerBolsaHorasEmpleado($pdo, $empleadoId) {
    $bolsa = ['hoy' => 0, 'semana' => 0, 'mes' => 0, 'acumulado' => 0];
    try {
        $hoy = date('Y-m-d');
        $stmt = $pdo->prepare("SELECT minutos_balance FROM resumen_diario WHERE empleado_id = ? AND fecha = ?");
        $stmt->execute([$empleadoId, $hoy]);
        $r = $stmt->fetch();
        if ($r) $bolsa['hoy'] = $r->minutos_balance;
        
        $inicioSemana = date('Y-m-d', strtotime('monday this week'));
        $stmt = $pdo->prepare("SELECT SUM(minutos_balance) as t FROM resumen_diario WHERE empleado_id = ? AND fecha >= ?");
        $stmt->execute([$empleadoId, $inicioSemana]);
        $r = $stmt->fetch();
        if ($r) $bolsa['semana'] = $r->t ?? 0;
        
        $stmt = $pdo->prepare("SELECT minutos_balance, saldo_acumulado FROM banco_horas WHERE empleado_id = ? AND periodo = ?");
        $stmt->execute([$empleadoId, date('Y-m')]);
        $r = $stmt->fetch();
        if ($r) {
            $bolsa['mes'] = $r->minutos_balance;
            $bolsa['acumulado'] = $r->saldo_acumulado;
        }
    } catch (PDOException $e) {}
    return $bolsa;
}

/**
 * Guardar empleado (crear o actualizar)
 * @param PDO $pdo
 * @param array $datos
 * @param int|null $id
 * @return array
 */
function guardarEmpleado($pdo, $datos, $id = null) {
    $res = ['ok' => false, 'msg' => '', 'id' => null, 'pass' => null];
    
    // Validar NIF único
    $sql = "SELECT id FROM empleados WHERE nif = ?" . ($id ? " AND id != ?" : "");
    $stmt = $pdo->prepare($sql);
    $stmt->execute($id ? [$datos['nif'], $id] : [$datos['nif']]);
    if ($stmt->fetch()) {
        $res['msg'] = 'Ya existe un empleado con ese NIF';
        return $res;
    }
    
    // Validar límite de licencia (solo para nuevos empleados)
    if (!$id) {
        $checkLicencia = puede_crear_empleado($pdo);
        if (!$checkLicencia['permitido']) {
            $res['msg'] = $checkLicencia['mensaje'];
            return $res;
        }
    }
    
    try {
        if ($id) {
            // Actualizar
            $sql = "UPDATE empleados SET 
                nif=?, nombre=?, apellido1=?, apellido2=?, email=?, telefono=?, telefono_trabajo=?,
                direccion=?, coordenadas_domicilio=?, radio_domicilio=?,
                rol=?, convenio_id=?, horario_id=?, porcentaje_jornada=?, turno_grupo_id=?, supervisor_id=?, supervisor2_id=?,
                requiere_doble_validacion=?, dias_vacaciones=?, dias_vacaciones_antiguedad=?,
                dias_libre_disposicion=?, dias_libre_disp_antiguedad=?,
                fecha_alta=?, fecha_antiguedad=?, activo=?, updated_at=NOW()
                WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nif'], $datos['nombre'], $datos['apellido1'], $datos['apellido2'] ?? '',
                $datos['email'] ?: null, $datos['telefono'] ?: null, $datos['telefono_trabajo'] ?: null,
                $datos['direccion'] ?: null,
                $datos['coordenadas_domicilio'] ?: null, $datos['radio_domicilio'] ?? 50,
                $datos['rol'], $datos['convenio_id'] ?: null, $datos['horario_id'] ?: null, 
                $datos['porcentaje_jornada'] ?? 100, $datos['turno_grupo_id'] ?: null,
                $datos['supervisor_id'] ?: null, $datos['supervisor2_id'] ?: null,
                $datos['requiere_doble_validacion'] ?? 0,
                $datos['dias_vacaciones'] ?? 22, $datos['dias_vacaciones_antiguedad'] ?? 0,
                $datos['dias_libre_disposicion'] ?? 6, $datos['dias_libre_disp_antiguedad'] ?? 0,
                $datos['fecha_alta'] ?: null, $datos['fecha_antiguedad'] ?: null,
                $datos['activo'] ?? 1, $id
            ]);
            $res['id'] = $id;
            $res['msg'] = 'Empleado actualizado';
        } else {
            // Crear nuevo
            $pass = generarPassword();
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $sql = "INSERT INTO empleados (nif, nombre, apellido1, apellido2, email, telefono, telefono_trabajo,
                direccion, coordenadas_domicilio, radio_domicilio, rol, convenio_id, horario_id, porcentaje_jornada, turno_grupo_id,
                supervisor_id, supervisor2_id, requiere_doble_validacion,
                dias_vacaciones, dias_vacaciones_antiguedad, dias_libre_disposicion, dias_libre_disp_antiguedad,
                fecha_alta, fecha_antiguedad, password, activo, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nif'], $datos['nombre'], $datos['apellido1'], $datos['apellido2'] ?? '',
                $datos['email'] ?: null, $datos['telefono'] ?: null, $datos['telefono_trabajo'] ?: null,
                $datos['direccion'] ?: null,
                $datos['coordenadas_domicilio'] ?: null, $datos['radio_domicilio'] ?? 50,
                $datos['rol'], $datos['convenio_id'] ?: null, $datos['horario_id'] ?: null, 
                $datos['porcentaje_jornada'] ?? 100, $datos['turno_grupo_id'] ?: null,
                $datos['supervisor_id'] ?: null, $datos['supervisor2_id'] ?: null,
                $datos['requiere_doble_validacion'] ?? 0,
                $datos['dias_vacaciones'] ?? 22, $datos['dias_vacaciones_antiguedad'] ?? 0,
                $datos['dias_libre_disposicion'] ?? 6, $datos['dias_libre_disp_antiguedad'] ?? 0,
                $datos['fecha_alta'] ?: date('Y-m-d'), $datos['fecha_antiguedad'] ?: null, $hash
            ]);
            $res['id'] = $pdo->lastInsertId();
            $res['pass'] = $pass;
            $res['msg'] = "Empleado creado. Contraseña: <strong>$pass</strong>";
            
            // INICIALIZAR SALDOS para el nuevo empleado
            if (function_exists('inicializar_saldos_empleado')) {
                inicializar_saldos_empleado($pdo, $res['id'], date('Y'));
            }
        }
        
        // Si se actualizó, RECALCULAR SALDOS (por si cambió convenio o días)
        if ($id && function_exists('recalcular_saldos_empleado')) {
            recalcular_saldos_empleado($pdo, $id, date('Y'));
        }
        
        $res['ok'] = true;
    } catch (PDOException $e) {
        $res['msg'] = 'Error: ' . $e->getMessage();
    }
    return $res;
}

/**
 * Guardar asignación de centros a empleado
 * @param PDO $pdo
 * @param int $empId
 * @param array $centros
 * @param int $principal
 */
function guardarCentros($pdo, $empId, $centros, $principal) {
    $pdo->prepare("UPDATE empleados_centros SET activo=0 WHERE empleado_id=?")->execute([$empId]);
    if (empty($centros)) return;
    
    foreach ($centros as $cid) {
        $cid = (int)$cid;
        if ($cid <= 0) continue;
        
        $esPrinc = ($cid == $principal) ? 1 : 0;
        $stmt = $pdo->prepare("SELECT id FROM empleados_centros WHERE empleado_id=? AND centro_id=?");
        $stmt->execute([$empId, $cid]);
        
        if ($stmt->fetch()) {
            $pdo->prepare("UPDATE empleados_centros SET activo=1, es_principal=? WHERE empleado_id=? AND centro_id=?")->execute([$esPrinc, $empId, $cid]);
        } else {
            $pdo->prepare("INSERT INTO empleados_centros (empleado_id, centro_id, es_principal, activo, fecha_asignacion) VALUES (?,?,?,1,CURDATE())")->execute([$empId, $cid, $esPrinc]);
        }
    }
}

/**
 * Obtener listado de empleados para admin
 * @param PDO $pdo
 * @param array $filtros
 * @return array
 */
function obtenerListadoEmpleados($pdo, $filtros = []) {
    $where = ["1=1"];
    $params = [];
    
    if (!empty($filtros['buscar'])) {
        $where[] = "(e.nombre LIKE ? OR e.apellido1 LIKE ? OR e.nif LIKE ?)";
        $buscar = '%' . $filtros['buscar'] . '%';
        $params = array_merge($params, [$buscar, $buscar, $buscar]);
    }
    
    if (isset($filtros['activo']) && $filtros['activo'] !== '') {
        $where[] = "e.activo = ?";
        $params[] = $filtros['activo'];
    }
    
    if (!empty($filtros['rol'])) {
        $where[] = "e.rol = ?";
        $params[] = $filtros['rol'];
    }
    
    if (!empty($filtros['centro_id'])) {
        $where[] = "EXISTS (SELECT 1 FROM empleados_centros ec WHERE ec.empleado_id = e.id AND ec.centro_id = ? AND ec.activo = 1)";
        $params[] = $filtros['centro_id'];
    }
    
    $sql = "SELECT e.*, h.nombre as horario_nombre,
                   (SELECT GROUP_CONCAT(c.nombre SEPARATOR ', ') FROM empleados_centros ec JOIN centros c ON ec.centro_id = c.id WHERE ec.empleado_id = e.id AND ec.activo = 1) as centros_nombres
            FROM empleados e
            LEFT JOIN horarios h ON e.horario_id = h.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY e.apellido1, e.nombre";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}
