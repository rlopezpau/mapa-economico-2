<?php
/**
 * LM FICHAJES - Panel de Administración: Repositorio de Documentos
 * 
 * Gestión de documentos: nóminas, circulares, contratos, etc.
 * - Subir a un empleado, a un centro, o a todos
 * - Subida masiva de nóminas (detecta NIF en nombre archivo)
 * - Control de confirmación de lectura
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */
define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';
// Notificaciones
if (file_exists(INCLUDES_PATH . '/notificaciones.php')) {
    require_once INCLUDES_PATH . '/notificaciones.php';
}
// ============================================================================
// SEGURIDAD
// ============================================================================
requerir_login('../login.php');
if (!es_manager()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para gestionar documentos';
    header('Location: index.php');
    exit;
}
$usuario = obtener_usuario_actual($pdo);
$accion = $_GET['accion'] ?? 'listar';
$mensaje = '';
$error = '';
// ============================================================================
// CONSTANTES
// ============================================================================
define('DOCS_PATH', ROOT_PATH . '/uploads/documentos');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_TYPES', ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
$tiposDocumento = [
    'nomina' => '💰 Nómina',
    'contrato' => '📝 Contrato',
    'certificado' => '🏅 Certificado',
    'circular' => '📢 Circular',
    'formacion' => '🎓 Formación',
    'otro' => '📄 Otro'
];
$carpetasTipo = [
    'nomina' => 'nominas',
    'contrato' => 'contratos',
    'certificado' => 'certificados',
    'circular' => 'circulares',
    'formacion' => 'formacion',
    'otro' => 'otros'
];
// ============================================================================
// FUNCIONES
// ============================================================================
function subirDocumento($archivo, $tipo, $datos) {
    global $pdo, $usuario, $carpetasTipo;
    
    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'msg' => 'Error al subir archivo: ' . $archivo['error']];
    }
    
    if ($archivo['size'] > MAX_FILE_SIZE) {
        return ['ok' => false, 'msg' => 'Archivo demasiado grande (máx 10MB)'];
    }
    
    $mime = mime_content_type($archivo['tmp_name']);
    if (!in_array($mime, ALLOWED_TYPES)) {
        return ['ok' => false, 'msg' => 'Tipo de archivo no permitido'];
    }
    
    // Generar nombre único
    $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
    $nombreUnico = date('Ymd_His') . '_' . uniqid() . '.' . $extension;
    $carpeta = $carpetasTipo[$tipo] ?? 'otros';
    $rutaRelativa = $carpeta . '/' . $nombreUnico;
    $rutaCompleta = DOCS_PATH . '/' . $rutaRelativa;
    
    // Crear carpeta si no existe
    $dirCarpeta = dirname($rutaCompleta);
    if (!is_dir($dirCarpeta)) {
        mkdir($dirCarpeta, 0750, true);
    }
    
    if (!move_uploaded_file($archivo['tmp_name'], $rutaCompleta)) {
        return ['ok' => false, 'msg' => 'Error al guardar archivo'];
    }
    
    // Insertar en BD
    try {
        $sql = "INSERT INTO documentos_empleado 
                (empleado_id, centro_id, nombre, nombre_archivo, tipo_documento, descripcion,
                 ruta_archivo, tamano_bytes, mime_type, mes, anio, visible_empleado, 
                 requiere_confirmacion, subido_por, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $datos['empleado_id'] ?: null,
            $datos['centro_id'] ?: null,
            $datos['nombre'],
            $archivo['name'],
            $tipo,
            $datos['descripcion'] ?? null,
            $rutaRelativa,
            $archivo['size'],
            $mime,
            $datos['mes'] ?: null,
            $datos['anio'] ?: null,
            $datos['visible'] ?? 1,
            $datos['requiere_confirmacion'] ?? 0,
            $usuario->id
        ]);
        
        $docId = $pdo->lastInsertId();
        
        // NOTIFICACIÓN AL EMPLEADO (solo si el documento es para un empleado específico)
        if (!empty($datos['empleado_id']) && function_exists('notificar_documento_nuevo')) {
            notificar_documento_nuevo($pdo, $datos['empleado_id'], $datos['nombre']);
        }
        
        return ['ok' => true, 'id' => $docId, 'msg' => 'Documento subido correctamente'];
    } catch (PDOException $e) {
        @unlink($rutaCompleta);
        return ['ok' => false, 'msg' => 'Error BD: ' . $e->getMessage()];
    }
}
function subirNominasMasivo($archivos) {
    global $pdo, $usuario;
    
    $resultados = ['ok' => 0, 'error' => 0, 'detalles' => []];
    
    // Obtener todos los NIFs de empleados
    $stmt = $pdo->query("SELECT id, nif, nombre, apellido1 FROM empleados WHERE activo = 1");
    $empleados = [];
    while ($row = $stmt->fetch()) {
        $nifLimpio = strtoupper(preg_replace('/[^A-Z0-9]/', '', $row->nif));
        $empleados[$nifLimpio] = $row;
    }
    
    $mesActual = (int)date('m');
    $anioActual = (int)date('Y');
    
    for ($i = 0; $i < count($archivos['name']); $i++) {
        if ($archivos['error'][$i] !== UPLOAD_ERR_OK) continue;
        
        $nombreArchivo = $archivos['name'][$i];
        $nombreLimpio = strtoupper(preg_replace('/[^A-Z0-9]/', '', pathinfo($nombreArchivo, PATHINFO_FILENAME)));
        
        // Buscar NIF en el nombre del archivo
        $empleadoEncontrado = null;
        foreach ($empleados as $nif => $emp) {
            if (strpos($nombreLimpio, $nif) !== false) {
                $empleadoEncontrado = $emp;
                break;
            }
        }
        
        if (!$empleadoEncontrado) {
            $resultados['error']++;
            $resultados['detalles'][] = "❌ {$nombreArchivo}: No se encontró NIF en el nombre";
            continue;
        }
        
        // Preparar archivo temporal para subir
        $archivoTemp = [
            'name' => $nombreArchivo,
            'tmp_name' => $archivos['tmp_name'][$i],
            'error' => $archivos['error'][$i],
            'size' => $archivos['size'][$i]
        ];
        
        $datos = [
            'empleado_id' => $empleadoEncontrado->id,
            'centro_id' => null,
            'nombre' => "Nómina " . str_pad($mesActual, 2, '0', STR_PAD_LEFT) . "/" . $anioActual,
            'descripcion' => null,
            'mes' => $mesActual,
            'anio' => $anioActual,
            'visible' => 1,
            'requiere_confirmacion' => 0
        ];
        
        $res = subirDocumento($archivoTemp, 'nomina', $datos);
        
        if ($res['ok']) {
            $resultados['ok']++;
            $resultados['detalles'][] = "✅ {$nombreArchivo} → {$empleadoEncontrado->nombre} {$empleadoEncontrado->apellido1}";
        } else {
            $resultados['error']++;
            $resultados['detalles'][] = "❌ {$nombreArchivo}: {$res['msg']}";
        }
    }
    
    return $resultados;
}
function eliminarDocumento($pdo, $id) {
    $stmt = $pdo->prepare("SELECT ruta_archivo FROM documentos_empleado WHERE id = ?");
    $stmt->execute([$id]);
    $doc = $stmt->fetch();
    
    if ($doc) {
        $rutaCompleta = DOCS_PATH . '/' . $doc->ruta_archivo;
        if (file_exists($rutaCompleta)) {
            @unlink($rutaCompleta);
        }
        $pdo->prepare("DELETE FROM documentos_empleado WHERE id = ?")->execute([$id]);
        return true;
    }
    return false;
}
// ============================================================================
// PROCESAR POST
// ============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $act = $_POST['accion'] ?? '';
    
    // Subir documento individual
    if ($act === 'subir' && isset($_FILES['archivo'])) {
        $destinoTipo = $_POST['destino_tipo'] ?? 'empleado';
        $datos = [
            'empleado_id' => ($destinoTipo === 'empleado') ? (int)($_POST['empleado_id'] ?? 0) : null,
            'centro_id' => ($destinoTipo === 'centro') ? (int)($_POST['centro_id'] ?? 0) : null,
            'nombre' => trim($_POST['nombre'] ?? ''),
            'descripcion' => trim($_POST['descripcion'] ?? ''),
            'mes' => (int)($_POST['mes'] ?? 0) ?: null,
            'anio' => (int)($_POST['anio'] ?? 0) ?: null,
            'visible' => isset($_POST['visible']) ? 1 : 0,
            'requiere_confirmacion' => isset($_POST['requiere_confirmacion']) ? 1 : 0
        ];
        
        if (empty($datos['nombre'])) {
            $error = 'El nombre del documento es obligatorio';
        } else {
            $res = subirDocumento($_FILES['archivo'], $_POST['tipo_documento'] ?? 'otro', $datos);
            if ($res['ok']) {
                $mensaje = $res['msg'];
                if (function_exists('audit_crear')) {
                    audit_crear('documentos_empleado', $res['id'], "Documento subido: {$datos['nombre']}", $datos);
                }
                $accion = 'listar';
            } else {
                $error = $res['msg'];
            }
        }
    }
    
    // Subida masiva de nóminas
    if ($act === 'nominas_masivo' && isset($_FILES['nominas'])) {
        $res = subirNominasMasivo($_FILES['nominas']);
        if ($res['ok'] > 0) {
            $mensaje = "Nóminas procesadas: {$res['ok']} OK, {$res['error']} errores";
        } else {
            $error = "No se pudo procesar ninguna nómina";
        }
        $_SESSION['nominas_resultado'] = $res['detalles'];
        $accion = 'listar';
    }
    
    // Eliminar documento
    if ($act === 'eliminar') {
        $idDoc = (int)($_POST['documento_id'] ?? 0);
        if ($idDoc > 0 && eliminarDocumento($pdo, $idDoc)) {
            $mensaje = 'Documento eliminado';
            if (function_exists('audit_eliminar')) {
                audit_eliminar('documentos_empleado', $idDoc, "Documento eliminado", []);
            }
        } else {
            $error = 'No se pudo eliminar el documento';
        }
    }
}
// ============================================================================
// OBTENER DATOS
// ============================================================================
$empleados = $pdo->query("SELECT id, nif, nombre, apellido1 FROM empleados WHERE activo=1 ORDER BY apellido1, nombre")->fetchAll();
$centros = $pdo->query("SELECT id, nombre FROM centros WHERE activo=1 ORDER BY nombre")->fetchAll();
// Stats para sidebar
$stats = ['fichajes_pendientes' => 0];
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM fichajes WHERE estado='pendiente'");
    $stats['fichajes_pendientes'] = $stmt->fetchColumn();
} catch (PDOException $e) {}
// Listado de documentos
$documentos = [];
if ($accion === 'listar') {
    $filtroTipo = $_GET['tipo'] ?? '';
    $filtroEmpleado = (int)($_GET['empleado_id'] ?? 0);
    $filtroCentro = (int)($_GET['centro_id'] ?? 0);
    
    $where = ["1=1"];
    $params = [];
    
    if ($filtroTipo) {
        $where[] = "d.tipo_documento = ?";
        $params[] = $filtroTipo;
    }
    if ($filtroEmpleado) {
        $where[] = "d.empleado_id = ?";
        $params[] = $filtroEmpleado;
    }
    if ($filtroCentro) {
        $where[] = "d.centro_id = ?";
        $params[] = $filtroCentro;
    }
    
    $sql = "SELECT d.*, 
                   CONCAT(e.nombre, ' ', e.apellido1) as empleado_nombre,
                   c.nombre as centro_nombre,
                   CONCAT(u.nombre, ' ', u.apellido1) as subido_por_nombre
            FROM documentos_empleado d
            LEFT JOIN empleados e ON d.empleado_id = e.id
            LEFT JOIN centros c ON d.centro_id = c.id
            LEFT JOIN empleados u ON d.subido_por = u.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY d.created_at DESC
            LIMIT 100";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $documentos = $stmt->fetchAll();
}
// ============================================================================
// CONFIG PÁGINA
// ============================================================================
$titulo = 'Repositorio de Documentos';
$paginaActual = 'documentos';
// ============================================================================
// RENDERIZAR
// ============================================================================
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>
<?php if ($mensaje): ?>
    <div class="alert alert-success">✅ <?= $mensaje ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['nominas_resultado'])): ?>
    <div class="card" style="margin-bottom: 1rem;">
        <div class="card-header"><span class="card-title">📋 Resultado subida masiva de nóminas</span></div>
        <div class="card-body" style="max-height: 200px; overflow-y: auto; font-size: 0.875rem;">
            <?php foreach ($_SESSION['nominas_resultado'] as $linea): ?>
                <div><?= htmlspecialchars($linea) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php unset($_SESSION['nominas_resultado']); ?>
<?php endif; ?>
<?php if ($accion === 'listar'): ?>
    <!-- LISTADO -->
    <div class="page-header">
        <div>
            <h1 class="page-title">📁 Repositorio de Documentos</h1>
            <p class="page-subtitle"><?= count($documentos) ?> documento(s)</p>
        </div>
        <div class="btn-group">
            <a href="?accion=subir" class="btn btn-primary">📤 Subir Documento</a>
            <a href="?accion=nominas" class="btn btn-success">💰 Subir Nóminas Masivo</a>
        </div>
    </div>
    
    <!-- Filtros -->
    <div class="card" style="margin-bottom: 1rem;">
        <div class="card-body" style="padding: 0.75rem;">
            <form method="GET" style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
                <select name="tipo" class="form-control" style="width: auto;">
                    <option value="">-- Todos los tipos --</option>
                    <?php foreach ($tiposDocumento as $k => $v): ?>
                    <option value="<?= $k ?>" <?= ($filtroTipo ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="empleado_id" class="form-control" style="width: auto;">
                    <option value="">-- Todos los empleados --</option>
                    <?php foreach ($empleados as $e): ?>
                    <option value="<?= $e->id ?>" <?= ($filtroEmpleado ?? 0) == $e->id ? 'selected' : '' ?>><?= htmlspecialchars($e->apellido1 . ', ' . $e->nombre) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-outline">🔍 Filtrar</button>
                <a href="?" class="btn btn-outline">✖ Limpiar</a>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Nombre</th>
                        <th>Destinatario</th>
                        <th>Periodo</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($documentos)): ?>
                        <tr><td colspan="6" style="text-align: center; padding: 2rem; color: #64748b;">No hay documentos</td></tr>
                    <?php else: ?>
                        <?php foreach ($documentos as $d): ?>
                            <tr>
                                <td><span class="badge badge-info"><?= $tiposDocumento[$d->tipo_documento] ?? $d->tipo_documento ?></span></td>
                                <td>
                                    <strong><?= htmlspecialchars($d->nombre) ?></strong>
                                    <br><small style="color: #64748b;"><?= htmlspecialchars($d->nombre_archivo) ?></small>
                                </td>
                                <td>
                                    <?php if ($d->empleado_id): ?>
                                        👤 <?= htmlspecialchars($d->empleado_nombre) ?>
                                    <?php elseif ($d->centro_id): ?>
                                        🏛️ <?= htmlspecialchars($d->centro_nombre) ?>
                                    <?php else: ?>
                                        <span class="badge badge-warning">📢 TODOS</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($d->mes && $d->anio): ?>
                                        <?= str_pad($d->mes, 2, '0', STR_PAD_LEFT) ?>/<?= $d->anio ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d/m/Y H:i', strtotime($d->created_at)) ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="descargar_documento.php?id=<?= $d->id ?>" class="btn btn-sm btn-outline" title="Descargar">⬇️</a>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('¿Eliminar este documento?')">
                                            <?= csrf_campo() ?>
                                            <input type="hidden" name="accion" value="eliminar">
                                            <input type="hidden" name="documento_id" value="<?= $d->id ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="Eliminar">🗑️</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php elseif ($accion === 'subir'): ?>
    <!-- SUBIR DOCUMENTO -->
    <div class="page-header">
        <div>
            <h1 class="page-title">📤 Subir Documento</h1>
        </div>
        <a href="?" class="btn btn-outline">← Volver</a>
    </div>
    
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="subir">
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
            <div>
                <div class="card">
                    <div class="card-header"><span class="card-title">📄 Información del Documento</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Archivo <span class="required">*</span></label>
                            <input type="file" name="archivo" required class="form-control" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png">
                            <div class="form-hint">PDF, Word, Excel o imágenes. Máximo 10MB.</div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Nombre del documento <span class="required">*</span></label>
                                <input type="text" name="nombre" required class="form-control" placeholder="Ej: Nómina Enero 2025">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Tipo</label>
                                <select name="tipo_documento" class="form-control">
                                    <?php foreach ($tiposDocumento as $k => $v): ?>
                                    <option value="<?= $k ?>"><?= $v ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" class="form-control" rows="2" placeholder="Opcional"></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Mes</label>
                                <select name="mes" class="form-control">
                                    <option value="">-- Sin mes --</option>
                                    <?php for ($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?= $m ?>" <?= $m == date('m') ? 'selected' : '' ?>><?= str_pad($m, 2, '0', STR_PAD_LEFT) ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Año</label>
                                <input type="number" name="anio" value="<?= date('Y') ?>" class="form-control" min="2020" max="2050">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="card">
                    <div class="card-header"><span class="card-title">👥 Destinatario</span></div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-check" style="margin-bottom: 0.5rem;">
                                <input type="radio" name="destino_tipo" value="empleado" checked onchange="mostrarDestino(this.value)">
                                Un empleado
                            </label>
                            <label class="form-check" style="margin-bottom: 0.5rem;">
                                <input type="radio" name="destino_tipo" value="centro" onchange="mostrarDestino(this.value)">
                                Todos los de un centro
                            </label>
                            <label class="form-check">
                                <input type="radio" name="destino_tipo" value="todos" onchange="mostrarDestino(this.value)">
                                Todos los empleados
                            </label>
                        </div>
                        
                        <div id="destino_empleado" class="form-group" style="margin-top: 1rem;">
                            <label class="form-label">Empleado</label>
                            <select name="empleado_id" class="form-control">
                                <option value="">-- Seleccionar --</option>
                                <?php foreach ($empleados as $e): ?>
                                <option value="<?= $e->id ?>"><?= htmlspecialchars($e->apellido1 . ', ' . $e->nombre) ?> (<?= $e->nif ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div id="destino_centro" class="form-group" style="margin-top: 1rem; display: none;">
                            <label class="form-label">Centro</label>
                            <select name="centro_id" class="form-control">
                                <option value="">-- Seleccionar --</option>
                                <?php foreach ($centros as $c): ?>
                                <option value="<?= $c->id ?>"><?= htmlspecialchars($c->nombre) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div id="destino_todos" style="margin-top: 1rem; display: none; padding: 1rem; background: #fef3c7; border-radius: 0.5rem;">
                            <strong>⚠️ Atención:</strong> Este documento será visible para TODOS los empleados.
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">⚙️ Opciones</span></div>
                    <div class="card-body">
                        <label class="form-check">
                            <input type="checkbox" name="visible" checked>
                            Visible para el empleado
                        </label>
                        <label class="form-check" style="margin-top: 0.5rem;">
                            <input type="checkbox" name="requiere_confirmacion">
                            Requiere confirmación de lectura
                        </label>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="form-actions">
            <a href="?" class="btn btn-outline">Cancelar</a>
            <button type="submit" class="btn btn-success">📤 Subir Documento</button>
        </div>
    </form>
    
    <script>
    function mostrarDestino(tipo) {
        document.getElementById('destino_empleado').style.display = tipo === 'empleado' ? 'block' : 'none';
        document.getElementById('destino_centro').style.display = tipo === 'centro' ? 'block' : 'none';
        document.getElementById('destino_todos').style.display = tipo === 'todos' ? 'block' : 'none';
    }
    </script>
<?php elseif ($accion === 'nominas'): ?>
    <!-- SUBIDA MASIVA DE NÓMINAS -->
    <div class="page-header">
        <div>
            <h1 class="page-title">💰 Subida Masiva de Nóminas</h1>
        </div>
        <a href="?" class="btn btn-outline">← Volver</a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 0.5rem; padding: 1.5rem; margin-bottom: 1.5rem;">
                <h3 style="margin: 0 0 1rem 0; color: #1e40af;">📋 ¿Cómo funciona?</h3>
                <ol style="margin: 0; padding-left: 1.5rem; color: #1e40af;">
                    <li>Los archivos deben contener el <strong>NIF del empleado</strong> en el nombre</li>
                    <li>Ejemplo: <code>nomina_12345678A_enero.pdf</code> o <code>12345678A.pdf</code></li>
                    <li>El sistema detectará automáticamente a qué empleado pertenece cada nómina</li>
                    <li>Se asignará el mes y año actuales</li>
                </ol>
            </div>
            
            <form method="POST" enctype="multipart/form-data">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="nominas_masivo">
                
                <div class="form-group">
                    <label class="form-label">Seleccionar archivos de nóminas</label>
                    <input type="file" name="nominas[]" multiple required class="form-control" accept=".pdf">
                    <div class="form-hint">Selecciona todos los PDFs de nóminas. El nombre debe contener el NIF.</div>
                </div>
                
                <div id="archivos_seleccionados" style="margin: 1rem 0; display: none;">
                    <strong>Archivos seleccionados:</strong>
                    <ul id="lista_archivos" style="margin: 0.5rem 0; padding-left: 1.5rem;"></ul>
                </div>
                
                <div class="form-actions" style="border-top: none; padding-top: 0;">
                    <a href="?" class="btn btn-outline">Cancelar</a>
                    <button type="submit" class="btn btn-success">💰 Procesar Nóminas</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Lista de NIFs para referencia -->
    <div class="card" style="margin-top: 1rem;">
        <div class="card-header"><span class="card-title">👥 NIFs de empleados activos</span></div>
        <div class="card-body" style="max-height: 300px; overflow-y: auto;">
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 0.5rem; font-size: 0.875rem;">
                <?php foreach ($empleados as $e): ?>
                <div style="padding: 0.375rem; background: #f8fafc; border-radius: 0.25rem;">
                    <strong><?= htmlspecialchars($e->nif) ?></strong> - <?= htmlspecialchars($e->apellido1 . ', ' . $e->nombre) ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <script>
    document.querySelector('input[name="nominas[]"]').addEventListener('change', function(e) {
        var lista = document.getElementById('lista_archivos');
        var contenedor = document.getElementById('archivos_seleccionados');
        lista.innerHTML = '';
        
        if (this.files.length > 0) {
            contenedor.style.display = 'block';
            for (var i = 0; i < this.files.length; i++) {
                var li = document.createElement('li');
                li.textContent = this.files[i].name;
                lista.appendChild(li);
            }
        } else {
            contenedor.style.display = 'none';
        }
    });
    </script>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
