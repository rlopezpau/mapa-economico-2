<?php
/**
 * LM FICHAJES - Panel de Administración - Validación de Fichajes
 * 
 * Pantalla para validar fichajes pendientes con incidencias.
 * VERSIÓN REFACTORIZADA - Usa layout compartido
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.1.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/fichajes.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Headers de seguridad
establecer_headers_seguridad();

// Requerir login y rol mínimo de supervisor
requerir_login();
if (!es_supervisor()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: ../portal.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$mensajeError = '';

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf()) {
        $mensajeError = 'Error de seguridad. Recarga la página.';
    } else {
        $accion = $_POST['accion'] ?? '';
        
        // Validación individual
        if ($accion === 'validar' || $accion === 'aprobar' || $accion === 'rechazar') {
            $fichajeId = sanitizar_int($_POST['fichaje_id'] ?? 0);
            $observacion = sanitizar($_POST['observacion'] ?? '');
            $horaCorregida = !empty($_POST['hora_corregida']) ? $_POST['hora_corregida'] : null;
            
            $resultado = validar_fichaje(
                $pdo, 
                $fichajeId, 
                $usuario->id,
                ($accion === 'validar' || $accion === 'aprobar') ? 'aprobar' : 'rechazar',
                $horaCorregida,
                $observacion
            );
            
            if ($resultado['exito']) {
                $_SESSION['mensaje_fichajes'] = $resultado['mensaje'];
                
                // AUDITORÍA ENS
                if (function_exists('registrar_auditoria')) {
                    $tipoAudit = ($accion === 'rechazar') ? 'WARNING' : 'INFO';
                    registrar_auditoria('VALIDACION', "Fichaje {$accion}: ID {$fichajeId}", 
                        ['fichaje_id' => $fichajeId, 'accion' => $accion, 'observacion' => $observacion], 
                        $tipoAudit, $usuario->id, 'fichajes', $fichajeId);
                }
                
                header('Location: fichajes.php');
                exit;
            } else {
                $mensajeError = $resultado['mensaje'];
            }
        }
        
        // Validación masiva
        if ($accion === 'validar_masivo' || $accion === 'rechazar_masivo') {
            $fichajeIds = $_POST['fichajes'] ?? [];
            
            if (!empty($fichajeIds)) {
                $resultado = validar_fichajes_masivo(
                    $pdo,
                    $fichajeIds,
                    $usuario->id,
                    ($accion === 'validar_masivo') ? 'aprobar' : 'rechazar'
                );
                
                if ($resultado['exito']) {
                    $_SESSION['mensaje_fichajes'] = $resultado['mensaje'];
                    header('Location: fichajes.php');
                    exit;
                } else {
                    $mensajeError = $resultado['mensaje'];
                }
            } else {
                $mensajeError = 'No se seleccionaron fichajes';
            }
        }
    }
    
    regenerar_csrf();
}

// Recuperar mensaje de sesión si existe
if (isset($_SESSION['mensaje_fichajes'])) {
    $mensaje = $_SESSION['mensaje_fichajes'];
    unset($_SESSION['mensaje_fichajes']);
}

// Procesar validación rápida por GET (desde dashboard)
if (isset($_GET['validar']) || isset($_GET['rechazar'])) {
    $fichajeId = sanitizar_int($_GET['validar'] ?? $_GET['rechazar'] ?? 0);
    $accion = isset($_GET['validar']) ? 'aprobar' : 'rechazar';
    
    if ($fichajeId > 0) {
        $resultado = validar_fichaje($pdo, $fichajeId, $usuario->id, $accion);
        if ($resultado['exito']) {
            $mensaje = $resultado['mensaje'];
        } else {
            $mensajeError = $resultado['mensaje'];
        }
    }
}

// Filtros
$filtros = [
    'fecha_desde' => $_GET['fecha_desde'] ?? '',
    'fecha_hasta' => $_GET['fecha_hasta'] ?? '',
    'empleado_id' => sanitizar_int($_GET['empleado_id'] ?? 0),
    'centro_id' => sanitizar_int($_GET['centro_id'] ?? 0),
    'tipo_incidencia' => $_GET['tipo_incidencia'] ?? ''
];

// Paginación
$pagina = max(1, sanitizar_int($_GET['pagina'] ?? 1));
$porPagina = 20;
$offset = ($pagina - 1) * $porPagina;

// Obtener datos
$resultado = obtener_fichajes_pendientes($pdo, $porPagina, $offset, $filtros);
$fichajes = $resultado['fichajes'];
$totalPendientes = $resultado['total'];
$totalPaginas = $resultado['paginas'];

// Datos para filtros
$empleados = obtener_empleados_selector($pdo);
$centros = obtener_centros_admin($pdo, true);

// Variables para layout compartido
$stats = obtener_estadisticas_dashboard($pdo);
$paginaActual = 'fichajes';
$titulo = 'Validar Fichajes';

// ============================================================================
// LAYOUT COMPARTIDO
// ============================================================================
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<!-- Estilos específicos de fichajes -->
<style>
.filtros { background: white; border-radius: 0.75rem; padding: 1.25rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.filtros-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1rem; }
.filtro-group label { display: block; font-size: 0.75rem; font-weight: 600; color: #64748b; margin-bottom: 0.375rem; text-transform: uppercase; }
.filtro-group input, .filtro-group select { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #e2e8f0; border-radius: 0.5rem; font-size: 0.875rem; }
.filtros-actions { display: flex; gap: 0.5rem; justify-content: flex-end; }
.actions-bar { display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc; }
.selected-count { font-size: 0.875rem; color: #64748b; }
.btn-group { display: flex; gap: 0.5rem; }
.fichaje-card { padding: 1.25rem; border-bottom: 1px solid #e2e8f0; transition: background 0.2s; }
.fichaje-card:hover { background: #f8fafc; }
.fichaje-header { display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 1rem; }
.fichaje-checkbox { width: 1.25rem; height: 1.25rem; margin-top: 0.25rem; }
.fichaje-info { flex: 1; }
.fichaje-empleado { font-weight: 600; color: #1e293b; font-size: 1rem; }
.fichaje-meta { font-size: 0.8125rem; color: #64748b; margin-top: 0.25rem; }
.fichaje-fecha { font-size: 0.875rem; color: #475569; text-align: right; }
.fichaje-fecha strong { display: block; font-size: 1rem; color: #1e293b; }
.fichaje-body { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; padding: 1rem; background: #f8fafc; border-radius: 0.5rem; }
.fichaje-dato { font-size: 0.8125rem; }
.fichaje-dato label { color: #64748b; display: block; margin-bottom: 0.125rem; }
.fichaje-dato span { color: #1e293b; font-weight: 500; }
.incidencias { display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 0.75rem 0; }
.incidencia { display: inline-flex; align-items: center; gap: 0.375rem; padding: 0.375rem 0.75rem; border-radius: 0.375rem; font-size: 0.75rem; font-weight: 500; }
.incidencia-ubicacion { background: #fef3c7; color: #92400e; }
.incidencia-horario { background: #fee2e2; color: #991b1b; }
.fichaje-actions { display: flex; gap: 0.5rem; justify-content: flex-end; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; }
.mensaje { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem; }
.mensaje.success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
.mensaje.error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.empty-state { text-align: center; padding: 4rem 2rem; color: #64748b; }
.empty-state .icon { font-size: 4rem; margin-bottom: 1rem; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal.active { display: flex; }
.modal-content { background: white; border-radius: 0.75rem; width: 90%; max-width: 500px; max-height: 90vh; overflow: auto; }
.modal-header { padding: 1.25rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-title { font-weight: 600; font-size: 1.125rem; }
.modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b; }
.modal-body { padding: 1.25rem; }
.modal-footer { padding: 1.25rem; border-top: 1px solid #e2e8f0; display: flex; gap: 0.75rem; justify-content: flex-end; }
.info-box { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem; }
.info-box-title { font-weight: 600; color: #0369a1; margin-bottom: 0.5rem; }
.info-box-content { font-size: 0.875rem; color: #0c4a6e; }
.paginacion { display: flex; justify-content: center; gap: 0.25rem; margin-top: 1.5rem; }
.paginacion a, .paginacion span { padding: 0.5rem 0.875rem; border-radius: 0.375rem; font-size: 0.875rem; }
.paginacion a { background: white; border: 1px solid #e2e8f0; color: #475569; text-decoration: none; }
.paginacion a:hover { background: #f1f5f9; }
.paginacion .active { background: #0ea5e9; color: white; border: 1px solid #0ea5e9; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">Validar Fichajes</h1>
        <p style="color: #64748b; margin: 0;"><?= $totalPendientes ?> fichajes pendientes de validación</p>
    </div>
</div>

<!-- Mensajes -->
<?php if ($mensaje): ?>
    <div class="mensaje success">✅ <?= sanitizar($mensaje) ?></div>
<?php endif; ?>

<?php if ($mensajeError): ?>
    <div class="mensaje error">❌ <?= sanitizar($mensajeError) ?></div>
<?php endif; ?>

<!-- Filtros -->
<form method="GET" class="filtros">
    <div class="filtros-grid">
        <div class="filtro-group">
            <label>Desde</label>
            <input type="date" name="fecha_desde" value="<?= sanitizar($filtros['fecha_desde']) ?>">
        </div>
        <div class="filtro-group">
            <label>Hasta</label>
            <input type="date" name="fecha_hasta" value="<?= sanitizar($filtros['fecha_hasta']) ?>">
        </div>
        <div class="filtro-group">
            <label>Empleado</label>
            <select name="empleado_id">
                <option value="">Todos</option>
                <?php foreach ($empleados as $emp): ?>
                    <option value="<?= $emp->id ?>" <?= $filtros['empleado_id'] == $emp->id ? 'selected' : '' ?>>
                        <?= sanitizar($emp->apellido1 . ', ' . $emp->nombre) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filtro-group">
            <label>Centro</label>
            <select name="centro_id">
                <option value="">Todos</option>
                <?php foreach ($centros as $centro): ?>
                    <option value="<?= $centro->id ?>" <?= $filtros['centro_id'] == $centro->id ? 'selected' : '' ?>>
                        <?= sanitizar($centro->nombre) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filtro-group">
            <label>Tipo incidencia</label>
            <select name="tipo_incidencia">
                <option value="">Todas</option>
                <option value="ubicacion" <?= $filtros['tipo_incidencia'] === 'ubicacion' ? 'selected' : '' ?>>📍 Ubicación</option>
                <option value="horario" <?= $filtros['tipo_incidencia'] === 'horario' ? 'selected' : '' ?>>🕐 Horario</option>
            </select>
        </div>
    </div>
    <div class="filtros-actions">
        <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
        <a href="fichajes.php" class="btn btn-outline">Limpiar</a>
    </div>
</form>

<!-- Lista de fichajes -->
<div class="card">
    <form method="POST" id="formMasivo">
        <?= csrf_campo() ?>
        
        <?php if (!empty($fichajes)): ?>
        <div class="actions-bar">
            <div class="selected-count">
                <span id="countSelected">0</span> seleccionados
            </div>
            <div class="btn-group">
                <button type="submit" name="accion" value="validar_masivo" class="btn btn-success btn-sm">
                    ✓ Validar seleccionados
                </button>
                <button type="submit" name="accion" value="rechazar_masivo" class="btn btn-danger btn-sm">
                    ✗ Rechazar seleccionados
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (empty($fichajes)): ?>
            <div class="empty-state">
                <div class="icon">✅</div>
                <h3>No hay fichajes pendientes</h3>
                <p>Todos los fichajes han sido validados</p>
            </div>
        <?php else: ?>
            <?php foreach ($fichajes as $fichaje): ?>
                <div class="fichaje-card">
                    <div class="fichaje-header">
                        <input type="checkbox" name="fichajes[]" value="<?= $fichaje->id ?>" class="fichaje-checkbox">
                        <div class="fichaje-info">
                            <div class="fichaje-empleado">
                                <?= sanitizar($fichaje->nombre . ' ' . $fichaje->apellido1) ?>
                            </div>
                            <div class="fichaje-meta">
                                <?= sanitizar($fichaje->centro_nombre ?? 'Sin centro') ?> · 
                                <?= ucfirst($fichaje->tipo) ?>
                            </div>
                        </div>
                        <div class="fichaje-fecha">
                            <strong><?= substr($fichaje->hora, 0, 5) ?></strong>
                            <?= date('d/m/Y', strtotime($fichaje->fecha)) ?>
                        </div>
                    </div>
                    
                    <div class="fichaje-body">
                        <div class="fichaje-dato">
                            <label>Modo</label>
                            <span><?= ucfirst($fichaje->modo_trabajo ?? 'Presencial') ?></span>
                        </div>
                        <div class="fichaje-dato">
                            <label>IP</label>
                            <span><?= sanitizar($fichaje->ip ?? '-') ?></span>
                        </div>
                        <?php if (!empty($fichaje->coordenadas)): ?>
                        <div class="fichaje-dato">
                            <label>Ubicación</label>
                            <span>
                                <a href="https://www.google.com/maps?q=<?= urlencode($fichaje->coordenadas) ?>" target="_blank">
                                    📍 Ver mapa
                                </a>
                                <?php if ($fichaje->distancia_metros): ?>
                                    (<?= number_format($fichaje->distancia_metros, 0) ?>m)
                                <?php endif; ?>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($fichaje->incidencias)): ?>
                    <div class="incidencias">
                        <?php 
                        $incidencias = is_array($fichaje->incidencias) ? $fichaje->incidencias : explode(',', $fichaje->incidencias);
                        foreach ($incidencias as $inc): 
                            $inc = trim($inc);
                            $clase = strpos(strtolower($inc), 'ubicacion') !== false ? 'ubicacion' : 'horario';
                        ?>
                            <span class="incidencia incidencia-<?= $clase ?>"><?= sanitizar($inc) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($fichaje->observaciones_empleado)): ?>
                    <div style="background: #f0f9ff; padding: 0.75rem; border-radius: 0.375rem; margin: 0.75rem 0; font-size: 0.875rem;">
                        <strong>💬 Nota del empleado:</strong> <?= sanitizar($fichaje->observaciones_empleado) ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="fichaje-actions">
                        <button type="button" onclick="abrirModalValidar(<?= $fichaje->id ?>, 'rechazar')" class="btn btn-danger btn-sm">
                            ✗ Rechazar
                        </button>
                        <button type="button" onclick="abrirModalValidar(<?= $fichaje->id ?>, 'aprobar')" class="btn btn-success btn-sm">
                            ✓ Validar
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Paginación -->
            <?php if ($totalPaginas > 1): ?>
            <div class="paginacion">
                <?php if ($pagina > 1): ?>
                    <a href="?pagina=<?= $pagina - 1 ?>&<?= http_build_query($filtros) ?>">← Anterior</a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $pagina - 2); $i <= min($totalPaginas, $pagina + 2); $i++): ?>
                    <?php if ($i == $pagina): ?>
                        <span class="active"><?= $i ?></span>
                    <?php else: ?>
                        <a href="?pagina=<?= $i ?>&<?= http_build_query($filtros) ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($pagina < $totalPaginas): ?>
                    <a href="?pagina=<?= $pagina + 1 ?>&<?= http_build_query($filtros) ?>">Siguiente →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </form>
</div>

<!-- Modal Validar -->
<div class="modal" id="modalValidar">
    <div class="modal-content">
        <form method="POST">
            <?= csrf_campo() ?>
            <input type="hidden" name="fichaje_id" id="modalFichajeId">
            <input type="hidden" name="accion" id="modalAccion">
            
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitulo">Validar Fichaje</h3>
                <button type="button" class="modal-close" onclick="cerrarModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <div class="info-box">
                    <div class="info-box-title">ℹ️ Información</div>
                    <div class="info-box-content" id="modalInfo">
                        Al validar este fichaje, se aprobará y contará para el cálculo de horas.
                    </div>
                </div>
                
                <div class="form-group" id="grupoHoraCorregida" style="display:none;">
                    <label class="form-label">🕐 Hora corregida (opcional)</label>
                    <input type="time" name="hora_corregida" id="horaCorregida" class="form-control">
                    <div class="form-hint">Deja en blanco para mantener la hora original</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">📝 Observaciones</label>
                    <textarea name="observacion" class="form-control" rows="3" placeholder="Añade una observación si es necesario..."></textarea>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="cerrarModal()">Cancelar</button>
                <button type="submit" class="btn" id="modalBtnSubmit">Confirmar</button>
            </div>
        </form>
    </div>
</div>

<script>
// Seleccionar todos
document.getElementById('selectAll')?.addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.fichaje-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
    actualizarContador();
});

// Contador de seleccionados
document.querySelectorAll('.fichaje-checkbox').forEach(cb => {
    cb.addEventListener('change', actualizarContador);
});

function actualizarContador() {
    const count = document.querySelectorAll('.fichaje-checkbox:checked').length;
    document.getElementById('countSelected').textContent = count;
}

// Modal
function abrirModalValidar(fichajeId, accion) {
    document.getElementById('modalFichajeId').value = fichajeId;
    document.getElementById('modalAccion').value = accion;
    
    const titulo = document.getElementById('modalTitulo');
    const info = document.getElementById('modalInfo');
    const btn = document.getElementById('modalBtnSubmit');
    const grupoHora = document.getElementById('grupoHoraCorregida');
    
    if (accion === 'aprobar') {
        titulo.textContent = '✅ Validar Fichaje';
        info.textContent = 'Al validar este fichaje, se aprobará y contará para el cálculo de horas. Opcionalmente puedes corregir la hora.';
        btn.textContent = '✓ Validar';
        btn.className = 'btn btn-success';
        grupoHora.style.display = 'block';
    } else {
        titulo.textContent = '❌ Rechazar Fichaje';
        info.textContent = 'Al rechazar este fichaje, NO contará para el cálculo de horas. El empleado será notificado.';
        btn.textContent = '✗ Rechazar';
        btn.className = 'btn btn-danger';
        grupoHora.style.display = 'none';
    }
    
    document.getElementById('modalValidar').classList.add('active');
}

function cerrarModal() {
    document.getElementById('modalValidar').classList.remove('active');
}

// Cerrar modal con Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') cerrarModal();
});

// Cerrar modal al hacer clic fuera
document.getElementById('modalValidar')?.addEventListener('click', function(e) {
    if (e.target === this) cerrarModal();
});
</script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
