<?php
/**
 * LM FICHAJES - Admin: Solicitudes RGPD
 * @version 1.0.1 - Con CSRF
 */
define('LMFICHAJES', true);
require_once '../config.php';
require_once '../includes/auth.php';

// Notificaciones
if (file_exists('../includes/notificaciones.php')) {
    require_once '../includes/notificaciones.php';
}

requerir_login();
if (!es_admin()) die('Acceso denegado');

$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    if (!isset($_POST['csrf_token']) || !verificar_csrf($_POST['csrf_token'])) {
        $mensaje = 'Error de seguridad. Recarga la página.';
        $tipo_mensaje = 'error';
    } else {
        $solicitud_id = intval($_POST['solicitud_id'] ?? 0);
        $accion = $_POST['accion'];
        if ($solicitud_id > 0) {
            $respuesta = trim($_POST['respuesta'] ?? '');
            
            // Obtener datos de la solicitud ANTES de actualizar
            $stmtSol = $pdo->prepare("SELECT empleado_id, tipo_derecho FROM solicitudes_rgpd WHERE id = ?");
            $stmtSol->execute([$solicitud_id]);
            $datosSolicitud = $stmtSol->fetch();
            
            if ($accion === 'completar') {
                $pdo->prepare("UPDATE solicitudes_rgpd SET estado = 'completada', respuesta = ?, updated_at = NOW() WHERE id = ?")->execute([$respuesta, $solicitud_id]);
                $mensaje = 'Solicitud completada.';
                $tipo_mensaje = 'success';
                
                // NOTIFICACIÓN AL EMPLEADO
                if ($datosSolicitud && function_exists('notificar_rgpd_completada')) {
                    notificar_rgpd_completada($pdo, $datosSolicitud->empleado_id, traducir_derecho($datosSolicitud->tipo_derecho));
                }
                
            } elseif ($accion === 'rechazar') {
                $pdo->prepare("UPDATE solicitudes_rgpd SET estado = 'rechazada', respuesta = ?, updated_at = NOW() WHERE id = ?")->execute([$respuesta, $solicitud_id]);
                $mensaje = 'Solicitud rechazada.';
                $tipo_mensaje = 'warning';
                
                // NOTIFICACIÓN AL EMPLEADO
                if ($datosSolicitud && function_exists('notificar_rgpd_rechazada')) {
                    notificar_rgpd_rechazada($pdo, $datosSolicitud->empleado_id, traducir_derecho($datosSolicitud->tipo_derecho), $respuesta);
                }
            }
        }
    }
}

$csrf_token = generar_csrf();
$solicitudes = [];
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'solicitudes_rgpd'");
    if ($stmt->rowCount() > 0) {
        $solicitudes = $pdo->query("SELECT s.*, e.nombre, e.apellido1, e.apellido2, e.email FROM solicitudes_rgpd s LEFT JOIN empleados e ON s.empleado_id = e.id ORDER BY CASE s.estado WHEN 'pendiente' THEN 0 ELSE 1 END, s.created_at DESC")->fetchAll();
    }
} catch (Exception $e) {}

function traducir_derecho($t) { return ['acceso'=>'Acceso','rectificacion'=>'Rectificación','supresion'=>'Supresión','portabilidad'=>'Portabilidad'][$t] ?? $t; }
function traducir_estado($e) { return ['pendiente'=>'Pendiente','completada'=>'Completada','rechazada'=>'Rechazada'][$e] ?? $e; }
function nombre_empleado($s) { return trim(($s->nombre ?? '') . ' ' . ($s->apellido1 ?? '')) ?: 'Empleado #' . $s->empleado_id; }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitudes RGPD - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        h1 { color: #1e40af; }
        .btn { padding: 8px 16px; border-radius: 6px; border: none; cursor: pointer; font-size: 0.9rem; text-decoration: none; display: inline-block; }
        .btn-primary { background: #1e40af; color: white; }
        .btn-success { background: #059669; color: white; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-back { background: #6b7280; color: white; margin-bottom: 20px; }
        .mensaje { padding: 16px; border-radius: 8px; margin-bottom: 20px; }
        .mensaje.success { background: #d1fae5; color: #065f46; }
        .mensaje.warning { background: #fef3c7; color: #92400e; }
        .mensaje.error { background: #fee2e2; color: #991b1b; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; }
        .estado { padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; }
        .estado-pendiente { background: #fef3c7; color: #92400e; }
        .estado-completada { background: #d1fae5; color: #065f46; }
        .estado-rechazada { background: #fee2e2; color: #991b1b; }
        .acciones { display: flex; gap: 8px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal.active { display: flex; align-items: center; justify-content: center; }
        .modal-content { background: white; padding: 30px; border-radius: 12px; max-width: 500px; width: 90%; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-group textarea { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; min-height: 100px; }
        .empty { text-align: center; padding: 40px; color: #6b7280; }
        .info { font-size: 0.85rem; color: #6b7280; }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="btn btn-back">← Volver</a>
        <h1>⚖️ Solicitudes RGPD</h1>
        <?php if ($mensaje): ?><div class="mensaje <?= $tipo_mensaje ?>"><?= htmlspecialchars($mensaje) ?></div><?php endif; ?>
        <div class="card">
            <?php if (empty($solicitudes)): ?>
            <div class="empty"><p>No hay solicitudes RGPD.</p></div>
            <?php else: ?>
            <table>
                <thead><tr><th>Fecha</th><th>Empleado</th><th>Tipo</th><th>Descripción</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                    <?php foreach ($solicitudes as $s): ?>
                    <tr>
                        <td><?= date('d/m/Y H:i', strtotime($s->created_at)) ?></td>
                        <td><strong><?= htmlspecialchars(nombre_empleado($s)) ?></strong><br><span class="info"><?= htmlspecialchars($s->email ?? '') ?></span></td>
                        <td><?= htmlspecialchars(traducir_derecho($s->tipo_derecho)) ?></td>
                        <td><?= htmlspecialchars($s->descripcion ?: '-') ?></td>
                        <td><span class="estado estado-<?= $s->estado ?>"><?= traducir_estado($s->estado) ?></span></td>
                        <td>
                            <?php if ($s->estado === 'pendiente'): ?>
                            <div class="acciones">
                                <button class="btn btn-success" onclick="abrirModal(<?= $s->id ?>, 'completar')">✓</button>
                                <button class="btn btn-danger" onclick="abrirModal(<?= $s->id ?>, 'rechazar')">✗</button>
                            </div>
                            <?php else: ?><span class="info"><?= $s->respuesta ? 'Respondida' : '-' ?></span><?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
    <div id="modal" class="modal">
        <div class="modal-content">
            <h3 id="modal-titulo">Responder</h3>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                <input type="hidden" name="solicitud_id" id="modal-id">
                <input type="hidden" name="accion" id="modal-accion">
                <div class="form-group"><label>Respuesta (opcional)</label><textarea name="respuesta"></textarea></div>
                <div style="display:flex;gap:10px;justify-content:flex-end;">
                    <button type="button" class="btn" onclick="cerrarModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="modal-btn">Confirmar</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    function abrirModal(id, accion) {
        document.getElementById('modal-id').value = id;
        document.getElementById('modal-accion').value = accion;
        document.getElementById('modal-titulo').textContent = accion === 'completar' ? 'Completar' : 'Rechazar';
        document.getElementById('modal-btn').className = accion === 'completar' ? 'btn btn-success' : 'btn btn-danger';
        document.getElementById('modal').classList.add('active');
    }
    function cerrarModal() { document.getElementById('modal').classList.remove('active'); }
    document.getElementById('modal').onclick = function(e) { if (e.target === this) cerrarModal(); };
    </script>
</body>
</html>
