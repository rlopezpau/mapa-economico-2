<?php
/**
 * LM FICHAJES - Panel de Datos de Demostración
 * VERSIÓN CON LAYOUT COMPARTIDO
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once __DIR__ . '/includes/admin_functions.php';

requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'Solo administradores pueden gestionar datos demo';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';

function contarDatosDemo($pdo) {
    $stats = ['empleados' => 0, 'centros' => 0, 'horarios' => 0, 'fichajes' => 0, 'ausencias' => 0];
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM empleados WHERE nombre LIKE 'DEMO_%'");
        $stats['empleados'] = $stmt->fetchColumn();
        $stmt = $pdo->query("SELECT COUNT(*) FROM centros WHERE nombre LIKE 'DEMO_%'");
        $stats['centros'] = $stmt->fetchColumn();
        $stmt = $pdo->query("SELECT COUNT(*) FROM horarios WHERE nombre LIKE 'DEMO_%'");
        $stats['horarios'] = $stmt->fetchColumn();
        $stmt = $pdo->query("SELECT COUNT(*) FROM fichajes WHERE empleado_id IN (SELECT id FROM empleados WHERE nombre LIKE 'DEMO_%')");
        $stats['fichajes'] = $stmt->fetchColumn();
    } catch (Exception $e) {}
    return $stats;
}

function crearDatosDemo($pdo) {
    $resultado = ['exito' => false, 'mensaje' => '', 'creados' => []];
    
    try {
        $pdo->beginTransaction();
        
        $centros = [
            ['DEMO01', 'DEMO_Ayuntamiento Central', 'Plaza Mayor 1, Barcelona', '41.3825,2.1769', 150],
            ['DEMO02', 'DEMO_Biblioteca Municipal', 'Calle Cultura 25, Barcelona', '41.3850,2.1800', 100],
            ['DEMO03', 'DEMO_Polideportivo Norte', 'Avda Deportes 100, Barcelona', '41.3900,2.1700', 200],
            ['DEMO04', 'DEMO_Centro Civico Sur', 'Calle Participacion 50, Barcelona', '41.3750,2.1850', 100],
            ['DEMO05', 'DEMO_Oficina Urbanismo', 'Paseo Planificacion 15, Barcelona', '41.3870,2.1720', 100],
            ['DEMO06', 'DEMO_Servicios Sociales', 'Calle Bienestar 8, Barcelona', '41.3810,2.1750', 80],
        ];
        $stmtCentro = $pdo->prepare("INSERT INTO centros (codigo, nombre, direccion, coordenadas, radio_metros, activo) VALUES (?, ?, ?, ?, ?, 1)");
        foreach ($centros as $c) { $stmtCentro->execute($c); }
        $resultado['creados']['centros'] = count($centros);
        
        $horarios = [
            ['DEMO_Jornada Intensiva 7h30', 'continua', 7.50, 37.50, '07:30:00', '15:00:00', null, null, '09:00:00', '14:00:00'],
            ['DEMO_Jornada Intensiva 8h', 'continua', 7.50, 37.50, '08:00:00', '15:30:00', null, null, '09:00:00', '14:00:00'],
            ['DEMO_Jornada Partida', 'partida', 8.00, 40.00, '08:00:00', '14:00:00', '16:00:00', '18:00:00', '09:00:00', '13:00:00'],
            ['DEMO_Horario Flexible', 'continua', 7.50, 37.50, '07:00:00', '15:30:00', null, null, '10:00:00', '13:00:00'],
            ['DEMO_Turno Manana', 'continua', 8.00, 40.00, '06:00:00', '14:00:00', null, null, '07:00:00', '13:00:00'],
            ['DEMO_Turno Tarde', 'continua', 8.00, 40.00, '14:00:00', '22:00:00', null, null, '15:00:00', '21:00:00'],
            ['DEMO_Media Jornada', 'continua', 4.00, 20.00, '08:00:00', '12:00:00', null, null, '09:00:00', '11:30:00'],
        ];
        $stmtHorario = $pdo->prepare("INSERT INTO horarios (nombre, tipo, horas_diarias, horas_semanales, hora_entrada, hora_salida, hora_entrada_tarde, hora_salida_tarde, troncal_inicio, troncal_fin, cortesia_entrada, cortesia_salida, tolerancia_minutos, activo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 5, 5, 15, 1)");
        foreach ($horarios as $h) { $stmtHorario->execute($h); }
        $resultado['creados']['horarios'] = count($horarios);
        
        $horariosIds = [];
        $stmt = $pdo->query("SELECT id, nombre FROM horarios WHERE nombre LIKE 'DEMO_%'");
        while ($row = $stmt->fetch()) { $horariosIds[$row->nombre] = $row->id; }
        
        $centrosIds = [];
        $stmt = $pdo->query("SELECT id, nombre FROM centros WHERE nombre LIKE 'DEMO_%'");
        while ($row = $stmt->fetch()) { $centrosIds[$row->nombre] = $row->id; }
        
        $password = password_hash('Demo1234!', PASSWORD_DEFAULT);
        
        try {
            $stmt = $pdo->query("SHOW COLUMNS FROM empleados LIKE 'porcentaje_jornada'");
            if ($stmt->rowCount() == 0) {
                $pdo->exec("ALTER TABLE empleados ADD COLUMN porcentaje_jornada DECIMAL(5,2) DEFAULT 100.00 AFTER horario_id");
            }
        } catch (Exception $e) {}
        
        $empleados = [
            ['11111111A', 'DEMO_Admin', 'Garcia', 'Lopez', 'admin.demo@test.es', '600000001', 'admin', 'DEMO_Horario Flexible', 100],
            ['22222222B', 'DEMO_Maria', 'Fernandez', 'Ruiz', 'maria.demo@test.es', '600000002', 'manager', 'DEMO_Jornada Intensiva 7h30', 100],
            ['33333333C', 'DEMO_Carlos', 'Martinez', 'Sanchez', 'carlos.demo@test.es', '600000003', 'manager', 'DEMO_Jornada Partida', 100],
            ['44444444D', 'DEMO_Ana', 'Lopez', 'Garcia', 'ana.demo@test.es', '600000004', 'supervisor', 'DEMO_Jornada Intensiva 8h', 100],
            ['55555555E', 'DEMO_Pedro', 'Sanchez', 'Martinez', 'pedro.demo@test.es', '600000005', 'supervisor', 'DEMO_Turno Tarde', 100],
            ['66666666F', 'DEMO_Laura', 'Rodriguez', 'Perez', 'laura.demo@test.es', '600000006', 'empleado', 'DEMO_Jornada Intensiva 7h30', 100],
            ['77777777G', 'DEMO_Javier', 'Hernandez', 'Gonzalez', 'javier.demo@test.es', '600000007', 'empleado', 'DEMO_Jornada Partida', 100],
            ['88888888H', 'DEMO_Elena', 'Diaz', 'Torres', 'elena.demo@test.es', '600000008', 'empleado', 'DEMO_Horario Flexible', 100],
            ['99999999J', 'DEMO_Miguel', 'Moreno', 'Jimenez', 'miguel.demo@test.es', '600000009', 'empleado', 'DEMO_Turno Manana', 100],
            ['12121212K', 'DEMO_Carmen', 'Munoz', 'Alvarez', 'carmen.demo@test.es', '600000010', 'empleado', 'DEMO_Jornada Intensiva 8h', 100],
            ['13131313L', 'DEMO_Roberto', 'Ruiz', 'Fernandez', 'roberto.demo@test.es', '600000011', 'empleado', 'DEMO_Media Jornada', 50],
            ['14141414M', 'DEMO_Isabel', 'Gonzalez', 'Diaz', 'isabel.demo@test.es', '600000012', 'empleado', 'DEMO_Media Jornada', 50],
        ];
        
        $stmtEmp = $pdo->prepare("INSERT INTO empleados (nif, nombre, apellido1, apellido2, email, telefono, password, rol, horario_id, porcentaje_jornada, activo, debe_cambiar_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)");
        foreach ($empleados as $emp) {
            $horarioId = $horariosIds[$emp[7]] ?? null;
            $stmtEmp->execute([$emp[0], $emp[1], $emp[2], $emp[3], $emp[4], $emp[5], $password, $emp[6], $horarioId, $emp[8]]);
        }
        $resultado['creados']['empleados'] = count($empleados);
        
        $empleadosIds = [];
        $stmt = $pdo->query("SELECT id, nif FROM empleados WHERE nombre LIKE 'DEMO_%'");
        while ($row = $stmt->fetch()) { $empleadosIds[$row->nif] = $row->id; }
        
        $asignaciones = [
            ['11111111A', 'DEMO_Ayuntamiento Central', 1], ['22222222B', 'DEMO_Ayuntamiento Central', 1],
            ['33333333C', 'DEMO_Biblioteca Municipal', 1], ['44444444D', 'DEMO_Ayuntamiento Central', 1],
            ['55555555E', 'DEMO_Polideportivo Norte', 1], ['66666666F', 'DEMO_Ayuntamiento Central', 1],
            ['77777777G', 'DEMO_Biblioteca Municipal', 1], ['88888888H', 'DEMO_Polideportivo Norte', 1],
            ['99999999J', 'DEMO_Centro Civico Sur', 1], ['12121212K', 'DEMO_Oficina Urbanismo', 1],
            ['13131313L', 'DEMO_Servicios Sociales', 1], ['14141414M', 'DEMO_Ayuntamiento Central', 1],
        ];
        $stmtAsig = $pdo->prepare("INSERT INTO empleados_centros (empleado_id, centro_id, es_principal, activo) VALUES (?, ?, ?, 1)");
        foreach ($asignaciones as $asig) {
            $empId = $empleadosIds[$asig[0]] ?? null;
            $centroId = $centrosIds[$asig[1]] ?? null;
            if ($empId && $centroId) { $stmtAsig->execute([$empId, $centroId, $asig[2]]); }
        }
        
        $supervisiones = [
            ['66666666F', '44444444D'], ['12121212K', '44444444D'],
            ['77777777G', '55555555E'], ['88888888H', '55555555E'], ['99999999J', '55555555E'],
            ['13131313L', '22222222B'], ['14141414M', '33333333C'],
        ];
        $stmtSup = $pdo->prepare("UPDATE empleados SET supervisor_id = ? WHERE id = ?");
        foreach ($supervisiones as $sup) {
            $empId = $empleadosIds[$sup[0]] ?? null;
            $supId = $empleadosIds[$sup[1]] ?? null;
            if ($empId && $supId) { $stmtSup->execute([$supId, $empId]); }
        }
        
        $centroAyto = $centrosIds['DEMO_Ayuntamiento Central'] ?? null;
        if ($centroAyto) {
            $stmtFichaje = $pdo->prepare("INSERT INTO fichajes (empleado_id, centro_id, fecha, hora, tipo, modo, estado) VALUES (?, ?, ?, ?, ?, 'presencial', ?)");
            $ayer = date('Y-m-d', strtotime('-1 day'));
            $fichajes = 0;
            
            foreach (['66666666F', '77777777G', '88888888H', '12121212K'] as $nif) {
                $empId = $empleadosIds[$nif] ?? null;
                if (!$empId) continue;
                $stmtFichaje->execute([$empId, $centroAyto, $ayer, '07:55:00', 'entrada', 'auto_aprobado']);
                $stmtFichaje->execute([$empId, $centroAyto, $ayer, '15:05:00', 'salida', 'auto_aprobado']);
                $fichajes += 2;
            }
            
            $hoy = date('Y-m-d');
            $stmtPend = $pdo->prepare("INSERT INTO fichajes (empleado_id, centro_id, fecha, hora, tipo, modo, estado, incidencia_horario, observacion_empleado) VALUES (?, ?, ?, ?, ?, 'presencial', 'pendiente', ?, ?)");
            
            $empLaura = $empleadosIds['66666666F'] ?? null;
            if ($empLaura) {
                $stmtPend->execute([$empLaura, $centroAyto, $hoy, '07:15:00', 'entrada', 1, 'Reunion temprana']);
                $fichajes++;
            }
            
            $resultado['creados']['fichajes'] = $fichajes;
        }
        
        $pdo->commit();
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Datos de demostración creados correctamente';
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error: ' . $e->getMessage();
    }
    
    return $resultado;
}

function eliminarDatosDemo($pdo) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    try {
        $pdo->beginTransaction();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        $stmt = $pdo->query("SELECT id FROM empleados WHERE nombre LIKE 'DEMO_%'");
        $empIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($empIds)) {
            $ids = implode(',', $empIds);
            $pdo->exec("DELETE FROM fichajes WHERE empleado_id IN ({$ids})");
            try { $pdo->exec("DELETE FROM solicitudes_ausencia WHERE empleado_id IN ({$ids})"); } catch (Exception $e) {}
            try { $pdo->exec("DELETE FROM saldo_ausencias WHERE empleado_id IN ({$ids})"); } catch (Exception $e) {}
            try { $pdo->exec("DELETE FROM resumen_diario WHERE empleado_id IN ({$ids})"); } catch (Exception $e) {}
            $pdo->exec("DELETE FROM empleados_centros WHERE empleado_id IN ({$ids})");
            $pdo->exec("DELETE FROM empleados WHERE id IN ({$ids})");
        }
        
        $stmt = $pdo->query("SELECT id FROM horarios WHERE nombre LIKE 'DEMO_%'");
        $horIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($horIds)) {
            $ids = implode(',', $horIds);
            try { $pdo->exec("DELETE FROM horarios_dias WHERE horario_id IN ({$ids})"); } catch (Exception $e) {}
            $pdo->exec("DELETE FROM horarios WHERE id IN ({$ids})");
        }
        
        $pdo->exec("DELETE FROM centros WHERE nombre LIKE 'DEMO_%'");
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->commit();
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Datos eliminados correctamente';
    } catch (Exception $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error: ' . $e->getMessage();
    }
    return $resultado;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf()) {
    $accion = $_POST['accion'] ?? '';
    if ($accion === 'crear_demo') {
        $r = crearDatosDemo($pdo);
        if ($r['exito']) $mensaje = $r['mensaje']; else $error = $r['mensaje'];
    }
    if ($accion === 'eliminar_demo') {
        $r = eliminarDatosDemo($pdo);
        if ($r['exito']) $mensaje = $r['mensaje']; else $error = $r['mensaje'];
    }
    regenerar_csrf();
}

$statsDemo = contarDatosDemo($pdo);
$hayDatosDemo = ($statsDemo['empleados'] ?? 0) > 0;

$paginaActual = 'datos_demo';
$titulo = 'Datos de Demostración';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.demo-header { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; padding: 2rem; border-radius: 16px; margin-bottom: 2rem; text-align: center; }
.demo-header h1 { margin: 0 0 0.5rem; font-size: 1.75rem; }
.demo-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.demo-card { background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.demo-card h3 { margin: 0 0 1rem; font-size: 1rem; }
.demo-card ul { margin: 0; padding-left: 1.25rem; color: #64748b; font-size: 0.9rem; }
.demo-actions { background: white; border-radius: 12px; padding: 2rem; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.btn-demo { padding: 1rem 2rem; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; border: none; }
.btn-crear { background: #10b981; color: white; }
.btn-eliminar { background: #ef4444; color: white; }
.stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.5rem; background: #f8fafc; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; }
.stat-item { text-align: center; }
.stat-item .value { font-size: 1.5rem; font-weight: 700; color: #6366f1; }
.stat-item .label { font-size: 0.75rem; color: #64748b; }
.credenciales { background: #f0fdf4; border: 1px solid #22c55e; border-radius: 12px; padding: 1.5rem; margin-top: 2rem; }
.credenciales table { width: 100%; border-collapse: collapse; }
.credenciales th, .credenciales td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #dcfce7; }
.credenciales code { background: #dcfce7; padding: 0.125rem 0.375rem; border-radius: 4px; }
</style>

<div class="demo-header">
    <h1>🎭 Datos de Demostración</h1>
    <p>Crea datos de prueba para probar el sistema</p>
</div>

<?php if ($mensaje): ?><div class="alert alert-success">✅ <?= sanitizar($mensaje) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger">❌ <?= sanitizar($error) ?></div><?php endif; ?>

<div class="demo-grid">
    <div class="demo-card"><h3>👥 12 Empleados</h3><ul><li>1 Admin</li><li>2 Managers</li><li>2 Supervisores</li><li>7 Empleados</li></ul></div>
    <div class="demo-card"><h3>🏢 6 Centros</h3><ul><li>Ayuntamiento</li><li>Biblioteca</li><li>Polideportivo</li><li>Centro Cívico</li><li>Urbanismo</li><li>Servicios Sociales</li></ul></div>
    <div class="demo-card"><h3>🕐 7 Horarios</h3><ul><li>Intensiva (2)</li><li>Partida</li><li>Flexible</li><li>Turnos</li><li>Media jornada</li></ul></div>
    <div class="demo-card"><h3>📋 Fichajes</h3><ul><li>Fichajes ayer</li><li>Pendientes hoy</li><li>Con incidencias</li></ul></div>
</div>

<?php if ($hayDatosDemo): ?>
<div class="stats-grid">
    <div class="stat-item"><div class="value"><?= $statsDemo['empleados'] ?></div><div class="label">Empleados</div></div>
    <div class="stat-item"><div class="value"><?= $statsDemo['centros'] ?></div><div class="label">Centros</div></div>
    <div class="stat-item"><div class="value"><?= $statsDemo['horarios'] ?></div><div class="label">Horarios</div></div>
    <div class="stat-item"><div class="value"><?= $statsDemo['fichajes'] ?></div><div class="label">Fichajes</div></div>
    <div class="stat-item"><div class="value"><?= $statsDemo['ausencias'] ?></div><div class="label">Ausencias</div></div>
</div>
<?php endif; ?>

<div class="demo-actions">
    <?php if (!$hayDatosDemo): ?>
        <h2>🚀 Crear Datos Demo</h2>
        <p>Se crearán empleados, centros, horarios y fichajes de prueba.</p>
        <form method="POST"><?= csrf_campo() ?><input type="hidden" name="accion" value="crear_demo"><button type="submit" class="btn-demo btn-crear">✨ Crear Datos Demo</button></form>
    <?php else: ?>
        <h2>🗑️ Eliminar Datos Demo</h2>
        <form method="POST" onsubmit="return confirm('¿Seguro?');"><?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar_demo"><button type="submit" class="btn-demo btn-eliminar">🗑️ Eliminar</button></form>
    <?php endif; ?>
</div>

<?php if ($hayDatosDemo): ?>
<div class="credenciales">
    <h3>🔑 Credenciales</h3>
    <table>
        <tr><th>NIF</th><th>Nombre</th><th>Rol</th><th>Password</th></tr>
        <tr><td><code>11111111A</code></td><td>DEMO_Admin</td><td>Admin</td><td><code>Demo1234!</code></td></tr>
        <tr><td><code>22222222B</code></td><td>DEMO_Maria</td><td>Manager</td><td><code>Demo1234!</code></td></tr>
        <tr><td><code>44444444D</code></td><td>DEMO_Ana</td><td>Supervisor</td><td><code>Demo1234!</code></td></tr>
        <tr><td><code>66666666F</code></td><td>DEMO_Laura</td><td>Empleado</td><td><code>Demo1234!</code></td></tr>
        <tr><td><code>13131313L</code></td><td>DEMO_Roberto</td><td>Empleado 50%</td><td><code>Demo1234!</code></td></tr>
    </table>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
