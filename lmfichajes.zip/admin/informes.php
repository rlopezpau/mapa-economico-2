<?php
/**
 * LM FICHAJES - Panel Admin: Informes
 * 
 * Generación de informes y estadísticas
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos - solo admin
requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);

// Tipo de informe
$tipoInforme = $_GET['tipo'] ?? 'resumen';
$fechaDesde = $_GET['fecha_desde'] ?? date('Y-m-01');
$fechaHasta = $_GET['fecha_hasta'] ?? date('Y-m-d');
$empleadoId = (int)($_GET['empleado_id'] ?? 0);
$centroId = (int)($_GET['centro_id'] ?? 0);

// Datos para filtros
$empleados = $pdo->query("SELECT id, nombre, apellido1 FROM empleados WHERE activo = 1 ORDER BY apellido1")->fetchAll();
$centros = $pdo->query("SELECT id, nombre FROM centros WHERE activo = 1 ORDER BY nombre")->fetchAll();

// Variables para layout
$paginaActual = 'informes';
$titulo = 'Informes';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.informe-tabs { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 2px solid #e2e8f0; padding-bottom: 0.5rem; }
.informe-tab { padding: 0.75rem 1.25rem; border-radius: 0.5rem 0.5rem 0 0; text-decoration: none; color: #64748b; font-weight: 500; }
.informe-tab:hover { background: #f8fafc; }
.informe-tab.active { background: #0ea5e9; color: white; }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
.stat-card { background: white; padding: 1.25rem; border-radius: 0.75rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.stat-value { font-size: 2rem; font-weight: 700; color: #1e3a5f; }
.stat-label { color: #64748b; font-size: 0.875rem; }
.table-informe { width: 100%; border-collapse: collapse; }
.table-informe th, .table-informe td { padding: 0.75rem 1rem; text-align: left; border-bottom: 1px solid #e2e8f0; }
.table-informe th { background: #f8fafc; font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 600; }
.table-informe tr:hover { background: #f8fafc; }
.progress-bar { height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden; }
.progress-fill { height: 100%; background: #22c55e; border-radius: 4px; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">📊 Informes</h1>
        <p class="page-subtitle">Estadísticas y reportes del sistema</p>
    </div>
</div>

<!-- Tabs de informes -->
<div class="informe-tabs">
    <a href="?tipo=resumen" class="informe-tab <?= $tipoInforme === 'resumen' ? 'active' : '' ?>">📈 Resumen General</a>
    <a href="?tipo=fichajes" class="informe-tab <?= $tipoInforme === 'fichajes' ? 'active' : '' ?>">⏰ Fichajes</a>
    <a href="?tipo=ausencias" class="informe-tab <?= $tipoInforme === 'ausencias' ? 'active' : '' ?>">📅 Ausencias</a>
    <a href="?tipo=horas" class="informe-tab <?= $tipoInforme === 'horas' ? 'active' : '' ?>">🕐 Horas Trabajadas</a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
            <input type="hidden" name="tipo" value="<?= htmlspecialchars($tipoInforme) ?>">
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Desde</label>
                <input type="date" name="fecha_desde" class="form-control" value="<?= $fechaDesde ?>">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Hasta</label>
                <input type="date" name="fecha_hasta" class="form-control" value="<?= $fechaHasta ?>">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Empleado</label>
                <select name="empleado_id" class="form-control">
                    <option value="">Todos</option>
                    <?php foreach ($empleados as $emp): ?>
                    <option value="<?= $emp->id ?>" <?= $empleadoId == $emp->id ? 'selected' : '' ?>>
                        <?= htmlspecialchars($emp->apellido1 . ', ' . $emp->nombre) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Centro</label>
                <select name="centro_id" class="form-control">
                    <option value="">Todos</option>
                    <?php foreach ($centros as $centro): ?>
                    <option value="<?= $centro->id ?>" <?= $centroId == $centro->id ? 'selected' : '' ?>>
                        <?= htmlspecialchars($centro->nombre) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary">📊 Generar</button>
        </form>
    </div>
</div>

<?php if ($tipoInforme === 'resumen'): ?>
<!-- RESUMEN GENERAL -->
<?php
// Estadísticas generales - usando fecha (no fecha_hora)
$statsGen = $pdo->query("SELECT 
    (SELECT COUNT(*) FROM empleados WHERE activo = 1) as empleados_activos,
    (SELECT COUNT(*) FROM fichajes WHERE fecha BETWEEN '$fechaDesde' AND '$fechaHasta') as total_fichajes,
    (SELECT COUNT(*) FROM fichajes WHERE estado = 'pendiente') as fichajes_pendientes,
    (SELECT COUNT(*) FROM solicitudes_ausencia WHERE estado = 'pendiente') as ausencias_pendientes
")->fetch();
?>

<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-value"><?= $statsGen->empleados_activos ?></div>
        <div class="stat-label">👥 Empleados activos</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $statsGen->total_fichajes ?></div>
        <div class="stat-label">⏰ Fichajes en período</div>
    </div>
    <div class="stat-card">
        <div class="stat-value" style="color: #f59e0b;"><?= $statsGen->fichajes_pendientes ?></div>
        <div class="stat-label">⚠️ Fichajes pendientes validar</div>
    </div>
    <div class="stat-card">
        <div class="stat-value" style="color: #0ea5e9;"><?= $statsGen->ausencias_pendientes ?></div>
        <div class="stat-label">📅 Ausencias pendientes</div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title">📈 Fichajes por día</span>
    </div>
    <div class="card-body">
        <?php
        $fichajesPorDia = $pdo->query("
            SELECT fecha, COUNT(*) as total
            FROM fichajes 
            WHERE fecha BETWEEN '$fechaDesde' AND '$fechaHasta'
            GROUP BY fecha
            ORDER BY fecha DESC
            LIMIT 14
        ")->fetchAll();
        ?>
        
        <?php if (empty($fichajesPorDia)): ?>
        <p style="text-align: center; color: #64748b;">No hay datos en el período seleccionado</p>
        <?php else: ?>
        <table class="table-informe">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Total fichajes</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fichajesPorDia as $dia): ?>
                <tr>
                    <td><?= date('d/m/Y (l)', strtotime($dia->fecha)) ?></td>
                    <td><strong><?= $dia->total ?></strong></td>
                    <td style="width: 200px;">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?= min(100, $dia->total * 5) ?>%"></div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php elseif ($tipoInforme === 'horas'): ?>
<!-- INFORME DE HORAS -->
<?php
$sqlHoras = "SELECT e.id, e.nombre, e.apellido1, 
                    COALESCE(SUM(rd.minutos_trabajados), 0) as minutos_total,
                    COUNT(DISTINCT rd.fecha) as dias_trabajados
             FROM empleados e
             LEFT JOIN resumen_diario rd ON e.id = rd.empleado_id 
                 AND rd.fecha BETWEEN ? AND ?
             WHERE e.activo = 1";
$paramsHoras = [$fechaDesde, $fechaHasta];

if ($empleadoId) {
    $sqlHoras .= " AND e.id = ?";
    $paramsHoras[] = $empleadoId;
}
if ($centroId) {
    $sqlHoras .= " AND e.id IN (SELECT empleado_id FROM empleados_centros WHERE centro_id = ?)";
    $paramsHoras[] = $centroId;
}

$sqlHoras .= " GROUP BY e.id ORDER BY e.apellido1";

$stmtHoras = $pdo->prepare($sqlHoras);
$stmtHoras->execute($paramsHoras);
$datosHoras = $stmtHoras->fetchAll();
?>

<div class="card">
    <div class="card-header">
        <span class="card-title">🕐 Horas trabajadas por empleado</span>
    </div>
    <div class="card-body">
        <table class="table-informe">
            <thead>
                <tr>
                    <th>Empleado</th>
                    <th>Días trabajados</th>
                    <th>Horas totales</th>
                    <th>Media/día</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($datosHoras as $emp): 
                    $horas = floor($emp->minutos_total / 60);
                    $mins = (int)$emp->minutos_total % 60;
                    $mediaDia = $emp->dias_trabajados > 0 ? round($emp->minutos_total / $emp->dias_trabajados / 60, 1) : 0;
                ?>
                <tr>
                    <td><strong><?= htmlspecialchars($emp->apellido1 . ', ' . $emp->nombre) ?></strong></td>
                    <td><?= $emp->dias_trabajados ?></td>
                    <td><?= $horas ?>h <?= $mins ?>m</td>
                    <td><?= $mediaDia ?>h</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tipoInforme === 'ausencias'): ?>
<!-- INFORME DE AUSENCIAS -->
<?php
$sqlAus = "SELECT t.nombre as tipo, t.color, COUNT(*) as total, SUM(s.dias_solicitados) as dias
           FROM solicitudes_ausencia s
           JOIN tipos_ausencia t ON s.tipo_ausencia_id = t.id
           WHERE s.estado = 'aprobada'
             AND s.fecha_inicio BETWEEN ? AND ?
           GROUP BY t.id
           ORDER BY total DESC";
$stmtAus = $pdo->prepare($sqlAus);
$stmtAus->execute([$fechaDesde, $fechaHasta]);
$datosAus = $stmtAus->fetchAll();
?>

<div class="card">
    <div class="card-header">
        <span class="card-title">📅 Ausencias por tipo</span>
    </div>
    <div class="card-body">
        <?php if (empty($datosAus)): ?>
        <p style="text-align: center; color: #64748b;">No hay ausencias en el período seleccionado</p>
        <?php else: ?>
        <table class="table-informe">
            <thead>
                <tr>
                    <th>Tipo de ausencia</th>
                    <th>Solicitudes</th>
                    <th>Días totales</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($datosAus as $aus): ?>
                <tr>
                    <td>
                        <span style="display: inline-block; width: 12px; height: 12px; border-radius: 50%; background: <?= $aus->color ?>; margin-right: 0.5rem;"></span>
                        <?= htmlspecialchars($aus->tipo) ?>
                    </td>
                    <td><?= $aus->total ?></td>
                    <td><strong><?= $aus->dias ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php else: ?>
<!-- INFORME DE FICHAJES -->
<?php
$sqlFich = "SELECT f.*, e.nombre, e.apellido1, c.nombre as centro
            FROM fichajes f
            JOIN empleados e ON f.empleado_id = e.id
            LEFT JOIN centros c ON f.centro_id = c.id
            WHERE f.fecha BETWEEN ? AND ?";
$paramsFich = [$fechaDesde, $fechaHasta];

if ($empleadoId) {
    $sqlFich .= " AND f.empleado_id = ?";
    $paramsFich[] = $empleadoId;
}

if ($centroId) {
    $sqlFich .= " AND f.centro_id = ?";
    $paramsFich[] = $centroId;
}

$sqlFich .= " ORDER BY f.fecha DESC, f.hora DESC LIMIT 100";

$stmtFich = $pdo->prepare($sqlFich);
$stmtFich->execute($paramsFich);
$fichajes = $stmtFich->fetchAll();
?>

<div class="card">
    <div class="card-header">
        <span class="card-title">⏰ Últimos fichajes</span>
    </div>
    <div class="card-body">
        <table class="table-informe">
            <thead>
                <tr>
                    <th>Fecha/Hora</th>
                    <th>Empleado</th>
                    <th>Tipo</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fichajes as $f): ?>
                <tr>
                    <td><?= date('d/m/Y', strtotime($f->fecha)) ?> <?= substr($f->hora, 0, 5) ?></td>
                    <td><?= htmlspecialchars($f->apellido1 . ', ' . $f->nombre) ?></td>
                    <td><?= ucfirst($f->tipo) ?></td>
                    <td>
                        <span class="badge badge-<?= $f->estado === 'validado' || $f->estado === 'auto_aprobado' ? 'success' : ($f->estado === 'pendiente' ? 'warning' : 'danger') ?>">
                            <?= ucfirst($f->estado) ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
