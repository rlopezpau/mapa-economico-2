<?php
/**
 * LM FICHAJES - Panel Admin: Gestión de Centros de Trabajo
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.1.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

$usuario = obtener_usuario_actual($pdo);

// Verificar permisos
requerir_login();
if (!es_supervisor()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: ../portal.php');
    exit;
}

$accion = $_GET['accion'] ?? 'listar';
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$mensaje = '';
$error = '';

// Procesar formularios POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Token de seguridad inválido.';
    } else {
        $accionPost = $_POST['accion'] ?? '';
        
        if ($accionPost === 'guardar') {
            $datos = [
                'id' => isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null,
                'codigo' => trim(strip_tags($_POST['codigo'] ?? '')),
                'nombre' => trim(strip_tags($_POST['nombre'] ?? '')),
                'direccion' => trim(strip_tags($_POST['direccion'] ?? '')),
                'coordenadas' => trim(strip_tags($_POST['coordenadas'] ?? '')),
                'radio_metros' => (int)($_POST['radio_metros'] ?? 100),
                'activo' => isset($_POST['activo']) ? 1 : 0
            ];
            
            if (empty($datos['nombre'])) {
                $error = 'El nombre del centro es obligatorio';
                $accion = $datos['id'] ? 'editar' : 'nuevo';
                $id = $datos['id'];
            } elseif (!empty($datos['coordenadas']) && !preg_match('/^-?\d+\.?\d*\s*,\s*-?\d+\.?\d*$/', $datos['coordenadas'])) {
                $error = 'Formato de coordenadas incorrecto. Use: latitud, longitud';
                $accion = $datos['id'] ? 'editar' : 'nuevo';
                $id = $datos['id'];
            } else {
                $resultado = guardar_centro($pdo, $datos);
                if ($resultado['exito']) {
                    $mensaje = $resultado['mensaje'];
                    $accion = 'listar';
                    
                    // AUDITORÍA ENS
                    if (function_exists('registrar_auditoria')) {
                        $tipoAccion = $datos['id'] ? 'UPDATE' : 'CREATE';
                        $desc = $datos['id'] ? "Centro actualizado: {$datos['nombre']}" : "Centro creado: {$datos['nombre']}";
                        registrar_auditoria($tipoAccion, $desc, $datos, 'INFO', $usuario->id ?? null, 'centros', $resultado['id'] ?? $datos['id']);
                    }
                } else {
                    $error = $resultado['mensaje'];
                    $accion = $datos['id'] ? 'editar' : 'nuevo';
                    $id = $datos['id'];
                }
            }
        } elseif ($accionPost === 'eliminar') {
            $idEliminar = (int)($_POST['id'] ?? 0);
            $resultado = eliminar_centro($pdo, $idEliminar);
            $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
            $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
            $accion = 'listar';
            
            // AUDITORÍA ENS
            if ($resultado['exito'] && function_exists('registrar_auditoria')) {
                registrar_auditoria('DELETE', "Centro eliminado: ID {$idEliminar}", ['id' => $idEliminar], 'WARNING', $usuario->id ?? null, 'centros', $idEliminar);
            }
        } elseif ($accionPost === 'toggle_activo') {
            $resultado = toggle_centro_activo($pdo, (int)($_POST['id'] ?? 0));
            $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
            $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
            $accion = 'listar';
        }
    }
}

// Obtener datos
$centro = null;
$centros = [];
$empleadosCentro = [];

if (($accion === 'editar' || $accion === 'ver') && $id) {
    $centro = obtener_centro_admin($pdo, $id);
    if (!$centro) {
        $error = 'Centro no encontrado';
        $accion = 'listar';
    } else {
        $empleadosCentro = obtener_empleados_centro($pdo, $id);
    }
}

if ($accion === 'listar') {
    $centros = obtener_centros_admin($pdo);
}

// Variables para layout compartido
$stats = obtener_estadisticas_dashboard($pdo);
$usuario = obtener_usuario_actual($pdo);
$paginaActual = 'centros';
$tituloPagina = 'Centros de Trabajo';

// Usar layout compartido
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<?php if ($mensaje): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($mensaje); ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger">❌ <?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<?php if ($accion === 'listar'): ?>
<!-- LISTADO -->
<div class="page-header">
    <div>
        <h1 class="page-title">Centros de Trabajo</h1>
        <p style="color: #64748b; margin: 0;">Gestiona los centros donde los empleados pueden fichar</p>
    </div>
    <a href="?accion=nuevo" class="btn btn-primary">➕ Nuevo Centro</a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($centros)): ?>
        <div style="text-align: center; padding: 3rem; color: #64748b;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🏛️</div>
            <h3 style="color: #1e293b; margin-bottom: 0.5rem;">No hay centros registrados</h3>
            <p>Crea el primer centro de trabajo</p>
            <a href="?accion=nuevo" class="btn btn-primary" style="margin-top: 1rem;">➕ Crear Centro</a>
        </div>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Centro</th>
                    <th>Coordenadas</th>
                    <th>Radio</th>
                    <th>Empleados</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($centros as $c): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($c->nombre); ?></strong>
                        <?php if (!empty($c->codigo)): ?> <span class="badge badge-info"><?php echo htmlspecialchars($c->codigo); ?></span><?php endif; ?>
                        <?php if (!empty($c->direccion)): ?><div style="font-size: 0.8rem; color: #64748b;"><?php echo htmlspecialchars($c->direccion); ?></div><?php endif; ?>
                    </td>
                    <td><?php if (!empty($c->coordenadas)): ?><a href="https://www.google.com/maps?q=<?php echo urlencode($c->coordenadas); ?>" target="_blank">📍 <?php echo htmlspecialchars($c->coordenadas); ?></a><?php else: ?>-<?php endif; ?></td>
                    <td><?php echo $c->radio_metros; ?>m</td>
                    <td><span class="badge badge-info"><?php echo $c->num_empleados; ?></span></td>
                    <td><?php echo $c->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?></td>
                    <td>
                        <div style="display: flex; gap: 0.375rem;">
                            <a href="?accion=ver&id=<?php echo $c->id; ?>" class="btn btn-outline btn-sm">👁️</a>
                            <a href="?accion=editar&id=<?php echo $c->id; ?>" class="btn btn-outline btn-sm">✏️</a>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('¿Cambiar estado?')">
                                <?= csrf_campo() ?>
                                <input type="hidden" name="accion" value="toggle_activo">
                                <input type="hidden" name="id" value="<?php echo $c->id; ?>">
                                <button type="submit" class="btn btn-outline btn-sm"><?php echo $c->activo ? '🔴' : '🟢'; ?></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php elseif ($accion === 'nuevo' || $accion === 'editar'): ?>
<!-- FORMULARIO -->
<div class="page-header">
    <div>
        <h1 class="page-title"><?php echo $accion === 'nuevo' ? '➕ Nuevo Centro' : '✏️ Editar Centro'; ?></h1>
    </div>
    <a href="?accion=listar" class="btn btn-outline">← Volver</a>
</div>

<div class="card">
    <div class="card-header"><span class="card-title">📋 Datos del Centro</span></div>
    <div class="card-body">
        <form method="POST" id="formCentro">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="guardar">
            <?php if ($centro): ?><input type="hidden" name="id" value="<?php echo $centro->id; ?>"><?php endif; ?>
            
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Código <small style="color: #64748b;">(opcional)</small></label>
                    <input type="text" name="codigo" class="form-control" value="<?php echo $centro ? htmlspecialchars($centro->codigo ?? '') : ''; ?>" placeholder="Ej: CT-001" maxlength="20">
                </div>
                <div class="form-group">
                    <label class="form-label">Nombre <span class="required">*</span></label>
                    <input type="text" name="nombre" class="form-control" required value="<?php echo $centro ? htmlspecialchars($centro->nombre) : ''; ?>" placeholder="Ej: Oficina Central">
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Dirección completa</label>
                <input type="text" name="direccion" id="direccion" class="form-control" value="<?php echo $centro ? htmlspecialchars($centro->direccion ?? '') : ''; ?>" placeholder="Ej: Calle Mayor, 15 - 46001 Valencia">
                <div class="form-hint">Incluye calle, número, código postal y ciudad</div>
            </div>
            
            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0;">
                <h3 style="font-weight: 600; color: #1e293b; margin-bottom: 1rem;">📍 Geolocalización</h3>
                
                <div class="form-group">
                    <label class="form-label">Paso 1: Buscar ubicación en Google Maps</label>
                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <button type="button" class="btn btn-primary" onclick="buscarDireccionEnMaps()">🔍 Buscar Dirección en Google Maps</button>
                        <button type="button" class="btn btn-outline" onclick="mostrarAyudaCoordenadas()">❓ Cómo obtener coordenadas</button>
                    </div>
                    <div class="form-hint">Se abrirá Google Maps con la dirección. Haz clic derecho en la ubicación exacta y copia las coordenadas.</div>
                </div>
                
                <div id="ayudaCoordenadas" style="display: none; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem;">
                    <strong>📋 Cómo obtener coordenadas de Google Maps:</strong>
                    <ol style="margin: 0.5rem 0 0 1.5rem; color: #475569;">
                        <li>Haz clic en "Buscar Dirección en Google Maps"</li>
                        <li>En Google Maps, navega hasta la ubicación exacta del centro</li>
                        <li>Haz <strong>clic derecho</strong> sobre el punto exacto</li>
                        <li>Aparecerán las coordenadas en la parte superior del menú</li>
                        <li>Haz <strong>clic en las coordenadas</strong> para copiarlas</li>
                        <li>Vuelve aquí y <strong>pega</strong> (Ctrl+V) en el campo de coordenadas</li>
                    </ol>
                    <button type="button" class="btn btn-sm btn-outline" onclick="document.getElementById('ayudaCoordenadas').style.display='none'" style="margin-top: 0.75rem;">Cerrar ayuda</button>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Paso 2: Pegar coordenadas</label>
                    <div style="display: flex; gap: 0.5rem;">
                        <input type="text" name="coordenadas" id="coordenadas" class="form-control" value="<?php echo $centro ? htmlspecialchars($centro->coordenadas ?? '') : ''; ?>" placeholder="Pega aquí las coordenadas (ej: 39.4699, -0.3763)">
                        <button type="button" class="btn btn-success" onclick="verificarCoordenadas()">✓ Verificar</button>
                    </div>
                    <div class="form-hint" id="coordsStatus">Formato: latitud, longitud (ejemplo: 39.4699, -0.3763)</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Radio permitido para fichar</label>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <input type="number" name="radio_metros" id="radio_metros" class="form-control" style="width: 120px;" value="<?php echo $centro ? $centro->radio_metros : 100; ?>" min="10" max="5000" step="10">
                        <span>metros</span>
                    </div>
                    <div class="form-hint">Distancia máxima desde el centro donde se permite fichar</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Mapa de verificación</label>
                    <div id="mapContainer" style="background: #f1f5f9; border-radius: 0.5rem; height: 200px; display: flex; align-items: center; justify-content: center; color: #64748b; overflow: hidden; border: 1px solid #e2e8f0;">
                        <?php if ($centro && !empty($centro->coordenadas)): ?>
                        <div style="text-align: center;">
                            <div style="font-size: 3rem; margin-bottom: 0.5rem;">📍</div>
                            <p style="margin-bottom: 1rem;"><strong><?php echo htmlspecialchars($centro->coordenadas); ?></strong></p>
                            <a href="https://www.google.com/maps?q=<?php echo urlencode($centro->coordenadas); ?>" target="_blank" class="btn btn-primary">🗺️ Ver en Google Maps</a>
                        </div>
                        <?php else: ?>
                        <div style="text-align: center;">
                            <div style="font-size: 3rem; margin-bottom: 0.5rem;">🗺️</div>
                            <p>Introduce las coordenadas y haz clic en Verificar</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <?php if ($centro): ?>
            <div class="form-group" style="margin-top: 1.5rem;">
                <label class="form-check">
                    <input type="checkbox" name="activo" <?php echo $centro->activo ? 'checked' : ''; ?>>
                    Centro activo
                </label>
            </div>
            <?php endif; ?>
            
            <div style="display: flex; justify-content: center; gap: 1rem; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0;">
                <a href="?accion=listar" class="btn btn-outline">Cancelar</a>
                <button type="submit" class="btn btn-success">💾 <?php echo $accion === 'nuevo' ? 'Crear Centro' : 'Guardar Cambios'; ?></button>
            </div>
        </form>
    </div>
</div>

<?php if ($accion === 'editar' && $centro && count($empleadosCentro) > 0): ?>
<div class="card">
    <div class="card-header"><span class="card-title">👥 Empleados asignados (<?php echo count($empleadosCentro); ?>)</span></div>
    <div class="card-body">
        <?php foreach ($empleadosCentro as $emp): ?>
        <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background: #f8fafc; border-radius: 0.5rem; margin-bottom: 0.5rem;">
            <div style="width: 2.5rem; height: 2.5rem; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: #64748b;"><?php echo strtoupper(substr($emp->nombre, 0, 1)); ?></div>
            <div style="flex: 1;">
                <div style="font-weight: 500; color: #1e293b;"><?php echo nombre_completo_empleado($emp); ?></div>
                <div style="font-size: 0.8rem; color: #64748b;"><?php echo $emp->horario_nombre ?? 'Sin horario'; ?></div>
            </div>
            <?php if ($emp->es_principal): ?><span style="font-size: 0.75rem; background: #fef3c7; color: #92400e; padding: 0.25rem 0.5rem; border-radius: 0.25rem;">Principal</span><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php elseif ($accion === 'ver' && $centro): ?>
<!-- VER DETALLE -->
<div class="page-header">
    <div>
        <h1 class="page-title"><?php echo htmlspecialchars($centro->nombre); ?></h1>
        <p style="color: #64748b; margin: 0;"><?php echo !empty($centro->codigo) ? 'Código: ' . htmlspecialchars($centro->codigo) : 'Centro de trabajo'; ?></p>
    </div>
    <div style="display: flex; gap: 0.5rem;">
        <a href="?accion=editar&id=<?php echo $centro->id; ?>" class="btn btn-primary">✏️ Editar</a>
        <a href="?accion=listar" class="btn btn-outline">← Volver</a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title">📋 Información</span>
        <?php echo $centro->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?>
    </div>
    <div class="card-body">
        <div class="info-grid">
            <div class="info-item"><div class="info-label">Dirección</div><div class="info-value"><?php echo !empty($centro->direccion) ? htmlspecialchars($centro->direccion) : '-'; ?></div></div>
            <div class="info-item"><div class="info-label">Coordenadas</div><div class="info-value"><?php if (!empty($centro->coordenadas)): ?><?php echo htmlspecialchars($centro->coordenadas); ?> <a href="https://www.google.com/maps?q=<?php echo urlencode($centro->coordenadas); ?>" target="_blank">Ver mapa →</a><?php else: ?>-<?php endif; ?></div></div>
            <div class="info-item"><div class="info-label">Radio</div><div class="info-value"><?php echo $centro->radio_metros; ?> metros</div></div>
            <div class="info-item"><div class="info-label">Empleados</div><div class="info-value"><?php echo $centro->num_empleados; ?></div></div>
        </div>
        <?php if (!empty($centro->coordenadas)): ?>
        <div style="margin-top: 1.5rem; background: #f1f5f9; border-radius: 0.5rem; padding: 2rem; text-align: center;">
            <div style="font-size: 3rem; margin-bottom: 0.5rem;">📍</div>
            <p style="margin-bottom: 1rem;"><strong><?php echo htmlspecialchars($centro->coordenadas); ?></strong></p>
            <a href="https://www.google.com/maps?q=<?php echo urlencode($centro->coordenadas); ?>" target="_blank" class="btn btn-primary">🗺️ Ver ubicación en Google Maps</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if (count($empleadosCentro) > 0): ?>
<div class="card">
    <div class="card-header"><span class="card-title">👥 Empleados (<?php echo count($empleadosCentro); ?>)</span></div>
    <div class="card-body">
        <?php foreach ($empleadosCentro as $emp): ?>
        <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background: #f8fafc; border-radius: 0.5rem; margin-bottom: 0.5rem;">
            <div style="width: 2.5rem; height: 2.5rem; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: #64748b;"><?php echo strtoupper(substr($emp->nombre, 0, 1)); ?></div>
            <div style="flex: 1;">
                <div style="font-weight: 500;"><a href="empleados.php?accion=editar&id=<?php echo $emp->id; ?>" style="color: #1e293b; text-decoration: none;"><?php echo nombre_completo_empleado($emp); ?></a></div>
                <div style="font-size: 0.8rem; color: #64748b;"><?php echo $emp->horario_nombre ?? 'Sin horario'; ?></div>
            </div>
            <?php if ($emp->es_principal): ?><span style="font-size: 0.75rem; background: #fef3c7; color: #92400e; padding: 0.25rem 0.5rem; border-radius: 0.25rem;">Principal</span><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php if ($centro->num_empleados == 0): ?>
<div class="card" style="border-color: #fca5a5;">
    <div class="card-header" style="background: #fef2f2;"><span class="card-title" style="color: #991b1b;">⚠️ Zona de peligro</span></div>
    <div class="card-body">
        <p style="margin-bottom: 1rem; color: #64748b;">Este centro no tiene empleados y puede eliminarse.</p>
        <form method="POST" onsubmit="return confirm('¿Eliminar este centro? No se puede deshacer.')">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="eliminar">
            <input type="hidden" name="id" value="<?php echo $centro->id; ?>">
            <button type="submit" class="btn btn-danger">🗑️ Eliminar Centro</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php endif; ?>

<script>
function buscarDireccionEnMaps() {
    var direccion = document.getElementById('direccion').value.trim();
    if (!direccion) {
        alert('Primero escribe la dirección del centro en el campo "Dirección completa"');
        document.getElementById('direccion').focus();
        return;
    }
    window.open('https://www.google.com/maps/search/' + encodeURIComponent(direccion), '_blank');
}

function mostrarAyudaCoordenadas() {
    var ayuda = document.getElementById('ayudaCoordenadas');
    ayuda.style.display = ayuda.style.display === 'none' ? 'block' : 'none';
}

function verificarCoordenadas() {
    var coords = document.getElementById('coordenadas').value.trim();
    var status = document.getElementById('coordsStatus');
    
    if (!coords) {
        status.innerHTML = '❌ <span style="color:#dc2626">Introduce las coordenadas copiadas de Google Maps</span>';
        return;
    }
    
    var regex = /^-?\d+\.?\d*\s*,\s*-?\d+\.?\d*$/;
    if (!regex.test(coords)) {
        status.innerHTML = '❌ <span style="color:#dc2626">Formato incorrecto. Debe ser: latitud, longitud (ej: 39.4699, -0.3763)</span>';
        return;
    }
    
    status.innerHTML = '✅ <span style="color:#16a34a">Coordenadas válidas</span>';
    document.getElementById('mapContainer').innerHTML = '<div style="text-align:center;padding:2rem;"><div style="font-size:3rem;margin-bottom:0.5rem;">📍</div><p style="margin-bottom:1rem;"><strong>' + coords + '</strong></p><a href="https://www.google.com/maps?q=' + encodeURIComponent(coords) + '" target="_blank" class="btn btn-primary">🗺️ Ver en Google Maps</a></div>';
}

document.getElementById('coordenadas')?.addEventListener('paste', function() {
    setTimeout(verificarCoordenadas, 100);
});

document.getElementById('coordenadas')?.addEventListener('blur', function() {
    if (this.value.trim()) verificarCoordenadas();
});
</script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
