<?php
/**
 * VISOR DE LOGS - SOLO ADMINISTRADORES
 */

require_once '../config.php';
require_once '../includes/auth.php';

requerir_login();
if (!es_admin()) {
    header('HTTP/1.1 403 Forbidden');
    die('Acceso denegado. Solo administradores.');
}

$log_file = '../logs/php_errors.log';
$lineas = 100; // Últimas 100 líneas

$contenido = '';
if (file_exists($log_file)) {
    $file = new SplFileObject($log_file);
    $file->seek(PHP_INT_MAX);
    $total_lines = $file->key();
    
    $start = max(0, $total_lines - $lineas);
    $file->seek($start);
    
    while (!$file->eof()) {
        $contenido .= htmlspecialchars($file->fgets());
    }
} else {
    $contenido = 'No hay archivo de log o está vacío.';
}

// Registrar acceso
require_once '../includes/auditoria.php';
registrar_auditoria($pdo, 'VER_LOGS', 'Acceso al visor de logs');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Logs del Sistema - LM Fichajes</title>
    <style>
        body { font-family: system-ui, sans-serif; padding: 20px; background: #1e293b; color: #e2e8f0; }
        h1 { color: #60a5fa; }
        pre { background: #0f172a; padding: 20px; border-radius: 8px; overflow-x: auto; font-size: 0.75rem; line-height: 1.5; max-height: 70vh; overflow-y: auto; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #3b82f6; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .warning { color: #fbbf24; }
        .error { color: #f87171; }
    </style>
</head>
<body>
    <a href="index.php" class="back-btn">← Volver al Admin</a>
    <h1>📋 Logs del Sistema</h1>
    <p>Mostrando últimas <?php echo $lineas; ?> líneas de <code>logs/php_errors.log</code></p>
    <pre><?php echo $contenido ?: 'Sin errores registrados.'; ?></pre>
    <p style="color: #64748b; font-size: 0.75rem;">
        ⚠️ Este acceso queda registrado en auditoría.
    </p>
</body>
</html>
