<?php
/**
 * LM FICHAJES - Gestión de Incidencias de Fichajes
 * 
 * Panel para que el administrador vea y corrija:
 * - Fichajes de entrada sin salida
 * - Salidas sin entrada
 * - Fichajes fuera de horario pendientes de validar
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/../config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/fichajes.php';

establecer_headers_seguridad();

// Verificar autenticación y permisos
$usuario = obtener_usuario_actual($pdo);
if (!$usuario || !in_array($usuario->rol, ['admin', 'rrhh', 'supervisor'])) {
    header('Location: ../login.php');
    exit;
}

$mensaje = '';
$error = '';

// ============================================================================
// PROCESAR ACCIONES
// ============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $accion = $_POST['accion'] ?? '';
    
    // CORREGIR FICHAJE SIN SALIDA
    if ($accion === 'corregir_salida') {
        $fichajeId = (int)($_POST['fichaje_id'] ?? 0);
        $horaSalida = $_POST['hora_salida'] ?? '';
        $observacion = trim($_POST['observacion'] ?? '');
        
        if ($fichajeId && $horaSalida) {
            try {
                // Obtener el fichaje de entrada
                $stmt = $pdo->prepare("SELECT * FROM fichajes WHERE id = ? AND tipo = 'entrada'");
                $stmt->execute([$fichajeId]);
                $entrada = $stmt->fetch();
                
                if ($entrada) {
                    // Validar que la hora de salida sea posterior a la entrada
                    if ($horaSalida <= $entrada->hora) {
                        $error = 'La hora de salida debe ser posterior a la entrada (' . substr($entrada->hora, 0, 5) . ')';
                    } else {
                        // Crear fichaje de salida
                        $stmt = $pdo->prepare("
                            INSERT INTO fichajes (
                                empleado_id, centro_id, fecha, hora, tipo, modo,
                                estado, observacion, ip_address, created_at
                            ) VALUES (?, ?, ?, ?, 'salida', ?, 'validado', ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $entrada->empleado_id,
                            $entrada->centro_id,
                            $entrada->fecha,
                            $horaSalida,
                            $entrada->modo,
                            'Salida añadida por ' . $usuario->nombre . ': ' . $observacion,
                            $_SERVER['REMOTE_ADDR']
                        ]);
                        
                        // Actualizar resumen diario
                        if (function_exists('actualizar_resumen_diario')) {
                            actualizar_resumen_diario($pdo, $entrada->empleado_id, $entrada->fecha);
                        }
                        
                        // Auditoría
                        if (function_exists('registrar_auditoria')) {
                            registrar_auditoria('FICHAJE_CORREGIDO', 
                                "Salida añadida manualmente para entrada ID {$fichajeId}", 
                                ['fichaje_entrada' => $fichajeId, 'hora_salida' => $horaSalida],
                                'INFO', $usuario->id, 'fichajes', $fichajeId);
                        }
                        
                        $mensaje = 'Salida registrada correctamente para el día ' . date('d/m/Y', strtotime($entrada->fecha));
                    }
                } else {
                    $error = 'Fichaje no encontrado';
                }
            } catch (PDOException $e) {
                $error = 'Error al guardar: ' . $e->getMessage();
            }
        } else {
            $error = 'Debe indicar la hora de salida';
        }
    }
    
    // MARCAR COMO INCIDENCIA JUSTIFICADA
    if ($accion === 'justificar') {
        $fichajeId = (int)($_POST['fichaje_id'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? '');
        
        if ($fichajeId && $motivo) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE fichajes 
                    SET observacion = CONCAT(COALESCE(observacion, ''), ' [Justificado por {$usuario->nombre}: ', ?, ']'),
                        estado = 'validado'
                    WHERE id = ?
                ");
                $stmt->execute([$motivo, $fichajeId]);
                $mensaje = 'Incidencia justificada correctamente';
            } catch (PDOException $e) {
                $error = 'Error al justificar';
            }
        }
    }
    
    // RECHAZAR FICHAJE
    if ($accion === 'rechazar') {
        $fichajeId = (int)($_POST['fichaje_id'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? '');
        
        if ($fichajeId) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE fichajes 
                    SET estado = 'rechazado',
                        observacion = CONCAT(COALESCE(observacion, ''), ' [Rechazado por {$usuario->nombre}: ', ?, ']')
                    WHERE id = ?
                ");
                $stmt->execute([$motivo ?: 'Sin motivo', $fichajeId]);
                $mensaje = 'Fichaje rechazado';
            } catch (PDOException $e) {
                $error = 'Error al rechazar';
            }
        }
    }
}

// ============================================================================
// OBTENER INCIDENCIAS
// ============================================================================

// Filtros
$filtroEmpleado = $_GET['empleado'] ?? '';
$filtroFechaDesde = $_GET['fecha_desde'] ?? date('Y-m-01');
$filtroFechaHasta = $_GET['fecha_hasta'] ?? date('Y-m-d');

// 1. Fichajes de ENTRADA sin SALIDA (de días anteriores a hoy)
$sqlSinSalida = "
    SELECT 
        f.id,
        f.empleado_id,
        e.nombre,
        e.apellido1,
        e.apellido2,
        f.fecha,
        f.hora as hora_entrada,
        f.centro_id,
        c.nombre as centro_nombre,
        f.modo,
        f.estado,
        DATEDIFF(CURDATE(), f.fecha) as dias_abierto
    FROM fichajes f
    JOIN empleados e ON f.empleado_id = e.id
    LEFT JOIN centros c ON f.centro_id = c.id
    WHERE f.tipo = 'entrada'
      AND f.fecha < CURDATE()
      AND f.fecha BETWEEN ? AND ?
      AND f.estado != 'rechazado'
      AND NOT EXISTS (
          SELECT 1 FROM fichajes f2 
          WHERE f2.empleado_id = f.empleado_id 
            AND f2.fecha = f.fecha 
            AND f2.tipo = 'salida'
            AND f2.estado != 'rechazado'
            AND f2.hora > f.hora
      )
";
$paramsSinSalida = [$filtroFechaDesde, $filtroFechaHasta];

if ($filtroEmpleado) {
    $sqlSinSalida .= " AND f.empleado_id = ?";
    $paramsSinSalida[] = $filtroEmpleado;
}
$sqlSinSalida .= " ORDER BY f.fecha DESC, e.apellido1";

$stmt = $pdo->prepare($sqlSinSalida);
$stmt->execute($paramsSinSalida);
$fichajesSinSalida = $stmt->fetchAll();

// 2. Fichajes PENDIENTES de validación
$sqlPendientes = "
    SELECT 
        f.id,
        f.empleado_id,
        e.nombre,
        e.apellido1,
        f.fecha,
        f.hora,
        f.tipo,
        f.fuera_horario,
        f.fuera_ubicacion,
        f.distancia_metros,
        f.observacion,
        c.nombre as centro_nombre
    FROM fichajes f
    JOIN empleados e ON f.empleado_id = e.id
    LEFT JOIN centros c ON f.centro_id = c.id
    WHERE f.estado = 'pendiente'
      AND f.fecha BETWEEN ? AND ?
";
$paramsPendientes = [$filtroFechaDesde, $filtroFechaHasta];

if ($filtroEmpleado) {
    $sqlPendientes .= " AND f.empleado_id = ?";
    $paramsPendientes[] = $filtroEmpleado;
}
$sqlPendientes .= " ORDER BY f.fecha DESC, f.hora DESC";

$stmt = $pdo->prepare($sqlPendientes);
$stmt->execute($paramsPendientes);
$fichajesPendientes = $stmt->fetchAll();

// Lista de empleados para filtro
$empleados = $pdo->query("SELECT id, nombre, apellido1 FROM empleados WHERE activo = 1 ORDER BY apellido1")->fetchAll();

// Contadores para el resumen
$totalSinSalida = count($fichajesSinSalida);
$totalPendientes = count($fichajesPendientes);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incidencias de Fichajes - LM Fichajes</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #1a365d;
        }
        .header {
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 22px; }
        .header a { color: white; text-decoration: none; opacity: 0.9; }
        .header a:hover { opacity: 1; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 30px; }
        
        .resumen {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .resumen-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            text-align: center;
        }
        .resumen-card.alerta { border-left: 4px solid #ef4444; }
        .resumen-card.warning { border-left: 4px solid #f59e0b; }
        .resumen-card .numero {
            font-size: 36px;
            font-weight: 700;
            color: #1a365d;
        }
        .resumen-card.alerta .numero { color: #ef4444; }
        .resumen-card.warning .numero { color: #f59e0b; }
        .resumen-card .label { color: #64748b; font-size: 14px; }
        
        .filtros {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .filtros form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: end;
        }
        .filtro-grupo { display: flex; flex-direction: column; gap: 5px; }
        .filtro-grupo label { font-size: 12px; color: #64748b; font-weight: 600; }
        .filtro-grupo input, .filtro-grupo select {
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-primary { background: #3b82f6; color: white; }
        .btn-primary:hover { background: #2563eb; }
        .btn-success { background: #10b981; color: white; }
        .btn-success:hover { background: #059669; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-danger:hover { background: #dc2626; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        .seccion {
            background: white;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .seccion-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .seccion-header h2 { font-size: 16px; display: flex; align-items: center; gap: 10px; }
        .badge {
            background: #ef4444;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #f1f5f9; }
        th { background: #f8fafc; font-weight: 600; font-size: 12px; color: #64748b; text-transform: uppercase; }
        tr:hover { background: #f8fafc; }
        
        .estado {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .estado-pendiente { background: #fef3c7; color: #92400e; }
        .estado-alerta { background: #fee2e2; color: #dc2626; }
        
        .acciones { display: flex; gap: 8px; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal.activo { display: flex; }
        .modal-content {
            background: white;
            border-radius: 16px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
        }
        .modal-content h3 { margin-bottom: 20px; }
        .modal-content .form-grupo { margin-bottom: 15px; }
        .modal-content label { display: block; margin-bottom: 5px; font-weight: 600; }
        .modal-content input, .modal-content textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }
        .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
        
        .mensaje { padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; }
        .mensaje-exito { background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; }
        .mensaje-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        
        .empty-state {
            padding: 40px;
            text-align: center;
            color: #64748b;
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>⚠️ Incidencias de Fichajes</h1>
        <a href="index.php">← Volver al panel</a>
    </div>
    
    <div class="container">
        <?php if ($mensaje): ?>
            <div class="mensaje mensaje-exito">✅ <?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="mensaje mensaje-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Resumen -->
        <div class="resumen">
            <div class="resumen-card alerta">
                <div class="numero"><?= $totalSinSalida ?></div>
                <div class="label">Fichajes sin cerrar</div>
            </div>
            <div class="resumen-card warning">
                <div class="numero"><?= $totalPendientes ?></div>
                <div class="label">Pendientes de validar</div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="filtros">
            <form method="GET">
                <div class="filtro-grupo">
                    <label>Empleado</label>
                    <select name="empleado">
                        <option value="">Todos</option>
                        <?php foreach ($empleados as $e): ?>
                            <option value="<?= $e->id ?>" <?= $filtroEmpleado == $e->id ? 'selected' : '' ?>>
                                <?= htmlspecialchars($e->apellido1 . ', ' . $e->nombre) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filtro-grupo">
                    <label>Desde</label>
                    <input type="date" name="fecha_desde" value="<?= $filtroFechaDesde ?>">
                </div>
                <div class="filtro-grupo">
                    <label>Hasta</label>
                    <input type="date" name="fecha_hasta" value="<?= $filtroFechaHasta ?>">
                </div>
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </form>
        </div>
        
        <!-- Fichajes sin salida -->
        <div class="seccion">
            <div class="seccion-header">
                <h2>🚨 Fichajes sin cerrar <span class="badge"><?= $totalSinSalida ?></span></h2>
            </div>
            <?php if (empty($fichajesSinSalida)): ?>
                <div class="empty-state">
                    <div class="icon">✅</div>
                    <p>No hay fichajes pendientes de cerrar</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Empleado</th>
                            <th>Fecha</th>
                            <th>Entrada</th>
                            <th>Centro</th>
                            <th>Días abierto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fichajesSinSalida as $f): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($f->apellido1 . ' ' . ($f->apellido2 ?? '') . ', ' . $f->nombre) ?></strong></td>
                                <td><?= date('d/m/Y', strtotime($f->fecha)) ?></td>
                                <td><?= substr($f->hora_entrada, 0, 5) ?></td>
                                <td><?= htmlspecialchars($f->centro_nombre ?? '-') ?></td>
                                <td>
                                    <span class="estado estado-alerta"><?= $f->dias_abierto ?> día(s)</span>
                                </td>
                                <td class="acciones">
                                    <button class="btn btn-success btn-sm" onclick="abrirModalSalida(<?= $f->id ?>, '<?= $f->fecha ?>', '<?= substr($f->hora_entrada, 0, 5) ?>', '<?= htmlspecialchars($f->nombre) ?>')">
                                        + Añadir salida
                                    </button>
                                    <button class="btn btn-danger btn-sm" onclick="abrirModalRechazar(<?= $f->id ?>)">
                                        Rechazar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <!-- Fichajes pendientes de validación -->
        <div class="seccion">
            <div class="seccion-header">
                <h2>⏳ Pendientes de validación <span class="badge" style="background:#f59e0b"><?= $totalPendientes ?></span></h2>
            </div>
            <?php if (empty($fichajesPendientes)): ?>
                <div class="empty-state">
                    <div class="icon">✅</div>
                    <p>No hay fichajes pendientes de validar</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Empleado</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Tipo</th>
                            <th>Incidencia</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fichajesPendientes as $f): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($f->apellido1 . ', ' . $f->nombre) ?></strong></td>
                                <td><?= date('d/m/Y', strtotime($f->fecha)) ?></td>
                                <td><?= substr($f->hora, 0, 5) ?></td>
                                <td><?= ucfirst($f->tipo) ?></td>
                                <td>
                                    <?php if ($f->fuera_horario): ?>
                                        <span class="estado estado-pendiente">Fuera de horario</span>
                                    <?php endif; ?>
                                    <?php if ($f->fuera_ubicacion): ?>
                                        <span class="estado estado-pendiente">Fuera ubicación (<?= $f->distancia_metros ?>m)</span>
                                    <?php endif; ?>
                                </td>
                                <td class="acciones">
                                    <form method="POST" style="display:inline">
                                        <?= csrf_campo() ?>
                                        <input type="hidden" name="accion" value="justificar">
                                        <input type="hidden" name="fichaje_id" value="<?= $f->id ?>">
                                        <input type="hidden" name="motivo" value="Validado manualmente">
                                        <button type="submit" class="btn btn-success btn-sm">✓ Validar</button>
                                    </form>
                                    <button class="btn btn-danger btn-sm" onclick="abrirModalRechazar(<?= $f->id ?>)">✗ Rechazar</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal añadir salida -->
    <div class="modal" id="modalSalida">
        <div class="modal-content">
            <h3>➕ Añadir hora de salida</h3>
            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="corregir_salida">
                <input type="hidden" name="fichaje_id" id="salida_fichaje_id">
                
                <div class="form-grupo">
                    <label>Empleado</label>
                    <input type="text" id="salida_empleado" readonly>
                </div>
                
                <div class="form-grupo">
                    <label>Fecha</label>
                    <input type="text" id="salida_fecha" readonly>
                </div>
                
                <div class="form-grupo">
                    <label>Entrada registrada</label>
                    <input type="text" id="salida_entrada" readonly>
                </div>
                
                <div class="form-grupo">
                    <label>Hora de salida real *</label>
                    <input type="time" name="hora_salida" id="salida_hora" required>
                </div>
                
                <div class="form-grupo">
                    <label>Observaciones</label>
                    <textarea name="observacion" rows="2" placeholder="Motivo del olvido, quién reportó, etc."></textarea>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn" onclick="cerrarModal('modalSalida')">Cancelar</button>
                    <button type="submit" class="btn btn-success">Guardar salida</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal rechazar -->
    <div class="modal" id="modalRechazar">
        <div class="modal-content">
            <h3>❌ Rechazar fichaje</h3>
            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="rechazar">
                <input type="hidden" name="fichaje_id" id="rechazar_fichaje_id">
                
                <div class="form-grupo">
                    <label>Motivo del rechazo</label>
                    <textarea name="motivo" rows="3" placeholder="Explique por qué se rechaza este fichaje"></textarea>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn" onclick="cerrarModal('modalRechazar')">Cancelar</button>
                    <button type="submit" class="btn btn-danger">Rechazar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function abrirModalSalida(id, fecha, horaEntrada, empleado) {
            document.getElementById('salida_fichaje_id').value = id;
            document.getElementById('salida_empleado').value = empleado;
            document.getElementById('salida_fecha').value = fecha;
            document.getElementById('salida_entrada').value = horaEntrada;
            document.getElementById('salida_hora').value = '';
            document.getElementById('modalSalida').classList.add('activo');
        }
        
        function abrirModalRechazar(id) {
            document.getElementById('rechazar_fichaje_id').value = id;
            document.getElementById('modalRechazar').classList.add('activo');
        }
        
        function cerrarModal(id) {
            document.getElementById(id).classList.remove('activo');
        }
        
        // Cerrar modal con Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal').forEach(m => m.classList.remove('activo'));
            }
        });
        
        // Cerrar modal al hacer clic fuera
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('activo');
                }
            });
        });
    </script>
</body>
</html>
