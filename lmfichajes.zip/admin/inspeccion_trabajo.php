<?php
/**
 * LM FICHAJES - Panel Admin: Gestión Accesos Inspección de Trabajo
 * 
 * Permite crear códigos de acceso temporales para la Inspección de Trabajo
 * según los requisitos del RD 8/2019.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos - solo admin
requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'Solo administradores pueden gestionar accesos de inspección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';

// ============================================================================
// CREAR TABLA SI NO EXISTE
// ============================================================================
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS inspeccion_accesos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            codigo VARCHAR(32) NOT NULL UNIQUE,
            nombre_inspector VARCHAR(100) NOT NULL,
            organismo VARCHAR(150) DEFAULT 'Inspección de Trabajo y Seguridad Social',
            motivo TEXT,
            fecha_desde DATE NOT NULL,
            fecha_hasta DATE NOT NULL,
            fecha_expiracion DATETIME NOT NULL,
            usos_restantes INT DEFAULT NULL COMMENT 'NULL = ilimitados',
            activo TINYINT(1) DEFAULT 1,
            total_accesos INT DEFAULT 0,
            ultimo_acceso DATETIME DEFAULT NULL,
            creado_por INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_codigo (codigo),
            INDEX idx_activo_expiracion (activo, fecha_expiracion)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {
    // Tabla ya existe o error menor
}

// ============================================================================
// PROCESAR ACCIONES
// ============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $accion = $_POST['accion'] ?? '';
    
    // CREAR NUEVO ACCESO
    if ($accion === 'crear_acceso') {
        $nombre = sanitizar($_POST['nombre_inspector'] ?? '');
        $organismo = sanitizar($_POST['organismo'] ?? 'Inspección de Trabajo y Seguridad Social');
        $motivo = sanitizar($_POST['motivo'] ?? '');
        $fechaDesde = $_POST['fecha_desde'] ?? '';
        $fechaHasta = $_POST['fecha_hasta'] ?? '';
        $diasValido = (int)($_POST['dias_valido'] ?? 7);
        $usosMax = $_POST['usos_max'] ?? '';
        
        if (empty($nombre) || empty($fechaDesde) || empty($fechaHasta)) {
            $error = 'Complete todos los campos obligatorios';
        } elseif ($fechaDesde > $fechaHasta) {
            $error = 'La fecha desde no puede ser mayor que hasta';
        } else {
            // Generar código único
            $codigo = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8) . '-' . substr(bin2hex(random_bytes(4)), 0, 8));
            $fechaExpiracion = date('Y-m-d H:i:s', strtotime("+{$diasValido} days"));
            $usosRestantes = $usosMax !== '' ? (int)$usosMax : null;
            
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO inspeccion_accesos 
                    (codigo, nombre_inspector, organismo, motivo, fecha_desde, fecha_hasta, fecha_expiracion, usos_restantes, creado_por)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$codigo, $nombre, $organismo, $motivo, $fechaDesde, $fechaHasta, $fechaExpiracion, $usosRestantes, $usuario->id]);
                
                $mensaje = "Código de acceso creado: <strong>{$codigo}</strong>";
                
                // Auditoría ENS
                if (function_exists('registrar_auditoria')) {
                    registrar_auditoria('INSPECCION_CODIGO_CREADO', "Código IT creado para: {$nombre}", 
                        ['codigo' => $codigo, 'inspector' => $nombre, 'periodo' => "{$fechaDesde} a {$fechaHasta}"], 
                        'WARNING', $usuario->id, 'inspeccion_accesos', $pdo->lastInsertId());
                }
            } catch (PDOException $e) {
                $error = 'Error al crear el código de acceso';
            }
        }
    }
    
    // DESACTIVAR ACCESO
    if ($accion === 'desactivar' && isset($_POST['acceso_id'])) {
        $accesoId = (int)$_POST['acceso_id'];
        $pdo->prepare("UPDATE inspeccion_accesos SET activo = 0 WHERE id = ?")->execute([$accesoId]);
        $mensaje = 'Código de acceso desactivado';
        
        if (function_exists('registrar_auditoria')) {
            registrar_auditoria('INSPECCION_CODIGO_DESACTIVADO', "Código IT desactivado ID: {$accesoId}", 
                [], 'WARNING', $usuario->id, 'inspeccion_accesos', $accesoId);
        }
    }
    
    // REACTIVAR ACCESO
    if ($accion === 'reactivar' && isset($_POST['acceso_id'])) {
        $accesoId = (int)$_POST['acceso_id'];
        $pdo->prepare("UPDATE inspeccion_accesos SET activo = 1 WHERE id = ?")->execute([$accesoId]);
        $mensaje = 'Código de acceso reactivado';
    }
}

// ============================================================================
// OBTENER DATOS
// ============================================================================
$accesos = $pdo->query("
    SELECT ia.*, 
           CONCAT(e.nombre, ' ', e.apellido1) as creador_nombre,
           CASE 
               WHEN ia.activo = 0 THEN 'desactivado'
               WHEN ia.fecha_expiracion < NOW() THEN 'expirado'
               WHEN ia.usos_restantes IS NOT NULL AND ia.usos_restantes <= 0 THEN 'agotado'
               ELSE 'activo'
           END as estado_real
    FROM inspeccion_accesos ia
    LEFT JOIN empleados e ON ia.creado_por = e.id
    ORDER BY ia.created_at DESC
")->fetchAll();

$accesosActivos = array_filter($accesos, fn($a) => $a->estado_real === 'activo');

// Variables para layout
$paginaActual = 'inspeccion';
$titulo = 'Inspección de Trabajo';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.it-header { background: linear-gradient(135deg, #7c3aed, #a855f7); color: white; padding: 2rem; border-radius: 1rem; margin-bottom: 2rem; }
.it-header h1 { margin: 0 0 0.5rem; font-size: 1.5rem; }
.it-header p { opacity: 0.9; margin: 0; }

.form-crear { background: white; border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.form-crear h3 { margin: 0 0 1.5rem; color: #1e3a5f; }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }

.acceso-card { background: white; border-radius: 0.75rem; padding: 1.25rem; margin-bottom: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 4px solid #7c3aed; }
.acceso-card.expirado { border-left-color: #94a3b8; opacity: 0.7; }
.acceso-card.desactivado { border-left-color: #ef4444; opacity: 0.6; }
.acceso-card.agotado { border-left-color: #f59e0b; opacity: 0.7; }

.acceso-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
.acceso-codigo { font-family: monospace; font-size: 1.25rem; font-weight: 700; color: #7c3aed; background: #f3e8ff; padding: 0.5rem 1rem; border-radius: 0.5rem; }
.acceso-estado { padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
.estado-activo { background: #dcfce7; color: #166534; }
.estado-expirado { background: #e2e8f0; color: #64748b; }
.estado-desactivado { background: #fee2e2; color: #991b1b; }
.estado-agotado { background: #fef3c7; color: #92400e; }

.acceso-details { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1rem; }
.acceso-detail label { display: block; font-size: 0.7rem; color: #64748b; text-transform: uppercase; margin-bottom: 0.25rem; }
.acceso-detail span { font-weight: 500; color: #1e3a5f; }

.acceso-stats { display: flex; gap: 1.5rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; font-size: 0.85rem; color: #64748b; }

.url-box { background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 0.5rem; padding: 1rem; margin-top: 1rem; }
.url-box code { display: block; word-break: break-all; color: #7c3aed; font-size: 0.9rem; }
.url-box small { display: block; margin-top: 0.5rem; color: #64748b; }

.empty-state { text-align: center; padding: 3rem; color: #64748b; }
.empty-state .icon { font-size: 4rem; margin-bottom: 1rem; }
</style>

<div class="it-header">
    <h1>🔐 Acceso Inspección de Trabajo</h1>
    <p>Gestión de códigos de acceso para la Inspección de Trabajo según RD 8/2019</p>
</div>

<?php if ($mensaje): ?>
<div class="alert alert-success">✅ <?= $mensaje ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- URL del portal -->
<div class="url-box">
    <strong>🔗 URL del Portal de Inspección:</strong>
    <code><?= APP_URL ?>/inspeccion.php</code>
    <small>Proporcione esta URL junto con el código de acceso al inspector</small>
</div>

<!-- Formulario crear nuevo -->
<div class="form-crear" style="margin-top: 1.5rem;">
    <h3>➕ Crear Nuevo Código de Acceso</h3>
    <form method="POST">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="crear_acceso">
        
        <div class="form-grid">
            <div class="form-group">
                <label class="form-label">Nombre del Inspector *</label>
                <input type="text" name="nombre_inspector" class="form-control" required placeholder="Ej: Juan García López">
            </div>
            
            <div class="form-group">
                <label class="form-label">Organismo</label>
                <input type="text" name="organismo" class="form-control" value="Inspección de Trabajo y Seguridad Social">
            </div>
            
            <div class="form-group">
                <label class="form-label">Datos Desde *</label>
                <input type="date" name="fecha_desde" class="form-control" required value="<?= date('Y-m-01', strtotime('-3 months')) ?>">
            </div>
            
            <div class="form-group">
                <label class="form-label">Datos Hasta *</label>
                <input type="date" name="fecha_hasta" class="form-control" required value="<?= date('Y-m-d') ?>">
            </div>
            
            <div class="form-group">
                <label class="form-label">Código válido durante</label>
                <select name="dias_valido" class="form-control">
                    <option value="1">1 día</option>
                    <option value="3">3 días</option>
                    <option value="7" selected>7 días</option>
                    <option value="15">15 días</option>
                    <option value="30">30 días</option>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Máximo usos</label>
                <input type="number" name="usos_max" class="form-control" placeholder="Ilimitado" min="1">
            </div>
        </div>
        
        <div class="form-group" style="margin-top: 1rem;">
            <label class="form-label">Motivo / Referencia expediente</label>
            <input type="text" name="motivo" class="form-control" placeholder="Ej: Inspección rutinaria / Expediente 2026/00123">
        </div>
        
        <button type="submit" class="btn btn-primary" style="margin-top: 1rem;">🔑 Generar Código de Acceso</button>
    </form>
</div>

<!-- Lista de accesos -->
<h3 style="margin: 2rem 0 1rem;">📋 Códigos de Acceso (<?= count($accesosActivos) ?> activos)</h3>

<?php if (empty($accesos)): ?>
<div class="card">
    <div class="empty-state">
        <div class="icon">🔐</div>
        <h3>No hay códigos de acceso</h3>
        <p>Cree un código cuando la Inspección de Trabajo solicite acceso a los registros</p>
    </div>
</div>
<?php else: ?>
    <?php foreach ($accesos as $acc): ?>
    <div class="acceso-card <?= $acc->estado_real ?>">
        <div class="acceso-header">
            <div class="acceso-codigo"><?= htmlspecialchars($acc->codigo) ?></div>
            <span class="acceso-estado estado-<?= $acc->estado_real ?>">
                <?php
                echo match($acc->estado_real) {
                    'activo' => '✅ Activo',
                    'expirado' => '⏰ Expirado',
                    'desactivado' => '🚫 Desactivado',
                    'agotado' => '📭 Sin usos',
                    default => $acc->estado_real
                };
                ?>
            </span>
        </div>
        
        <div class="acceso-details">
            <div class="acceso-detail">
                <label>Inspector</label>
                <span>👤 <?= htmlspecialchars($acc->nombre_inspector) ?></span>
            </div>
            <div class="acceso-detail">
                <label>Organismo</label>
                <span>🏛️ <?= htmlspecialchars($acc->organismo) ?></span>
            </div>
            <div class="acceso-detail">
                <label>Período datos</label>
                <span>📅 <?= date('d/m/Y', strtotime($acc->fecha_desde)) ?> - <?= date('d/m/Y', strtotime($acc->fecha_hasta)) ?></span>
            </div>
            <div class="acceso-detail">
                <label>Código expira</label>
                <span>⏱️ <?= date('d/m/Y H:i', strtotime($acc->fecha_expiracion)) ?></span>
            </div>
            <?php if ($acc->motivo): ?>
            <div class="acceso-detail" style="grid-column: span 2;">
                <label>Motivo</label>
                <span>📝 <?= htmlspecialchars($acc->motivo) ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="acceso-stats">
            <span>📊 Accesos: <?= $acc->total_accesos ?></span>
            <?php if ($acc->usos_restantes !== null): ?>
            <span>🎫 Usos restantes: <?= $acc->usos_restantes ?></span>
            <?php endif; ?>
            <?php if ($acc->ultimo_acceso): ?>
            <span>🕐 Último: <?= date('d/m/Y H:i', strtotime($acc->ultimo_acceso)) ?></span>
            <?php endif; ?>
            <span>👤 Creado por: <?= htmlspecialchars($acc->creador_nombre ?? 'Sistema') ?></span>
            
            <div style="margin-left: auto;">
                <?php if ($acc->estado_real === 'activo'): ?>
                <form method="POST" style="display: inline;" onsubmit="return confirm('¿Desactivar este código?');">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="desactivar">
                    <input type="hidden" name="acceso_id" value="<?= $acc->id ?>">
                    <button type="submit" class="btn btn-danger btn-sm">🚫 Desactivar</button>
                </form>
                <?php elseif ($acc->estado_real === 'desactivado'): ?>
                <form method="POST" style="display: inline;">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="reactivar">
                    <input type="hidden" name="acceso_id" value="<?= $acc->id ?>">
                    <button type="submit" class="btn btn-outline btn-sm">🔄 Reactivar</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
