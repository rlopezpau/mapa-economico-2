<?php
/**
 * RECÁLCULO COMPLETO DE SALDOS DE AUSENCIAS
 * 
 * Este script:
 * 1. Crea los saldos iniciales basándose en el convenio del empleado
 * 2. Incluye días por antigüedad 
 * 3. Recalcula los días disfrutados basándose en solicitudes aprobadas
 * 
 * Solo accesible para administradores.
 * ELIMINAR DESPUÉS DE USAR o integrar en mantenimiento.php
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/../config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/ausencias.php';

establecer_headers_seguridad();
requerir_login();

// Solo administradores
if (!es_admin()) {
    die('Acceso denegado');
}

$mensaje = '';
$resultados = [];
$anioActual = date('Y');

// Procesar recálculo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $anio = (int)($_POST['anio'] ?? date('Y'));
    
    try {
        $pdo->beginTransaction();
        
        // 1. Obtener todos los empleados activos con su convenio
        $stmt = $pdo->query("
            SELECT e.id, e.nombre, e.apellido1, e.convenio_id,
                   e.dias_vacaciones, e.dias_vacaciones_antiguedad,
                   e.dias_libre_disposicion, e.dias_libre_disp_antiguedad
            FROM empleados e 
            WHERE e.activo = 1
        ");
        $empleados = $stmt->fetchAll();
        
        // 2. Obtener todos los tipos de ausencia activos
        $tiposAusencia = $pdo->query("SELECT * FROM tipos_ausencia WHERE activo = 1 ORDER BY orden")->fetchAll();
        
        // Identificar IDs de Vacaciones y Asuntos Propios
        $tipoVacacionesId = null;
        $tipoAsuntosPropiosId = null;
        foreach ($tiposAusencia as $t) {
            if ($t->nombre === 'Vacaciones') $tipoVacacionesId = $t->id;
            if ($t->nombre === 'Asuntos Propios') $tipoAsuntosPropiosId = $t->id;
        }
        
        foreach ($empleados as $emp) {
            $tiposActualizados = 0;
            $saldosCreados = 0;
            
            // 3. Obtener días del convenio del empleado
            $diasConvenio = [];
            if ($emp->convenio_id) {
                $stmt = $pdo->prepare("
                    SELECT ctd.tipo_ausencia_id, ctd.dias 
                    FROM convenios_tipos_dias ctd
                    WHERE ctd.convenio_id = ?
                ");
                $stmt->execute([$emp->convenio_id]);
                foreach ($stmt->fetchAll() as $dc) {
                    $diasConvenio[$dc->tipo_ausencia_id] = $dc->dias;
                }
            }
            
            // 4. Para cada tipo de ausencia, crear/actualizar saldo
            foreach ($tiposAusencia as $tipo) {
                $diasAsignados = 0;
                
                // Determinar días según tipo
                if ($tipo->id == $tipoVacacionesId) {
                    // Vacaciones: días del empleado + antigüedad
                    $diasAsignados = ($emp->dias_vacaciones ?? 22) + ($emp->dias_vacaciones_antiguedad ?? 0);
                } elseif ($tipo->id == $tipoAsuntosPropiosId) {
                    // Asuntos propios: días del empleado + antigüedad
                    $diasAsignados = ($emp->dias_libre_disposicion ?? 6) + ($emp->dias_libre_disp_antiguedad ?? 0);
                } elseif (isset($diasConvenio[$tipo->id])) {
                    // Días del convenio
                    $diasAsignados = $diasConvenio[$tipo->id];
                } elseif ($tipo->dias_maximos !== null && $tipo->dias_maximos > 0) {
                    // Días máximos del tipo
                    $diasAsignados = $tipo->dias_maximos;
                }
                
                if ($diasAsignados > 0) {
                    // Verificar si existe el saldo
                    $stmt = $pdo->prepare("
                        SELECT id FROM saldo_ausencias 
                        WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
                    ");
                    $stmt->execute([$emp->id, $tipo->id, $anio]);
                    $saldoExiste = $stmt->fetch();
                    
                    if ($saldoExiste) {
                        // Actualizar días asignados (mantener disfrutados)
                        $stmt = $pdo->prepare("
                            UPDATE saldo_ausencias 
                            SET dias_asignados = ?
                            WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
                        ");
                        $stmt->execute([$diasAsignados, $emp->id, $tipo->id, $anio]);
                        $tiposActualizados++;
                    } else {
                        // Crear nuevo saldo
                        $stmt = $pdo->prepare("
                            INSERT INTO saldo_ausencias 
                            (empleado_id, tipo_ausencia_id, anio, dias_asignados, dias_disfrutados, dias_pendientes)
                            VALUES (?, ?, ?, ?, 0, 0)
                        ");
                        $stmt->execute([$emp->id, $tipo->id, $anio, $diasAsignados]);
                        $saldosCreados++;
                    }
                }
            }
            
            // 5. Recalcular días disfrutados basándose en solicitudes aprobadas
            // Primero resetear todos los días disfrutados y pendientes
            $stmt = $pdo->prepare("
                UPDATE saldo_ausencias 
                SET dias_disfrutados = 0, dias_pendientes = 0 
                WHERE empleado_id = ? AND anio = ?
            ");
            $stmt->execute([$emp->id, $anio]);
            
            // Calcular días de solicitudes aprobadas
            $stmt = $pdo->prepare("
                SELECT tipo_ausencia_id, SUM(dias_solicitados) as total_dias
                FROM solicitudes_ausencia
                WHERE empleado_id = ? 
                AND estado = 'aprobada'
                AND YEAR(fecha_inicio) = ?
                GROUP BY tipo_ausencia_id
            ");
            $stmt->execute([$emp->id, $anio]);
            $solicitudesAprobadas = $stmt->fetchAll();
            
            foreach ($solicitudesAprobadas as $sol) {
                $stmt = $pdo->prepare("
                    UPDATE saldo_ausencias 
                    SET dias_disfrutados = ?
                    WHERE empleado_id = ? AND tipo_ausencia_id = ? AND anio = ?
                ");
                $stmt->execute([$sol->total_dias, $emp->id, $sol->tipo_ausencia_id, $anio]);
            }
            
            $resultados[] = [
                'empleado' => $emp->nombre . ' ' . $emp->apellido1,
                'convenio_id' => $emp->convenio_id,
                'saldos_creados' => $saldosCreados,
                'tipos_actualizados' => $tiposActualizados,
                'solicitudes_procesadas' => count($solicitudesAprobadas)
            ];
        }
        
        $pdo->commit();
        $mensaje = "✅ Recálculo completado para " . count($empleados) . " empleados (Año {$anio})";
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $mensaje = "❌ Error: " . $e->getMessage();
    }
}

// Obtener estadísticas actuales
$stmt = $pdo->prepare("
    SELECT 
        e.nombre, e.apellido1,
        c.nombre as convenio_nombre,
        ta.nombre as tipo_ausencia,
        sa.dias_asignados,
        sa.dias_disfrutados,
        sa.dias_pendientes,
        (sa.dias_asignados - sa.dias_disfrutados - sa.dias_pendientes) as dias_disponibles
    FROM saldo_ausencias sa
    INNER JOIN empleados e ON sa.empleado_id = e.id
    INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
    LEFT JOIN convenios c ON e.convenio_id = c.id
    WHERE sa.anio = ? AND e.activo = 1
    ORDER BY e.apellido1, e.nombre, ta.orden
");
$stmt->execute([$anioActual]);
$saldosActuales = $stmt->fetchAll();

// Obtener convenios disponibles
$convenios = $pdo->query("SELECT * FROM convenios WHERE activo = 1 ORDER BY nombre")->fetchAll();

// Obtener tipos de ausencia con sus días por convenio
$tiposConDias = [];
foreach ($convenios as $conv) {
    $stmt = $pdo->prepare("
        SELECT ta.nombre, ctd.dias 
        FROM convenios_tipos_dias ctd
        INNER JOIN tipos_ausencia ta ON ctd.tipo_ausencia_id = ta.id
        WHERE ctd.convenio_id = ?
        ORDER BY ta.orden
    ");
    $stmt->execute([$conv->id]);
    $tiposConDias[$conv->id] = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recálculo de Saldos</title>
    <style>
        body { font-family: sans-serif; padding: 20px; max-width: 1400px; margin: 0 auto; background: #f5f5f5; }
        .card { background: white; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #1e3a5f; }
        h2 { color: #1e3a5f; margin-top: 0; }
        .btn { padding: 12px 24px; background: #1e3a5f; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; }
        .btn:hover { background: #2d5a87; }
        .btn-danger { background: #ef4444; }
        .btn-danger:hover { background: #dc2626; }
        .msg { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .msg-ok { background: #d1fae5; color: #065f46; }
        .msg-error { background: #fee2e2; color: #991b1b; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 8px 10px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f8fafc; font-size: 11px; text-transform: uppercase; color: #64748b; }
        tr:hover { background: #f8fafc; }
        .warning { background: #fef3c7; color: #92400e; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .info { background: #dbeafe; color: #1e40af; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        select { padding: 10px; border-radius: 6px; border: 1px solid #d1d5db; font-size: 16px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .num { text-align: right; font-family: monospace; }
    </style>
</head>
<body>
    <h1>🔄 Recálculo Completo de Saldos de Ausencias</h1>
    
    <div class="info">
        ℹ️ <strong>Este proceso hace lo siguiente:</strong>
        <ol style="margin: 10px 0 0 20px;">
            <li>Crea saldos para cada tipo de ausencia basándose en el <strong>convenio del empleado</strong></li>
            <li>Incluye los <strong>días por antigüedad</strong> configurados en cada empleado</li>
            <li>Recalcula los <strong>días disfrutados</strong> basándose en las solicitudes aprobadas</li>
        </ol>
    </div>
    
    <?php if ($mensaje): ?>
    <div class="msg <?= str_starts_with($mensaje, '✅') ? 'msg-ok' : 'msg-error' ?>">
        <?= htmlspecialchars($mensaje) ?>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($resultados)): ?>
    <div class="card">
        <h2>📋 Resultados del Recálculo</h2>
        <table>
            <tr>
                <th>Empleado</th>
                <th>Convenio</th>
                <th>Saldos Creados</th>
                <th>Tipos Actualizados</th>
                <th>Solicitudes Procesadas</th>
            </tr>
            <?php foreach ($resultados as $r): ?>
            <tr>
                <td><?= htmlspecialchars($r['empleado']) ?></td>
                <td><?= $r['convenio_id'] ? "ID: {$r['convenio_id']}" : '<span class="badge badge-warning">Sin convenio</span>' ?></td>
                <td class="num"><?= $r['saldos_creados'] ?></td>
                <td class="num"><?= $r['tipos_actualizados'] ?></td>
                <td class="num"><?= $r['solicitudes_procesadas'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>
    
    <div class="grid">
        <div class="card">
            <h2>🔧 Ejecutar Recálculo</h2>
            <form method="POST">
                <?= csrf_campo() ?>
                <p>
                    <label>Año a recalcular:</label>
                    <select name="anio">
                        <?php for ($y = date('Y'); $y >= date('Y') - 2; $y--): ?>
                        <option value="<?= $y ?>"><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </p>
                <button type="submit" class="btn btn-danger" 
                        onclick="return confirm('¿Seguro? Esto recreará los saldos de TODOS los empleados basándose en sus convenios.');">
                    🔄 Recalcular Todos los Saldos
                </button>
            </form>
        </div>
        
        <div class="card">
            <h2>📚 Convenios Configurados</h2>
            <?php if (empty($convenios)): ?>
            <p style="color: #ef4444;">⚠️ No hay convenios configurados. Ve a Admin → Convenios para crearlos.</p>
            <?php else: ?>
            <?php foreach ($convenios as $conv): ?>
            <details style="margin-bottom: 10px;">
                <summary style="cursor: pointer; font-weight: bold;"><?= htmlspecialchars($conv->nombre) ?></summary>
                <table style="margin-top: 10px;">
                    <tr><th>Tipo de Ausencia</th><th>Días</th></tr>
                    <?php foreach ($tiposConDias[$conv->id] ?? [] as $td): ?>
                    <tr>
                        <td><?= htmlspecialchars($td->nombre) ?></td>
                        <td class="num"><?= $td->dias ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($tiposConDias[$conv->id])): ?>
                    <tr><td colspan="2" style="color: #f59e0b;">Sin días configurados</td></tr>
                    <?php endif; ?>
                </table>
            </details>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card">
        <h2>📊 Saldos Actuales (<?= $anioActual ?>)</h2>
        <?php if (empty($saldosActuales)): ?>
        <p style="color: #ef4444;">⚠️ No hay saldos registrados. Ejecuta el recálculo para crearlos.</p>
        <?php else: ?>
        <div style="overflow-x: auto;">
        <table>
            <tr>
                <th>Empleado</th>
                <th>Convenio</th>
                <th>Tipo Ausencia</th>
                <th>Asignados</th>
                <th>Disfrutados</th>
                <th>Pendientes</th>
                <th>Disponibles</th>
            </tr>
            <?php 
            $empleadoAnterior = '';
            foreach ($saldosActuales as $s): 
                $empleadoActual = $s->nombre . ' ' . $s->apellido1;
                $mostrarEmpleado = ($empleadoActual !== $empleadoAnterior);
                $empleadoAnterior = $empleadoActual;
            ?>
            <tr <?= $mostrarEmpleado ? 'style="border-top: 2px solid #cbd5e1;"' : '' ?>>
                <td><?= $mostrarEmpleado ? htmlspecialchars($empleadoActual) : '' ?></td>
                <td><?= $mostrarEmpleado ? htmlspecialchars($s->convenio_nombre ?? '-') : '' ?></td>
                <td><?= htmlspecialchars($s->tipo_ausencia) ?></td>
                <td class="num"><?= (int)$s->dias_asignados ?></td>
                <td class="num"><?= (int)$s->dias_disfrutados ?></td>
                <td class="num"><?= (int)$s->dias_pendientes ?></td>
                <td class="num"><strong><?= (int)$s->dias_disponibles ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </table>
        </div>
        <?php endif; ?>
    </div>
    
    <p><a href="index.php">← Volver al Admin</a></p>
    <p style="color: red;"><strong>⚠️ Elimina este archivo (recalcular_saldos.php) cuando ya no lo necesites</strong></p>
</body>
</html>
