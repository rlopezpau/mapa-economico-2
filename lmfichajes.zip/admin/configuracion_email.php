<?php
/**
 * LM FICHAJES - Configuración de Email SMTP
 * 
 * Panel para configurar el envío de emails del sistema.
 * Permite al administrador configurar los datos SMTP de su organización.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// ============================================================================
// SEGURIDAD - Solo administradores
// ============================================================================
requerir_login('../login.php');
if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'Solo los administradores pueden acceder a esta sección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';
$testResult = null;

// ============================================================================
// FUNCIONES
// ============================================================================

function obtenerConfigEmail($pdo) {
    $config = [
        'smtp_host' => '',
        'smtp_puerto' => '587',
        'smtp_usuario' => '',
        'smtp_password' => '',
        'smtp_cifrado' => 'tls',
        'smtp_from_email' => '',
        'smtp_from_nombre' => 'LM Fichajes',
        'email_activo' => '0'
    ];
    
    try {
        $stmt = $pdo->query("SELECT clave, valor FROM configuracion WHERE clave LIKE 'smtp_%' OR clave = 'email_activo'");
        while ($row = $stmt->fetch()) {
            $config[$row->clave] = $row->valor;
        }
    } catch (PDOException $e) {}
    
    return $config;
}

function guardarConfigEmail($pdo, $datos) {
    $claves = ['smtp_host', 'smtp_puerto', 'smtp_usuario', 'smtp_password', 'smtp_cifrado', 'smtp_from_email', 'smtp_from_nombre', 'email_activo'];
    
    try {
        foreach ($claves as $clave) {
            if (isset($datos[$clave])) {
                $valor = trim($datos[$clave]);
                
                // No actualizar password si está vacío (mantener el anterior)
                if ($clave === 'smtp_password' && empty($valor)) {
                    continue;
                }
                
                $stmt = $pdo->prepare("SELECT clave FROM configuracion WHERE clave = ?");
                $stmt->execute([$clave]);
                
                if ($stmt->fetch()) {
                    $pdo->prepare("UPDATE configuracion SET valor = ? WHERE clave = ?")->execute([$valor, $clave]);
                } else {
                    $pdo->prepare("INSERT INTO configuracion (clave, valor, descripcion) VALUES (?, ?, ?)")
                        ->execute([$clave, $valor, '']);
                }
            }
        }
        return ['ok' => true, 'msg' => 'Configuración guardada correctamente'];
    } catch (PDOException $e) {
        return ['ok' => false, 'msg' => 'Error al guardar: ' . $e->getMessage()];
    }
}

// AUDITORÍA: Se llamará después de guardar exitosamente
function auditarConfigEmail($usuarioId) {
    if (function_exists('registrar_auditoria')) {
        registrar_auditoria('CONFIG_CHANGE', 'Configuración SMTP actualizada', [], 'INFO', $usuarioId, 'configuracion', null);
    }
}

function enviarEmailPrueba($pdo, $emailDestino) {
    $config = obtenerConfigEmail($pdo);
    
    if (empty($config['smtp_host']) || empty($config['smtp_usuario'])) {
        return ['ok' => false, 'msg' => 'Configura primero los datos SMTP'];
    }
    
    if (empty($emailDestino) || !filter_var($emailDestino, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'msg' => 'Email de destino no válido'];
    }
    
    $asunto = '🧪 Email de prueba - LM Fichajes';
    $cuerpo = "
    <html>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='background: #1a365d; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;'>
                <h1 style='margin: 0;'>🕐 LM Fichajes</h1>
            </div>
            <div style='background: #f8fafc; padding: 30px; border: 1px solid #e2e8f0; border-radius: 0 0 8px 8px;'>
                <h2 style='color: #059669; margin-top: 0;'>✅ ¡Configuración correcta!</h2>
                <p>Este es un email de prueba del sistema LM Fichajes.</p>
                <p>Si estás leyendo esto, significa que la configuración SMTP es correcta y el sistema puede enviar emails.</p>
                <div style='background: white; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; margin: 20px 0;'>
                    <strong>Datos de configuración:</strong><br>
                    <span style='color: #64748b;'>Servidor:</span> {$config['smtp_host']}<br>
                    <span style='color: #64748b;'>Puerto:</span> {$config['smtp_puerto']}<br>
                    <span style='color: #64748b;'>Cifrado:</span> {$config['smtp_cifrado']}<br>
                    <span style='color: #64748b;'>Remitente:</span> {$config['smtp_from_nombre']} &lt;{$config['smtp_from_email']}&gt;
                </div>
                <p style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b;'>
                    Enviado el " . date('d/m/Y H:i:s') . "
                </p>
            </div>
        </div>
    </body>
    </html>";
    
    // Intentar enviar con mail() nativo
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: {$config['smtp_from_nombre']} <{$config['smtp_from_email']}>\r\n";
    $headers .= "Reply-To: {$config['smtp_from_email']}\r\n";
    $headers .= "X-Mailer: LMFichajes/1.0\r\n";
    
    // Configurar SMTP para mail() si es posible
    ini_set('SMTP', $config['smtp_host']);
    ini_set('smtp_port', $config['smtp_puerto']);
    
    if (@mail($emailDestino, $asunto, $cuerpo, $headers)) {
        return ['ok' => true, 'msg' => "Email de prueba enviado a <strong>$emailDestino</strong>"];
    } else {
        $errorMsg = error_get_last()['message'] ?? 'Error desconocido';
        return ['ok' => false, 'msg' => "No se pudo enviar el email. Error: $errorMsg<br><small>Nota: Algunos servidores requieren PHPMailer para SMTP autenticado.</small>"];
    }
}

// ============================================================================
// PROCESAR POST
// ============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $accion = $_POST['accion'] ?? '';
    
    if ($accion === 'guardar') {
        $resultado = guardarConfigEmail($pdo, $_POST);
        if ($resultado['ok']) {
            $mensaje = $resultado['msg'];
            auditarConfigEmail($usuario->id);
        } else {
            $error = $resultado['msg'];
        }
    }
    
    if ($accion === 'probar') {
        $testResult = enviarEmailPrueba($pdo, trim($_POST['email_prueba'] ?? ''));
    }
}

// ============================================================================
// OBTENER DATOS
// ============================================================================
$config = obtenerConfigEmail($pdo);
$stats = ['fichajes_pendientes' => 0];
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM fichajes WHERE estado='pendiente'");
    $stats['fichajes_pendientes'] = $stmt->fetchColumn();
} catch (PDOException $e) {}

// ============================================================================
// CONFIG PÁGINA
// ============================================================================
$paginaActual = 'configuracion';
$tituloPagina = 'Configuración de Email';

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">📧 Configuración de Email</h1>
        <p style="color: #64748b; margin: 0;">Configura el servidor SMTP para el envío de emails del sistema</p>
    </div>
    <a href="configuracion.php" class="btn btn-outline">← Volver</a>
</div>

<?php if ($mensaje): ?>
<div class="alert alert-success"><?= $mensaje ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if ($testResult): ?>
<div class="alert <?= $testResult['ok'] ? 'alert-success' : 'alert-danger' ?>"><?= $testResult['msg'] ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
    <div>
        <!-- Formulario de configuración -->
        <form method="POST">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="guardar">
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">🔧 Servidor SMTP</span>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label class="form-label">Servidor SMTP <span class="required">*</span></label>
                            <input type="text" name="smtp_host" value="<?= htmlspecialchars($config['smtp_host']) ?>" class="form-control" placeholder="mail.tudominio.es" required>
                            <div class="form-hint">Dirección del servidor de correo saliente</div>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Puerto <span class="required">*</span></label>
                            <select name="smtp_puerto" class="form-control" required>
                                <option value="587" <?= $config['smtp_puerto'] === '587' ? 'selected' : '' ?>>587 (TLS - Recomendado)</option>
                                <option value="465" <?= $config['smtp_puerto'] === '465' ? 'selected' : '' ?>>465 (SSL)</option>
                                <option value="25" <?= $config['smtp_puerto'] === '25' ? 'selected' : '' ?>>25 (Sin cifrado)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Usuario SMTP <span class="required">*</span></label>
                            <input type="text" name="smtp_usuario" value="<?= htmlspecialchars($config['smtp_usuario']) ?>" class="form-control" placeholder="usuario@tudominio.es" required>
                            <div class="form-hint">Normalmente es la dirección de email completa</div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Contraseña SMTP <?= empty($config['smtp_password']) ? '<span class="required">*</span>' : '' ?></label>
                            <input type="password" name="smtp_password" class="form-control" placeholder="<?= empty($config['smtp_password']) ? 'Contraseña del email' : '••••••••' ?>">
                            <?php if (!empty($config['smtp_password'])): ?>
                            <div class="form-hint">Dejar vacío para mantener la actual</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Cifrado</label>
                        <div style="display: flex; gap: 1.5rem;">
                            <label class="form-check">
                                <input type="radio" name="smtp_cifrado" value="tls" <?= $config['smtp_cifrado'] === 'tls' ? 'checked' : '' ?>>
                                TLS (Recomendado)
                            </label>
                            <label class="form-check">
                                <input type="radio" name="smtp_cifrado" value="ssl" <?= $config['smtp_cifrado'] === 'ssl' ? 'checked' : '' ?>>
                                SSL
                            </label>
                            <label class="form-check">
                                <input type="radio" name="smtp_cifrado" value="" <?= empty($config['smtp_cifrado']) ? 'checked' : '' ?>>
                                Ninguno
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">✉️ Remitente</span>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Email del remitente <span class="required">*</span></label>
                            <input type="email" name="smtp_from_email" value="<?= htmlspecialchars($config['smtp_from_email']) ?>" class="form-control" placeholder="noreply@tudominio.es" required>
                            <div class="form-hint">Dirección que aparece como remitente</div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Nombre del remitente</label>
                            <input type="text" name="smtp_from_nombre" value="<?= htmlspecialchars($config['smtp_from_nombre']) ?>" class="form-control" placeholder="Fichajes Ayuntamiento">
                            <div class="form-hint">Nombre que aparece junto al email</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">⚡ Estado</span>
                </div>
                <div class="card-body">
                    <label class="form-check" style="font-size: 1rem;">
                        <input type="checkbox" name="email_activo" value="1" <?= $config['email_activo'] === '1' ? 'checked' : '' ?>>
                        <strong>Activar envío de emails</strong>
                    </label>
                    <p style="color: #64748b; font-size: 0.875rem; margin: 0.5rem 0 0 1.75rem;">
                        Si está desactivado, el sistema no enviará ningún email aunque esté configurado.
                    </p>
                </div>
            </div>
            
            <div style="display: flex; justify-content: center; gap: 1rem; margin-top: 1.5rem;">
                <button type="submit" class="btn btn-success">💾 Guardar Configuración</button>
            </div>
        </form>
    </div>
    
    <div>
        <!-- Panel de prueba -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">🧪 Probar Configuración</span>
            </div>
            <div class="card-body">
                <p style="color: #64748b; font-size: 0.875rem; margin-bottom: 1rem;">
                    Envía un email de prueba para verificar que la configuración es correcta.
                </p>
                <form method="POST">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="probar">
                    <div class="form-group">
                        <label class="form-label">Email de destino</label>
                        <input type="email" name="email_prueba" value="<?= htmlspecialchars($usuario->email ?? '') ?>" class="form-control" placeholder="tu@email.com" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">📤 Enviar Email de Prueba</button>
                </form>
            </div>
        </div>
        
        <!-- Ayuda -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">❓ Ayuda</span>
            </div>
            <div class="card-body" style="font-size: 0.875rem;">
                <p><strong>¿Dónde encuentro estos datos?</strong></p>
                <p style="color: #64748b;">
                    Los datos SMTP los proporciona tu proveedor de hosting o email. 
                    Normalmente están en el panel de control (cPanel, Plesk, etc.) 
                    en la sección "Cuentas de correo" → "Configurar cliente de correo".
                </p>
                
                <hr style="margin: 1rem 0; border: none; border-top: 1px solid #e2e8f0;">
                
                <p><strong>Configuración típica:</strong></p>
                <div style="background: #f8fafc; padding: 0.75rem; border-radius: 0.5rem; font-family: monospace; font-size: 0.75rem;">
                    Servidor: mail.tudominio.es<br>
                    Puerto: 587<br>
                    Cifrado: TLS<br>
                    Usuario: noreply@tudominio.es<br>
                    Contraseña: (la del email)
                </div>
                
                <hr style="margin: 1rem 0; border: none; border-top: 1px solid #e2e8f0;">
                
                <p><strong>El sistema envía emails para:</strong></p>
                <ul style="color: #64748b; margin: 0; padding-left: 1.25rem;">
                    <li>Nuevas contraseñas de empleados</li>
                    <li>Reseteo de contraseñas</li>
                    <li>Notificaciones de ausencias</li>
                </ul>
            </div>
        </div>
        
        <!-- Estado actual -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">📊 Estado Actual</span>
            </div>
            <div class="card-body">
                <div style="display: flex; align-items: center; gap: 0.75rem; padding: 1rem; background: <?= $config['email_activo'] === '1' ? '#dcfce7' : '#fef2f2' ?>; border-radius: 0.5rem;">
                    <span style="font-size: 1.5rem;"><?= $config['email_activo'] === '1' ? '✅' : '❌' ?></span>
                    <div>
                        <strong><?= $config['email_activo'] === '1' ? 'Emails Activados' : 'Emails Desactivados' ?></strong>
                        <div style="font-size: 0.75rem; color: #64748b;">
                            <?php if ($config['email_activo'] === '1'): ?>
                                El sistema puede enviar emails
                            <?php else: ?>
                                No se enviarán emails
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($config['smtp_host'])): ?>
                <div style="margin-top: 1rem; font-size: 0.8rem; color: #64748b;">
                    <strong>Servidor:</strong> <?= htmlspecialchars($config['smtp_host']) ?>:<?= htmlspecialchars($config['smtp_puerto']) ?><br>
                    <strong>Remitente:</strong> <?= htmlspecialchars($config['smtp_from_nombre']) ?> &lt;<?= htmlspecialchars($config['smtp_from_email']) ?>&gt;
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
