<?php
/**
 * LM FICHAJES - Bolsa de Horas
 * 
 * Panel para visualizar el balance de horas de los trabajadores:
 * - Horas trabajadas vs horas esperadas
 * - Saldo acumulado (bolsa de horas)
 * - Filtros por centro, empleado, mes y año
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.1
 * @date        2026-01-08
 * @modified    CORREGIDO: queries usan minutos_* en lugar de horas_*
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once __DIR__ . '/includes/admin_functions.php';

// Seguridad
requerir_login('../login.php');
if (!es_manager()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);

// ============================================================================
// FILTROS
// ============================================================================
$filtros = [
    'centro_id' => (int)($_GET['centro_id'] ?? 0),
    'empleado_id' => (int)($_GET['empleado_id'] ?? 0),
    'mes' => (int)($_GET['mes'] ?? date('n')),
    'anio' => (int)($_GET['anio'] ?? date('Y')),
];

// Obtener centros para filtro
$centros = [];
try {
    $stmt = $pdo->query("SELECT id, nombre FROM centros WHERE activo = 1 ORDER BY nombre");
    $centros = $stmt->fetchAll();
} catch (Exception $e) {}

// Obtener empleados para filtro (según centro si está seleccionado)
$empleadosFiltro = [];
$sqlEmpleados = "SELECT DISTINCT e.id, e.nombre, e.apellido1 
                 FROM empleados e 
                 LEFT JOIN empleados_centros ec ON e.id = ec.empleado_id
                 WHERE e.activo = 1";
if ($filtros['centro_id'] > 0) {
    $sqlEmpleados .= " AND ec.centro_id = " . $filtros['centro_id'];
}
$sqlEmpleados .= " ORDER BY e.apellido1, e.nombre";
try {
    $stmt = $pdo->query($sqlEmpleados);
    $empleadosFiltro = $stmt->fetchAll();
} catch (Exception $e) {}

// ============================================================================
// OBTENER DATOS DE BOLSA DE HORAS
// ============================================================================
function obtenerBolsaHoras($pdo, $filtros) {
    $anio = $filtros['anio'];
    $mes = $filtros['mes'];
    
    // Calcular fechas del mes
    $fechaInicio = sprintf('%04d-%02d-01', $anio, $mes);
    $fechaFin = date('Y-m-t', strtotime($fechaInicio));
    
    $where = ["e.activo = 1"];
    $params = [];
    
    if ($filtros['centro_id'] > 0) {
        $where[] = "ec.centro_id = ?";
        $params[] = $filtros['centro_id'];
    }
    
    if ($filtros['empleado_id'] > 0) {
        $where[] = "e.id = ?";
        $params[] = $filtros['empleado_id'];
    }
    
    $whereSQL = implode(' AND ', $where);
    
    // Query principal - CORREGIDO: usa minutos_* en lugar de horas_*
    $sql = "SELECT 
                e.id,
                e.nif,
                e.nombre,
                e.apellido1,
                e.apellido2,
                e.porcentaje_jornada,
                h.nombre as horario_nombre,
                h.horas_semanales,
                h.horas_diarias,
                c.nombre as centro_nombre,
                COALESCE(SUM(rd.minutos_trabajados), 0) / 60 as total_trabajadas,
                COALESCE(SUM(rd.minutos_esperados), 0) / 60 as total_esperadas,
                COUNT(DISTINCT rd.fecha) as dias_trabajados
            FROM empleados e
            LEFT JOIN empleados_centros ec ON e.id = ec.empleado_id AND ec.es_principal = 1
            LEFT JOIN centros c ON ec.centro_id = c.id
            LEFT JOIN horarios h ON e.horario_id = h.id
            LEFT JOIN resumen_diario rd ON e.id = rd.empleado_id 
                AND rd.fecha BETWEEN ? AND ?
            WHERE {$whereSQL}
            GROUP BY e.id, e.nif, e.nombre, e.apellido1, e.apellido2, e.porcentaje_jornada,
                     h.nombre, h.horas_semanales, h.horas_diarias, c.nombre
            ORDER BY e.apellido1, e.nombre";
    
    array_unshift($params, $fechaInicio, $fechaFin);
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $empleados = $stmt->fetchAll();
    
    // Calcular saldo acumulado del año hasta el mes anterior
    foreach ($empleados as &$emp) {
        // Saldo de meses anteriores en el año
        $fechaInicioAnio = sprintf('%04d-01-01', $anio);
        $fechaFinMesAnterior = date('Y-m-d', strtotime($fechaInicio . ' -1 day'));
        
        if ($fechaFinMesAnterior >= $fechaInicioAnio) {
            // CORREGIDO: usa minutos_* en lugar de horas_*
            $stmtAcum = $pdo->prepare("
                SELECT 
                    COALESCE(SUM(minutos_trabajados), 0) / 60 as trabajadas,
                    COALESCE(SUM(minutos_esperados), 0) / 60 as esperadas
                FROM resumen_diario 
                WHERE empleado_id = ? 
                AND fecha BETWEEN ? AND ?
            ");
            $stmtAcum->execute([$emp->id, $fechaInicioAnio, $fechaFinMesAnterior]);
            $acumulado = $stmtAcum->fetch();
            
            $emp->acumulado_trabajadas = $acumulado->trabajadas ?? 0;
            $emp->acumulado_esperadas = $acumulado->esperadas ?? 0;
            $emp->saldo_anterior = $emp->acumulado_trabajadas - $emp->acumulado_esperadas;
        } else {
            $emp->acumulado_trabajadas = 0;
            $emp->acumulado_esperadas = 0;
            $emp->saldo_anterior = 0;
        }
        
        // Calcular saldos
        $emp->saldo_mes = $emp->total_trabajadas - $emp->total_esperadas;
        $emp->saldo_total = $emp->saldo_anterior + $emp->saldo_mes;
        
        // Porcentaje de cumplimiento
        if ($emp->total_esperadas > 0) {
            $emp->porcentaje_cumplimiento = round(($emp->total_trabajadas / $emp->total_esperadas) * 100, 1);
        } else {
            $emp->porcentaje_cumplimiento = 0;
        }
    }
    
    return $empleados;
}

$bolsaHoras = obtenerBolsaHoras($pdo, $filtros);

// Calcular totales
$totales = [
    'trabajadas' => 0,
    'esperadas' => 0,
    'saldo_mes' => 0,
    'saldo_total' => 0,
];
foreach ($bolsaHoras as $emp) {
    $totales['trabajadas'] += $emp->total_trabajadas;
    $totales['esperadas'] += $emp->total_esperadas;
    $totales['saldo_mes'] += $emp->saldo_mes;
    $totales['saldo_total'] += $emp->saldo_total;
}

// Meses para selector
$meses = [
    1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
    5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
    9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre'
];

// Años disponibles
$anioActual = date('Y');
$anios = range($anioActual - 2, $anioActual + 1);

$titulo = 'Bolsa de Horas';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo ?> - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css?v=<?= APP_VERSION ?>">
    <style>
        .page-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.5rem;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .page-title {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .page-title h1 {
            margin: 0;
            font-size: 1.5rem;
            color: #1e293b;
        }
        
        .page-title .subtitle {
            color: #64748b;
            font-size: 0.9rem;
        }
        
        /* Filtros */
        .filtros-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
        }
        
        .filtros-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            align-items: end;
        }
        
        .filtro-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 600;
            color: #64748b;
            margin-bottom: 0.375rem;
            text-transform: uppercase;
        }
        
        .filtro-group select {
            width: 100%;
            padding: 0.625rem 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.9rem;
            background: white;
            cursor: pointer;
        }
        
        .filtro-group select:focus {
            outline: none;
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
        
        .btn-filtrar {
            padding: 0.625rem 1.25rem;
            background: #6366f1;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        
        .btn-filtrar:hover {
            background: #4f46e5;
        }
        
        /* Resumen */
        .resumen-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .resumen-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
        }
        
        .resumen-card .label {
            font-size: 0.8rem;
            color: #64748b;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .resumen-card .value {
            font-size: 1.75rem;
            font-weight: 700;
            color: #1e293b;
        }
        
        .resumen-card.positivo .value { color: #10b981; }
        .resumen-card.negativo .value { color: #ef4444; }
        
        /* Tabla */
        .tabla-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
        }
        
        .tabla-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .tabla-header h2 {
            margin: 0;
            font-size: 1rem;
            color: #1e293b;
        }
        
        .tabla-scroll {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 0.875rem 1rem;
            text-align: left;
            border-bottom: 1px solid #f1f5f9;
        }
        
        th {
            background: #f8fafc;
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        
        td {
            font-size: 0.9rem;
            color: #334155;
        }
        
        tr:hover {
            background: #f8fafc;
        }
        
        .empleado-info {
            display: flex;
            flex-direction: column;
        }
        
        .empleado-nombre {
            font-weight: 600;
            color: #1e293b;
        }
        
        .empleado-nif {
            font-size: 0.8rem;
            color: #94a3b8;
        }
        
        .centro-tag {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background: #f1f5f9;
            border-radius: 4px;
            font-size: 0.8rem;
            color: #64748b;
        }
        
        .jornada-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background: #dbeafe;
            color: #1d4ed8;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .jornada-badge.parcial {
            background: #fef3c7;
            color: #92400e;
        }
        
        .horas-cell {
            text-align: right;
            font-family: 'SF Mono', Monaco, monospace;
        }
        
        .saldo-cell {
            text-align: right;
            font-weight: 600;
            font-family: 'SF Mono', Monaco, monospace;
        }
        
        .saldo-positivo { color: #10b981; }
        .saldo-negativo { color: #ef4444; }
        .saldo-neutro { color: #64748b; }
        
        .barra-progreso {
            width: 80px;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .barra-progreso .fill {
            height: 100%;
            border-radius: 3px;
            transition: width 0.3s;
        }
        
        .barra-progreso .fill.excelente { background: #10b981; }
        .barra-progreso .fill.bueno { background: #3b82f6; }
        .barra-progreso .fill.bajo { background: #f59e0b; }
        .barra-progreso .fill.critico { background: #ef4444; }
        
        .porcentaje {
            font-size: 0.8rem;
            color: #64748b;
            margin-top: 0.25rem;
        }
        
        .sin-datos {
            text-align: center;
            padding: 3rem;
            color: #64748b;
        }
        
        .sin-datos .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        /* Totales */
        tr.fila-totales {
            background: #f8fafc;
            font-weight: 600;
        }
        
        tr.fila-totales td {
            border-top: 2px solid #e2e8f0;
        }
        
        /* Exportar */
        .btn-exportar {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: #10b981;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 0.85rem;
            cursor: pointer;
            text-decoration: none;
        }
        
        .btn-exportar:hover {
            background: #059669;
        }
        
        @media (max-width: 768px) {
            .page-header { flex-direction: column; align-items: flex-start; }
            .filtros-grid { grid-template-columns: 1fr 1fr; }
            th, td { padding: 0.625rem 0.5rem; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-left">
            <a href="<?= APP_URL ?>/admin/" class="logo">🏢 <?= APP_NAME ?></a>
            <span class="admin-badge">ADMIN</span>
        </div>
        <div class="header-right">
            <div class="user-info">
                <div class="name"><?= sanitizar($usuario->nombre . ' ' . $usuario->apellido1) ?></div>
                <div class="role"><?= ucfirst($usuario->rol) ?></div>
            </div>
            <a href="<?= APP_URL ?>/portal.php" class="btn-header">👤 Mi Portal</a>
            <a href="<?= APP_URL ?>/portal.php?logout=1" class="btn-header">🚪 Salir</a>
        </div>
    </header>
    
    <div class="layout">
        <!-- Sidebar -->
        <?php include __DIR__ . '/includes/layout_sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-container">
                <!-- Header -->
                <div class="page-header">
                    <div class="page-title">
                        <h1>⏱️ Bolsa de Horas</h1>
                        <span class="subtitle"><?= $meses[$filtros['mes']] ?> <?= $filtros['anio'] ?></span>
                    </div>
                    <a href="?<?= http_build_query(array_merge($filtros, ['exportar' => 'csv'])) ?>" class="btn-exportar">
                        📊 Exportar CSV
                    </a>
                </div>
                
                <!-- Filtros -->
                <div class="filtros-card">
                    <form method="GET" class="filtros-grid">
                        <div class="filtro-group">
                            <label>Centro</label>
                            <select name="centro_id" onchange="this.form.submit()">
                                <option value="0">Todos los centros</option>
                                <?php foreach ($centros as $centro): ?>
                                    <option value="<?= $centro->id ?>" <?= $filtros['centro_id'] == $centro->id ? 'selected' : '' ?>>
                                        <?= sanitizar($centro->nombre) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filtro-group">
                            <label>Empleado</label>
                            <select name="empleado_id" onchange="this.form.submit()">
                                <option value="0">Todos los empleados</option>
                                <?php foreach ($empleadosFiltro as $emp): ?>
                                    <option value="<?= $emp->id ?>" <?= $filtros['empleado_id'] == $emp->id ? 'selected' : '' ?>>
                                        <?= sanitizar($emp->apellido1 . ', ' . $emp->nombre) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filtro-group">
                            <label>Mes</label>
                            <select name="mes" onchange="this.form.submit()">
                                <?php foreach ($meses as $num => $nombre): ?>
                                    <option value="<?= $num ?>" <?= $filtros['mes'] == $num ? 'selected' : '' ?>>
                                        <?= $nombre ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filtro-group">
                            <label>Año</label>
                            <select name="anio" onchange="this.form.submit()">
                                <?php foreach ($anios as $a): ?>
                                    <option value="<?= $a ?>" <?= $filtros['anio'] == $a ? 'selected' : '' ?>>
                                        <?= $a ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
                
                <!-- Resumen -->
                <div class="resumen-grid">
                    <div class="resumen-card">
                        <div class="label">Horas Trabajadas</div>
                        <div class="value"><?= number_format($totales['trabajadas'], 2) ?>h</div>
                    </div>
                    <div class="resumen-card">
                        <div class="label">Horas Esperadas</div>
                        <div class="value"><?= number_format($totales['esperadas'], 2) ?>h</div>
                    </div>
                    <div class="resumen-card <?= $totales['saldo_mes'] >= 0 ? 'positivo' : 'negativo' ?>">
                        <div class="label">Saldo del Mes</div>
                        <div class="value"><?= ($totales['saldo_mes'] >= 0 ? '+' : '') . number_format($totales['saldo_mes'], 2) ?>h</div>
                    </div>
                    <div class="resumen-card <?= $totales['saldo_total'] >= 0 ? 'positivo' : 'negativo' ?>">
                        <div class="label">Saldo Total Año</div>
                        <div class="value"><?= ($totales['saldo_total'] >= 0 ? '+' : '') . number_format($totales['saldo_total'], 2) ?>h</div>
                    </div>
                </div>
                
                <!-- Tabla -->
                <div class="tabla-container">
                    <div class="tabla-header">
                        <h2>📋 Detalle por Empleado</h2>
                        <span style="color: #64748b; font-size: 0.9rem;"><?= count($bolsaHoras) ?> empleados</span>
                    </div>
                    
                    <?php if (empty($bolsaHoras)): ?>
                        <div class="sin-datos">
                            <div class="icon">📊</div>
                            <p>No hay datos para los filtros seleccionados</p>
                        </div>
                    <?php else: ?>
                        <div class="tabla-scroll">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Empleado</th>
                                        <th>Centro</th>
                                        <th>Jornada</th>
                                        <th style="text-align: right;">H. Trabajadas</th>
                                        <th style="text-align: right;">H. Esperadas</th>
                                        <th style="text-align: right;">Saldo Mes</th>
                                        <th style="text-align: right;">Saldo Anterior</th>
                                        <th style="text-align: right;">Saldo Total</th>
                                        <th>Cumplimiento</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bolsaHoras as $emp): ?>
                                        <?php
                                        $clasePorc = 'excelente';
                                        if ($emp->porcentaje_cumplimiento < 95) $clasePorc = 'bueno';
                                        if ($emp->porcentaje_cumplimiento < 85) $clasePorc = 'bajo';
                                        if ($emp->porcentaje_cumplimiento < 75) $clasePorc = 'critico';
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="empleado-info">
                                                    <span class="empleado-nombre"><?= sanitizar($emp->nombre . ' ' . $emp->apellido1) ?></span>
                                                    <span class="empleado-nif"><?= sanitizar($emp->nif) ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if ($emp->centro_nombre): ?>
                                                    <span class="centro-tag"><?= sanitizar($emp->centro_nombre) ?></span>
                                                <?php else: ?>
                                                    <span style="color: #94a3b8;">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="jornada-badge <?= ($emp->porcentaje_jornada ?? 100) < 100 ? 'parcial' : '' ?>">
                                                    <?= ($emp->porcentaje_jornada ?? 100) ?>%
                                                </span>
                                            </td>
                                            <td class="horas-cell"><?= number_format($emp->total_trabajadas, 2) ?>h</td>
                                            <td class="horas-cell"><?= number_format($emp->total_esperadas, 2) ?>h</td>
                                            <td class="saldo-cell <?= $emp->saldo_mes >= 0 ? 'saldo-positivo' : 'saldo-negativo' ?>">
                                                <?= ($emp->saldo_mes >= 0 ? '+' : '') . number_format($emp->saldo_mes, 2) ?>h
                                            </td>
                                            <td class="saldo-cell <?= $emp->saldo_anterior >= 0 ? 'saldo-positivo' : ($emp->saldo_anterior < 0 ? 'saldo-negativo' : 'saldo-neutro') ?>">
                                                <?= ($emp->saldo_anterior >= 0 ? '+' : '') . number_format($emp->saldo_anterior, 2) ?>h
                                            </td>
                                            <td class="saldo-cell <?= $emp->saldo_total >= 0 ? 'saldo-positivo' : 'saldo-negativo' ?>">
                                                <?= ($emp->saldo_total >= 0 ? '+' : '') . number_format($emp->saldo_total, 2) ?>h
                                            </td>
                                            <td>
                                                <div class="barra-progreso">
                                                    <div class="fill <?= $clasePorc ?>" style="width: <?= min(100, $emp->porcentaje_cumplimiento) ?>%"></div>
                                                </div>
                                                <div class="porcentaje"><?= $emp->porcentaje_cumplimiento ?>%</div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    
                                    <!-- Fila de totales -->
                                    <tr class="fila-totales">
                                        <td colspan="3"><strong>TOTALES</strong></td>
                                        <td class="horas-cell"><?= number_format($totales['trabajadas'], 2) ?>h</td>
                                        <td class="horas-cell"><?= number_format($totales['esperadas'], 2) ?>h</td>
                                        <td class="saldo-cell <?= $totales['saldo_mes'] >= 0 ? 'saldo-positivo' : 'saldo-negativo' ?>">
                                            <?= ($totales['saldo_mes'] >= 0 ? '+' : '') . number_format($totales['saldo_mes'], 2) ?>h
                                        </td>
                                        <td class="saldo-cell">-</td>
                                        <td class="saldo-cell <?= $totales['saldo_total'] >= 0 ? 'saldo-positivo' : 'saldo-negativo' ?>">
                                            <?= ($totales['saldo_total'] >= 0 ? '+' : '') . number_format($totales['saldo_total'], 2) ?>h
                                        </td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script>
    // Auto-actualizar empleados cuando cambia el centro
    document.querySelector('select[name="centro_id"]')?.addEventListener('change', function() {
        // El form ya hace submit, pero podríamos usar AJAX en el futuro
    });
    </script>
</body>
</html>
<?php
// Exportar CSV si se solicita
if (isset($_GET['exportar']) && $_GET['exportar'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="bolsa_horas_' . $filtros['anio'] . '_' . str_pad($filtros['mes'], 2, '0', STR_PAD_LEFT) . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8
    
    // Cabeceras
    fputcsv($output, ['NIF', 'Nombre', 'Centro', 'Jornada %', 'H. Trabajadas', 'H. Esperadas', 'Saldo Mes', 'Saldo Anterior', 'Saldo Total', 'Cumplimiento %'], ';');
    
    foreach ($bolsaHoras as $emp) {
        fputcsv($output, [
            $emp->nif,
            $emp->nombre . ' ' . $emp->apellido1,
            $emp->centro_nombre ?? '',
            $emp->porcentaje_jornada ?? 100,
            number_format($emp->total_trabajadas, 2, ',', ''),
            number_format($emp->total_esperadas, 2, ',', ''),
            number_format($emp->saldo_mes, 2, ',', ''),
            number_format($emp->saldo_anterior, 2, ',', ''),
            number_format($emp->saldo_total, 2, ',', ''),
            number_format($emp->porcentaje_cumplimiento, 1, ',', ''),
        ], ';');
    }
    
    fclose($output);
    exit;
}
?>
