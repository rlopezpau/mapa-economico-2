<?php
/**
 * LM FICHAJES - Panel Admin: Gestión de Ausencias
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/ausencias.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Notificaciones
if (file_exists(INCLUDES_PATH . '/notificaciones.php')) {
    require_once INCLUDES_PATH . '/notificaciones.php';
}

// Verificar permisos
requerir_login('../login.php');
if (!es_supervisor()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: ../portal.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);
$mensaje = '';
$error = '';

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $accion = $_POST['accion'] ?? '';
    $solicitudId = (int)($_POST['solicitud_id'] ?? 0);
    
    if ($accion === 'aprobar' && $solicitudId) {
        // Actualizar con validador1_id
        try {
            // Obtener datos de la solicitud ANTES de aprobar
            $stmtSol = $pdo->prepare("
                SELECT sa.empleado_id, sa.fecha_inicio, sa.fecha_fin, ta.nombre as tipo_nombre
                FROM solicitudes_ausencia sa
                INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
                WHERE sa.id = ?
            ");
            $stmtSol->execute([$solicitudId]);
            $datosSolicitud = $stmtSol->fetch();
            
            $sql = "UPDATE solicitudes_ausencia SET 
                        estado = 'aprobada',
                        validador1_id = ?,
                        validador1_fecha = NOW(),
                        validador1_observacion = ?
                    WHERE id = ? AND estado = 'pendiente'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$usuario->id, $_POST['observaciones'] ?? '', $solicitudId]);
            
            // ACTUALIZAR SALDO DEL EMPLEADO (sumar a días disfrutados)
            actualizar_saldo_ausencia($pdo, $solicitudId, 'aprobar_directo');
            
            $mensaje = 'Solicitud aprobada correctamente';
            
            // AUDITORÍA ENS
            if (function_exists('registrar_auditoria')) {
                registrar_auditoria('AUSENCIA_APROBADA', "Ausencia aprobada: ID {$solicitudId}", 
                    ['solicitud_id' => $solicitudId], 'INFO', $usuario->id, 'solicitudes_ausencia', $solicitudId);
            }
            
            // NOTIFICACIÓN AL EMPLEADO
            if ($datosSolicitud && function_exists('notificar_ausencia_aprobada')) {
                notificar_ausencia_aprobada(
                    $pdo, 
                    $datosSolicitud->empleado_id, 
                    $datosSolicitud->tipo_nombre,
                    date('d/m/Y', strtotime($datosSolicitud->fecha_inicio)),
                    date('d/m/Y', strtotime($datosSolicitud->fecha_fin)),
                    $solicitudId
                );
            }
        } catch (PDOException $e) {
            $error = 'Error al aprobar la solicitud';
        }
    }
    
    if ($accion === 'rechazar' && $solicitudId) {
        $motivo = trim($_POST['motivo_rechazo'] ?? '');
        if (empty($motivo)) {
            $error = 'Debe indicar un motivo de rechazo';
        } else {
            try {
                // Obtener datos de la solicitud ANTES de rechazar
                $stmtSol = $pdo->prepare("
                    SELECT sa.empleado_id, sa.fecha_inicio, sa.fecha_fin, ta.nombre as tipo_nombre
                    FROM solicitudes_ausencia sa
                    INNER JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
                    WHERE sa.id = ?
                ");
                $stmtSol->execute([$solicitudId]);
                $datosSolicitud = $stmtSol->fetch();
                
                $sql = "UPDATE solicitudes_ausencia SET 
                            estado = 'rechazada',
                            validador1_id = ?,
                            validador1_fecha = NOW(),
                            validador1_observacion = ?
                        WHERE id = ? AND estado = 'pendiente'";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$usuario->id, $motivo, $solicitudId]);
                $mensaje = 'Solicitud rechazada';
                
                // AUDITORÍA ENS
                if (function_exists('registrar_auditoria')) {
                    registrar_auditoria('AUSENCIA_RECHAZADA', "Ausencia rechazada: ID {$solicitudId}", 
                        ['solicitud_id' => $solicitudId, 'motivo' => $motivo], 'WARNING', $usuario->id, 'solicitudes_ausencia', $solicitudId);
                }
                
                // NOTIFICACIÓN AL EMPLEADO
                if ($datosSolicitud && function_exists('notificar_ausencia_rechazada')) {
                    notificar_ausencia_rechazada(
                        $pdo, 
                        $datosSolicitud->empleado_id, 
                        $datosSolicitud->tipo_nombre,
                        date('d/m/Y', strtotime($datosSolicitud->fecha_inicio)),
                        date('d/m/Y', strtotime($datosSolicitud->fecha_fin)),
                        $motivo,
                        $solicitudId
                    );
                }
            } catch (PDOException $e) {
                $error = 'Error al rechazar la solicitud';
            }
        }
    }
}

// Filtros
$filtros = [
    'estado' => $_GET['estado'] ?? 'pendiente',
    'empleado_id' => (int)($_GET['empleado_id'] ?? 0),
    'tipo_id' => (int)($_GET['tipo_id'] ?? 0),
    'fecha_desde' => $_GET['fecha_desde'] ?? '',
    'fecha_hasta' => $_GET['fecha_hasta'] ?? ''
];

// Obtener datos - usando validador1_id
$sql = "SELECT s.*, 
               e.nombre as empleado_nombre, 
               e.apellido1 as empleado_apellido1,
               t.nombre as tipo_nombre,
               t.color as tipo_color,
               v.nombre as validador_nombre,
               v.apellido1 as validador_apellido1
        FROM solicitudes_ausencia s
        JOIN empleados e ON s.empleado_id = e.id
        JOIN tipos_ausencia t ON s.tipo_ausencia_id = t.id
        LEFT JOIN empleados v ON s.validador1_id = v.id
        WHERE 1=1";
$params = [];

if ($filtros['estado']) {
    $sql .= " AND s.estado = ?";
    $params[] = $filtros['estado'];
}
if ($filtros['empleado_id']) {
    $sql .= " AND s.empleado_id = ?";
    $params[] = $filtros['empleado_id'];
}
if ($filtros['tipo_id']) {
    $sql .= " AND s.tipo_ausencia_id = ?";
    $params[] = $filtros['tipo_id'];
}
if ($filtros['fecha_desde']) {
    $sql .= " AND s.fecha_inicio >= ?";
    $params[] = $filtros['fecha_desde'];
}
if ($filtros['fecha_hasta']) {
    $sql .= " AND s.fecha_fin <= ?";
    $params[] = $filtros['fecha_hasta'];
}

$sql .= " ORDER BY s.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$solicitudes = $stmt->fetchAll();

// Datos para filtros
$empleados = $pdo->query("SELECT id, nombre, apellido1 FROM empleados WHERE activo = 1 ORDER BY apellido1")->fetchAll();
$tipos = $pdo->query("SELECT id, nombre FROM tipos_ausencia WHERE activo = 1 ORDER BY nombre")->fetchAll();

// Contar por estado
$contadores = [];
$stmtCount = $pdo->query("SELECT estado, COUNT(*) as total FROM solicitudes_ausencia GROUP BY estado");
foreach ($stmtCount->fetchAll() as $row) {
    $contadores[$row->estado] = $row->total;
}

// Variables para layout
$paginaActual = 'ausencias';
$titulo = 'Gestión de Ausencias';
$stats = obtener_estadisticas_dashboard($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.tabs-estado { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.tab-estado { padding: 0.5rem 1rem; border-radius: 2rem; font-size: 0.875rem; text-decoration: none; border: 1px solid #e2e8f0; color: #64748b; display: flex; align-items: center; gap: 0.5rem; }
.tab-estado:hover { background: #f8fafc; }
.tab-estado.active { background: #0ea5e9; color: white; border-color: #0ea5e9; }
.tab-estado .count { background: rgba(0,0,0,0.1); padding: 0.125rem 0.5rem; border-radius: 1rem; font-size: 0.75rem; }
.tab-estado.active .count { background: rgba(255,255,255,0.2); }
.solicitud-card { background: white; border-radius: 0.75rem; padding: 1.25rem; margin-bottom: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.solicitud-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
.solicitud-empleado { font-weight: 600; font-size: 1rem; }
.solicitud-tipo { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
.solicitud-fechas { display: flex; gap: 2rem; margin: 1rem 0; padding: 1rem; background: #f8fafc; border-radius: 0.5rem; }
.solicitud-fecha label { display: block; font-size: 0.75rem; color: #64748b; margin-bottom: 0.25rem; }
.solicitud-fecha span { font-weight: 600; }
.solicitud-motivo { margin: 1rem 0; padding: 1rem; background: #fef3c7; border-radius: 0.5rem; font-size: 0.875rem; }
.solicitud-acciones { display: flex; gap: 0.5rem; justify-content: flex-end; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; }
.estado-badge { padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
.estado-pendiente { background: #fef3c7; color: #92400e; }
.estado-aprobada { background: #dcfce7; color: #166534; }
.estado-rechazada { background: #fee2e2; color: #991b1b; }
.estado-borrador { background: #e2e8f0; color: #64748b; }
.empty-state { text-align: center; padding: 3rem; color: #64748b; }
.empty-state .icon { font-size: 3rem; margin-bottom: 1rem; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">📅 Gestión de Ausencias</h1>
        <p class="page-subtitle">Gestiona las solicitudes de ausencia de los empleados</p>
    </div>
</div>

<?php if ($mensaje): ?>
<div class="alert alert-success">✅ <?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- Tabs de estado -->
<div class="tabs-estado">
    <a href="?estado=pendiente" class="tab-estado <?= $filtros['estado'] === 'pendiente' ? 'active' : '' ?>">
        ⏳ Pendientes <span class="count"><?= $contadores['pendiente'] ?? 0 ?></span>
    </a>
    <a href="?estado=aprobada" class="tab-estado <?= $filtros['estado'] === 'aprobada' ? 'active' : '' ?>">
        ✅ Aprobadas <span class="count"><?= $contadores['aprobada'] ?? 0 ?></span>
    </a>
    <a href="?estado=rechazada" class="tab-estado <?= $filtros['estado'] === 'rechazada' ? 'active' : '' ?>">
        ❌ Rechazadas <span class="count"><?= $contadores['rechazada'] ?? 0 ?></span>
    </a>
    <a href="?estado=" class="tab-estado <?= empty($filtros['estado']) ? 'active' : '' ?>">
        📋 Todas
    </a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body">
        <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
            <input type="hidden" name="estado" value="<?= htmlspecialchars($filtros['estado']) ?>">
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Empleado</label>
                <select name="empleado_id" class="form-control" style="min-width: 200px;">
                    <option value="">Todos</option>
                    <?php foreach ($empleados as $emp): ?>
                    <option value="<?= $emp->id ?>" <?= $filtros['empleado_id'] == $emp->id ? 'selected' : '' ?>>
                        <?= htmlspecialchars($emp->apellido1 . ', ' . $emp->nombre) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Tipo</label>
                <select name="tipo_id" class="form-control">
                    <option value="">Todos</option>
                    <?php foreach ($tipos as $tipo): ?>
                    <option value="<?= $tipo->id ?>" <?= $filtros['tipo_id'] == $tipo->id ? 'selected' : '' ?>>
                        <?= htmlspecialchars($tipo->nombre) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Desde</label>
                <input type="date" name="fecha_desde" class="form-control" value="<?= $filtros['fecha_desde'] ?>">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label class="form-label">Hasta</label>
                <input type="date" name="fecha_hasta" class="form-control" value="<?= $filtros['fecha_hasta'] ?>">
            </div>
            
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
            <a href="ausencias.php" class="btn btn-outline">Limpiar</a>
        </form>
    </div>
</div>

<!-- Lista de solicitudes -->
<?php if (empty($solicitudes)): ?>
<div class="card">
    <div class="empty-state">
        <div class="icon">📅</div>
        <h3>No hay solicitudes</h3>
        <p>No se encontraron solicitudes con los filtros seleccionados</p>
    </div>
</div>
<?php else: ?>
    <?php foreach ($solicitudes as $sol): ?>
    <div class="solicitud-card">
        <div class="solicitud-header">
            <div>
                <div class="solicitud-empleado">
                    <?= htmlspecialchars($sol->empleado_nombre . ' ' . $sol->empleado_apellido1) ?>
                </div>
                <span class="solicitud-tipo" style="background: <?= $sol->tipo_color ?>20; color: <?= $sol->tipo_color ?>;">
                    <?= htmlspecialchars($sol->tipo_nombre) ?>
                </span>
            </div>
            <span class="estado-badge estado-<?= $sol->estado ?>">
                <?= ucfirst($sol->estado) ?>
            </span>
        </div>
        
        <div class="solicitud-fechas">
            <div class="solicitud-fecha">
                <label>Fecha inicio</label>
                <span><?= date('d/m/Y', strtotime($sol->fecha_inicio)) ?></span>
                <small style="color: #64748b;"><?= ucfirst($sol->jornada_inicio) ?></small>
            </div>
            <div class="solicitud-fecha">
                <label>Fecha fin</label>
                <span><?= date('d/m/Y', strtotime($sol->fecha_fin)) ?></span>
                <small style="color: #64748b;"><?= ucfirst($sol->jornada_fin) ?></small>
            </div>
            <div class="solicitud-fecha">
                <label>Días solicitados</label>
                <span><?= $sol->dias_solicitados ?></span>
            </div>
        </div>
        
        <?php if ($sol->motivo): ?>
        <div class="solicitud-motivo">
            <strong>📝 Motivo:</strong> <?= htmlspecialchars($sol->motivo) ?>
        </div>
        <?php endif; ?>
        
        <?php if ($sol->estado === 'pendiente'): ?>
        <div class="solicitud-acciones">
            <form method="POST" style="display: inline;">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="rechazar">
                <input type="hidden" name="solicitud_id" value="<?= $sol->id ?>">
                <input type="text" name="motivo_rechazo" placeholder="Motivo de rechazo..." required style="padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 0.375rem; margin-right: 0.5rem;">
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Rechazar esta solicitud?')">❌ Rechazar</button>
            </form>
            <form method="POST" style="display: inline;">
                <?= csrf_campo() ?>
                <input type="hidden" name="accion" value="aprobar">
                <input type="hidden" name="solicitud_id" value="<?= $sol->id ?>">
                <button type="submit" class="btn btn-success btn-sm">✅ Aprobar</button>
            </form>
        </div>
        <?php elseif ($sol->validador1_id): ?>
        <div style="font-size: 0.8rem; color: #64748b; margin-top: 1rem;">
            <?= $sol->estado === 'aprobada' ? '✅ Aprobada' : '❌ Rechazada' ?> por 
            <?= htmlspecialchars($sol->validador_nombre . ' ' . $sol->validador_apellido1) ?>
            el <?= date('d/m/Y H:i', strtotime($sol->validador1_fecha)) ?>
            <?php if ($sol->validador1_observacion): ?>
            <br><em>"<?= htmlspecialchars($sol->validador1_observacion) ?>"</em>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
