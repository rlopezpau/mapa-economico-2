<?php
/**
 * LM FICHAJES - Descarga segura de documentos
 * 
 * Solo permite descarga si:
 * - Es admin/manager
 * - O el documento es para ese empleado
 * - O el documento es para su centro
 * - O el documento es para todos
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

requerir_login('login.php');

$usuario = obtener_usuario_actual($pdo);
$docId = (int)($_GET['id'] ?? 0);

if ($docId <= 0) {
    header('HTTP/1.1 400 Bad Request');
    die('Documento no especificado');
}

// Obtener documento
$stmt = $pdo->prepare("SELECT * FROM documentos_empleado WHERE id = ?");
$stmt->execute([$docId]);
$doc = $stmt->fetch();

if (!$doc) {
    header('HTTP/1.1 404 Not Found');
    die('Documento no encontrado');
}

// Verificar permisos
$tieneAcceso = false;

// Admin/Manager siempre tienen acceso
if (es_manager()) {
    $tieneAcceso = true;
}
// Documento para este empleado específico
elseif ($doc->empleado_id && $doc->empleado_id == $usuario->id) {
    $tieneAcceso = true;
}
// Documento para todos
elseif (!$doc->empleado_id && !$doc->centro_id) {
    $tieneAcceso = true;
}
// Documento para un centro específico
elseif ($doc->centro_id) {
    // Verificar si el empleado pertenece al centro
    try {
        $stmt = $pdo->prepare("SELECT 1 FROM empleados_centros WHERE empleado_id = ? AND centro_id = ? AND activo = 1");
        $stmt->execute([$usuario->id, $doc->centro_id]);
        if ($stmt->fetch()) {
            $tieneAcceso = true;
        }
    } catch (PDOException $e) {
        // Si la tabla no existe, dar acceso si el documento es visible para empleados
        // (esto permite que funcione incluso sin la tabla empleados_centros)
        if ($doc->visible_empleado) {
            $tieneAcceso = true;
        }
    }
}

if (!$tieneAcceso) {
    header('HTTP/1.1 403 Forbidden');
    die('No tienes permiso para ver este documento');
}

// Verificar que el documento no está oculto para empleados
if (!es_manager() && !$doc->visible_empleado) {
    header('HTTP/1.1 403 Forbidden');
    die('Este documento no está disponible');
}

// Verificar que el archivo existe
$rutaCompleta = ROOT_PATH . '/uploads/documentos/' . $doc->ruta_archivo;
if (!file_exists($rutaCompleta)) {
    header('HTTP/1.1 404 Not Found');
    die('Archivo no encontrado en el servidor');
}

// Registrar descarga (auditoría)
if (function_exists('registrar_auditoria')) {
    registrar_auditoria('READ', "Documento descargado: {$doc->nombre}", ['documento_id' => $docId], 'INFO', $usuario->id, 'documentos_empleado', $docId);
}

// Enviar archivo
$mime = $doc->mime_type ?: 'application/octet-stream';
$nombreDescarga = $doc->nombre_archivo;

header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . $nombreDescarga . '"');
header('Content-Length: ' . filesize($rutaCompleta));
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');

readfile($rutaCompleta);
exit;
