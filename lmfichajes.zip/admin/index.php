<?php
/**
 * LM FICHAJES - Panel de Administración: Dashboard
 * 
 * Página principal del panel de administración.
 * Muestra resumen de estadísticas, fichajes pendientes y actividad reciente.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     2.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/auditoria.php';
require_once INCLUDES_PATH . '/licencias.php';
require_once __DIR__ . '/includes/admin_functions.php';

// ============================================================================
// SEGURIDAD Y PERMISOS
// ============================================================================

requerir_login('../login.php');

if (!es_supervisor()) {
    audit_permiso_denegado('admin/index.php', 'Rol insuficiente');
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder al panel de administración';
    header('Location: ../portal.php');
    exit;
}

// ============================================================================
// OBTENER DATOS
// ============================================================================

$usuario = obtener_usuario_actual($pdo);
$stats = obtener_estadisticas_dashboard($pdo);

// Fichajes pendientes de validación
$resultadoFichajes = obtener_fichajes_pendientes($pdo, 5);
$fichajesPendientes = $resultadoFichajes['fichajes'] ?? [];

// Actividad reciente (últimos 10 registros de auditoría)
$actividadReciente = [];
try {
    $stmt = $pdo->query("
        SELECT a.*, e.nombre, e.apellido1 
        FROM audit_log a 
        LEFT JOIN empleados e ON a.usuario_id = e.id
        ORDER BY a.created_at DESC 
        LIMIT 10
    ");
    $actividadReciente = $stmt->fetchAll();
} catch (PDOException $e) {
    // Tabla puede no existir aún
}

// ============================================================================
// CONFIGURACIÓN DE PÁGINA
// ============================================================================

$titulo = 'Dashboard';
$paginaActual = 'dashboard';

// ============================================================================
// RENDERIZAR PÁGINA
// ============================================================================

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

            <!-- Mensajes -->
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="alert alert-success">✅ <?php echo htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_mensaje'])): ?>
                <div class="alert alert-error">❌ <?php echo htmlspecialchars($_SESSION['error_mensaje']); unset($_SESSION['error_mensaje']); ?></div>
            <?php endif; ?>

            <!-- Header de página -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Dashboard</h1>
                    <p class="page-subtitle">Resumen del sistema de fichajes · <?php echo date('l, d \de F \de Y'); ?></p>
                </div>
            </div>
            
            <!-- Estadísticas principales -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div>
                        <div class="stat-value"><?php echo $stats['empleados_activos'] ?? 0; ?></div>
                        <div class="stat-label">Empleados activos</div>
                    </div>
                </div>
                
                <div class="stat-card highlight">
                    <div class="stat-icon">✅</div>
                    <div>
                        <div class="stat-value"><?php echo $stats['fichajes_hoy'] ?? 0; ?></div>
                        <div class="stat-label">Fichajes hoy</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🏃</div>
                    <div>
                        <div class="stat-value"><?php echo $stats['trabajando_ahora'] ?? 0; ?></div>
                        <div class="stat-label">Trabajando ahora</div>
                    </div>
                </div>
                
                <div class="stat-card <?php echo ($stats['fichajes_pendientes'] ?? 0) > 0 ? 'highlight' : ''; ?>" 
                     style="<?php echo ($stats['fichajes_pendientes'] ?? 0) > 0 ? 'background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);' : ''; ?>">
                    <div class="stat-icon">⏳</div>
                    <div>
                        <div class="stat-value"><?php echo $stats['fichajes_pendientes'] ?? 0; ?></div>
                        <div class="stat-label">Pendientes validar</div>
                    </div>
                </div>
            </div>
            
            <!-- Contenido en dos columnas -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                
                <!-- Fichajes pendientes -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title">⏳ Fichajes Pendientes de Validación</span>
                        <?php if (count($fichajesPendientes) > 0): ?>
                            <a href="fichajes.php" class="btn btn-sm btn-outline">Ver todos</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if (empty($fichajesPendientes)): ?>
                            <div class="empty-state" style="padding: 2rem;">
                                <div class="icon">✅</div>
                                <p>No hay fichajes pendientes</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($fichajesPendientes as $fichaje): ?>
                                <div class="list-item">
                                    <div class="avatar avatar-sm">
                                        <?php echo strtoupper(substr($fichaje->nombre ?? '?', 0, 1)); ?>
                                    </div>
                                    <div style="flex: 1;">
                                        <strong><?php echo htmlspecialchars(($fichaje->apellido1 ?? '') . ', ' . ($fichaje->nombre ?? '')); ?></strong>
                                        <div style="font-size: 0.8rem; color: #64748b;">
                                            <?php echo date('d/m/Y', strtotime($fichaje->fecha)); ?> 
                                            <?php echo substr($fichaje->hora, 0, 5); ?> -
                                            <?php echo ucfirst($fichaje->tipo); ?>
                                        </div>
                                    </div>
                                    <div>
                                        <?php if ($fichaje->fuera_ubicacion ?? false): ?>
                                            <span class="badge badge-warning">📍</span>
                                        <?php endif; ?>
                                        <?php if ($fichaje->fuera_horario ?? false): ?>
                                            <span class="badge badge-warning">🕐</span>
                                        <?php endif; ?>
                                    </div>
                                    <a href="fichajes.php?validar=<?php echo $fichaje->id; ?>" class="btn btn-sm btn-primary">
                                        Validar
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Actividad reciente -->
                <div class="card">
                    <div class="card-header">
                        <span class="card-title">📋 Actividad Reciente</span>
                        <?php if (es_admin()): ?>
                            <a href="auditoria.php" class="btn btn-sm btn-outline">Ver auditoría</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if (empty($actividadReciente)): ?>
                            <div class="empty-state" style="padding: 2rem;">
                                <div class="icon">📋</div>
                                <p>No hay actividad registrada</p>
                                <small style="color: #94a3b8;">Ejecuta install_auditoria.php primero</small>
                            </div>
                        <?php else: ?>
                            <?php foreach ($actividadReciente as $log): ?>
                                <div class="list-item" style="padding: 0.5rem 0.75rem;">
                                    <div style="flex: 1;">
                                        <div style="font-size: 0.875rem;">
                                            <?php 
                                            $icono = match($log->tipo) {
                                                'LOGIN_OK' => '🔓',
                                                'LOGIN_FAIL' => '🔒',
                                                'LOGOUT' => '🚪',
                                                'CREATE' => '➕',
                                                'UPDATE' => '✏️',
                                                'DELETE' => '🗑️',
                                                'FICHAJE' => '⏱️',
                                                'VALIDACION' => '✅',
                                                default => '📌'
                                            };
                                            echo $icono . ' ' . htmlspecialchars($log->descripcion);
                                            ?>
                                        </div>
                                        <div style="font-size: 0.75rem; color: #64748b;">
                                            <?php echo $log->nombre ? htmlspecialchars($log->nombre . ' ' . $log->apellido1) : 'Sistema'; ?>
                                            · <?php echo date('d/m H:i', strtotime($log->created_at)); ?>
                                        </div>
                                    </div>
                                    <span class="badge badge-<?php 
                                        echo match($log->nivel) {
                                            'WARNING' => 'warning',
                                            'ERROR' => 'danger',
                                            'CRITICAL' => 'danger',
                                            default => 'neutral'
                                        };
                                    ?>" style="font-size: 0.65rem;">
                                        <?php echo $log->nivel; ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Resumen adicional -->
            <div class="card" style="margin-top: 1.5rem;">
                <div class="card-header">
                    <span class="card-title">📊 Resumen del Sistema</span>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Centros de trabajo</div>
                            <div class="info-value"><?php echo $stats['centros_activos'] ?? 0; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Horarios configurados</div>
                            <div class="info-value"><?php echo $stats['horarios_activos'] ?? 0; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Fichajes este mes</div>
                            <div class="info-value"><?php echo $stats['fichajes_mes'] ?? 0; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Versión</div>
                            <div class="info-value"><?php echo APP_VERSION; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Widget de Licencia -->
            <?php 
            if (function_exists('obtener_uso_licencia')) {
                $usoLicencia = obtener_uso_licencia($pdo);
                $colorEmpleados = $usoLicencia['empleados']['porcentaje'] >= 90 ? '#dc2626' : ($usoLicencia['empleados']['porcentaje'] >= 70 ? '#f59e0b' : '#22c55e');
                $colorCentros = $usoLicencia['centros']['porcentaje'] >= 90 ? '#dc2626' : ($usoLicencia['centros']['porcentaje'] >= 70 ? '#f59e0b' : '#22c55e');
            ?>
            <div class="card" style="margin-top: 1.5rem;">
                <div class="card-header">
                    <span class="card-title">📋 Licencia: <?= htmlspecialchars($usoLicencia['plan']) ?></span>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                <span style="color: #64748b;">Empleados</span>
                                <span><strong><?= $usoLicencia['empleados']['actuales'] ?></strong> / <?= $usoLicencia['empleados']['maximo'] ?></span>
                            </div>
                            <div style="background: #e5e7eb; border-radius: 6px; height: 10px; overflow: hidden;">
                                <div style="background: <?= $colorEmpleados ?>; height: 100%; width: <?= $usoLicencia['empleados']['porcentaje'] ?>%; transition: width 0.3s;"></div>
                            </div>
                        </div>
                        <div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                <span style="color: #64748b;">Centros</span>
                                <span><strong><?= $usoLicencia['centros']['actuales'] ?></strong> / <?= $usoLicencia['centros']['maximo'] ?></span>
                            </div>
                            <div style="background: #e5e7eb; border-radius: 6px; height: 10px; overflow: hidden;">
                                <div style="background: <?= $colorCentros ?>; height: 100%; width: <?= $usoLicencia['centros']['porcentaje'] ?>%; transition: width 0.3s;"></div>
                            </div>
                        </div>
                    </div>
                    <?php if ($usoLicencia['dias_restantes'] !== null && $usoLicencia['dias_restantes'] <= 15): ?>
                    <div style="background: #fef3c7; color: #92400e; padding: 10px; border-radius: 6px; margin-top: 15px; font-size: 13px;">
                        ⚠️ Tu licencia expira en <?= $usoLicencia['dias_restantes'] ?> días. Contacta con soporte para renovar.
                    </div>
                    <?php endif; ?>
                    <?php if (!$usoLicencia['vigente']): ?>
                    <div style="background: #fee2e2; color: #dc2626; padding: 10px; border-radius: 6px; margin-top: 15px; font-size: 13px;">
                        ❌ Licencia expirada. Contacta con soporte para renovar.
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php } ?>

<?php
require_once __DIR__ . '/includes/layout_footer.php';
?>
