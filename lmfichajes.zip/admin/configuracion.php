<?php
/**
 * LM FICHAJES - Panel Admin: Configuración de Empresa
 * VERSIÓN CON LAYOUT COMPARTIDO + GESTIÓN DE LICENCIA
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/../config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/licencias.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

establecer_headers_seguridad();
requerir_login('../login.php');

if (!es_admin()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: index.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);

define('LOGOS_PATH', ROOT_PATH . '/uploads/logos');
define('LOGOS_URL', APP_URL . '/uploads/logos');

if (!is_dir(LOGOS_PATH)) {
    mkdir(LOGOS_PATH, 0755, true);
}

function obtener_configuracion_local($pdo) {
    $config = [];
    $stmt = $pdo->query("SELECT clave, valor FROM configuracion");
    while ($row = $stmt->fetch()) {
        $config[$row->clave] = $row->valor;
    }
    return $config;
}

function guardar_configuracion_local($pdo, $clave, $valor) {
    $stmt = $pdo->prepare("INSERT INTO configuracion (clave, valor, updated_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE valor = VALUES(valor), updated_at = NOW()");
    return $stmt->execute([$clave, $valor]);
}

$config = obtener_configuracion_local($pdo);

$defaults = [
    'nombre_empresa' => '', 'cif_nif' => '', 'direccion' => '', 'codigo_postal' => '',
    'localidad' => '', 'provincia' => '', 'telefono' => '', 'email' => '', 'web' => '',
    'coordenadas' => '', 'logo_url' => '', 'color_primario' => '#2d5a87', 'color_secundario' => '#10b981',
    'dias_vacaciones_defecto' => '22', 'dias_asuntos_propios' => '6', 'geoloc_obligatoria' => '1',
    'radio_metros_defecto' => '100', 'validacion_doble' => '0', 'permitir_teletrabajo' => '1',
    'permitir_fichaje_manual' => '0', 'mostrar_banco_horas' => '1', 'notificar_incidencias' => '1'
];

$config = array_merge($defaults, $config);
$mensaje = '';
$tipoMensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $mensaje = 'Error de seguridad. Recarga la página.';
        $tipoMensaje = 'error';
    } else {
        $accion = $_POST['accion'] ?? '';
        
        if ($accion === 'guardar_empresa') {
            $campos = ['nombre_empresa', 'cif_nif', 'direccion', 'codigo_postal', 'localidad', 'provincia', 'telefono', 'email', 'web', 'coordenadas'];
            foreach ($campos as $campo) {
                $valor = sanitizar($_POST[$campo] ?? '');
                guardar_configuracion_local($pdo, $campo, $valor);
                $config[$campo] = $valor;
            }
            $mensaje = 'Datos de empresa guardados correctamente';
            $tipoMensaje = 'success';
            
            // AUDITORÍA ENS
            if (function_exists('registrar_auditoria')) {
                registrar_auditoria('CONFIG_CHANGE', 'Datos de empresa actualizados', ['campos' => $campos], 'INFO', $usuario->id, 'configuracion', null);
            }
        }
        elseif ($accion === 'subir_logo') {
            if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $archivo = $_FILES['logo'];
                $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
                $maxSize = 2 * 1024 * 1024;
                
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $tipoMime = finfo_file($finfo, $archivo['tmp_name']);
                finfo_close($finfo);
                
                if (!in_array($tipoMime, $tiposPermitidos)) {
                    $mensaje = 'Tipo de archivo no permitido.';
                    $tipoMensaje = 'error';
                } elseif ($archivo['size'] > $maxSize) {
                    $mensaje = 'El archivo es demasiado grande. Máximo 2MB.';
                    $tipoMensaje = 'error';
                } else {
                    $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
                    $nombreArchivo = 'logo_' . time() . '.' . strtolower($extension);
                    $rutaDestino = LOGOS_PATH . '/' . $nombreArchivo;
                    
                    if (!empty($config['logo_url'])) {
                        $logoAnterior = LOGOS_PATH . '/' . basename($config['logo_url']);
                        if (file_exists($logoAnterior)) unlink($logoAnterior);
                    }
                    
                    if (move_uploaded_file($archivo['tmp_name'], $rutaDestino)) {
                        $logoUrl = LOGOS_URL . '/' . $nombreArchivo;
                        guardar_configuracion_local($pdo, 'logo_url', $logoUrl);
                        $config['logo_url'] = $logoUrl;
                        $mensaje = 'Logo subido correctamente';
                        $tipoMensaje = 'success';
                    } else {
                        $mensaje = 'Error al guardar el archivo';
                        $tipoMensaje = 'error';
                    }
                }
            }
        }
        elseif ($accion === 'eliminar_logo') {
            if (!empty($config['logo_url'])) {
                $logoPath = LOGOS_PATH . '/' . basename($config['logo_url']);
                if (file_exists($logoPath)) unlink($logoPath);
                guardar_configuracion_local($pdo, 'logo_url', '');
                $config['logo_url'] = '';
                $mensaje = 'Logo eliminado';
                $tipoMensaje = 'success';
            }
        }
        elseif ($accion === 'guardar_personalizacion') {
            $colorPrimario = $_POST['color_primario'] ?? '#2d5a87';
            $colorSecundario = $_POST['color_secundario'] ?? '#10b981';
            if (preg_match('/^#[0-9A-Fa-f]{6}$/', $colorPrimario)) {
                guardar_configuracion_local($pdo, 'color_primario', $colorPrimario);
                $config['color_primario'] = $colorPrimario;
            }
            if (preg_match('/^#[0-9A-Fa-f]{6}$/', $colorSecundario)) {
                guardar_configuracion_local($pdo, 'color_secundario', $colorSecundario);
                $config['color_secundario'] = $colorSecundario;
            }
            $mensaje = 'Colores guardados correctamente';
            $tipoMensaje = 'success';
        }
        elseif ($accion === 'guardar_sistema') {
            $parametros = [
                'dias_vacaciones_defecto' => intval($_POST['dias_vacaciones_defecto'] ?? 22),
                'dias_asuntos_propios' => intval($_POST['dias_asuntos_propios'] ?? 6),
                'radio_metros_defecto' => intval($_POST['radio_metros_defecto'] ?? 100),
                'geoloc_obligatoria' => isset($_POST['geoloc_obligatoria']) ? '1' : '0',
                'validacion_doble' => isset($_POST['validacion_doble']) ? '1' : '0',
                'permitir_teletrabajo' => isset($_POST['permitir_teletrabajo']) ? '1' : '0',
                'permitir_fichaje_manual' => isset($_POST['permitir_fichaje_manual']) ? '1' : '0',
                'mostrar_banco_horas' => isset($_POST['mostrar_banco_horas']) ? '1' : '0',
                'notificar_incidencias' => isset($_POST['notificar_incidencias']) ? '1' : '0'
            ];
            foreach ($parametros as $clave => $valor) {
                guardar_configuracion_local($pdo, $clave, $valor);
                $config[$clave] = $valor;
            }
            $mensaje = 'Parámetros del sistema guardados correctamente';
            $tipoMensaje = 'success';
        }
        elseif ($accion === 'activar_licencia') {
            $codigoLicencia = trim($_POST['codigo_licencia'] ?? '');
            
            if (empty($codigoLicencia)) {
                $mensaje = 'El código de licencia es obligatorio';
                $tipoMensaje = 'error';
            } else {
                $resultado = activar_licencia($pdo, $codigoLicencia);
                
                if ($resultado['ok']) {
                    $mensaje = 'Licencia activada correctamente: ' . ($resultado['licencia']['plan_nombre'] ?? 'Plan activado');
                    $tipoMensaje = 'success';
                    
                    // AUDITORÍA ENS
                    if (function_exists('registrar_auditoria')) {
                        registrar_auditoria('LICENSE_ACTIVATED', 'Licencia activada', ['codigo' => $codigoLicencia], 'INFO', $usuario->id, 'configuracion', null);
                    }
                } else {
                    $mensaje = $resultado['error'] ?? 'Error al validar la licencia';
                    $tipoMensaje = 'error';
                }
            }
        }
    }
}

$provincias = ['Álava','Albacete','Alicante','Almería','Asturias','Ávila','Badajoz','Barcelona','Burgos','Cáceres','Cádiz','Cantabria','Castellón','Ciudad Real','Córdoba','Cuenca','Girona','Granada','Guadalajara','Guipúzcoa','Huelva','Huesca','Illes Balears','Jaén','A Coruña','La Rioja','Las Palmas','León','Lleida','Lugo','Madrid','Málaga','Murcia','Navarra','Ourense','Palencia','Pontevedra','Salamanca','Santa Cruz de Tenerife','Segovia','Sevilla','Soria','Tarragona','Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza','Ceuta','Melilla'];
sort($provincias);

$paginaActual = 'configuracion';
$titulo = 'Configuración del Sistema';
$stats = obtener_estadisticas_dashboard($pdo);

// Obtener datos de licencia
$licenciaActual = obtener_licencia_activa($pdo);
$codigoActual = obtener_codigo_licencia($pdo);
$usoLicencia = obtener_uso_licencia($pdo);

require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<style>
.config-tabs { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 2px solid #e2e8f0; padding-bottom: 0.5rem; flex-wrap: wrap; }
.config-tab { padding: 0.75rem 1.25rem; border-radius: 0.5rem 0.5rem 0 0; background: none; border: none; cursor: pointer; font-size: 0.9rem; color: #64748b; font-weight: 500; }
.config-tab:hover { background: #f8fafc; }
.config-tab.active { background: #4f46e5; color: white; }
.tab-content { display: none; }
.tab-content.active { display: block; }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; }
.form-grid.cols-3 { grid-template-columns: repeat(3, 1fr); }
.form-group.full-width { grid-column: 1 / -1; }
.form-hint { font-size: 0.75rem; color: #64748b; margin-top: 0.25rem; display: block; }
.logo-section { display: flex; gap: 2rem; align-items: center; flex-wrap: wrap; }
.logo-preview { width: 150px; height: 150px; border: 2px dashed #e2e8f0; border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #f8fafc; }
.logo-preview img { max-width: 100%; max-height: 100%; object-fit: contain; border-radius: 8px; }
.logo-preview .placeholder { font-size: 3rem; color: #cbd5e1; }
.logo-actions { display: flex; flex-direction: column; gap: 0.75rem; }
.btn-upload { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1.5rem; background: #4f46e5; color: white; border-radius: 8px; cursor: pointer; font-weight: 500; }
.btn-upload:hover { background: #4338ca; }
.logo-upload input[type="file"] { display: none; }
.color-group { display: flex; align-items: center; gap: 1rem; }
.color-value { font-family: monospace; color: #64748b; }
.preview-box { padding: 1.5rem; border-radius: 8px; text-align: center; margin-top: 1rem; }
.preview-box h3 { margin: 0 0 0.25rem; }
.preview-box p { margin: 0; opacity: 0.9; }
.toggle-group { display: flex; align-items: center; justify-content: space-between; padding: 1rem 0; border-bottom: 1px solid #f1f5f9; }
.toggle-group:last-child { border-bottom: none; }
.toggle-info h4 { font-size: 0.9rem; font-weight: 500; margin: 0 0 0.25rem; }
.toggle-info p { font-size: 0.8rem; color: #64748b; margin: 0; }
.toggle { position: relative; width: 48px; height: 26px; }
.toggle input { opacity: 0; width: 0; height: 0; }
.toggle-slider { position: absolute; cursor: pointer; inset: 0; background: #cbd5e1; transition: 0.3s; border-radius: 26px; }
.toggle-slider:before { content: ""; position: absolute; height: 20px; width: 20px; left: 3px; bottom: 3px; background: white; transition: 0.3s; border-radius: 50%; }
.toggle input:checked + .toggle-slider { background: #10b981; }
.toggle input:checked + .toggle-slider:before { transform: translateX(22px); }
.form-actions { display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0; }
.coordenadas-input { display: flex; gap: 0.75rem; }
.coordenadas-input input { flex: 1; }

/* Estilos para licencia */
.licencia-status { padding: 1rem 1.25rem; border-radius: 10px; margin-bottom: 1.5rem; }
.licencia-status.valida { background: #dcfce7; border: 1px solid #86efac; }
.licencia-status.invalida { background: #fee2e2; border: 1px solid #fca5a5; }
.licencia-status.gracia { background: #fef3c7; border: 1px solid #fcd34d; }
.licencia-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
.licencia-plan { font-weight: 600; font-size: 1.1rem; }
.licencia-badge { padding: 0.25rem 0.75rem; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
.licencia-badge.perpetua { background: #dbeafe; color: #1e40af; }
.licencia-badge.temporal { background: #fef3c7; color: #92400e; }
.licencia-badge.cache { background: #f3f4f6; color: #6b7280; }
.licencia-codigo { font-family: monospace; background: rgba(255,255,255,0.5); padding: 0.35rem 0.75rem; border-radius: 6px; font-size: 0.9rem; }
.licencia-uso { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1.5rem; }
.uso-item label { display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-size: 0.85rem; color: #64748b; }
.uso-item label strong { color: #1e293b; }
.uso-barra { background: #e5e7eb; border-radius: 6px; height: 10px; overflow: hidden; }
.uso-barra-fill { height: 100%; border-radius: 6px; transition: width 0.3s; }
.uso-barra-fill.verde { background: #22c55e; }
.uso-barra-fill.amarillo { background: #f59e0b; }
.uso-barra-fill.rojo { background: #dc2626; }
.licencia-input-group { display: flex; gap: 0.75rem; }
.licencia-input-group input { flex: 1; font-family: monospace; font-size: 1rem; letter-spacing: 1px; }
</style>

<div class="page-header">
    <div>
        <h1 class="page-title">⚙️ Configuración del Sistema</h1>
        <p class="page-subtitle">Datos de empresa, personalización, parámetros y licencia</p>
    </div>
</div>

<?php if ($mensaje): ?>
<div class="alert alert-<?= $tipoMensaje === 'success' ? 'success' : 'danger' ?>">
    <?= $tipoMensaje === 'success' ? '✅' : '❌' ?> <?= sanitizar($mensaje) ?>
</div>
<?php endif; ?>

<div class="config-tabs">
    <button class="config-tab active" onclick="cambiarTab('empresa')">🏢 Datos Empresa</button>
    <button class="config-tab" onclick="cambiarTab('logo')">🖼️ Logo</button>
    <button class="config-tab" onclick="cambiarTab('colores')">🎨 Personalización</button>
    <button class="config-tab" onclick="cambiarTab('sistema')">⚙️ Sistema</button>
    <button class="config-tab" onclick="cambiarTab('licencia')">🔑 Licencia</button>
</div>

<!-- TAB: DATOS EMPRESA -->
<div id="tab-empresa" class="tab-content active">
    <div class="card">
        <div class="card-header"><span class="card-title">🏢 Datos de la Empresa</span></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                <input type="hidden" name="accion" value="guardar_empresa">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Nombre de la Empresa *</label>
                        <input type="text" name="nombre_empresa" class="form-control" value="<?= sanitizar($config['nombre_empresa']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">CIF / NIF</label>
                        <input type="text" name="cif_nif" class="form-control" value="<?= sanitizar($config['cif_nif']) ?>">
                    </div>
                    <div class="form-group full-width">
                        <label class="form-label">Dirección</label>
                        <div class="coordenadas-input">
                            <input type="text" name="direccion" id="direccion" class="form-control" value="<?= sanitizar($config['direccion']) ?>">
                            <a href="https://www.google.com/maps" target="_blank" class="btn btn-secondary" id="btnBuscarDir">🔍 Buscar en Maps</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Código Postal</label>
                        <input type="text" name="codigo_postal" class="form-control" value="<?= sanitizar($config['codigo_postal']) ?>" maxlength="5">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Localidad</label>
                        <input type="text" name="localidad" class="form-control" value="<?= sanitizar($config['localidad']) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Provincia</label>
                        <select name="provincia" class="form-control">
                            <option value="">Seleccionar...</option>
                            <?php foreach ($provincias as $prov): ?>
                            <option value="<?= $prov ?>" <?= $config['provincia'] === $prov ? 'selected' : '' ?>><?= $prov ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Teléfono</label>
                        <input type="tel" name="telefono" class="form-control" value="<?= sanitizar($config['telefono']) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= sanitizar($config['email']) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Web</label>
                        <input type="url" name="web" class="form-control" value="<?= sanitizar($config['web']) ?>" placeholder="https://">
                    </div>
                    <div class="form-group full-width">
                        <label class="form-label">Coordenadas GPS (sede principal)</label>
                        <div class="coordenadas-input">
                            <input type="text" name="coordenadas" id="coordenadas" class="form-control" value="<?= sanitizar($config['coordenadas']) ?>" placeholder="40.4168, -3.7038">
                            <a href="https://www.google.com/maps" target="_blank" class="btn btn-secondary" id="btnMaps">🗺️ Ver en Maps</a>
                        </div>
                        <span class="form-hint">Formato: latitud, longitud (ej: 40.4168, -3.7038)</span>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">💾 Guardar datos</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- TAB: LOGO -->
<div id="tab-logo" class="tab-content">
    <div class="card">
        <div class="card-header"><span class="card-title">🖼️ Logo de la Empresa</span></div>
        <div class="card-body">
            <div class="logo-section">
                <div class="logo-preview">
                    <?php if (!empty($config['logo_url'])): ?>
                        <img src="<?= sanitizar($config['logo_url']) ?>?t=<?= time() ?>" alt="Logo">
                    <?php else: ?>
                        <span class="placeholder">🏢</span>
                        <span style="font-size: 0.75rem; color: #94a3b8;">Sin logo</span>
                    <?php endif; ?>
                </div>
                <div class="logo-actions">
                    <form method="POST" enctype="multipart/form-data" id="formLogo" class="logo-upload">
                        <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                        <input type="hidden" name="accion" value="subir_logo">
                        <label class="btn-upload">
                            📤 Subir logo
                            <input type="file" name="logo" id="inputLogo" accept="image/*">
                        </label>
                    </form>
                    <?php if (!empty($config['logo_url'])): ?>
                    <form method="POST" onsubmit="return confirm('¿Eliminar el logo?')">
                        <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                        <input type="hidden" name="accion" value="eliminar_logo">
                        <button type="submit" class="btn btn-danger">🗑️ Eliminar</button>
                    </form>
                    <?php endif; ?>
                    <span class="form-hint">Formatos: JPG, PNG, GIF, WebP, SVG. Máx 2MB.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TAB: COLORES -->
<div id="tab-colores" class="tab-content">
    <div class="card">
        <div class="card-header"><span class="card-title">🎨 Colores de la Interfaz</span></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                <input type="hidden" name="accion" value="guardar_personalizacion">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Color Primario</label>
                        <div class="color-group">
                            <input type="color" name="color_primario" id="colorPrimario" value="<?= sanitizar($config['color_primario']) ?>">
                            <span class="color-value" id="valorPrimario"><?= sanitizar($config['color_primario']) ?></span>
                        </div>
                        <span class="form-hint">Color principal del header</span>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Color Secundario</label>
                        <div class="color-group">
                            <input type="color" name="color_secundario" id="colorSecundario" value="<?= sanitizar($config['color_secundario']) ?>">
                            <span class="color-value" id="valorSecundario"><?= sanitizar($config['color_secundario']) ?></span>
                        </div>
                        <span class="form-hint">Color de acentos</span>
                    </div>
                </div>
                <div class="preview-box" id="previewColores" style="background: <?= sanitizar($config['color_primario']) ?>; color: white;">
                    <h3><?= sanitizar($config['nombre_empresa'] ?: 'Mi Empresa') ?></h3>
                    <p>Vista previa del header</p>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="resetearColores()">↩️ Por defecto</button>
                    <button type="submit" class="btn btn-primary">💾 Guardar colores</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- TAB: SISTEMA -->
<div id="tab-sistema" class="tab-content">
    <div class="card">
        <div class="card-header"><span class="card-title">⚙️ Parámetros del Sistema</span></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                <input type="hidden" name="accion" value="guardar_sistema">
                
                <h3 style="font-size: 0.9rem; color: #64748b; margin-bottom: 1rem;">📅 Días por Defecto</h3>
                <div class="form-grid cols-3">
                    <div class="form-group">
                        <label class="form-label">Días Vacaciones</label>
                        <input type="number" name="dias_vacaciones_defecto" class="form-control" value="<?= intval($config['dias_vacaciones_defecto']) ?>" min="0" max="45">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Días Asuntos Propios</label>
                        <input type="number" name="dias_asuntos_propios" class="form-control" value="<?= intval($config['dias_asuntos_propios']) ?>" min="0" max="15">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Radio Geovalla (m)</label>
                        <input type="number" name="radio_metros_defecto" class="form-control" value="<?= intval($config['radio_metros_defecto']) ?>" min="10" max="1000">
                    </div>
                </div>
                
                <h3 style="font-size: 0.9rem; color: #64748b; margin: 1.5rem 0 1rem;">🔧 Opciones</h3>
                
                <div class="toggle-group">
                    <div class="toggle-info"><h4>📍 Geolocalización obligatoria</h4><p>Los empleados deben permitir la ubicación</p></div>
                    <label class="toggle"><input type="checkbox" name="geoloc_obligatoria" <?= $config['geoloc_obligatoria'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                <div class="toggle-group">
                    <div class="toggle-info"><h4>✅ Validación doble</h4><p>Incidencias requieren dos aprobaciones</p></div>
                    <label class="toggle"><input type="checkbox" name="validacion_doble" <?= $config['validacion_doble'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                <div class="toggle-group">
                    <div class="toggle-info"><h4>🏠 Permitir teletrabajo</h4><p>Empleados pueden fichar en modo teletrabajo</p></div>
                    <label class="toggle"><input type="checkbox" name="permitir_teletrabajo" <?= $config['permitir_teletrabajo'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                <div class="toggle-group">
                    <div class="toggle-info"><h4>✏️ Fichaje manual</h4><p>Supervisores pueden añadir fichajes manualmente</p></div>
                    <label class="toggle"><input type="checkbox" name="permitir_fichaje_manual" <?= $config['permitir_fichaje_manual'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                <div class="toggle-group">
                    <div class="toggle-info"><h4>⏱️ Mostrar banco de horas</h4><p>Empleados ven su balance de horas</p></div>
                    <label class="toggle"><input type="checkbox" name="mostrar_banco_horas" <?= $config['mostrar_banco_horas'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                <div class="toggle-group">
                    <div class="toggle-info"><h4>🔔 Notificar incidencias</h4><p>Email a supervisores con fichajes pendientes</p></div>
                    <label class="toggle"><input type="checkbox" name="notificar_incidencias" <?= $config['notificar_incidencias'] ? 'checked' : '' ?>><span class="toggle-slider"></span></label>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">💾 Guardar parámetros</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- TAB: LICENCIA -->
<div id="tab-licencia" class="tab-content">
    <div class="card">
        <div class="card-header"><span class="card-title">🔑 Licencia del Sistema</span></div>
        <div class="card-body">
            
            <?php if ($licenciaActual['ok'] ?? false): ?>
            <!-- Licencia válida -->
            <div class="licencia-status valida <?= ($usoLicencia['en_periodo_gracia'] ?? false) ? 'gracia' : '' ?>">
                <div class="licencia-header">
                    <div>
                        <span style="color: #166534; font-weight: 600;">✅ Licencia Activa</span>
                        <span class="licencia-plan" style="margin-left: 1rem;"><?= sanitizar($usoLicencia['plan']) ?></span>
                    </div>
                    <div>
                        <?php if ($usoLicencia['perpetua'] ?? false): ?>
                            <span class="licencia-badge perpetua">♾️ Perpetua</span>
                        <?php elseif (($usoLicencia['dias_restantes'] ?? null) !== null): ?>
                            <span class="licencia-badge temporal">⏳ <?= $usoLicencia['dias_restantes'] ?> días restantes</span>
                        <?php endif; ?>
                        <?php if ($usoLicencia['desde_cache'] ?? false): ?>
                            <span class="licencia-badge cache">📦 Cache</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="margin-top: 0.75rem;">
                    <span class="licencia-codigo"><?= sanitizar($codigoActual) ?></span>
                </div>
                
                <?php if ($usoLicencia['en_periodo_gracia'] ?? false): ?>
                <div style="margin-top: 1rem; padding: 0.75rem; background: #fef3c7; border-radius: 8px; color: #92400e;">
                    ⚠️ <strong>Período de gracia activo.</strong> No se puede conectar con el servidor de licencias. Verifique su conexión a Internet.
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Uso de la licencia -->
            <div class="licencia-uso">
                <div class="uso-item">
                    <label>
                        <span>👥 Empleados</span>
                        <strong><?= $usoLicencia['empleados']['actuales'] ?> / <?= $usoLicencia['empleados']['maximo'] ?></strong>
                    </label>
                    <?php 
                    $pctEmp = $usoLicencia['empleados']['porcentaje'];
                    $colorEmp = $pctEmp >= 90 ? 'rojo' : ($pctEmp >= 70 ? 'amarillo' : 'verde');
                    ?>
                    <div class="uso-barra">
                        <div class="uso-barra-fill <?= $colorEmp ?>" style="width: <?= min($pctEmp, 100) ?>%;"></div>
                    </div>
                </div>
                <div class="uso-item">
                    <label>
                        <span>🏢 Centros</span>
                        <strong><?= $usoLicencia['centros']['actuales'] ?> / <?= $usoLicencia['centros']['maximo'] ?></strong>
                    </label>
                    <?php 
                    $pctCen = $usoLicencia['centros']['porcentaje'];
                    $colorCen = $pctCen >= 90 ? 'rojo' : ($pctCen >= 70 ? 'amarillo' : 'verde');
                    ?>
                    <div class="uso-barra">
                        <div class="uso-barra-fill <?= $colorCen ?>" style="width: <?= min($pctCen, 100) ?>%;"></div>
                    </div>
                </div>
            </div>
            
            <?php else: ?>
            <!-- Sin licencia o licencia inválida -->
            <div class="licencia-status invalida">
                <span style="color: #dc2626; font-weight: 600;">❌ <?= sanitizar($licenciaActual['error'] ?? 'Licencia no válida') ?></span>
                <?php if (!empty($codigoActual)): ?>
                    <div style="margin-top: 0.5rem; font-size: 0.85rem;">
                        Código actual: <span class="licencia-codigo"><?= sanitizar($codigoActual) ?></span>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <!-- Formulario para activar/cambiar licencia -->
            <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0;">
                <h3 style="font-size: 0.95rem; margin-bottom: 1rem; color: #475569;">
                    <?= ($licenciaActual['ok'] ?? false) ? '🔄 Cambiar o Revalidar Licencia' : '🔑 Activar Licencia' ?>
                </h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generar_csrf() ?>">
                    <input type="hidden" name="accion" value="activar_licencia">
                    
                    <div class="form-group">
                        <label class="form-label">Código de Licencia</label>
                        <div class="licencia-input-group">
                            <input type="text" name="codigo_licencia" class="form-control" 
                                   placeholder="LMF-2026-XXXXXX" 
                                   value="<?= sanitizar($codigoActual ?? '') ?>">
                            <button type="submit" class="btn btn-primary">
                                <?= ($licenciaActual['ok'] ?? false) ? '🔄 Revalidar' : '✅ Activar' ?>
                            </button>
                        </div>
                        <span class="form-hint">Introduce el código de licencia proporcionado por LM Fichajes</span>
                    </div>
                </form>
            </div>
            
            <div style="margin-top: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; font-size: 0.85rem; color: #64748b;">
                <strong>ℹ️ Información:</strong><br>
                • La licencia se revalida automáticamente cada 24 horas<br>
                • Si no hay conexión, el sistema funciona en modo gracia durante 7 días<br>
                • Para ampliar los límites o renovar, contacte con <a href="mailto:soporte@lmfichajes.es" style="color: #4f46e5;">soporte@lmfichajes.es</a>
            </div>
        </div>
    </div>
</div>

<script>
function cambiarTab(tabId) {
    document.querySelectorAll('.config-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('tab-' + tabId).classList.add('active');
}

document.getElementById('inputLogo').addEventListener('change', function() {
    if (this.files.length > 0) document.getElementById('formLogo').submit();
});

document.getElementById('colorPrimario').addEventListener('input', function() {
    document.getElementById('valorPrimario').textContent = this.value;
    document.getElementById('previewColores').style.background = this.value;
});

document.getElementById('colorSecundario').addEventListener('input', function() {
    document.getElementById('valorSecundario').textContent = this.value;
});

function resetearColores() {
    document.getElementById('colorPrimario').value = '#2d5a87';
    document.getElementById('colorSecundario').value = '#10b981';
    document.getElementById('valorPrimario').textContent = '#2d5a87';
    document.getElementById('valorSecundario').textContent = '#10b981';
    document.getElementById('previewColores').style.background = '#2d5a87';
}

function actualizarEnlaceMaps() {
    const coord = document.getElementById('coordenadas').value.trim();
    const btn = document.getElementById('btnMaps');
    if (coord && coord.includes(',')) {
        const [lat, lng] = coord.split(',').map(c => c.trim());
        if (lat && lng && !isNaN(lat) && !isNaN(lng)) {
            btn.href = 'https://www.google.com/maps?q=' + lat + ',' + lng;
            btn.innerHTML = '🗺️ Ver en Maps';
        }
    }
}

function actualizarEnlaceBuscarDir() {
    const dir = document.getElementById('direccion').value.trim();
    const btn = document.getElementById('btnBuscarDir');
    if (dir) {
        btn.href = 'https://www.google.com/maps/search/' + encodeURIComponent(dir);
    } else {
        btn.href = 'https://www.google.com/maps';
    }
}

document.getElementById('coordenadas').addEventListener('input', actualizarEnlaceMaps);
document.getElementById('direccion').addEventListener('input', actualizarEnlaceBuscarDir);
actualizarEnlaceMaps();
actualizarEnlaceBuscarDir();
</script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
