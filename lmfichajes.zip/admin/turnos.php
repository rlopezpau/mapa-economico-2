<?php
/**
 * LM FICHAJES - Panel Admin: Gestión de Turnos Rotativos
 * 
 * CRUD completo para turnos semanales rotativos.
 * Permite crear grupos de turnos (A/B/C...) y asignar horarios a cada semana.
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     1.0.0
 * @date        2025-01-04
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos
requerir_login('../login.php');
if (!es_supervisor()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: ../portal.php');
    exit;
}

$usuario = obtener_usuario_actual($pdo);

// Variables
$accion = $_GET['accion'] ?? 'listar';
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$mensaje = '';
$error = '';

// ============================================================================
// FUNCIONES ESPECÍFICAS DE TURNOS
// ============================================================================

/**
 * Obtener todos los grupos de turnos
 */
function obtener_turnos_grupo($pdo) {
    $sql = "SELECT tg.*, 
                   COUNT(DISTINCT ts.id) as num_semanas_config,
                   COUNT(DISTINCT e.id) as num_empleados,
                   GROUP_CONCAT(DISTINCT CONCAT(ts.nombre_semana, ':', h.nombre) ORDER BY ts.num_semana SEPARATOR '|') as rotacion
            FROM turnos_grupo tg
            LEFT JOIN turnos_semana ts ON ts.turno_grupo_id = tg.id
            LEFT JOIN horarios h ON h.id = ts.horario_id
            LEFT JOIN empleados e ON e.turno_grupo_id = tg.id AND e.activo = 1
            GROUP BY tg.id
            ORDER BY tg.nombre";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Obtener un grupo de turno con sus semanas
 */
function obtener_turno_grupo($pdo, $id) {
    $sql = "SELECT * FROM turnos_grupo WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $turno = $stmt->fetch();
    
    if ($turno) {
        // Obtener semanas configuradas
        $sql = "SELECT ts.*, h.nombre as horario_nombre 
                FROM turnos_semana ts
                LEFT JOIN horarios h ON h.id = ts.horario_id
                WHERE ts.turno_grupo_id = ?
                ORDER BY ts.num_semana";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $turno->semanas = $stmt->fetchAll();
        
        // Obtener empleados asignados
        $sql = "SELECT id, nombre, apellido1, apellido2, nif 
                FROM empleados 
                WHERE turno_grupo_id = ? AND activo = 1
                ORDER BY apellido1, nombre";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $turno->empleados = $stmt->fetchAll();
    }
    
    return $turno;
}

/**
 * Guardar grupo de turno
 */
function guardar_turno_grupo($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    $id = $datos['id'] ?? null;
    
    try {
        $pdo->beginTransaction();
        
        if ($id) {
            // Actualizar
            $sql = "UPDATE turnos_grupo SET 
                    nombre = ?, descripcion = ?, num_semanas = ?, 
                    fecha_inicio = ?, activo = ?, updated_at = NOW()
                    WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'],
                $datos['descripcion'] ?? null,
                $datos['num_semanas'],
                $datos['fecha_inicio'],
                $datos['activo'] ?? 1,
                $id
            ]);
            $resultado['mensaje'] = 'Turno actualizado correctamente';
        } else {
            // Crear nuevo
            $sql = "INSERT INTO turnos_grupo (nombre, descripcion, num_semanas, fecha_inicio, semana_actual, activo)
                    VALUES (?, ?, ?, ?, 1, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'],
                $datos['descripcion'] ?? null,
                $datos['num_semanas'],
                $datos['fecha_inicio']
            ]);
            $id = $pdo->lastInsertId();
            $resultado['mensaje'] = 'Turno creado correctamente';
        }
        
        $resultado['id'] = $id;
        
        // Guardar configuración de semanas
        if (isset($datos['semanas']) && is_array($datos['semanas'])) {
            // Eliminar semanas existentes
            $stmt = $pdo->prepare("DELETE FROM turnos_semana WHERE turno_grupo_id = ?");
            $stmt->execute([$id]);
            
            // Insertar nuevas
            $stmt = $pdo->prepare("INSERT INTO turnos_semana (turno_grupo_id, num_semana, nombre_semana, horario_id) VALUES (?, ?, ?, ?)");
            
            foreach ($datos['semanas'] as $numSemana => $semanaData) {
                if (!empty($semanaData['horario_id'])) {
                    $stmt->execute([
                        $id,
                        $numSemana,
                        $semanaData['nombre'] ?? "Semana $numSemana",
                        $semanaData['horario_id']
                    ]);
                }
            }
        }
        
        $pdo->commit();
        $resultado['exito'] = true;
        
        // AUDITORÍA ENS
        if (function_exists('registrar_auditoria')) {
            $tipoAccion = isset($datos['id']) && $datos['id'] ? 'UPDATE' : 'CREATE';
            $desc = $tipoAccion === 'UPDATE' ? "Turno actualizado: {$datos['nombre']}" : "Turno creado: {$datos['nombre']}";
            registrar_auditoria($tipoAccion, $desc, ['nombre' => $datos['nombre']], 'INFO', $_SESSION['usuario_id'] ?? null, 'turnos_grupo', $id);
        }
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error al guardar: ' . $e->getMessage();
        error_log('Error guardar turno: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Eliminar grupo de turno
 */
function eliminar_turno_grupo($pdo, $id) {
    $resultado = ['exito' => false, 'mensaje' => ''];
    
    // Verificar si tiene empleados asignados
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM empleados WHERE turno_grupo_id = ? AND activo = 1");
    $stmt->execute([$id]);
    if ($stmt->fetchColumn() > 0) {
        $resultado['mensaje'] = 'No se puede eliminar: hay empleados asignados a este turno';
        return $resultado;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Eliminar semanas
        $stmt = $pdo->prepare("DELETE FROM turnos_semana WHERE turno_grupo_id = ?");
        $stmt->execute([$id]);
        
        // Eliminar grupo
        $stmt = $pdo->prepare("DELETE FROM turnos_grupo WHERE id = ?");
        $stmt->execute([$id]);
        
        $pdo->commit();
        $resultado['exito'] = true;
        $resultado['mensaje'] = 'Turno eliminado correctamente';
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error al eliminar';
        error_log('Error eliminar turno: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Calcular qué semana del turno corresponde a una fecha
 */
function calcular_semana_turno($fechaInicio, $numSemanas, $fechaConsulta = null) {
    if (!$fechaConsulta) $fechaConsulta = date('Y-m-d');
    
    $inicio = new DateTime($fechaInicio);
    $consulta = new DateTime($fechaConsulta);
    
    // Calcular diferencia en semanas
    $diff = $inicio->diff($consulta);
    $diasDiff = $diff->days;
    if ($diff->invert) $diasDiff = -$diasDiff;
    
    $semanasTranscurridas = floor($diasDiff / 7);
    
    // Calcular semana actual en el ciclo (1-based)
    $semanaActual = ($semanasTranscurridas % $numSemanas) + 1;
    if ($semanaActual < 1) $semanaActual += $numSemanas;
    
    return $semanaActual;
}

/**
 * Obtener el horario que corresponde a un empleado en una fecha
 */
function obtener_horario_empleado_fecha($pdo, $empleadoId, $fecha = null) {
    if (!$fecha) $fecha = date('Y-m-d');
    
    // Obtener datos del empleado
    $sql = "SELECT e.horario_id, e.turno_grupo_id, tg.fecha_inicio, tg.num_semanas
            FROM empleados e
            LEFT JOIN turnos_grupo tg ON tg.id = e.turno_grupo_id
            WHERE e.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$empleadoId]);
    $emp = $stmt->fetch();
    
    if (!$emp) return null;
    
    // Si tiene turno rotativo, calcular qué horario le toca
    if ($emp->turno_grupo_id && $emp->fecha_inicio) {
        $semanaActual = calcular_semana_turno($emp->fecha_inicio, $emp->num_semanas, $fecha);
        
        // Obtener horario de esa semana
        $sql = "SELECT h.* FROM turnos_semana ts
                JOIN horarios h ON h.id = ts.horario_id
                WHERE ts.turno_grupo_id = ? AND ts.num_semana = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$emp->turno_grupo_id, $semanaActual]);
        $horario = $stmt->fetch();
        
        if ($horario) {
            $horario->es_turno_rotativo = true;
            $horario->semana_actual = $semanaActual;
            return $horario;
        }
    }
    
    // Si no tiene turno rotativo o no se encontró, usar horario fijo
    if ($emp->horario_id) {
        $sql = "SELECT * FROM horarios WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$emp->horario_id]);
        $horario = $stmt->fetch();
        if ($horario) {
            $horario->es_turno_rotativo = false;
            return $horario;
        }
    }
    
    return null;
}

// ============================================================================
// PROCESAR FORMULARIOS
// ============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Token de seguridad inválido';
    } else {
        $accionPost = $_POST['accion'] ?? '';
        
        switch ($accionPost) {
            case 'guardar':
                $datos = [
                    'id' => isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null,
                    'nombre' => trim(strip_tags($_POST['nombre'] ?? '')),
                    'descripcion' => trim(strip_tags($_POST['descripcion'] ?? '')),
                    'num_semanas' => (int)($_POST['num_semanas'] ?? 2),
                    'fecha_inicio' => $_POST['fecha_inicio'] ?? date('Y-m-d'),
                    'activo' => isset($_POST['activo']) ? 1 : 0,
                    'semanas' => []
                ];
                
                // Procesar semanas
                for ($i = 1; $i <= $datos['num_semanas']; $i++) {
                    $datos['semanas'][$i] = [
                        'nombre' => trim($_POST["semana_{$i}_nombre"] ?? "Semana $i"),
                        'horario_id' => (int)($_POST["semana_{$i}_horario"] ?? 0)
                    ];
                }
                
                if (empty($datos['nombre'])) {
                    $error = 'El nombre es obligatorio';
                } else {
                    $resultado = guardar_turno_grupo($pdo, $datos);
                    if ($resultado['exito']) {
                        $mensaje = $resultado['mensaje'];
                        $accion = 'listar';
                    } else {
                        $error = $resultado['mensaje'];
                    }
                }
                break;
                
            case 'eliminar':
                $idEliminar = (int)($_POST['id'] ?? 0);
                if ($idEliminar > 0) {
                    $resultado = eliminar_turno_grupo($pdo, $idEliminar);
                    $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
                    $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
                }
                $accion = 'listar';
                break;
        }
    }
}

// ============================================================================
// OBTENER DATOS
// ============================================================================

$turno = null;
$turnos = [];
$horarios = [];

// Obtener horarios disponibles para los selects
$horarios = $pdo->query("SELECT id, nombre, tipo FROM horarios WHERE activo = 1 ORDER BY nombre")->fetchAll();

if (($accion === 'editar' || $accion === 'ver') && $id) {
    $turno = obtener_turno_grupo($pdo, $id);
    if (!$turno) {
        $error = 'Turno no encontrado';
        $accion = 'listar';
    }
}

if ($accion === 'listar') {
    $turnos = obtener_turnos_grupo($pdo);
}

$stats = obtener_estadisticas_dashboard($pdo);
$csrf_token = generar_csrf();

// Letras para semanas
$letras = ['', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

// Variables para layout compartido
$paginaActual = 'turnos';
$titulo = 'Turnos Rotativos';

// Layout compartido
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<!-- Estilos específicos de turnos -->
<style>
.main { flex: 1; padding: 1.5rem; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.page-title { font-size: 1.5rem; color: #1e293b; margin-bottom: 0.25rem; }
.page-subtitle { color: #64748b; font-size: 0.875rem; }
.card { background: white; border-radius: 0.75rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; margin-bottom: 1.5rem; }
.card-header { padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.card-title { font-weight: 600; color: #1e293b; }
.card-body { padding: 1.25rem; }
.table-container { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 0.875rem 1rem; text-align: left; border-bottom: 1px solid #e2e8f0; }
th { background: #f8fafc; font-size: 0.75rem; font-weight: 600; color: #64748b; text-transform: uppercase; }
.btn { padding: 0.5rem 1rem; border-radius: 0.5rem; font-size: 0.875rem; font-weight: 500; cursor: pointer; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: 0.375rem; }
.btn-primary { background: #0ea5e9; color: white; }
.btn-primary:hover { background: #0284c7; }
.btn-success { background: #22c55e; color: white; }
.btn-danger { background: #ef4444; color: white; }
.btn-outline { background: white; border: 1px solid #e2e8f0; color: #475569; }
.btn-outline:hover { background: #f8fafc; }
.btn-sm { padding: 0.375rem 0.75rem; font-size: 0.8125rem; }
.badge { padding: 0.25rem 0.625rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
.badge-success { background: #dcfce7; color: #166534; }
.badge-danger { background: #fee2e2; color: #991b1b; }
.badge-info { background: #e0f2fe; color: #0369a1; }
.alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem; }
.alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
.alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.alert-info { background: #e0f2fe; color: #0369a1; border: 1px solid #7dd3fc; }
.form-group { margin-bottom: 1rem; }
.form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #374151; margin-bottom: 0.375rem; }
.form-control { width: 100%; padding: 0.625rem 0.875rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-size: 0.9375rem; }
.form-control:focus { outline: none; border-color: #0ea5e9; box-shadow: 0 0 0 3px rgba(14,165,233,0.1); }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
.form-hint { font-size: 0.75rem; color: #64748b; margin-top: 0.25rem; }
.form-check { display: flex; align-items: center; gap: 0.5rem; }
.acciones { display: flex; gap: 0.375rem; }
.empty-state { text-align: center; padding: 3rem 2rem; color: #64748b; }
.empty-state .icon { font-size: 3rem; margin-bottom: 1rem; }
.rotacion-visual { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.rotacion-item { display: flex; flex-direction: column; align-items: center; padding: 0.5rem; border-radius: 0.5rem; background: #f1f5f9; }
.rotacion-item.semana-actual { background: #dcfce7; border: 2px solid #22c55e; }
.rotacion-letra { font-weight: 700; font-size: 1rem; }
.rotacion-horario { font-size: 0.7rem; color: #64748b; }
.semanas-grid { display: grid; gap: 1rem; }
.semana-card { background: #f8fafc; padding: 1rem; border-radius: 0.5rem; }
.semana-letra { font-weight: 700; font-size: 1.25rem; color: #1e3a5f; }
</style>

            <?php if ($mensaje): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($mensaje); ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error">❌ <?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            
            <?php if ($accion === 'listar'): ?>
            <!-- LISTADO -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Turnos Rotativos</h1>
                    <p class="page-subtitle">Configura turnos semanales (A/B, A/B/C, etc.)</p>
                </div>
                <a href="?accion=nuevo" class="btn btn-primary">➕ Nuevo Turno</a>
            </div>
            
            <div class="alert alert-info">
                💡 <strong>¿Cómo funciona?</strong> Crea un grupo de turno con varias semanas (A, B, C...), asigna un horario diferente a cada semana, y luego asigna empleados al turno. El sistema calcula automáticamente qué horario les corresponde cada semana.
            </div>
            
            <div class="card">
                <?php if (empty($turnos)): ?>
                <div class="empty-state">
                    <div class="icon">🔄</div>
                    <h3>No hay turnos rotativos</h3>
                    <p>Crea un turno para asignar rotaciones semanales a empleados</p>
                    <a href="?accion=nuevo" class="btn btn-primary" style="margin-top:1rem">➕ Crear Turno</a>
                </div>
                <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Rotación</th>
                                <th>Empleados</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($turnos as $t): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($t->nombre); ?></strong>
                                    <?php if ($t->descripcion): ?>
                                    <div style="font-size:0.8rem;color:#64748b"><?php echo htmlspecialchars($t->descripcion); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="rotacion-visual">
                                        <?php 
                                        if ($t->rotacion) {
                                            $partes = explode('|', $t->rotacion);
                                            foreach ($partes as $i => $parte) {
                                                list($nombre, $horario) = explode(':', $parte);
                                                $semanaActual = calcular_semana_turno($t->fecha_inicio, $t->num_semanas);
                                                $esActual = ($i + 1) == $semanaActual;
                                                echo '<span class="rotacion-item' . ($esActual ? ' semana-actual' : '') . '">';
                                                echo '<span class="rotacion-letra">' . $letras[$i+1] . '</span>';
                                                echo '<span class="rotacion-horario">' . htmlspecialchars($horario) . '</span>';
                                                echo '</span>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </td>
                                <td><span class="badge badge-info"><?php echo $t->num_empleados; ?></span></td>
                                <td><?php echo $t->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?></td>
                                <td>
                                    <div class="acciones">
                                        <a href="?accion=ver&id=<?php echo $t->id; ?>" class="btn btn-outline btn-sm">👁️</a>
                                        <a href="?accion=editar&id=<?php echo $t->id; ?>" class="btn btn-outline btn-sm">✏️</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <?php elseif ($accion === 'nuevo' || $accion === 'editar'): ?>
            <!-- FORMULARIO -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo $accion === 'nuevo' ? 'Nuevo Turno Rotativo' : 'Editar Turno'; ?></h1>
                    <p class="page-subtitle">Configura las semanas y horarios del turno</p>
                </div>
                <a href="?accion=listar" class="btn btn-outline">← Volver</a>
            </div>
            
            <form method="POST" id="formTurno">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="accion" value="guardar">
                <?php if ($turno): ?><input type="hidden" name="id" value="<?php echo $turno->id; ?>"><?php endif; ?>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">📋 Información del Turno</span></div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Nombre del turno <span class="required">*</span></label>
                                <input type="text" name="nombre" class="form-control" required
                                       value="<?php echo $turno ? htmlspecialchars($turno->nombre) : ''; ?>"
                                       placeholder="Ej: Rotativo Policía">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Número de semanas</label>
                                <select name="num_semanas" class="form-control" id="numSemanas" onchange="actualizarSemanas()">
                                    <?php for ($i = 2; $i <= 6; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo ($turno && $turno->num_semanas == $i) ? 'selected' : ($i == 2 && !$turno ? 'selected' : ''); ?>>
                                        <?php echo $i; ?> semanas (<?php echo implode('/', array_slice($letras, 1, $i)); ?>)
                                    </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Descripción</label>
                                <input type="text" name="descripcion" class="form-control"
                                       value="<?php echo $turno ? htmlspecialchars($turno->descripcion) : ''; ?>"
                                       placeholder="Descripción opcional">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Fecha inicio de rotación</label>
                                <input type="date" name="fecha_inicio" class="form-control"
                                       value="<?php echo $turno ? $turno->fecha_inicio : date('Y-m-d', strtotime('monday this week')); ?>">
                                <div class="form-hint">Debe ser un lunes. El ciclo comienza desde esta fecha.</div>
                            </div>
                        </div>
                        
                        <?php if ($turno): ?>
                        <div class="form-group">
                            <label class="form-check">
                                <input type="checkbox" name="activo" <?php echo $turno->activo ? 'checked' : ''; ?>>
                                <span>Turno activo</span>
                            </label>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">📅 Configuración de Semanas</span></div>
                    <div class="card-body">
                        <p style="color:#64748b;margin-bottom:1rem">Asigna un horario diferente a cada semana del ciclo:</p>
                        
                        <div class="semanas-config" id="semanasConfig">
                            <?php 
                            $numSemanas = $turno ? $turno->num_semanas : 2;
                            $semanasConfig = [];
                            if ($turno && !empty($turno->semanas)) {
                                foreach ($turno->semanas as $s) {
                                    $semanasConfig[$s->num_semana] = $s;
                                }
                            }
                            
                            for ($i = 1; $i <= $numSemanas; $i++):
                                $semana = $semanasConfig[$i] ?? null;
                                $semanaActual = $turno ? calcular_semana_turno($turno->fecha_inicio, $turno->num_semanas) : 0;
                            ?>
                            <div class="semana-item <?php echo $i == $semanaActual ? 'semana-actual' : ''; ?>" id="semana<?php echo $i; ?>">
                                <div class="semana-header">
                                    <div class="semana-letra"><?php echo $letras[$i]; ?></div>
                                    <div class="semana-titulo">Semana <?php echo $letras[$i]; ?></div>
                                    <?php if ($i == $semanaActual): ?>
                                    <span class="badge badge-success">Semana actual</span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label class="form-label">Nombre (opcional)</label>
                                        <input type="text" name="semana_<?php echo $i; ?>_nombre" class="form-control"
                                               value="<?php echo $semana ? htmlspecialchars($semana->nombre_semana) : 'Semana ' . $letras[$i]; ?>"
                                               placeholder="Ej: Mañanas, Tardes...">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Horario asignado <span class="required">*</span></label>
                                        <select name="semana_<?php echo $i; ?>_horario" class="form-control" required>
                                            <option value="">-- Seleccionar horario --</option>
                                            <?php foreach ($horarios as $h): ?>
                                            <option value="<?php echo $h->id; ?>" <?php echo ($semana && $semana->horario_id == $h->id) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($h->nombre); ?> 
                                                (<?php echo $h->tipo === 'continua' ? '☀️' : ($h->tipo === 'partida' ? '🌓' : '🔄'); ?>)
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <?php endfor; ?>
                        </div>
                        
                        <?php if (empty($horarios)): ?>
                        <div class="alert alert-warning">
                            ⚠️ No hay horarios creados. <a href="horarios.php?accion=nuevo">Crea horarios primero</a> para poder asignarlos a las semanas.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">💾 <?php echo $accion === 'nuevo' ? 'Crear Turno' : 'Guardar Cambios'; ?></button>
                    <a href="?accion=listar" class="btn btn-outline">Cancelar</a>
                </div>
            </form>
            
            <?php elseif ($accion === 'ver' && $turno): ?>
            <!-- VER DETALLE -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo htmlspecialchars($turno->nombre); ?></h1>
                    <p class="page-subtitle"><?php echo $turno->descripcion ? htmlspecialchars($turno->descripcion) : 'Turno rotativo de ' . $turno->num_semanas . ' semanas'; ?></p>
                </div>
                <div style="display:flex;gap:0.5rem">
                    <a href="?accion=editar&id=<?php echo $turno->id; ?>" class="btn btn-primary">✏️ Editar</a>
                    <a href="?accion=listar" class="btn btn-outline">← Volver</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">📊 Información</span>
                    <?php echo $turno->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Semanas en ciclo</div>
                            <div class="info-value"><?php echo $turno->num_semanas; ?> (<?php echo implode('/', array_slice($letras, 1, $turno->num_semanas)); ?>)</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Fecha inicio</div>
                            <div class="info-value"><?php echo date('d/m/Y', strtotime($turno->fecha_inicio)); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Semana actual</div>
                            <?php $semanaActual = calcular_semana_turno($turno->fecha_inicio, $turno->num_semanas); ?>
                            <div class="info-value" style="color:#10b981">Semana <?php echo $letras[$semanaActual]; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Empleados</div>
                            <div class="info-value"><?php echo count($turno->empleados); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header"><span class="card-title">📅 Rotación de Semanas</span></div>
                <div class="card-body">
                    <?php foreach ($turno->semanas as $s): 
                        $esActual = $s->num_semana == $semanaActual;
                    ?>
                    <div class="semana-item <?php echo $esActual ? '' : ''; ?>" style="<?php echo $esActual ? 'border-color:#10b981;background:#f0fdf4' : ''; ?>">
                        <div class="semana-header">
                            <div class="semana-letra" style="<?php echo $esActual ? 'background:#10b981' : ''; ?>"><?php echo $letras[$s->num_semana]; ?></div>
                            <div class="semana-titulo"><?php echo htmlspecialchars($s->nombre_semana); ?></div>
                            <?php if ($esActual): ?>
                            <span class="badge badge-success">← ESTA SEMANA</span>
                            <?php endif; ?>
                        </div>
                        <p style="color:#64748b;margin-left:55px">
                            Horario: <strong><?php echo htmlspecialchars($s->horario_nombre); ?></strong>
                        </p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <?php if (!empty($turno->empleados)): ?>
            <div class="card">
                <div class="card-header"><span class="card-title">👥 Empleados Asignados (<?php echo count($turno->empleados); ?>)</span></div>
                <div class="card-body">
                    <?php foreach ($turno->empleados as $emp): ?>
                    <div class="empleado-item">
                        <div class="empleado-avatar"><?php echo strtoupper(substr($emp->nombre, 0, 1)); ?></div>
                        <div>
                            <a href="empleados.php?accion=editar&id=<?php echo $emp->id; ?>" style="color:#1e293b;text-decoration:none;font-weight:500">
                                <?php echo htmlspecialchars($emp->nombre . ' ' . $emp->apellido1); ?>
                            </a>
                            <div style="font-size:0.8rem;color:#64748b"><?php echo $emp->nif; ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                💡 Este turno no tiene empleados asignados. Ve a <a href="empleados.php">Empleados</a> y asigna este turno a los trabajadores.
            </div>
            <?php endif; ?>
            
            <?php if (count($turno->empleados) == 0): ?>
            <div class="card" style="border-color:#fca5a5">
                <div class="card-header" style="background:#fef2f2"><span class="card-title" style="color:#991b1b">⚠️ Zona de peligro</span></div>
                <div class="card-body">
                    <p style="margin-bottom:1rem;color:#64748b">Este turno no tiene empleados y puede eliminarse.</p>
                    <form method="POST" onsubmit="return confirm('¿Eliminar este turno? No se puede deshacer.')">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" name="id" value="<?php echo $turno->id; ?>">
                        <button type="submit" class="btn btn-danger">🗑️ Eliminar Turno</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <?php endif; ?>
        </main>
    </div>
    
    <script>
    var letras = ['', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    var horarios = <?php echo json_encode($horarios); ?>;
    
    function actualizarSemanas() {
        var num = parseInt(document.getElementById('numSemanas').value);
        var container = document.getElementById('semanasConfig');
        container.innerHTML = '';
        
        for (var i = 1; i <= num; i++) {
            var html = `
            <div class="semana-item" id="semana${i}">
                <div class="semana-header">
                    <div class="semana-letra">${letras[i]}</div>
                    <div class="semana-titulo">Semana ${letras[i]}</div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nombre (opcional)</label>

                        <input type="text" name="semana_${i}_nombre" class="form-control"
                               value="Semana ${letras[i]}" placeholder="Ej: Mañanas, Tardes...">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Horario asignado <span class="required">*</span></label>
                        <select name="semana_${i}_horario" class="form-control" required>
                            <option value="">-- Seleccionar horario --</option>
                            ${horarios.map(h => `<option value="${h.id}">${h.nombre}</option>`).join('')}
                        </select>
                    </div>
                </div>
            </div>`;
            container.innerHTML += html;
        }
    }
    </script>
</body>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
