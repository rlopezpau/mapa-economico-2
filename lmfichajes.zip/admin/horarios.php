<?php
/**
 * LM FICHAJES - Panel Admin: Gestión de Horarios
 * 
 * CRUD completo de horarios con:
 * - Configuración de jornada (continua/partida/flexible)
 * - Horarios troncales (mañana y tarde)
 * - Cortesías y tolerancias
 * - Configuración individual por día de la semana
 * - Soporte para turnos rotativos
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     2.0.0
 * @date        2025-01-04
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

// Verificar permisos
requerir_login('../login.php');
if (!es_supervisor()) {
    $_SESSION['error_mensaje'] = 'No tienes permisos para acceder a esta sección';
    header('Location: ../portal.php');
    exit;
}

// Obtener usuario actual
$usuario = obtener_usuario_actual($pdo);

// Variables
$accion = $_GET['accion'] ?? 'listar';
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$mensaje = '';
$error = '';

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificar_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Token de seguridad inválido. Recarga la página.';
    } else {
        $accionPost = $_POST['accion'] ?? '';
        
        switch ($accionPost) {
            case 'guardar':
                $datos = [
                    'id' => isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null,
                    'nombre' => trim(strip_tags($_POST['nombre'] ?? '')),
                    'tipo' => trim(strip_tags($_POST['tipo'] ?? 'continua')),
                    'horas_semanales' => (float)($_POST['horas_semanales'] ?? 37.5),
                    // Horario base (se usa si no hay config por día)
                    'hora_entrada' => trim($_POST['hora_entrada'] ?? ''),
                    'hora_salida' => trim($_POST['hora_salida'] ?? ''),
                    'hora_entrada_tarde' => trim($_POST['hora_entrada_tarde'] ?? '') ?: null,
                    'hora_salida_tarde' => trim($_POST['hora_salida_tarde'] ?? '') ?: null,
                    'troncal_inicio' => trim($_POST['troncal_inicio'] ?? '') ?: null,
                    'troncal_fin' => trim($_POST['troncal_fin'] ?? '') ?: null,
                    'troncal_tarde_inicio' => trim($_POST['troncal_tarde_inicio'] ?? '') ?: null,
                    'troncal_tarde_fin' => trim($_POST['troncal_tarde_fin'] ?? '') ?: null,
                    'cortesia_entrada' => (int)($_POST['cortesia_entrada'] ?? 5),
                    'cortesia_salida' => (int)($_POST['cortesia_salida'] ?? 5),
                    'tolerancia_minutos' => (int)($_POST['tolerancia_minutos'] ?? 15),
                    'activo' => isset($_POST['activo']) ? 1 : 0
                ];
                
                // Procesar configuración por día
                $configPorDia = isset($_POST['config_por_dia']) && $_POST['config_por_dia'] == '1';
                $datos['dias'] = [];
                $horasTotales = 0;
                
                for ($d = 1; $d <= 7; $d++) {
                    $esLaborable = isset($_POST['dia_laborable'][$d]) ? 1 : 0;
                    $horasDia = $esLaborable ? (float)($_POST['dia_horas'][$d] ?? 7.5) : 0;
                    $horasTotales += $horasDia;
                    
                    $datos['dias'][$d] = [
                        'es_laborable' => $esLaborable,
                        'horas_esperadas' => $horasDia,
                        'hora_entrada' => $configPorDia && $esLaborable ? (trim($_POST['dia_entrada'][$d] ?? '') ?: null) : null,
                        'hora_salida' => $configPorDia && $esLaborable ? (trim($_POST['dia_salida'][$d] ?? '') ?: null) : null,
                        'hora_entrada_tarde' => $configPorDia && $esLaborable ? (trim($_POST['dia_entrada_tarde'][$d] ?? '') ?: null) : null,
                        'hora_salida_tarde' => $configPorDia && $esLaborable ? (trim($_POST['dia_salida_tarde'][$d] ?? '') ?: null) : null,
                        'troncal_inicio' => $configPorDia && $esLaborable ? (trim($_POST['dia_troncal_inicio'][$d] ?? '') ?: null) : null,
                        'troncal_fin' => $configPorDia && $esLaborable ? (trim($_POST['dia_troncal_fin'][$d] ?? '') ?: null) : null,
                        'troncal_tarde_inicio' => $configPorDia && $esLaborable ? (trim($_POST['dia_troncal_tarde_inicio'][$d] ?? '') ?: null) : null,
                        'troncal_tarde_fin' => $configPorDia && $esLaborable ? (trim($_POST['dia_troncal_tarde_fin'][$d] ?? '') ?: null) : null,
                    ];
                }
                
                // Calcular horas diarias promedio
                $diasLaborables = count(array_filter($datos['dias'], fn($d) => $d['es_laborable']));
                $datos['horas_diarias'] = $diasLaborables > 0 ? round($horasTotales / $diasLaborables, 2) : 7.5;
                
                // Validaciones
                if (empty($datos['nombre'])) {
                    $error = 'El nombre del horario es obligatorio';
                } elseif ($diasLaborables === 0) {
                    $error = 'Debes seleccionar al menos un día laborable';
                } else {
                    $resultado = guardar_horario_completo($pdo, $datos);
                    if ($resultado['exito']) {
                        $mensaje = $resultado['mensaje'];
                        $accion = 'listar';
                    } else {
                        $error = $resultado['mensaje'];
                        $accion = $datos['id'] ? 'editar' : 'nuevo';
                        $id = $datos['id'];
                    }
                }
                break;
                
            case 'eliminar':
                $idEliminar = (int)($_POST['id'] ?? 0);
                if ($idEliminar > 0) {
                    $resultado = eliminar_horario($pdo, $idEliminar);
                    $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
                    $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
                }
                $accion = 'listar';
                break;
                
            case 'toggle_activo':
                $idToggle = (int)($_POST['id'] ?? 0);
                if ($idToggle > 0) {
                    $resultado = toggle_horario_activo($pdo, $idToggle);
                    $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
                    $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
                }
                $accion = 'listar';
                break;
                
            case 'duplicar':
                $idDuplicar = (int)($_POST['id'] ?? 0);
                if ($idDuplicar > 0) {
                    $resultado = duplicar_horario($pdo, $idDuplicar);
                    $mensaje = $resultado['exito'] ? $resultado['mensaje'] : '';
                    $error = !$resultado['exito'] ? $resultado['mensaje'] : '';
                }
                $accion = 'listar';
                break;
        }
    }
}

// Obtener datos según acción
$horario = null;
$horarios = [];
$empleadosHorario = [];
$diasConfig = [];

// Valores por defecto para nuevo horario
$diasDefault = [
    1 => ['es_laborable' => 1, 'horas_esperadas' => 7.5],
    2 => ['es_laborable' => 1, 'horas_esperadas' => 7.5],
    3 => ['es_laborable' => 1, 'horas_esperadas' => 7.5],
    4 => ['es_laborable' => 1, 'horas_esperadas' => 7.5],
    5 => ['es_laborable' => 1, 'horas_esperadas' => 7.5],
    6 => ['es_laborable' => 0, 'horas_esperadas' => 0],
    7 => ['es_laborable' => 0, 'horas_esperadas' => 0],
];

if (($accion === 'editar' || $accion === 'ver') && $id) {
    $horario = obtener_horario_completo($pdo, $id);
    if (!$horario) {
        $error = 'Horario no encontrado';
        $accion = 'listar';
    } else {
        $empleadosHorario = obtener_empleados_horario($pdo, $id);
        // Cargar configuración por día
        if (!empty($horario->dias)) {
            foreach ($horario->dias as $dia) {
                $diasConfig[$dia->dia_semana] = $dia;
            }
        }
    }
}

if ($accion === 'listar') {
    $horarios = obtener_horarios_admin($pdo);
}

// Obtener estadísticas para sidebar
$stats = obtener_estadisticas_dashboard($pdo);

// Generar token CSRF
$csrf_token = generar_csrf();

// Nombres de días
$diasSemana = [
    1 => ['nombre' => 'Lunes', 'abrev' => 'Lun'],
    2 => ['nombre' => 'Martes', 'abrev' => 'Mar'],
    3 => ['nombre' => 'Miércoles', 'abrev' => 'Mié'],
    4 => ['nombre' => 'Jueves', 'abrev' => 'Jue'],
    5 => ['nombre' => 'Viernes', 'abrev' => 'Vie'],
    6 => ['nombre' => 'Sábado', 'abrev' => 'Sáb'],
    7 => ['nombre' => 'Domingo', 'abrev' => 'Dom']
];

/**
 * Función auxiliar para guardar horario con configuración por día
 */
function guardar_horario_completo($pdo, $datos) {
    $resultado = ['exito' => false, 'mensaje' => '', 'id' => null];
    $id = $datos['id'] ?? null;
    
    try {
        $pdo->beginTransaction();
        
        if ($id) {
            // Actualizar horario existente
            $sql = "UPDATE horarios SET 
                    nombre = ?, tipo = ?, horas_diarias = ?, horas_semanales = ?,
                    hora_entrada = ?, hora_salida = ?,
                    hora_entrada_tarde = ?, hora_salida_tarde = ?,
                    troncal_inicio = ?, troncal_fin = ?,
                    troncal_tarde_inicio = ?, troncal_tarde_fin = ?,
                    cortesia_entrada = ?, cortesia_salida = ?,
                    tolerancia_minutos = ?, activo = ?, updated_at = NOW()
                    WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'], $datos['tipo'] ?? 'continua',
                $datos['horas_diarias'] ?? 7.5, $datos['horas_semanales'] ?? 37.5,
                $datos['hora_entrada'] ?? null, $datos['hora_salida'] ?? null,
                $datos['hora_entrada_tarde'] ?? null, $datos['hora_salida_tarde'] ?? null,
                $datos['troncal_inicio'] ?? null, $datos['troncal_fin'] ?? null,
                $datos['troncal_tarde_inicio'] ?? null, $datos['troncal_tarde_fin'] ?? null,
                $datos['cortesia_entrada'] ?? 5, $datos['cortesia_salida'] ?? 5,
                $datos['tolerancia_minutos'] ?? 15, $datos['activo'] ?? 1, $id
            ]);
            $resultado['id'] = $id;
            $resultado['mensaje'] = 'Horario actualizado correctamente';
        } else {
            // Crear nuevo horario
            $sql = "INSERT INTO horarios 
                    (nombre, tipo, horas_diarias, horas_semanales,
                     hora_entrada, hora_salida,
                     hora_entrada_tarde, hora_salida_tarde,
                     troncal_inicio, troncal_fin,
                     troncal_tarde_inicio, troncal_tarde_fin,
                     cortesia_entrada, cortesia_salida, tolerancia_minutos, activo)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $datos['nombre'], $datos['tipo'] ?? 'continua',
                $datos['horas_diarias'] ?? 7.5, $datos['horas_semanales'] ?? 37.5,
                $datos['hora_entrada'] ?? null, $datos['hora_salida'] ?? null,
                $datos['hora_entrada_tarde'] ?? null, $datos['hora_salida_tarde'] ?? null,
                $datos['troncal_inicio'] ?? null, $datos['troncal_fin'] ?? null,
                $datos['troncal_tarde_inicio'] ?? null, $datos['troncal_tarde_fin'] ?? null,
                $datos['cortesia_entrada'] ?? 5, $datos['cortesia_salida'] ?? 5,
                $datos['tolerancia_minutos'] ?? 15
            ]);
            $resultado['id'] = $pdo->lastInsertId();
            $id = $resultado['id'];
            $resultado['mensaje'] = 'Horario creado correctamente';
        }
        
        // Actualizar días de la semana
        if (isset($datos['dias']) && is_array($datos['dias'])) {
            // Eliminar días existentes
            $stmt = $pdo->prepare("DELETE FROM horarios_dias WHERE horario_id = ?");
            $stmt->execute([$id]);
            
            // Insertar nuevos días
            $sql = "INSERT INTO horarios_dias 
                    (horario_id, dia_semana, es_laborable, horas_esperadas,
                     hora_entrada, hora_salida, hora_entrada_tarde, hora_salida_tarde,
                     troncal_inicio, troncal_fin, troncal_tarde_inicio, troncal_tarde_fin)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            
            foreach ($datos['dias'] as $diaSemana => $diaInfo) {
                $stmt->execute([
                    $id,
                    $diaSemana,
                    $diaInfo['es_laborable'] ?? 0,
                    $diaInfo['horas_esperadas'] ?? 0,
                    $diaInfo['hora_entrada'] ?? null,
                    $diaInfo['hora_salida'] ?? null,
                    $diaInfo['hora_entrada_tarde'] ?? null,
                    $diaInfo['hora_salida_tarde'] ?? null,
                    $diaInfo['troncal_inicio'] ?? null,
                    $diaInfo['troncal_fin'] ?? null,
                    $diaInfo['troncal_tarde_inicio'] ?? null,
                    $diaInfo['troncal_tarde_fin'] ?? null
                ]);
            }
        }
        
        $pdo->commit();
        $resultado['exito'] = true;
        
        // AUDITORÍA ENS
        if (function_exists('registrar_auditoria')) {
            $tipoAccion = $datos['id'] ? 'UPDATE' : 'CREATE';
            $desc = $datos['id'] ? "Horario actualizado: {$datos['nombre']}" : "Horario creado: {$datos['nombre']}";
            registrar_auditoria($tipoAccion, $desc, ['nombre' => $datos['nombre'], 'tipo' => $datos['tipo'] ?? ''], 'INFO', $_SESSION['usuario_id'] ?? null, 'horarios', $id);
        }
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $resultado['mensaje'] = 'Error al guardar el horario';
        error_log('Error guardar horario: ' . $e->getMessage());
    }
    
    return $resultado;
}

/**
 * Obtener horario con toda su configuración
 */
function obtener_horario_completo($pdo, $id) {
    $sql = "SELECT * FROM horarios WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $horario = $stmt->fetch();
    
    if ($horario) {
        // Obtener días
        $sql = "SELECT * FROM horarios_dias WHERE horario_id = ? ORDER BY dia_semana";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $horario->dias = $stmt->fetchAll();
        
        // Contar empleados
        $sql = "SELECT COUNT(*) FROM empleados WHERE horario_id = ? AND activo = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $horario->num_empleados = $stmt->fetchColumn();
    }
    
    return $horario;
}

// Variables para layout compartido
$paginaActual = 'horarios';
$titulo = 'Horarios';

// Layout compartido
require_once __DIR__ . '/includes/layout_header.php';
require_once __DIR__ . '/includes/layout_sidebar.php';
?>

<!-- Estilos específicos de horarios -->
<style>
.main { flex: 1; padding: 1.5rem; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.page-title { font-size: 1.5rem; color: #1e293b; margin-bottom: 0.25rem; }
.page-subtitle { color: #64748b; font-size: 0.875rem; }
.card { background: white; border-radius: 0.75rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; margin-bottom: 1.5rem; }
.card-header { padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.card-title { font-weight: 600; color: #1e293b; }
.card-body { padding: 1.25rem; }
.table-container { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 0.875rem 1rem; text-align: left; border-bottom: 1px solid #e2e8f0; }
th { background: #f8fafc; font-size: 0.75rem; font-weight: 600; color: #64748b; text-transform: uppercase; }
.btn { padding: 0.5rem 1rem; border-radius: 0.5rem; font-size: 0.875rem; font-weight: 500; cursor: pointer; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: 0.375rem; }
.btn-primary { background: #0ea5e9; color: white; }
.btn-primary:hover { background: #0284c7; }
.btn-success { background: #22c55e; color: white; }
.btn-danger { background: #ef4444; color: white; }
.btn-outline { background: white; border: 1px solid #e2e8f0; color: #475569; }
.btn-outline:hover { background: #f8fafc; }
.btn-sm { padding: 0.375rem 0.75rem; font-size: 0.8125rem; }
.badge { padding: 0.25rem 0.625rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 500; }
.badge-success { background: #dcfce7; color: #166534; }
.badge-danger { background: #fee2e2; color: #991b1b; }
.badge-info { background: #e0f2fe; color: #0369a1; }
.alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem; }
.alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
.alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.alert-info { background: #e0f2fe; color: #0369a1; border: 1px solid #7dd3fc; }
.form-group { margin-bottom: 1rem; }
.form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #374151; margin-bottom: 0.375rem; }
.form-control { width: 100%; padding: 0.625rem 0.875rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-size: 0.9375rem; }
.form-control:focus { outline: none; border-color: #0ea5e9; box-shadow: 0 0 0 3px rgba(14,165,233,0.1); }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
.form-hint { font-size: 0.75rem; color: #64748b; margin-top: 0.25rem; }
.form-check { display: flex; align-items: center; gap: 0.5rem; }
.acciones { display: flex; gap: 0.375rem; }
.empty-state { text-align: center; padding: 3rem 2rem; color: #64748b; }
.empty-state .icon { font-size: 3rem; margin-bottom: 1rem; }
.tipo-jornada { display: inline-flex; align-items: center; gap: 0.375rem; }
.rotacion-visual { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.rotacion-item { display: flex; flex-direction: column; align-items: center; padding: 0.5rem; border-radius: 0.5rem; background: #f1f5f9; }
.rotacion-item.semana-actual { background: #dcfce7; border: 2px solid #22c55e; }
.rotacion-letra { font-weight: 700; font-size: 1rem; }
.rotacion-horario { font-size: 0.7rem; color: #64748b; }
.dias-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.5rem; margin: 1rem 0; }
.dia-item { padding: 0.75rem; background: #f8fafc; border-radius: 0.5rem; text-align: center; }
.dia-item.laborable { background: #dcfce7; }
.dia-nombre { font-weight: 600; font-size: 0.8rem; margin-bottom: 0.5rem; }
.tabs { display: flex; border-bottom: 2px solid #e2e8f0; margin-bottom: 1.5rem; }
.tab { padding: 0.75rem 1.5rem; cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -2px; font-weight: 500; color: #64748b; }
.tab.active { border-bottom-color: #0ea5e9; color: #0ea5e9; }
.tab-content { display: none; }
.tab-content.active { display: block; }
</style>

            <?php if ($mensaje): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($mensaje); ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error">❌ <?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            
            <?php if ($accion === 'listar'): ?>
            <!-- LISTADO -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Horarios de Trabajo</h1>
                    <p class="page-subtitle"><?php echo count($horarios); ?> horario(s) configurado(s)</p>
                </div>
                <a href="?accion=nuevo" class="btn btn-primary">➕ Nuevo Horario</a>
            </div>
            
            <div class="card">
                <?php if (empty($horarios)): ?>
                <div class="empty-state">
                    <div class="icon">🕐</div>
                    <h3>No hay horarios registrados</h3>
                    <p>Crea el primer horario para asignar a empleados</p>
                    <a href="?accion=nuevo" class="btn btn-primary" style="margin-top:1rem">➕ Crear Horario</a>
                </div>
                <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Tipo</th>
                                <th>Jornada</th>
                                <th>Horas</th>
                                <th>Empleados</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($horarios as $h): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($h->nombre); ?></strong></td>
                                <td>
                                    <?php if ($h->tipo === 'continua'): ?>
                                    <span class="tipo-jornada">☀️ Continua</span>
                                    <?php elseif ($h->tipo === 'partida'): ?>
                                    <span class="tipo-jornada">🌓 Partida</span>
                                    <?php else: ?>
                                    <span class="tipo-jornada">🔄 Flexible</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $jornada = substr($h->hora_entrada ?? '08:00', 0, 5) . '-' . substr($h->hora_salida ?? '15:00', 0, 5);
                                    if ($h->tipo === 'partida' && $h->hora_entrada_tarde) {
                                        $jornada .= ' / ' . substr($h->hora_entrada_tarde, 0, 5) . '-' . substr($h->hora_salida_tarde, 0, 5);
                                    }
                                    echo $jornada;
                                    ?>
                                </td>
                                <td><?php echo $h->horas_diarias; ?>h/día<br><small style="color:#64748b"><?php echo $h->horas_semanales; ?>h/sem</small></td>
                                <td><span class="badge badge-info"><?php echo $h->num_empleados ?? 0; ?></span></td>
                                <td><?php echo $h->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?></td>
                                <td>
                                    <div class="acciones">
                                        <a href="?accion=ver&id=<?php echo $h->id; ?>" class="btn btn-outline btn-sm">👁️</a>
                                        <a href="?accion=editar&id=<?php echo $h->id; ?>" class="btn btn-outline btn-sm">✏️</a>
                                        <form method="POST" style="display:inline" onsubmit="return confirm('¿Duplicar este horario?')">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                            <input type="hidden" name="accion" value="duplicar">
                                            <input type="hidden" name="id" value="<?php echo $h->id; ?>">
                                            <button type="submit" class="btn btn-outline btn-sm">📋</button>
                                        </form>
                                        <form method="POST" style="display:inline" onsubmit="return confirm('¿Cambiar estado?')">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                            <input type="hidden" name="accion" value="toggle_activo">
                                            <input type="hidden" name="id" value="<?php echo $h->id; ?>">
                                            <button type="submit" class="btn btn-outline btn-sm"><?php echo $h->activo ? '🔴' : '🟢'; ?></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <?php elseif ($accion === 'nuevo' || $accion === 'editar'): ?>
            <!-- FORMULARIO -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo $accion === 'nuevo' ? 'Nuevo Horario' : 'Editar Horario'; ?></h1>
                    <p class="page-subtitle"><?php echo $accion === 'nuevo' ? 'Configura un nuevo horario de trabajo' : 'Modifica la configuración del horario'; ?></p>
                </div>
                <a href="?accion=listar" class="btn btn-outline">← Volver</a>
            </div>
            
            <form method="POST" id="formHorario">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="accion" value="guardar">
                <?php if ($horario): ?><input type="hidden" name="id" value="<?php echo $horario->id; ?>"><?php endif; ?>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">📋 Información Básica</span></div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Nombre del horario <span class="required">*</span></label>
                                <input type="text" name="nombre" class="form-control" required
                                       value="<?php echo $horario ? htmlspecialchars($horario->nombre) : ''; ?>"
                                       placeholder="Ej: Jornada Administrativa">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Tipo de jornada</label>
                                <select name="tipo" class="form-control" id="tipoJornada" onchange="toggleTarde()">
                                    <option value="continua" <?php echo ($horario && $horario->tipo === 'continua') ? 'selected' : ''; ?>>☀️ Jornada Continua</option>
                                    <option value="partida" <?php echo ($horario && $horario->tipo === 'partida') ? 'selected' : ''; ?>>🌓 Jornada Partida</option>
                                    <option value="flexible" <?php echo ($horario && $horario->tipo === 'flexible') ? 'selected' : ''; ?>>🔄 Jornada Flexible</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Horas semanales totales</label>
                            <input type="number" name="horas_semanales" class="form-control" style="width:150px"
                                   value="<?php echo $horario ? $horario->horas_semanales : 37.5; ?>"
                                   min="1" max="60" step="0.5">
                            <div class="form-hint">Total de horas a trabajar por semana</div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">🌅 Horario Base (Mañana)</span></div>
                    <div class="card-body">
                        <div class="form-row-4">
                            <div class="form-group">
                                <label class="form-label">Hora entrada</label>
                                <input type="time" name="hora_entrada" class="form-control"
                                       value="<?php echo $horario && $horario->hora_entrada ? substr($horario->hora_entrada, 0, 5) : '08:00'; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Hora salida</label>
                                <input type="time" name="hora_salida" class="form-control"
                                       value="<?php echo $horario && $horario->hora_salida ? substr($horario->hora_salida, 0, 5) : '15:00'; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Troncal inicio</label>
                                <input type="time" name="troncal_inicio" class="form-control"
                                       value="<?php echo $horario && $horario->troncal_inicio ? substr($horario->troncal_inicio, 0, 5) : '09:00'; ?>">
                                <div class="form-hint">Presencia obligatoria</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Troncal fin</label>
                                <input type="time" name="troncal_fin" class="form-control"
                                       value="<?php echo $horario && $horario->troncal_fin ? substr($horario->troncal_fin, 0, 5) : '14:00'; ?>">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card" id="seccionTarde" style="<?php echo ($horario && $horario->tipo === 'partida') ? '' : 'display:none;'; ?>">
                    <div class="card-header"><span class="card-title">🌆 Horario Tarde (Jornada Partida)</span></div>
                    <div class="card-body">
                        <div class="form-row-4">
                            <div class="form-group">
                                <label class="form-label">Hora entrada tarde</label>
                                <input type="time" name="hora_entrada_tarde" class="form-control"
                                       value="<?php echo $horario && $horario->hora_entrada_tarde ? substr($horario->hora_entrada_tarde, 0, 5) : '16:00'; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Hora salida tarde</label>
                                <input type="time" name="hora_salida_tarde" class="form-control"
                                       value="<?php echo $horario && $horario->hora_salida_tarde ? substr($horario->hora_salida_tarde, 0, 5) : '19:00'; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Troncal tarde inicio</label>
                                <input type="time" name="troncal_tarde_inicio" class="form-control"
                                       value="<?php echo $horario && $horario->troncal_tarde_inicio ? substr($horario->troncal_tarde_inicio, 0, 5) : '16:30'; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Troncal tarde fin</label>
                                <input type="time" name="troncal_tarde_fin" class="form-control"
                                       value="<?php echo $horario && $horario->troncal_tarde_fin ? substr($horario->troncal_tarde_fin, 0, 5) : '18:30'; ?>">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header"><span class="card-title">⏱️ Cortesías y Tolerancias</span></div>
                    <div class="card-body">
                        <div class="form-row-3">
                            <div class="form-group">
                                <label class="form-label">Cortesía entrada (min)</label>
                                <input type="number" name="cortesia_entrada" class="form-control"
                                       value="<?php echo $horario ? $horario->cortesia_entrada : 5; ?>"
                                       min="0" max="30">
                                <div class="form-hint">Margen sin penalización al entrar</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Cortesía salida (min)</label>
                                <input type="number" name="cortesia_salida" class="form-control"
                                       value="<?php echo $horario ? $horario->cortesia_salida : 5; ?>"
                                       min="0" max="30">
                                <div class="form-hint">Margen sin penalización al salir</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Tolerancia fichaje (min)</label>
                                <input type="number" name="tolerancia_minutos" class="form-control"
                                       value="<?php echo $horario ? $horario->tolerancia_minutos : 15; ?>"
                                       min="0" max="60">
                                <div class="form-hint">Margen general para fichajes</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <span class="card-title">📅 Días Laborables y Horas por Día</span>
                    </div>
                    <div class="card-body">
                        <div class="toggle-wrapper">
                            <label class="toggle">
                                <input type="checkbox" name="config_por_dia" value="1" id="toggleConfigDia" onchange="toggleConfigPorDia()"
                                       <?php 
                                       // Activar si algún día tiene configuración específica
                                       $tieneConfigDia = false;
                                       foreach ($diasConfig as $d) {
                                           if ($d->hora_entrada || $d->troncal_inicio) $tieneConfigDia = true;
                                       }
                                       echo $tieneConfigDia ? 'checked' : '';
                                       ?>>
                                <span class="toggle-slider"></span>
                            </label>
                            <span>Configuración avanzada por día (horarios diferentes cada día)</span>
                        </div>
                        
                        <div class="dias-grid">
                            <?php foreach ($diasSemana as $num => $dia): 
                                $diaConfig = $diasConfig[$num] ?? null;
                                $esLaborable = $diaConfig ? $diaConfig->es_laborable : ($diasDefault[$num]['es_laborable'] ?? 0);
                                $horasDia = $diaConfig ? $diaConfig->horas_esperadas : ($diasDefault[$num]['horas_esperadas'] ?? 7.5);
                            ?>
                            <div class="dia-card <?php echo $esLaborable ? 'activo' : 'inactivo'; ?>" id="diaCard<?php echo $num; ?>" onclick="toggleDia(<?php echo $num; ?>)">
                                <input type="checkbox" name="dia_laborable[<?php echo $num; ?>]" id="diaCheck<?php echo $num; ?>" 
                                       <?php echo $esLaborable ? 'checked' : ''; ?> style="display:none">
                                <div class="dia-nombre"><?php echo $dia['abrev']; ?></div>
                                <div class="dia-horas">
                                    <input type="number" name="dia_horas[<?php echo $num; ?>]" 
                                           value="<?php echo $horasDia; ?>" 
                                           min="0" max="12" step="0.5" 
                                           onclick="event.stopPropagation()" 
                                           onchange="actualizarHorasTotales()">h
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div id="configDiaDetalle" style="display:none;">
                            <h4 style="margin: 1.5rem 0 1rem; color:#1e293b;">⚙️ Configuración Específica por Día</h4>
                            
                            <?php foreach ($diasSemana as $num => $dia): 
                                $diaConfig = $diasConfig[$num] ?? null;
                            ?>
                            <div class="config-dia-detalle" id="configDia<?php echo $num; ?>">
                                <div class="config-dia-header">
                                    <span class="config-dia-titulo"><?php echo $dia['nombre']; ?></span>
                                </div>
                                <div class="form-row-4">
                                    <div class="form-group">
                                        <label class="form-label">Entrada</label>
                                        <input type="time" name="dia_entrada[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->hora_entrada ? substr($diaConfig->hora_entrada, 0, 5) : ''; ?>"
                                               placeholder="Usar base">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Salida</label>
                                        <input type="time" name="dia_salida[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->hora_salida ? substr($diaConfig->hora_salida, 0, 5) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Troncal inicio</label>
                                        <input type="time" name="dia_troncal_inicio[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->troncal_inicio ? substr($diaConfig->troncal_inicio, 0, 5) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Troncal fin</label>
                                        <input type="time" name="dia_troncal_fin[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->troncal_fin ? substr($diaConfig->troncal_fin, 0, 5) : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-row-4" id="configDiaTarde<?php echo $num; ?>" style="display:none;">
                                    <div class="form-group">
                                        <label class="form-label">Entrada tarde</label>
                                        <input type="time" name="dia_entrada_tarde[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->hora_entrada_tarde ? substr($diaConfig->hora_entrada_tarde, 0, 5) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Salida tarde</label>
                                        <input type="time" name="dia_salida_tarde[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->hora_salida_tarde ? substr($diaConfig->hora_salida_tarde, 0, 5) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Troncal tarde ini</label>
                                        <input type="time" name="dia_troncal_tarde_inicio[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->troncal_tarde_inicio ? substr($diaConfig->troncal_tarde_inicio, 0, 5) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Troncal tarde fin</label>
                                        <input type="time" name="dia_troncal_tarde_fin[<?php echo $num; ?>]" class="form-control"
                                               value="<?php echo $diaConfig && $diaConfig->troncal_tarde_fin ? substr($diaConfig->troncal_tarde_fin, 0, 5) : ''; ?>">
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            
                            <div class="form-hint" style="margin-top:1rem">
                                💡 Deja los campos vacíos para usar el horario base configurado arriba
                            </div>
                        </div>
                        
                        <div style="margin-top:1rem; padding:0.75rem; background:#f0f9ff; border-radius:0.5rem;">
                            <strong>Total semanal:</strong> <span id="horasTotales">37.5</span>h 
                            <span style="color:#64748b; margin-left:1rem">
                                (Días laborables: <span id="diasLaborables">5</span>)
                            </span>
                        </div>
                    </div>
                </div>
                
                <?php if ($horario): ?>
                <div class="card">
                    <div class="card-body">
                        <label class="form-check">
                            <input type="checkbox" name="activo" <?php echo $horario->activo ? 'checked' : ''; ?>>
                            <span>Horario activo</span>
                        </label>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">💾 <?php echo $accion === 'nuevo' ? 'Crear Horario' : 'Guardar Cambios'; ?></button>
                    <a href="?accion=listar" class="btn btn-outline">Cancelar</a>
                </div>
            </form>
            
            <?php if ($accion === 'editar' && $horario && count($empleadosHorario) > 0): ?>
            <div class="card">
                <div class="card-header"><span class="card-title">👥 Empleados con este horario (<?php echo count($empleadosHorario); ?>)</span></div>
                <div class="card-body">
                    <?php foreach ($empleadosHorario as $emp): ?>
                    <div class="empleado-item">
                        <div class="empleado-avatar"><?php echo strtoupper(substr($emp->nombre, 0, 1)); ?></div>
                        <div class="empleado-nombre"><?php echo htmlspecialchars($emp->nombre . ' ' . $emp->apellido1); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php elseif ($accion === 'ver' && $horario): ?>
            <!-- VER DETALLE -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo htmlspecialchars($horario->nombre); ?></h1>
                    <p class="page-subtitle">
                        <?php if ($horario->tipo === 'continua'): ?>☀️ Jornada Continua
                        <?php elseif ($horario->tipo === 'partida'): ?>🌓 Jornada Partida
                        <?php else: ?>🔄 Jornada Flexible<?php endif; ?>
                    </p>
                </div>
                <div style="display:flex;gap:0.5rem">
                    <a href="?accion=editar&id=<?php echo $horario->id; ?>" class="btn btn-primary">✏️ Editar</a>
                    <a href="?accion=listar" class="btn btn-outline">← Volver</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">📋 Configuración</span>
                    <?php echo $horario->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>'; ?>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Jornada Mañana</div>
                            <div class="info-value"><?php echo substr($horario->hora_entrada, 0, 5); ?> - <?php echo substr($horario->hora_salida, 0, 5); ?></div>
                        </div>
                        <?php if ($horario->tipo === 'partida' && $horario->hora_entrada_tarde): ?>
                        <div class="info-item">
                            <div class="info-label">Jornada Tarde</div>
                            <div class="info-value"><?php echo substr($horario->hora_entrada_tarde, 0, 5); ?> - <?php echo substr($horario->hora_salida_tarde, 0, 5); ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <div class="info-label">Troncal Mañana</div>
                            <div class="info-value"><?php echo $horario->troncal_inicio ? substr($horario->troncal_inicio, 0, 5) . ' - ' . substr($horario->troncal_fin, 0, 5) : 'No definido'; ?></div>
                        </div>
                        <?php if ($horario->tipo === 'partida' && $horario->troncal_tarde_inicio): ?>
                        <div class="info-item">
                            <div class="info-label">Troncal Tarde</div>
                            <div class="info-value"><?php echo substr($horario->troncal_tarde_inicio, 0, 5); ?> - <?php echo substr($horario->troncal_tarde_fin, 0, 5); ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <div class="info-label">Horas Diarias</div>
                            <div class="info-value"><?php echo $horario->horas_diarias; ?>h</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Horas Semanales</div>
                            <div class="info-value"><?php echo $horario->horas_semanales; ?>h</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Cortesía Entrada</div>
                            <div class="info-value"><?php echo $horario->cortesia_entrada; ?> min</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Cortesía Salida</div>
                            <div class="info-value"><?php echo $horario->cortesia_salida; ?> min</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Empleados</div>
                            <div class="info-value"><?php echo $horario->num_empleados; ?></div>
                        </div>
                    </div>
                    
                    <?php if (!empty($horario->dias)): ?>
                    <h4 style="margin:1.5rem 0 1rem">📅 Configuración por Día</h4>
                    <div class="dias-grid">
                        <?php foreach ($diasSemana as $num => $dia): 
                            $diaConfig = $diasConfig[$num] ?? null;
                            $esLaborable = $diaConfig ? $diaConfig->es_laborable : 0;
                            $horas = $diaConfig ? $diaConfig->horas_esperadas : 0;
                        ?>
                        <div class="dia-card <?php echo $esLaborable ? 'activo' : 'inactivo'; ?>" style="cursor:default">
                            <div class="dia-nombre"><?php echo $dia['abrev']; ?></div>
                            <div class="dia-horas"><?php echo $esLaborable ? $horas . 'h' : 'Libre'; ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if (count($empleadosHorario) > 0): ?>
            <div class="card">
                <div class="card-header"><span class="card-title">👥 Empleados (<?php echo count($empleadosHorario); ?>)</span></div>
                <div class="card-body">
                    <?php foreach ($empleadosHorario as $emp): ?>
                    <div class="empleado-item">
                        <div class="empleado-avatar"><?php echo strtoupper(substr($emp->nombre, 0, 1)); ?></div>
                        <div class="empleado-nombre">
                            <a href="empleados.php?accion=editar&id=<?php echo $emp->id; ?>" style="color:inherit;text-decoration:none">
                                <?php echo htmlspecialchars($emp->nombre . ' ' . $emp->apellido1); ?>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($horario->num_empleados == 0): ?>
            <div class="card" style="border-color:#fca5a5">
                <div class="card-header" style="background:#fef2f2"><span class="card-title" style="color:#991b1b">⚠️ Zona de peligro</span></div>
                <div class="card-body">
                    <p style="margin-bottom:1rem;color:#64748b">Este horario no tiene empleados y puede eliminarse.</p>
                    <form method="POST" onsubmit="return confirm('¿Eliminar este horario? No se puede deshacer.')">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" name="id" value="<?php echo $horario->id; ?>">
                        <button type="submit" class="btn btn-danger">🗑️ Eliminar Horario</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <?php endif; ?>
        </main>

    </div>
    
    <script>
    function toggleTarde() {
        var tipo = document.getElementById('tipoJornada').value;
        var seccion = document.getElementById('seccionTarde');
        seccion.style.display = tipo === 'partida' ? 'block' : 'none';
        
        // También mostrar/ocultar config tarde por día
        for (var i = 1; i <= 7; i++) {
            var configTarde = document.getElementById('configDiaTarde' + i);
            if (configTarde) configTarde.style.display = tipo === 'partida' ? 'grid' : 'none';
        }
    }
    
    function toggleDia(num) {
        var checkbox = document.getElementById('diaCheck' + num);
        var card = document.getElementById('diaCard' + num);
        checkbox.checked = !checkbox.checked;
        card.classList.toggle('activo', checkbox.checked);
        card.classList.toggle('inactivo', !checkbox.checked);
        actualizarHorasTotales();
        actualizarConfigDia();
    }
    
    function toggleConfigPorDia() {
        var activo = document.getElementById('toggleConfigDia').checked;
        document.getElementById('configDiaDetalle').style.display = activo ? 'block' : 'none';
        if (activo) actualizarConfigDia();
    }
    
    function actualizarConfigDia() {
        for (var i = 1; i <= 7; i++) {
            var checkbox = document.getElementById('diaCheck' + i);
            var config = document.getElementById('configDia' + i);
            if (config) {
                config.classList.toggle('visible', checkbox.checked);
            }
        }
    }
    
    function actualizarHorasTotales() {
        var total = 0;
        var dias = 0;
        for (var i = 1; i <= 7; i++) {
            var checkbox = document.getElementById('diaCheck' + i);
            if (checkbox && checkbox.checked) {
                var horasInput = document.querySelector('input[name="dia_horas[' + i + ']"]');
                if (horasInput) {
                    total += parseFloat(horasInput.value) || 0;
                    dias++;
                }
            }
        }
        document.getElementById('horasTotales').textContent = total.toFixed(1);
        document.getElementById('diasLaborables').textContent = dias;
    }
    
    // Inicializar
    document.addEventListener('DOMContentLoaded', function() {
        toggleTarde();
        toggleConfigPorDia();
        actualizarHorasTotales();
    });
    </script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
