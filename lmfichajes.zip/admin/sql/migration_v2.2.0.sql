-- ============================================================================
-- LM FICHAJES - Script de migración a versión 2.2.0
-- Fecha: 2026-01-16
--
-- Este script corrige las inconsistencias entre schema y código PHP.
-- Ejecutar sobre bases de datos existentes con versiones anteriores.
-- ============================================================================

-- Añadir columnas faltantes a HORARIOS
ALTER TABLE `horarios`
    ADD COLUMN IF NOT EXISTS `tolerancia_minutos` INT DEFAULT 15 COMMENT 'Minutos de tolerancia para entrada/salida',
    ADD COLUMN IF NOT EXISTS `cortesia_entrada` INT DEFAULT 5 COMMENT 'Minutos de cortesía en entrada',
    ADD COLUMN IF NOT EXISTS `cortesia_salida` INT DEFAULT 5 COMMENT 'Minutos de cortesía en salida';

-- Renombrar columnas de CONVENIOS (si existen con nombres antiguos)
-- MySQL no tiene IF EXISTS para CHANGE COLUMN, usamos procedimiento
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS migrate_convenios()
BEGIN
    -- Verificar si existe la columna antigua
    IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
               WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'convenios'
               AND COLUMN_NAME = 'dias_vacaciones') THEN
        ALTER TABLE `convenios` CHANGE COLUMN `dias_vacaciones` `dias_vacaciones_base` INT DEFAULT 22;
    END IF;

    IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
               WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'convenios'
               AND COLUMN_NAME = 'dias_libre_disposicion') THEN
        ALTER TABLE `convenios` CHANGE COLUMN `dias_libre_disposicion` `dias_libre_disposicion_base` INT DEFAULT 6;
    END IF;

    -- Añadir columnas si no existen
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'convenios'
                   AND COLUMN_NAME = 'dias_vacaciones_base') THEN
        ALTER TABLE `convenios` ADD COLUMN `dias_vacaciones_base` INT DEFAULT 22;
    END IF;

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'convenios'
                   AND COLUMN_NAME = 'dias_libre_disposicion_base') THEN
        ALTER TABLE `convenios` ADD COLUMN `dias_libre_disposicion_base` INT DEFAULT 6;
    END IF;
END//
DELIMITER ;
CALL migrate_convenios();
DROP PROCEDURE IF EXISTS migrate_convenios;

-- Migrar CONVENIOS_ANTIGUEDAD (estructura completamente nueva)
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS migrate_convenios_antiguedad()
BEGIN
    -- Verificar si necesita migración (tiene columna anos_minimo en lugar de anos_minimos)
    IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
               WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'convenios_antiguedad'
               AND COLUMN_NAME = 'anos_minimo') THEN

        -- Añadir nuevas columnas
        ALTER TABLE `convenios_antiguedad`
            ADD COLUMN IF NOT EXISTS `tipo` ENUM('vacaciones', 'libre_disposicion') DEFAULT 'vacaciones',
            ADD COLUMN IF NOT EXISTS `notas` VARCHAR(255) DEFAULT NULL,
            ADD COLUMN IF NOT EXISTS `acumulable` TINYINT(1) DEFAULT 1,
            ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

        -- Renombrar columnas
        ALTER TABLE `convenios_antiguedad`
            CHANGE COLUMN `anos_minimo` `anos_minimos` INT NOT NULL,
            CHANGE COLUMN `dias_extra` `dias_adicionales` INT NOT NULL DEFAULT 0;

    ELSEIF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
               WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'convenios_antiguedad'
               AND COLUMN_NAME = 'tipo') THEN
        -- Añadir columna tipo si no existe
        ALTER TABLE `convenios_antiguedad`
            ADD COLUMN `tipo` ENUM('vacaciones', 'libre_disposicion') DEFAULT 'vacaciones' AFTER `convenio_id`;
    END IF;
END//
DELIMITER ;
CALL migrate_convenios_antiguedad();
DROP PROCEDURE IF EXISTS migrate_convenios_antiguedad;

-- Añadir columna notas a CONVENIOS_TIPOS_DIAS
ALTER TABLE `convenios_tipos_dias`
    ADD COLUMN IF NOT EXISTS `notas` TEXT COMMENT 'Notas o condiciones especiales' AFTER `requiere_justificante`;

-- Añadir columnas faltantes a EMPLEADOS
ALTER TABLE `empleados`
    ADD COLUMN IF NOT EXISTS `telefono_trabajo` VARCHAR(20) COMMENT 'Teléfono de trabajo/extensión' AFTER `telefono`,
    ADD COLUMN IF NOT EXISTS `direccion` VARCHAR(255) COMMENT 'Dirección completa para teletrabajo' AFTER `telefono_trabajo`,
    ADD COLUMN IF NOT EXISTS `coordenadas_domicilio` VARCHAR(50) COMMENT 'Latitud,Longitud del domicilio' AFTER `direccion`,
    ADD COLUMN IF NOT EXISTS `radio_domicilio` INT DEFAULT 50 COMMENT 'Radio permitido para fichar en teletrabajo (metros)' AFTER `coordenadas_domicilio`,
    ADD COLUMN IF NOT EXISTS `porcentaje_jornada` DECIMAL(5,2) DEFAULT 100.00 COMMENT 'Porcentaje de jornada (50=media jornada)' AFTER `horario_id`,
    ADD COLUMN IF NOT EXISTS `requiere_doble_validacion` TINYINT(1) DEFAULT 0 COMMENT 'Requiere aprobación de ambos supervisores' AFTER `supervisor2_id`,
    ADD COLUMN IF NOT EXISTS `fecha_antiguedad` DATE COMMENT 'Fecha para cálculo de antigüedad (trienios)' AFTER `fecha_alta`;

-- ============================================================================
-- FIN DE LA MIGRACIÓN
-- ============================================================================
SELECT 'Migración a v2.2.0 completada' AS resultado;
