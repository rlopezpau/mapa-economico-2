-- ============================================================================
-- ACTUALIZACIÓN DE CONVENIOS - Días base y Reglas de Antigüedad
-- Ejecutar en phpMyAdmin o consola MySQL
-- ============================================================================

-- 1. Añadir campos de días base al convenio (si no existen)
ALTER TABLE convenios 
    ADD COLUMN IF NOT EXISTS dias_vacaciones_base INT DEFAULT 22 COMMENT 'Días de vacaciones base del convenio',
    ADD COLUMN IF NOT EXISTS dias_libre_disposicion_base INT DEFAULT 6 COMMENT 'Días de libre disposición base';

-- 2. Crear tabla de reglas de antigüedad
CREATE TABLE IF NOT EXISTS convenios_antiguedad (
    id INT AUTO_INCREMENT PRIMARY KEY,
    convenio_id INT NOT NULL,
    tipo ENUM('vacaciones', 'libre_disposicion') NOT NULL COMMENT 'Tipo de días afectados',
    anos_minimos INT NOT NULL COMMENT 'Años mínimos de antigüedad requeridos',
    dias_adicionales INT NOT NULL COMMENT 'Días adicionales que se otorgan',
    acumulable TINYINT(1) DEFAULT 1 COMMENT '1=se suma a tramos anteriores, 0=reemplaza',
    notas VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (convenio_id) REFERENCES convenios(id) ON DELETE CASCADE,
    UNIQUE KEY uk_convenio_tipo_anos (convenio_id, tipo, anos_minimos)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Reglas de días adicionales por antigüedad según convenio';

-- 3. Insertar datos de ejemplo para el convenio existente (ID 1)
-- Vacaciones: +1 día cada 5 años (trienios/quinquenios)
INSERT IGNORE INTO convenios_antiguedad (convenio_id, tipo, anos_minimos, dias_adicionales, notas) VALUES
(1, 'vacaciones', 5, 1, 'Primer quinquenio'),
(1, 'vacaciones', 10, 1, 'Segundo quinquenio'),
(1, 'vacaciones', 15, 1, 'Tercer quinquenio'),
(1, 'vacaciones', 20, 1, 'Cuarto quinquenio'),
(1, 'vacaciones', 25, 1, 'Quinto quinquenio');

-- Libre disposición: +1 día a los 10 años, +1 más a los 20
INSERT IGNORE INTO convenios_antiguedad (convenio_id, tipo, anos_minimos, dias_adicionales, notas) VALUES
(1, 'libre_disposicion', 10, 1, 'Primer tramo'),
(1, 'libre_disposicion', 20, 1, 'Segundo tramo');

-- 4. Actualizar días base del convenio existente
UPDATE convenios SET dias_vacaciones_base = 22, dias_libre_disposicion_base = 6 WHERE id = 1;

-- 5. Verificar estructura
SELECT 'Tabla convenios_antiguedad creada correctamente' AS resultado;
SELECT * FROM convenios_antiguedad;
