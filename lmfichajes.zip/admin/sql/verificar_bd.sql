-- ============================================================================
-- LM FICHAJES - Script de verificación y corrección de base de datos
-- Fecha: 2026-01-11
-- 
-- EJECUTAR ESTE SCRIPT EN phpMyAdmin o similar
-- Revisar cada sección antes de ejecutar
-- ============================================================================

-- ============================================================================
-- 1. VERIFICAR QUE EXISTE LA TABLA documentos_empleado
-- ============================================================================
-- Si esta consulta falla, necesitas crear la tabla

SELECT COUNT(*) as total_documentos FROM documentos_empleado;

-- Si no existe, crear con:
/*
CREATE TABLE IF NOT EXISTS documentos_empleado (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT NULL,
    centro_id INT NULL,
    nombre VARCHAR(255) NOT NULL,
    nombre_archivo VARCHAR(255) NOT NULL,
    tipo_documento VARCHAR(50) DEFAULT 'otro',
    descripcion TEXT NULL,
    ruta_archivo VARCHAR(500) NOT NULL,
    tamano_bytes INT DEFAULT 0,
    mime_type VARCHAR(100) NULL,
    mes INT NULL,
    anio INT NULL,
    visible_empleado TINYINT(1) DEFAULT 1,
    requiere_confirmacion TINYINT(1) DEFAULT 0,
    subido_por INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_empleado (empleado_id),
    INDEX idx_centro (centro_id),
    INDEX idx_visible (visible_empleado),
    INDEX idx_tipo (tipo_documento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

-- ============================================================================
-- 2. VERIFICAR TABLA documentos_confirmaciones
-- ============================================================================

SELECT COUNT(*) as total_confirmaciones FROM documentos_confirmaciones;

-- Si no existe, crear con:
/*
CREATE TABLE IF NOT EXISTS documentos_confirmaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    documento_id INT NOT NULL,
    empleado_id INT NOT NULL,
    confirmado_fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    UNIQUE KEY unique_confirmacion (documento_id, empleado_id),
    INDEX idx_documento (documento_id),
    INDEX idx_empleado (empleado_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

-- ============================================================================
-- 3. VERIFICAR TABLA empleados_centros (opcional)
-- ============================================================================
-- Esta tabla es OPCIONAL - el sistema funciona sin ella

SELECT COUNT(*) as asignaciones FROM empleados_centros;

-- Si quieres crearla:
/*
CREATE TABLE IF NOT EXISTS empleados_centros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT NOT NULL,
    centro_id INT NOT NULL,
    es_principal TINYINT(1) DEFAULT 0,
    activo TINYINT(1) DEFAULT 1,
    fecha_asignacion DATE NULL,
    UNIQUE KEY unique_asignacion (empleado_id, centro_id),
    INDEX idx_empleado (empleado_id),
    INDEX idx_centro (centro_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

-- ============================================================================
-- 4. VERIFICAR COLUMNA debe_cambiar_password EN empleados
-- ============================================================================

SELECT 
    column_name, data_type, column_default 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'empleados' 
AND column_name = 'debe_cambiar_password';

-- Si no existe, añadir con:
/*
ALTER TABLE empleados 
ADD COLUMN debe_cambiar_password TINYINT(1) DEFAULT 0 AFTER password;

ALTER TABLE empleados 
ADD COLUMN password_temporal TINYINT(1) DEFAULT 0 AFTER debe_cambiar_password;
*/

-- ============================================================================
-- 5. VERIFICAR TABLA saldo_ausencias
-- ============================================================================

SELECT COUNT(*) as registros_saldo FROM saldo_ausencias;

-- Verificar estructura:
DESCRIBE saldo_ausencias;

-- Si no existe, crear con:
/*
CREATE TABLE IF NOT EXISTS saldo_ausencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empleado_id INT NOT NULL,
    tipo_ausencia_id INT NOT NULL,
    anio INT NOT NULL,
    dias_asignados DECIMAL(5,2) DEFAULT 0,
    dias_disfrutados DECIMAL(5,2) DEFAULT 0,
    dias_pendientes DECIMAL(5,2) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_saldo (empleado_id, tipo_ausencia_id, anio),
    INDEX idx_empleado (empleado_id),
    INDEX idx_anio (anio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

-- ============================================================================
-- 6. INICIALIZAR SALDOS PARA EMPLEADOS ACTIVOS (si están vacíos)
-- ============================================================================
-- IMPORTANTE: Ejecutar solo si saldo_ausencias está vacía y quieres inicializar

/*
-- Esto crea saldos de vacaciones para todos los empleados activos en 2026
INSERT INTO saldo_ausencias (empleado_id, tipo_ausencia_id, anio, dias_asignados)
SELECT 
    e.id,
    ta.id,
    2026,
    COALESCE(e.dias_vacaciones, ta.dias_maximos, 22)
FROM empleados e
CROSS JOIN tipos_ausencia ta
WHERE e.activo = 1
AND ta.codigo = 'VACACIONES'
AND NOT EXISTS (
    SELECT 1 FROM saldo_ausencias sa 
    WHERE sa.empleado_id = e.id 
    AND sa.tipo_ausencia_id = ta.id 
    AND sa.anio = 2026
);
*/

-- ============================================================================
-- 7. DIAGNÓSTICO RÁPIDO
-- ============================================================================

-- Ver empleados activos
SELECT COUNT(*) as empleados_activos FROM empleados WHERE activo = 1;

-- Ver documentos subidos
SELECT tipo_documento, COUNT(*) as total, 
       SUM(CASE WHEN visible_empleado = 1 THEN 1 ELSE 0 END) as visibles
FROM documentos_empleado 
GROUP BY tipo_documento;

-- Ver tipos de ausencia configurados
SELECT id, codigo, nombre, dias_maximos FROM tipos_ausencia WHERE activo = 1;

-- Ver saldos actuales (2026)
SELECT e.nombre, e.apellido1, ta.nombre as tipo, sa.dias_asignados, sa.dias_disfrutados
FROM saldo_ausencias sa
JOIN empleados e ON sa.empleado_id = e.id
JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
WHERE sa.anio = 2026
ORDER BY e.apellido1, ta.nombre;

-- ============================================================================
-- FIN DEL SCRIPT
-- ============================================================================
