-- ============================================================================
-- LM FICHAJES - Esquema completo de base de datos
-- Fecha: 2026-01-16
-- Version: 2.2.0 (Corregido para consistencia con código PHP)
--
-- INSTRUCCIONES:
-- 1. Crear base de datos: CREATE DATABASE lmfichajes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- 2. Seleccionar BD: USE lmfichajes;
-- 3. Ejecutar este script
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================================
-- TABLA: configuracion
-- Configuración general del sistema
-- ============================================================================
CREATE TABLE IF NOT EXISTS `configuracion` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `clave` VARCHAR(100) NOT NULL UNIQUE,
    `valor` TEXT,
    `descripcion` VARCHAR(255),
    `tipo` ENUM('texto', 'numero', 'booleano', 'json') DEFAULT 'texto',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos iniciales de configuración
INSERT INTO `configuracion` (`clave`, `valor`, `descripcion`) VALUES
('nombre_empresa', 'Mi Empresa', 'Nombre de la empresa'),
('email_activo', '0', 'Activar envío de emails'),
('smtp_from_email', '', 'Email remitente'),
('smtp_from_nombre', 'LM Fichajes', 'Nombre remitente'),
('permitir_teletrabajo', '1', 'Permitir fichajes en teletrabajo'),
('requiere_geolocalizacion', '0', 'Requerir geolocalización'),
('dias_vacaciones_defecto', '22', 'Días de vacaciones por defecto'),
('dias_libre_disposicion', '6', 'Días de libre disposición')
ON DUPLICATE KEY UPDATE `valor` = VALUES(`valor`);

-- ============================================================================
-- TABLA: horarios
-- Horarios de trabajo
-- ============================================================================
CREATE TABLE IF NOT EXISTS `horarios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(100) NOT NULL,
    `descripcion` TEXT,
    `tipo` ENUM('fijo', 'flexible', 'turnos') DEFAULT 'fijo',
    `hora_entrada` TIME DEFAULT '09:00:00',
    `hora_salida` TIME DEFAULT '18:00:00',
    `troncal_inicio` TIME DEFAULT '10:00:00',
    `troncal_fin` TIME DEFAULT '14:00:00',
    `minutos_pausa` INT DEFAULT 60,
    `tolerancia_minutos` INT DEFAULT 15 COMMENT 'Minutos de tolerancia para entrada/salida',
    `cortesia_entrada` INT DEFAULT 5 COMMENT 'Minutos de cortesía en entrada',
    `cortesia_salida` INT DEFAULT 5 COMMENT 'Minutos de cortesía en salida',
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Horario por defecto
INSERT INTO `horarios` (`id`, `nombre`, `descripcion`, `tipo`) VALUES
(1, 'Horario General', 'Horario estándar de oficina', 'fijo')
ON DUPLICATE KEY UPDATE `nombre` = VALUES(`nombre`);

-- ============================================================================
-- TABLA: horarios_dias
-- Configuración de horas por día de la semana
-- ============================================================================
CREATE TABLE IF NOT EXISTS `horarios_dias` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `horario_id` INT NOT NULL,
    `dia_semana` TINYINT NOT NULL COMMENT '1=Lunes, 7=Domingo',
    `horas_esperadas` DECIMAL(4,2) DEFAULT 7.50,
    `es_laborable` TINYINT(1) DEFAULT 1,
    INDEX `idx_horario` (`horario_id`),
    FOREIGN KEY (`horario_id`) REFERENCES `horarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: centros
-- Centros de trabajo
-- ============================================================================
CREATE TABLE IF NOT EXISTS `centros` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo` VARCHAR(20),
    `nombre` VARCHAR(150) NOT NULL,
    `direccion` VARCHAR(255),
    `ciudad` VARCHAR(100),
    `codigo_postal` VARCHAR(10),
    `coordenadas` VARCHAR(50),
    `latitud` DECIMAL(10, 8),
    `longitud` DECIMAL(11, 8),
    `radio_metros` INT DEFAULT 100,
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Centro por defecto
INSERT INTO `centros` (`id`, `nombre`, `direccion`) VALUES
(1, 'Oficina Central', 'Dirección principal')
ON DUPLICATE KEY UPDATE `nombre` = VALUES(`nombre`);

-- ============================================================================
-- TABLA: turnos_grupo
-- Grupos de turnos rotativos
-- ============================================================================
CREATE TABLE IF NOT EXISTS `turnos_grupo` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(100) NOT NULL,
    `descripcion` TEXT,
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: turnos_semana
-- Detalle de turnos por semana
-- ============================================================================
CREATE TABLE IF NOT EXISTS `turnos_semana` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `turno_grupo_id` INT NOT NULL,
    `semana_numero` INT NOT NULL,
    `horario_id` INT,
    INDEX `idx_turno_grupo` (`turno_grupo_id`),
    FOREIGN KEY (`turno_grupo_id`) REFERENCES `turnos_grupo`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`horario_id`) REFERENCES `horarios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: convenios
-- Convenios colectivos
-- ============================================================================
CREATE TABLE IF NOT EXISTS `convenios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo` VARCHAR(20) NOT NULL UNIQUE,
    `nombre` VARCHAR(200) NOT NULL,
    `descripcion` TEXT,
    `dias_vacaciones_base` INT DEFAULT 22 COMMENT 'Días base de vacaciones según convenio',
    `dias_libre_disposicion_base` INT DEFAULT 6 COMMENT 'Días base de libre disposición según convenio',
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: convenios_antiguedad
-- Días extra por antigüedad según convenio
-- ============================================================================
CREATE TABLE IF NOT EXISTS `convenios_antiguedad` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `convenio_id` INT NOT NULL,
    `tipo` ENUM('vacaciones', 'libre_disposicion') NOT NULL COMMENT 'Tipo de días que aplica',
    `anos_minimos` INT NOT NULL COMMENT 'Años mínimos de antigüedad requeridos',
    `dias_adicionales` INT NOT NULL DEFAULT 0 COMMENT 'Días extra que se conceden',
    `acumulable` TINYINT(1) DEFAULT 1 COMMENT 'Si se acumula con otras reglas',
    `notas` VARCHAR(255) DEFAULT NULL COMMENT 'Notas explicativas (ej: Primer trienio)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_convenio` (`convenio_id`),
    UNIQUE KEY `uk_convenio_tipo_anos` (`convenio_id`, `tipo`, `anos_minimos`),
    FOREIGN KEY (`convenio_id`) REFERENCES `convenios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: tipos_ausencia (movida aquí para resolver dependencias)
-- Tipos de ausencias configurables
-- ============================================================================
CREATE TABLE IF NOT EXISTS `tipos_ausencia` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo` VARCHAR(50) NOT NULL UNIQUE,
    `nombre` VARCHAR(100) NOT NULL,
    `descripcion` TEXT,
    `categoria` ENUM('vacaciones', 'asuntos_propios', 'permiso_retribuido', 'permiso_no_retribuido', 'baja_medica', 'otros') DEFAULT 'otros',
    `dias_maximos` INT DEFAULT NULL COMMENT 'NULL = sin límite',
    `dias_preaviso` INT DEFAULT 0 COMMENT 'Días de antelación requeridos',
    `requiere_justificante` TINYINT(1) DEFAULT 0,
    `descuenta_vacaciones` TINYINT(1) DEFAULT 0,
    `color` VARCHAR(7) DEFAULT '#3b82f6',
    `orden` INT DEFAULT 0,
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tipos de ausencia por defecto
INSERT INTO `tipos_ausencia` (`codigo`, `nombre`, `categoria`, `dias_maximos`, `dias_preaviso`, `color`, `orden`) VALUES
('VACACIONES', 'Vacaciones', 'vacaciones', NULL, 15, '#10b981', 1),
('ASUNTOS_PROPIOS', 'Asuntos Propios', 'asuntos_propios', 6, 2, '#8b5cf6', 2),
('PERMISO_MATRIMONIO', 'Permiso por matrimonio', 'permiso_retribuido', 15, 30, '#ec4899', 10),
('PERMISO_NACIMIENTO', 'Permiso por nacimiento', 'permiso_retribuido', 2, 0, '#06b6d4', 11),
('PERMISO_FALLECIMIENTO', 'Permiso por fallecimiento', 'permiso_retribuido', 3, 0, '#64748b', 12),
('PERMISO_MUDANZA', 'Permiso por mudanza', 'permiso_retribuido', 1, 7, '#f97316', 13),
('BAJA_IT', 'Baja por IT', 'baja_medica', NULL, 0, '#ef4444', 20),
('EXCEDENCIA', 'Excedencia', 'otros', NULL, 30, '#6b7280', 30),
('OTROS', 'Otros', 'otros', NULL, 0, '#64748b', 99)
ON DUPLICATE KEY UPDATE `nombre` = VALUES(`nombre`), `categoria` = VALUES(`categoria`);

-- ============================================================================
-- TABLA: convenios_tipos_dias
-- Días asignados por tipo de ausencia según convenio
-- ============================================================================
CREATE TABLE IF NOT EXISTS `convenios_tipos_dias` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `convenio_id` INT NOT NULL,
    `tipo_ausencia_id` INT NOT NULL,
    `dias` DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'Días asignados para este tipo de ausencia',
    `dias_maximos` INT DEFAULT NULL COMMENT 'Máximo días por solicitud (NULL=sin límite)',
    `requiere_justificante` TINYINT(1) DEFAULT 0,
    `notas` TEXT COMMENT 'Notas o condiciones especiales',
    `activo` TINYINT(1) DEFAULT 1,
    INDEX `idx_convenio` (`convenio_id`),
    INDEX `idx_tipo` (`tipo_ausencia_id`),
    UNIQUE KEY `uk_convenio_tipo` (`convenio_id`, `tipo_ausencia_id`),
    FOREIGN KEY (`convenio_id`) REFERENCES `convenios`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`tipo_ausencia_id`) REFERENCES `tipos_ausencia`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: empleados
-- Empleados del sistema
-- ============================================================================
CREATE TABLE IF NOT EXISTS `empleados` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nif` VARCHAR(15) NOT NULL UNIQUE,
    `nombre` VARCHAR(100) NOT NULL,
    `apellido1` VARCHAR(100) NOT NULL,
    `apellido2` VARCHAR(100),
    `email` VARCHAR(150),
    `telefono` VARCHAR(20) COMMENT 'Teléfono personal',
    `telefono_trabajo` VARCHAR(20) COMMENT 'Teléfono de trabajo/extensión',
    `direccion` VARCHAR(255) COMMENT 'Dirección completa para teletrabajo',
    `coordenadas_domicilio` VARCHAR(50) COMMENT 'Latitud,Longitud del domicilio',
    `radio_domicilio` INT DEFAULT 50 COMMENT 'Radio permitido para fichar en teletrabajo (metros)',
    `password` VARCHAR(255) NOT NULL,
    `debe_cambiar_password` TINYINT(1) DEFAULT 0,
    `password_temporal` TINYINT(1) DEFAULT 0,
    `password_cambiado` DATETIME,
    `rol` ENUM('empleado', 'supervisor', 'manager', 'admin') DEFAULT 'empleado',
    `horario_id` INT,
    `porcentaje_jornada` DECIMAL(5,2) DEFAULT 100.00 COMMENT 'Porcentaje de jornada (50=media jornada)',
    `turno_grupo_id` INT,
    `centro_id` INT,
    `convenio_id` INT,
    `supervisor_id` INT,
    `supervisor2_id` INT,
    `requiere_doble_validacion` TINYINT(1) DEFAULT 0 COMMENT 'Requiere aprobación de ambos supervisores',
    `fecha_alta` DATE,
    `fecha_antiguedad` DATE COMMENT 'Fecha para cálculo de antigüedad (trienios)',
    `fecha_baja` DATE,
    `dias_vacaciones` INT DEFAULT 22 COMMENT 'Días base de vacaciones',
    `dias_vacaciones_antiguedad` INT DEFAULT 0 COMMENT 'Días extra por antigüedad',
    `dias_libre_disposicion` INT DEFAULT 6 COMMENT 'Días de asuntos propios',
    `dias_libre_disp_antiguedad` INT DEFAULT 0 COMMENT 'Días extra asuntos por antigüedad',
    `mfa_activo` TINYINT(1) DEFAULT 0,
    `mfa_secret` VARCHAR(100),
    `ultimo_acceso` DATETIME,
    `intentos_fallidos` INT DEFAULT 0,
    `bloqueado_hasta` DATETIME,
    `activo` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_nif` (`nif`),
    INDEX `idx_rol` (`rol`),
    INDEX `idx_activo` (`activo`),
    FOREIGN KEY (`horario_id`) REFERENCES `horarios`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`turno_grupo_id`) REFERENCES `turnos_grupo`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`centro_id`) REFERENCES `centros`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`convenio_id`) REFERENCES `convenios`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`supervisor_id`) REFERENCES `empleados`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`supervisor2_id`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuario admin por defecto (password: Admin123!)
INSERT INTO `empleados` (`nif`, `nombre`, `apellido1`, `email`, `password`, `rol`, `horario_id`, `centro_id`, `fecha_alta`, `activo`) VALUES
('00000000A', 'Administrador', 'Sistema', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, 1, CURDATE(), 1)
ON DUPLICATE KEY UPDATE `nombre` = VALUES(`nombre`);

-- ============================================================================
-- TABLA: empleados_centros
-- Asignación de empleados a múltiples centros
-- ============================================================================
CREATE TABLE IF NOT EXISTS `empleados_centros` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `centro_id` INT NOT NULL,
    `es_principal` TINYINT(1) DEFAULT 0,
    `activo` TINYINT(1) DEFAULT 1,
    `fecha_asignacion` DATE,
    UNIQUE KEY `unique_asignacion` (`empleado_id`, `centro_id`),
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_centro` (`centro_id`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`centro_id`) REFERENCES `centros`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: fichajes
-- Registros de fichajes
-- ============================================================================
CREATE TABLE IF NOT EXISTS `fichajes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `centro_id` INT,
    `fecha` DATE NOT NULL,
    `hora` TIME NOT NULL,
    `tipo` ENUM('entrada', 'salida', 'pausa_inicio', 'pausa_fin', 'visita') NOT NULL,
    `modo` ENUM('presencial', 'teletrabajo', 'visita', 'formacion') DEFAULT 'presencial',
    `estado` ENUM('auto_aprobado', 'pendiente', 'validado', 'autorizado', 'rechazado') DEFAULT 'auto_aprobado',
    `coordenadas` VARCHAR(50),
    `distancia_metros` INT,
    `ubicacion_lat` DECIMAL(10, 8),
    `ubicacion_lon` DECIMAL(11, 8),
    `radio_metros` INT,
    `geolocalizado` TINYINT(1) DEFAULT 0,
    `fuera_ubicacion` TINYINT(1) DEFAULT 0,
    `fuera_horario` TINYINT(1) DEFAULT 0,
    `observacion` TEXT,
    `validado_por` INT,
    `validado_fecha` DATETIME,
    `ip_address` VARCHAR(45),
    `user_agent` VARCHAR(255),
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_empleado_fecha` (`empleado_id`, `fecha`),
    INDEX `idx_fecha` (`fecha`),
    INDEX `idx_estado` (`estado`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`centro_id`) REFERENCES `centros`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`validado_por`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: resumen_diario
-- Resumen diario de horas trabajadas
-- ============================================================================
CREATE TABLE IF NOT EXISTS `resumen_diario` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `fecha` DATE NOT NULL,
    `minutos_trabajados` INT DEFAULT 0,
    `minutos_esperados` INT DEFAULT 450,
    `minutos_balance` INT DEFAULT 0,
    `primera_entrada` TIME,
    `ultima_salida` TIME,
    `num_fichajes` INT DEFAULT 0,
    `incidencias` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_empleado_fecha` (`empleado_id`, `fecha`),
    INDEX `idx_fecha` (`fecha`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: banco_horas
-- Banco de horas mensual
-- ============================================================================
CREATE TABLE IF NOT EXISTS `banco_horas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `periodo` CHAR(7) NOT NULL COMMENT 'Formato: YYYY-MM',
    `minutos_trabajados` INT DEFAULT 0,
    `minutos_esperados` INT DEFAULT 0,
    `minutos_balance` INT DEFAULT 0,
    `saldo_acumulado` INT DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_empleado_periodo` (`empleado_id`, `periodo`),
    INDEX `idx_periodo` (`periodo`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: saldo_ausencias
-- Saldo de días de ausencia por empleado y año
-- ============================================================================
CREATE TABLE IF NOT EXISTS `saldo_ausencias` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `tipo_ausencia_id` INT NOT NULL,
    `anio` INT NOT NULL,
    `dias_asignados` DECIMAL(5,2) DEFAULT 0,
    `dias_disfrutados` DECIMAL(5,2) DEFAULT 0,
    `dias_pendientes` DECIMAL(5,2) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_saldo` (`empleado_id`, `tipo_ausencia_id`, `anio`),
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_anio` (`anio`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`tipo_ausencia_id`) REFERENCES `tipos_ausencia`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: solicitudes_ausencia
-- Solicitudes de ausencias/vacaciones
-- ============================================================================
CREATE TABLE IF NOT EXISTS `solicitudes_ausencia` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `tipo_ausencia_id` INT NOT NULL,
    `fecha_inicio` DATE NOT NULL,
    `fecha_fin` DATE NOT NULL,
    `dias_solicitados` DECIMAL(5,2) NOT NULL,
    `jornada_inicio` ENUM('completa', 'mañana', 'tarde') DEFAULT 'completa',
    `jornada_fin` ENUM('completa', 'mañana', 'tarde') DEFAULT 'completa',
    `motivo` TEXT,
    `justificante_ruta` VARCHAR(500),
    `justificante_requerido` TINYINT(1) DEFAULT 0,
    `estado` ENUM('borrador', 'pendiente', 'aprobada', 'rechazada', 'cancelada', 'anulada') DEFAULT 'pendiente',
    -- Validador 1 (supervisor directo)
    `validador1_id` INT,
    `validador1_fecha` DATETIME,
    `validador1_observacion` TEXT,
    -- Validador 2 (RRHH o segundo nivel) - opcional
    `validador2_id` INT,
    `validador2_fecha` DATETIME,
    `validador2_observacion` TEXT,
    -- Campos legacy para compatibilidad
    `aprobada_por` INT,
    `fecha_aprobacion` DATETIME,
    `motivo_rechazo` TEXT,
    -- Auditoría
    `ip_solicitud` VARCHAR(45),
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_estado` (`estado`),
    INDEX `idx_fechas` (`fecha_inicio`, `fecha_fin`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`tipo_ausencia_id`) REFERENCES `tipos_ausencia`(`id`) ON DELETE RESTRICT,
    FOREIGN KEY (`validador1_id`) REFERENCES `empleados`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`validador2_id`) REFERENCES `empleados`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`aprobada_por`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: documentos_empleado
-- Documentos asignados a empleados
-- ============================================================================
CREATE TABLE IF NOT EXISTS `documentos_empleado` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NULL COMMENT 'NULL = todos los empleados',
    `centro_id` INT NULL COMMENT 'NULL = todos los centros',
    `nombre` VARCHAR(255) NOT NULL,
    `nombre_archivo` VARCHAR(255) NOT NULL,
    `tipo_documento` VARCHAR(50) DEFAULT 'otro',
    `descripcion` TEXT,
    `ruta_archivo` VARCHAR(500) NOT NULL,
    `tamano_bytes` INT DEFAULT 0,
    `mime_type` VARCHAR(100),
    `mes` INT NULL,
    `anio` INT NULL,
    `visible_empleado` TINYINT(1) DEFAULT 1,
    `requiere_confirmacion` TINYINT(1) DEFAULT 0,
    `subido_por` INT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_centro` (`centro_id`),
    INDEX `idx_visible` (`visible_empleado`),
    INDEX `idx_tipo` (`tipo_documento`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`centro_id`) REFERENCES `centros`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`subido_por`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: documentos_confirmaciones
-- Confirmaciones de lectura de documentos
-- ============================================================================
CREATE TABLE IF NOT EXISTS `documentos_confirmaciones` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `documento_id` INT NOT NULL,
    `empleado_id` INT NOT NULL,
    `confirmado_fecha` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `ip_address` VARCHAR(45),
    UNIQUE KEY `unique_confirmacion` (`documento_id`, `empleado_id`),
    INDEX `idx_documento` (`documento_id`),
    INDEX `idx_empleado` (`empleado_id`),
    FOREIGN KEY (`documento_id`) REFERENCES `documentos_empleado`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: notificaciones
-- Sistema de notificaciones
-- ============================================================================
CREATE TABLE IF NOT EXISTS `notificaciones` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `tipo` VARCHAR(50) NOT NULL,
    `titulo` VARCHAR(200) NOT NULL,
    `mensaje` TEXT,
    `url` VARCHAR(500),
    `leida` TINYINT(1) DEFAULT 0,
    `fecha_leida` DATETIME,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_leida` (`leida`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: intentos_login
-- Registro de intentos de login
-- ============================================================================
CREATE TABLE IF NOT EXISTS `intentos_login` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nif` VARCHAR(15) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `exito` TINYINT(1) DEFAULT 0 COMMENT 'Si el login fue exitoso',
    `user_agent` VARCHAR(500),
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_nif` (`nif`),
    INDEX `idx_ip` (`ip_address`),
    INDEX `idx_fecha` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: audit_log
-- Log de auditoría ENS
-- ============================================================================
CREATE TABLE IF NOT EXISTS `audit_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `tipo` VARCHAR(50) NOT NULL,
    `descripcion` TEXT NOT NULL,
    `datos` JSON,
    `nivel` ENUM('INFO', 'WARNING', 'ERROR', 'CRITICAL') DEFAULT 'INFO',
    `usuario_id` INT,
    `tabla_afectada` VARCHAR(100),
    `registro_id` INT,
    `ip_address` VARCHAR(45),
    `user_agent` VARCHAR(500),
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_tipo` (`tipo`),
    INDEX `idx_nivel` (`nivel`),
    INDEX `idx_usuario` (`usuario_id`),
    INDEX `idx_fecha` (`created_at`),
    FOREIGN KEY (`usuario_id`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: password_history
-- Historial de contraseñas
-- ============================================================================
CREATE TABLE IF NOT EXISTS `password_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: mfa_backup_codes
-- Códigos de respaldo MFA
-- ============================================================================
CREATE TABLE IF NOT EXISTS `mfa_backup_codes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `codigo` VARCHAR(20) NOT NULL,
    `usado` TINYINT(1) DEFAULT 0,
    `usado_fecha` DATETIME,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: solicitudes_rgpd
-- Solicitudes de derechos RGPD
-- ============================================================================
CREATE TABLE IF NOT EXISTS `solicitudes_rgpd` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `tipo_derecho` ENUM('acceso', 'rectificacion', 'cancelacion', 'oposicion', 'portabilidad') NOT NULL,
    `descripcion` TEXT,
    `estado` ENUM('pendiente', 'en_proceso', 'completada', 'rechazada') DEFAULT 'pendiente',
    `respuesta` TEXT,
    `procesada_por` INT,
    `fecha_procesada` DATETIME,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_estado` (`estado`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`procesada_por`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: inspeccion_accesos
-- Log de accesos para inspección de trabajo
-- ============================================================================
CREATE TABLE IF NOT EXISTS `inspeccion_accesos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo_acceso` VARCHAR(100) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `user_agent` VARCHAR(500),
    `consulta_realizada` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_codigo` (`codigo_acceso`),
    INDEX `idx_fecha` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: tickets
-- Sistema de tickets/soporte
-- ============================================================================
CREATE TABLE IF NOT EXISTS `tickets` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `empleado_id` INT NOT NULL,
    `asunto` VARCHAR(200) NOT NULL,
    `descripcion` TEXT NOT NULL,
    `categoria` VARCHAR(50) DEFAULT 'general',
    `prioridad` ENUM('baja', 'media', 'alta', 'urgente') DEFAULT 'media',
    `estado` ENUM('abierto', 'en_proceso', 'pendiente_usuario', 'resuelto', 'cerrado') DEFAULT 'abierto',
    `asignado_a` INT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_empleado` (`empleado_id`),
    INDEX `idx_estado` (`estado`),
    FOREIGN KEY (`empleado_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`asignado_a`) REFERENCES `empleados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLA: tickets_respuestas
-- Respuestas a tickets
-- ============================================================================
CREATE TABLE IF NOT EXISTS `tickets_respuestas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ticket_id` INT NOT NULL,
    `usuario_id` INT NOT NULL,
    `mensaje` TEXT NOT NULL,
    `es_interno` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_ticket` (`ticket_id`),
    FOREIGN KEY (`ticket_id`) REFERENCES `tickets`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`usuario_id`) REFERENCES `empleados`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- FIN DEL ESQUEMA
--
-- Usuario admin por defecto:
-- NIF: 00000000A
-- Password: password (cambiar inmediatamente)
-- ============================================================================
