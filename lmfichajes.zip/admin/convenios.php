<?php
/**
 * LM FICHAJES - Gestión de Convenios Colectivos
 * 
 * CRUD completo para convenios con:
 * - Días base de vacaciones y libre disposición
 * - Reglas de antigüedad configurables
 * - Días por tipo de ausencia
 * 
 * @package     LMFichajes
 * @subpackage  Admin
 * @version     2.0.0
 */

define('LMFICHAJES', true);
require_once dirname(__DIR__) . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
if (file_exists(INCLUDES_PATH . '/auditoria.php')) {
    require_once INCLUDES_PATH . '/auditoria.php';
}
require_once __DIR__ . '/includes/admin_functions.php';

$usuario = obtener_usuario_actual($pdo);

// ============================================================================
// SEGURIDAD
// ============================================================================
requerir_login('../login.php');
if (!es_admin()) {
    header('Location: index.php');
    exit;
}

$accion = $_GET['accion'] ?? 'listar';
$convenioId = (int)($_GET['id'] ?? 0);
$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

// ============================================================================
// VERIFICAR/CREAR TABLAS NECESARIAS
// ============================================================================
try {
    // Verificar si existen los campos en convenios
    $stmt = $pdo->query("SHOW COLUMNS FROM convenios LIKE 'dias_vacaciones_base'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE convenios 
            ADD COLUMN dias_vacaciones_base INT DEFAULT 22,
            ADD COLUMN dias_libre_disposicion_base INT DEFAULT 6");
    }
    
    // Verificar si existe la tabla de antigüedad
    $stmt = $pdo->query("SHOW TABLES LIKE 'convenios_antiguedad'");
    if (!$stmt->fetch()) {
        $pdo->exec("CREATE TABLE convenios_antiguedad (
            id INT AUTO_INCREMENT PRIMARY KEY,
            convenio_id INT NOT NULL,
            tipo ENUM('vacaciones', 'libre_disposicion') NOT NULL,
            anos_minimos INT NOT NULL,
            dias_adicionales INT NOT NULL,
            acumulable TINYINT(1) DEFAULT 1,
            notas VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (convenio_id) REFERENCES convenios(id) ON DELETE CASCADE,
            UNIQUE KEY uk_convenio_tipo_anos (convenio_id, tipo, anos_minimos)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
} catch (PDOException $e) {
    // Silenciar errores de creación
}

// ============================================================================
// PROCESAR POST
// ============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
    $act = $_POST['accion'] ?? '';
    
    // Guardar convenio (datos básicos + días base)
    if ($act === 'guardar_convenio') {
        $datos = [
            'codigo' => strtoupper(trim($_POST['codigo'] ?? '')),
            'nombre' => trim($_POST['nombre'] ?? ''),
            'descripcion' => trim($_POST['descripcion'] ?? ''),
            'dias_vacaciones_base' => (int)($_POST['dias_vacaciones_base'] ?? 22),
            'dias_libre_disposicion_base' => (int)($_POST['dias_libre_disposicion_base'] ?? 6),
            'activo' => isset($_POST['activo']) ? 1 : 0
        ];
        
        $idEdit = (int)($_POST['convenio_id'] ?? 0);
        
        if (empty($datos['codigo']) || empty($datos['nombre'])) {
            $error = 'El código y nombre son obligatorios';
        } else {
            try {
                $sqlCheck = "SELECT id FROM convenios WHERE codigo = ?" . ($idEdit ? " AND id != ?" : "");
                $stmt = $pdo->prepare($sqlCheck);
                $stmt->execute($idEdit ? [$datos['codigo'], $idEdit] : [$datos['codigo']]);
                
                if ($stmt->fetch()) {
                    $error = 'Ya existe un convenio con ese código';
                } else {
                    if ($idEdit) {
                        $stmt = $pdo->prepare("UPDATE convenios SET codigo=?, nombre=?, descripcion=?, dias_vacaciones_base=?, dias_libre_disposicion_base=?, activo=? WHERE id=?");
                        $stmt->execute([$datos['codigo'], $datos['nombre'], $datos['descripcion'], $datos['dias_vacaciones_base'], $datos['dias_libre_disposicion_base'], $datos['activo'], $idEdit]);
                        $_SESSION['mensaje'] = 'Convenio actualizado correctamente';
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO convenios (codigo, nombre, descripcion, dias_vacaciones_base, dias_libre_disposicion_base, activo) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$datos['codigo'], $datos['nombre'], $datos['descripcion'], $datos['dias_vacaciones_base'], $datos['dias_libre_disposicion_base'], $datos['activo']]);
                        $idEdit = $pdo->lastInsertId();
                        $_SESSION['mensaje'] = 'Convenio creado correctamente';
                    }
                    header('Location: convenios.php?accion=editar&id=' . $idEdit);
                    exit;
                }
            } catch (PDOException $e) {
                $error = 'Error al guardar: ' . $e->getMessage();
            }
        }
    }
    
    // Guardar días del convenio (otros tipos de ausencia)
    if ($act === 'guardar_dias') {
        $convId = (int)($_POST['convenio_id'] ?? 0);
        
        if ($convId) {
            try {
                $pdo->prepare("DELETE FROM convenios_tipos_dias WHERE convenio_id = ?")->execute([$convId]);
                
                $diasPost = $_POST['dias'] ?? [];
                $insertStmt = $pdo->prepare("INSERT INTO convenios_tipos_dias (convenio_id, tipo_ausencia_id, dias, notas) VALUES (?, ?, ?, ?)");
                
                foreach ($diasPost as $tipoId => $info) {
                    $numDias = (int)($info['dias'] ?? 0);
                    $notas = trim($info['notas'] ?? '');
                    if ($numDias > 0) {
                        $insertStmt->execute([$convId, $tipoId, $numDias, $notas]);
                    }
                }
                
                $_SESSION['mensaje'] = 'Días guardados correctamente';
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Error al guardar días: ' . $e->getMessage();
            }
            header('Location: convenios.php?accion=editar&id=' . $convId . '#otros-dias');
            exit;
        }
    }
    
    // Guardar reglas de antigüedad
    if ($act === 'guardar_antiguedad') {
        $convId = (int)($_POST['convenio_id'] ?? 0);
        
        if ($convId) {
            try {
                // Eliminar reglas existentes
                $pdo->prepare("DELETE FROM convenios_antiguedad WHERE convenio_id = ?")->execute([$convId]);
                
                // Insertar nuevas reglas
                $reglas = $_POST['antiguedad'] ?? [];
                $insertStmt = $pdo->prepare("INSERT INTO convenios_antiguedad (convenio_id, tipo, anos_minimos, dias_adicionales, notas) VALUES (?, ?, ?, ?, ?)");
                
                foreach ($reglas as $regla) {
                    $tipo = $regla['tipo'] ?? '';
                    $anos = (int)($regla['anos'] ?? 0);
                    $dias = (int)($regla['dias'] ?? 0);
                    $notas = trim($regla['notas'] ?? '');
                    
                    if ($tipo && $anos > 0 && $dias > 0) {
                        $insertStmt->execute([$convId, $tipo, $anos, $dias, $notas]);
                    }
                }
                
                $_SESSION['mensaje'] = 'Reglas de antigüedad guardadas correctamente';
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Error al guardar reglas: ' . $e->getMessage();
            }
            header('Location: convenios.php?accion=editar&id=' . $convId . '#antiguedad');
            exit;
        }
    }
    
    // Eliminar convenio
    if ($act === 'eliminar') {
        $idElim = (int)($_POST['convenio_id'] ?? 0);
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM empleados WHERE convenio_id = ?");
        $stmt->execute([$idElim]);
        
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['error'] = 'No se puede eliminar: hay empleados asignados a este convenio';
        } else {
            try {
                $pdo->prepare("DELETE FROM convenios WHERE id = ?")->execute([$idElim]);
                $_SESSION['mensaje'] = 'Convenio eliminado';
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Error al eliminar';
            }
        }
        header('Location: convenios.php');
        exit;
    }
    
    // Duplicar convenio
    if ($act === 'duplicar') {
        $idOrig = (int)($_POST['convenio_id'] ?? 0);
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM convenios WHERE id = ?");
            $stmt->execute([$idOrig]);
            $orig = $stmt->fetch();
            
            if ($orig) {
                $newCodigo = $orig->codigo . '_COPIA';
                $stmt = $pdo->prepare("INSERT INTO convenios (codigo, nombre, descripcion, dias_vacaciones_base, dias_libre_disposicion_base, activo) VALUES (?, ?, ?, ?, ?, 0)");
                $stmt->execute([$newCodigo, $orig->nombre . ' (Copia)', $orig->descripcion, $orig->dias_vacaciones_base ?? 22, $orig->dias_libre_disposicion_base ?? 6]);
                $newId = $pdo->lastInsertId();
                
                // Copiar días
                $pdo->prepare("INSERT INTO convenios_tipos_dias (convenio_id, tipo_ausencia_id, dias, notas) 
                    SELECT ?, tipo_ausencia_id, dias, notas FROM convenios_tipos_dias WHERE convenio_id = ?")
                    ->execute([$newId, $idOrig]);
                
                // Copiar reglas de antigüedad
                try {
                    $pdo->prepare("INSERT INTO convenios_antiguedad (convenio_id, tipo, anos_minimos, dias_adicionales, notas) 
                        SELECT ?, tipo, anos_minimos, dias_adicionales, notas FROM convenios_antiguedad WHERE convenio_id = ?")
                        ->execute([$newId, $idOrig]);
                } catch (PDOException $e) {}
                
                $_SESSION['mensaje'] = 'Convenio duplicado correctamente';
                header('Location: convenios.php?accion=editar&id=' . $newId);
                exit;
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Error al duplicar: ' . $e->getMessage();
        }
        header('Location: convenios.php');
        exit;
    }
    
    // Aplicar convenio a empleados
    if ($act === 'aplicar_convenio') {
        $convId = (int)($_POST['convenio_id'] ?? 0);
        
        if ($convId) {
            try {
                // Obtener convenio
                $stmt = $pdo->prepare("SELECT * FROM convenios WHERE id = ?");
                $stmt->execute([$convId]);
                $conv = $stmt->fetch();
                
                if ($conv) {
                    // Obtener reglas de antigüedad
                    $reglasAnt = [];
                    try {
                        $stmt = $pdo->prepare("SELECT * FROM convenios_antiguedad WHERE convenio_id = ? ORDER BY tipo, anos_minimos");
                        $stmt->execute([$convId]);
                        $reglasAnt = $stmt->fetchAll();
                    } catch (PDOException $e) {}
                    
                    // Obtener empleados con este convenio
                    $stmt = $pdo->prepare("SELECT id, fecha_antiguedad FROM empleados WHERE convenio_id = ? AND activo = 1");
                    $stmt->execute([$convId]);
                    $empleados = $stmt->fetchAll();
                    
                    $actualizados = 0;
                    foreach ($empleados as $emp) {
                        // Calcular años de antigüedad
                        $anosAntiguedad = 0;
                        if ($emp->fecha_antiguedad) {
                            $fechaAnt = new DateTime($emp->fecha_antiguedad);
                            $hoy = new DateTime();
                            $anosAntiguedad = $hoy->diff($fechaAnt)->y;
                        }
                        
                        // Calcular días extra por antigüedad
                        $diasVacAnt = 0;
                        $diasLDAnt = 0;
                        
                        foreach ($reglasAnt as $regla) {
                            if ($anosAntiguedad >= $regla->anos_minimos) {
                                if ($regla->tipo === 'vacaciones') {
                                    $diasVacAnt += $regla->dias_adicionales;
                                } else {
                                    $diasLDAnt += $regla->dias_adicionales;
                                }
                            }
                        }
                        
                        // Actualizar empleado
                        $stmt2 = $pdo->prepare("UPDATE empleados SET 
                            dias_vacaciones = ?, 
                            dias_vacaciones_antiguedad = ?,
                            dias_libre_disposicion = ?,
                            dias_libre_disp_antiguedad = ?
                            WHERE id = ?");
                        $stmt2->execute([
                            $conv->dias_vacaciones_base ?? 22,
                            $diasVacAnt,
                            $conv->dias_libre_disposicion_base ?? 6,
                            $diasLDAnt,
                            $emp->id
                        ]);
                        $actualizados++;
                    }
                    
                    $_SESSION['mensaje'] = "Convenio aplicado a {$actualizados} empleados";
                }
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Error al aplicar: ' . $e->getMessage();
            }
            header('Location: convenios.php?accion=editar&id=' . $convId . '#empleados');
            exit;
        }
    }
}

// ============================================================================
// OBTENER DATOS
// ============================================================================

// Lista de convenios
$convenios = $pdo->query("
    SELECT c.*, 
           (SELECT COUNT(*) FROM convenios_tipos_dias WHERE convenio_id = c.id) as tipos_configurados,
           (SELECT COUNT(*) FROM empleados WHERE convenio_id = c.id) as empleados_asignados
    FROM convenios c
    ORDER BY c.nombre
")->fetchAll();

// Contar reglas de antigüedad
try {
    foreach ($convenios as &$c) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM convenios_antiguedad WHERE convenio_id = ?");
        $stmt->execute([$c->id]);
        $c->reglas_antiguedad = $stmt->fetchColumn();
    }
    unset($c);
} catch (PDOException $e) {
    // Tabla no existe aún
}

// Datos del convenio actual
$convenio = null;
$diasConvenio = [];
$reglasAntiguedad = [];
$empleadosConvenio = [];

if ($convenioId && ($accion === 'editar' || $accion === 'ver')) {
    $stmt = $pdo->prepare("SELECT * FROM convenios WHERE id = ?");
    $stmt->execute([$convenioId]);
    $convenio = $stmt->fetch();
    
    if ($convenio) {
        // Días por tipo
        $stmt = $pdo->prepare("SELECT * FROM convenios_tipos_dias WHERE convenio_id = ?");
        $stmt->execute([$convenioId]);
        foreach ($stmt->fetchAll() as $d) {
            $diasConvenio[$d->tipo_ausencia_id] = $d;
        }
        
        // Reglas de antigüedad
        try {
            $stmt = $pdo->prepare("SELECT * FROM convenios_antiguedad WHERE convenio_id = ? ORDER BY tipo, anos_minimos");
            $stmt->execute([$convenioId]);
            $reglasAntiguedad = $stmt->fetchAll();
        } catch (PDOException $e) {
            $reglasAntiguedad = [];
        }
        
        // Empleados con este convenio
        $stmt = $pdo->prepare("SELECT id, nif, nombre, apellido1, fecha_antiguedad FROM empleados WHERE convenio_id = ? AND activo = 1 ORDER BY apellido1, nombre");
        $stmt->execute([$convenioId]);
        $empleadosConvenio = $stmt->fetchAll();
    }
}

// Tipos de ausencia (excluyendo Vacaciones y Asuntos Propios que van aparte)
$tiposAusencia = $pdo->query("
    SELECT * FROM tipos_ausencia 
    WHERE activo = 1 
    AND nombre NOT IN ('Vacaciones', 'Asuntos Propios')
    ORDER BY orden, nombre
")->fetchAll();

// Título
$pageTitle = match($accion) {
    'nuevo' => 'Nuevo Convenio',
    'editar' => 'Editar: ' . ($convenio->nombre ?? ''),
    default => 'Convenios Colectivos'
};

ob_start();
?>

<?php if ($mensaje): ?>
<div class="alert alert-success"><?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($accion === 'listar'): ?>
<!-- LISTADO -->
<div class="page-header">
    <div>
        <h1 class="page-title">Convenios Colectivos</h1>
        <p style="color: #64748b; margin: 0;">Gestiona días de vacaciones, permisos y antigüedad</p>
    </div>
    <a href="?accion=nuevo" class="btn btn-primary">+ Nuevo Convenio</a>
</div>

<div class="card">
    <?php if (empty($convenios)): ?>
    <div style="text-align: center; padding: 3rem; color: #64748b;">
        <h3>No hay convenios</h3>
        <p>Crea el primer convenio colectivo</p>
    </div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Vacaciones</th>
                <th>L.D.</th>
                <th>Reglas Antigüedad</th>
                <th>Empleados</th>
                <th>Estado</th>
                <th style="width: 120px;"></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($convenios as $c): ?>
            <tr>
                <td><strong><?= htmlspecialchars($c->codigo) ?></strong></td>
                <td><?= htmlspecialchars($c->nombre) ?></td>
                <td><?= $c->dias_vacaciones_base ?? 22 ?> días</td>
                <td><?= $c->dias_libre_disposicion_base ?? 6 ?> días</td>
                <td><?= $c->reglas_antiguedad ?? 0 ?></td>
                <td><?= $c->empleados_asignados ?></td>
                <td><?= $c->activo ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-danger">Inactivo</span>' ?></td>
                <td>
                    <a href="?accion=editar&id=<?= $c->id ?>" class="btn btn-outline btn-sm">Editar</a>
                    <?php if ($c->empleados_asignados == 0): ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar?')">
                        <?= csrf_campo() ?>
                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" name="convenio_id" value="<?= $c->id ?>">
                        <button class="btn btn-outline btn-sm" style="color:#dc2626;">×</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php elseif ($accion === 'nuevo' || $accion === 'editar'): ?>
<!-- FORMULARIO CONVENIO -->

<!-- Header simple -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h1 style="font-size: 1.5rem; font-weight: 600; color: #1e293b; margin: 0;">
        <?= $accion === 'nuevo' ? 'Nuevo Convenio' : htmlspecialchars($convenio->nombre ?? 'Editar Convenio') ?>
    </h1>
    <a href="convenios.php" class="btn btn-outline">← Volver</a>
</div>

<?php if ($convenio): ?>
<!-- Navegación por tabs -->
<div style="display: flex; border-bottom: 1px solid #e5e7eb; margin-bottom: 24px;">
    <button type="button" class="ctab active" onclick="showTab('datos', this)">Datos Básicos</button>
    <button type="button" class="ctab" onclick="showTab('antiguedad', this)">Reglas Antigüedad</button>
    <button type="button" class="ctab" onclick="showTab('otros-dias', this)">Otros Permisos</button>
    <button type="button" class="ctab" onclick="showTab('empleados', this)">Empleados (<?= count($empleadosConvenio) ?>)</button>
</div>
<style>
.ctab {
    padding: 12px 20px;
    border: none;
    background: none;
    color: #64748b;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    border-bottom: 2px solid transparent;
    margin-bottom: -1px;
}
.ctab:hover { color: #1e3a5f; }
.ctab.active { color: #1e3a5f; border-bottom-color: #1e3a5f; }
</style>
<?php endif; ?>

<!-- Tab: Datos Básicos -->
<div id="tab-datos" class="tab-content">
<div class="card">
    <div class="card-header"><span class="card-title">Información del Convenio</span></div>
    <div class="card-body">
        <form method="POST">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="guardar_convenio">
            <?php if ($convenio): ?><input type="hidden" name="convenio_id" value="<?= $convenio->id ?>"><?php endif; ?>
            
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Código <span class="required">*</span></label>
                    <input type="text" name="codigo" class="form-control" value="<?= htmlspecialchars($convenio->codigo ?? '') ?>" required style="text-transform: uppercase;" maxlength="20">
                </div>
                <div class="form-group">
                    <label class="form-label">Nombre <span class="required">*</span></label>
                    <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($convenio->nombre ?? '') ?>" required>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Descripción</label>
                <textarea name="descripcion" class="form-control" rows="2"><?= htmlspecialchars($convenio->descripcion ?? '') ?></textarea>
            </div>
            
            <hr style="margin: 25px 0; border: none; border-top: 1px solid #e5e7eb;">
            
            <h4 style="margin: 0 0 15px 0; color: #334155; font-size: 15px;">Días anuales según convenio</h4>
            
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Vacaciones</label>
                    <input type="number" name="dias_vacaciones_base" class="form-control" value="<?= $convenio->dias_vacaciones_base ?? 22 ?>" min="0" max="45">
                </div>
                <div class="form-group">
                    <label class="form-label">Libre Disposición / Asuntos Propios</label>
                    <input type="number" name="dias_libre_disposicion_base" class="form-control" value="<?= $convenio->dias_libre_disposicion_base ?? 6 ?>" min="0" max="15">
                </div>
            </div>
            
            <?php if ($convenio): ?>
            <div class="form-group" style="margin-top: 20px;">
                <label class="form-check">
                    <input type="checkbox" name="activo" <?= $convenio->activo ? 'checked' : '' ?>>
                    Convenio activo
                </label>
            </div>
            <?php endif; ?>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 <?= $convenio ? 'Guardar Cambios' : 'Crear Convenio' ?></button>
            </div>
        </form>
    </div>
</div>
</div>

<?php if ($convenio): ?>
<!-- Tab: Reglas de Antigüedad -->
<div id="tab-antiguedad" class="tab-content" style="display:none;">
<div class="card">
    <div class="card-header">
        <span class="card-title">Reglas de Antigüedad</span>
    </div>
    <div class="card-body">
        <p style="color: #64748b; margin-bottom: 20px;">
            Configura días adicionales según años de antigüedad. Los días se acumulan: si hay reglas a los 5 y 10 años, un empleado con 12 años recibe ambos beneficios.
        </p>
        
        <form method="POST" id="formAntiguedad">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="guardar_antiguedad">
            <input type="hidden" name="convenio_id" value="<?= $convenio->id ?>">
            
            <table class="table" id="tablaAntiguedad">
                <thead>
                    <tr>
                        <th style="width: 180px;">Tipo de Días</th>
                        <th style="width: 150px;">A partir de</th>
                        <th style="width: 130px;">Días Extra</th>
                        <th>Descripción</th>
                        <th style="width: 50px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $idx = 0;
                    if (!empty($reglasAntiguedad)):
                        foreach ($reglasAntiguedad as $regla): 
                    ?>
                    <tr>
                        <td>
                            <select name="antiguedad[<?= $idx ?>][tipo]" class="form-control">
                                <option value="vacaciones" <?= $regla->tipo === 'vacaciones' ? 'selected' : '' ?>>Vacaciones</option>
                                <option value="libre_disposicion" <?= $regla->tipo === 'libre_disposicion' ? 'selected' : '' ?>>Libre Disposición</option>
                            </select>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <input type="number" name="antiguedad[<?= $idx ?>][anos]" class="form-control" value="<?= $regla->anos_minimos ?>" min="1" max="50" style="width: 70px;">
                                <span style="color: #64748b;">años</span>
                            </div>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span style="color: #22c55e; font-weight: 600;">+</span>
                                <input type="number" name="antiguedad[<?= $idx ?>][dias]" class="form-control" value="<?= $regla->dias_adicionales ?>" min="1" max="30" style="width: 60px;">
                                <span style="color: #64748b;">días</span>
                            </div>
                        </td>
                        <td><input type="text" name="antiguedad[<?= $idx ?>][notas]" class="form-control" value="<?= htmlspecialchars($regla->notas ?? '') ?>" placeholder="Ej: Primer trienio"></td>
                        <td><button type="button" class="btn btn-outline btn-sm" onclick="this.closest('tr').remove()" style="color: #ef4444;">✕</button></td>
                    </tr>
                    <?php 
                        $idx++;
                        endforeach; 
                    endif;
                    ?>
                </tbody>
            </table>
            
            <div style="margin: 15px 0;">
                <button type="button" class="btn btn-outline" onclick="agregarReglaAntiguedad()">+ Añadir Regla</button>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 Guardar Reglas</button>
            </div>
        </form>
    </div>
</div>

<div class="card" style="margin-top: 20px;">
    <div class="card-header">
        <span class="card-title">Aplicar a Empleados</span>
    </div>
    <div class="card-body">
        <p style="margin-bottom: 15px; color: #64748b;">
            Actualiza los días de todos los empleados con este convenio según las reglas configuradas y su fecha de antigüedad.
        </p>
        
        <form method="POST" onsubmit="return confirm('¿Actualizar días de <?= count($empleadosConvenio) ?> empleados? Esto sobrescribirá sus días actuales.')">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="aplicar_convenio">
            <input type="hidden" name="convenio_id" value="<?= $convenio->id ?>">
            <button type="submit" class="btn btn-warning">Aplicar a <?= count($empleadosConvenio) ?> empleados</button>
        </form>
    </div>
</div>
</div>

<!-- Tab: Otros Días (Matrimonio, etc.) -->
<div id="tab-otros-dias" class="tab-content" style="display:none;">
<div class="card">
    <div class="card-header"><span class="card-title">Otros Permisos Retribuidos</span></div>
    <div class="card-body">
        <form method="POST">
            <?= csrf_campo() ?>
            <input type="hidden" name="accion" value="guardar_dias">
            <input type="hidden" name="convenio_id" value="<?= $convenio->id ?>">
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Tipo de Permiso</th>
                        <th style="width: 100px;">Días</th>
                        <th>Notas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tiposAusencia as $tipo): 
                        $dc = $diasConvenio[$tipo->id] ?? null;
                    ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($tipo->nombre) ?></strong>
                            <?php if ($tipo->descripcion): ?>
                            <br><small style="color: #64748b;"><?= htmlspecialchars($tipo->descripcion) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <input type="number" name="dias[<?= $tipo->id ?>][dias]" class="form-control" 
                                   value="<?= $dc->dias ?? 0 ?>" min="0" max="365">
                        </td>
                        <td>
                            <input type="text" name="dias[<?= $tipo->id ?>][notas]" class="form-control" 
                                   value="<?= htmlspecialchars($dc->notas ?? '') ?>" placeholder="Notas...">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 Guardar</button>
            </div>
        </form>
    </div>
</div>
</div>

<!-- Tab: Empleados -->
<div id="tab-empleados" class="tab-content" style="display:none;">
<div class="card">
    <div class="card-header">
        <span class="card-title">Empleados con este convenio</span>
    </div>
    <div class="card-body">
        <?php if (empty($empleadosConvenio)): ?>
        <p style="color: #64748b; text-align: center; padding: 2rem;">No hay empleados asignados a este convenio</p>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Empleado</th>
                    <th>NIF</th>
                    <th>Fecha Antigüedad</th>
                    <th>Años</th>
                    <th>+Vacaciones</th>
                    <th>+L.D.</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($empleadosConvenio as $emp): 
                    $anosAnt = 0;
                    if ($emp->fecha_antiguedad) {
                        $fechaAnt = new DateTime($emp->fecha_antiguedad);
                        $hoy = new DateTime();
                        $anosAnt = $hoy->diff($fechaAnt)->y;
                    }
                    
                    // Calcular días extra según reglas
                    $diasVacExtra = 0;
                    $diasLDExtra = 0;
                    foreach ($reglasAntiguedad as $regla) {
                        if ($anosAnt >= $regla->anos_minimos) {
                            if ($regla->tipo === 'vacaciones') {
                                $diasVacExtra += $regla->dias_adicionales;
                            } else {
                                $diasLDExtra += $regla->dias_adicionales;
                            }
                        }
                    }
                ?>
                <tr>
                    <td><a href="empleados.php?accion=ver&id=<?= $emp->id ?>"><?= htmlspecialchars($emp->apellido1 . ', ' . $emp->nombre) ?></a></td>
                    <td><?= htmlspecialchars($emp->nif) ?></td>
                    <td><?= $emp->fecha_antiguedad ? date('d/m/Y', strtotime($emp->fecha_antiguedad)) : '<span style="color:#dc2626;">—</span>' ?></td>
                    <td><strong><?= $anosAnt ?></strong></td>
                    <td><?= $diasVacExtra > 0 ? '<span style="color:#16a34a;">+'.$diasVacExtra.'</span>' : '—' ?></td>
                    <td><?= $diasLDExtra > 0 ? '<span style="color:#16a34a;">+'.$diasLDExtra.'</span>' : '—' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
</div>
<?php endif; ?>

<script>
let reglaIdx = <?= $idx ?? 0 ?>;

function agregarReglaAntiguedad() {
    const tbody = document.querySelector('#tablaAntiguedad tbody');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>
            <select name="antiguedad[${reglaIdx}][tipo]" class="form-control">
                <option value="vacaciones">Vacaciones</option>
                <option value="libre_disposicion">Libre Disposición</option>
            </select>
        </td>
        <td>
            <div style="display: flex; align-items: center; gap: 8px;">
                <input type="number" name="antiguedad[${reglaIdx}][anos]" class="form-control" min="1" max="50" style="width: 70px;" placeholder="5">
                <span style="color: #64748b;">años</span>
            </div>
        </td>
        <td>
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="color: #22c55e; font-weight: 600;">+</span>
                <input type="number" name="antiguedad[${reglaIdx}][dias]" class="form-control" min="1" max="30" style="width: 60px;" placeholder="1">
                <span style="color: #64748b;">días</span>
            </div>
        </td>
        <td><input type="text" name="antiguedad[${reglaIdx}][notas]" class="form-control" placeholder="Ej: Trienio"></td>
        <td><button type="button" class="btn btn-outline btn-sm" onclick="this.closest('tr').remove()" style="color: #ef4444;">✕</button></td>
    `;
    tbody.appendChild(tr);
    reglaIdx++;
}

function showTab(tabId, btn) {
    // Ocultar todos los tabs
    document.querySelectorAll('.tab-content').forEach(function(el) { el.style.display = 'none'; });
    // Quitar active de botones
    document.querySelectorAll('.ctab').forEach(function(el) { el.classList.remove('active'); });
    // Mostrar el seleccionado
    var tab = document.getElementById('tab-' + tabId);
    if (tab) tab.style.display = 'block';
    // Activar botón
    if (btn) btn.classList.add('active');
}

// Mostrar tab según hash de URL al cargar
document.addEventListener('DOMContentLoaded', function() {
    var hash = window.location.hash.replace('#', '');
    if (hash) {
        var tabs = document.querySelectorAll('.ctab');
        tabs.forEach(function(tab) {
            if (tab.textContent.toLowerCase().indexOf(hash) !== -1) {
                tab.click();
            }
        });
    }
});
</script>

<style>
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }
</style>

<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/includes/layout_header.php';
include __DIR__ . '/includes/layout_sidebar.php';
echo $content;
include __DIR__ . '/includes/layout_footer.php';
?>
