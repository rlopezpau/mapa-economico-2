<?php
/**
 * LM FICHAJES - Mis Documentos (Portal del Empleado)
 * 
 * Lista de documentos del empleado: nóminas, circulares, contratos, etc.
 * 
 * @package     LMFichajes
 * @version     1.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();
requerir_login();

$usuario = obtener_usuario_actual($pdo);

// Obtener configuración de empresa
$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
try {
    $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
    $config = $stmt->fetch();
    if ($config && !empty($config->valor)) {
        $nombreEmpresa = $config->valor;
    }
} catch (Exception $e) {}

// Obtener documentos del empleado
$documentos = [];
try {
    // Obtener centro_id del empleado (si tiene asignado directamente)
    $centroEmpleado = $usuario->centro_id ?? null;
    
    $sql = "SELECT d.*, 
                   (SELECT COUNT(*) FROM documentos_confirmaciones dc 
                    WHERE dc.documento_id = d.id AND dc.empleado_id = ?) as confirmado
            FROM documentos_empleado d
            WHERE d.visible_empleado = 1
              AND (
                  d.empleado_id = ? 
                  OR d.empleado_id IS NULL
                  OR (d.centro_id IS NOT NULL AND d.centro_id = ?)
              )
            ORDER BY d.created_at DESC
            LIMIT 100";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario->id, $usuario->id, $centroEmpleado]);
    $documentos = $stmt->fetchAll();
} catch (PDOException $e) {}

// Procesar confirmación de lectura
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_doc'])) {
    if (verificar_csrf($_POST['csrf_token'] ?? '')) {
        $docId = (int)$_POST['confirmar_doc'];
        try {
            $stmt = $pdo->prepare("INSERT IGNORE INTO documentos_confirmaciones 
                                   (documento_id, empleado_id, confirmado_fecha, ip_address) 
                                   VALUES (?, ?, NOW(), ?)");
            $stmt->execute([$docId, $usuario->id, obtener_ip_cliente()]);
        } catch (PDOException $e) {}
    }
    header('Location: mis-documentos.php');
    exit;
}

// Filtros
$filtroTipo = $_GET['tipo'] ?? '';
$filtroAnio = $_GET['anio'] ?? '';

if ($filtroTipo || $filtroAnio) {
    $documentos = array_filter($documentos, function($doc) use ($filtroTipo, $filtroAnio) {
        if ($filtroTipo && $doc->tipo_documento !== $filtroTipo) return false;
        if ($filtroAnio && $doc->anio != $filtroAnio) return false;
        return true;
    });
}

$tiposDocumento = [
    'nomina' => '💰 Nómina',
    'contrato' => '📝 Contrato',
    'certificado' => '🏅 Certificado',
    'circular' => '📢 Circular',
    'formacion' => '🎓 Formación',
    'otro' => '📄 Documento'
];

// Años disponibles
$aniosDisponibles = array_unique(array_filter(array_map(function($d) { return $d->anio; }, $documentos)));
rsort($aniosDisponibles);

$csrfToken = generar_csrf_token();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Documentos - <?= htmlspecialchars($nombreEmpresa) ?></title>
    <style>
        :root {
            --primary: #1a365d;
            --primary-light: #2d5a87;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-900: #111827;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            min-height: 100vh;
            color: var(--gray-900);
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            padding: 15px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
        }
        
        .header-content {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.2s;
        }
        
        .btn-back:hover { background: rgba(255,255,255,0.3); }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Filtros */
        .filtros {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filtros select {
            padding: 10px 15px;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            font-size: 14px;
            background: white;
            cursor: pointer;
        }
        
        .filtros select:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        .card-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--gray-200);
            background: var(--gray-100);
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--primary);
        }
        
        /* Lista de documentos */
        .doc-list {
            padding: 10px;
        }
        
        .doc-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 8px;
            background: var(--gray-100);
            transition: background 0.2s;
        }
        
        .doc-item:hover { background: var(--gray-200); }
        
        .doc-item.no-leido {
            background: #fef3c7;
            border-left: 4px solid var(--warning);
        }
        
        .doc-icon {
            font-size: 28px;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .doc-info {
            flex: 1;
            min-width: 0;
        }
        
        .doc-nombre {
            font-weight: 600;
            color: var(--gray-900);
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .doc-meta {
            font-size: 13px;
            color: var(--gray-500);
        }
        
        .badge-nuevo {
            background: var(--danger);
            color: white;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .badge-tipo {
            background: var(--primary);
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 6px;
        }
        
        .doc-actions {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }
        
        .btn {
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover { background: var(--primary-light); }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-success:hover { opacity: 0.9; }
        
        /* Sin documentos */
        .sin-docs {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        
        .sin-docs .icon {
            font-size: 60px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        /* Responsive */
        @media (max-width: 600px) {
            .doc-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .doc-actions {
                width: 100%;
            }
            
            .doc-actions .btn {
                flex: 1;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>📄 Mis Documentos</h1>
            <a href="portal.php" class="btn-back">← Volver</a>
        </div>
    </header>
    
    <div class="container">
        <!-- Filtros -->
        <form class="filtros" method="GET">
            <select name="tipo" onchange="this.form.submit()">
                <option value="">📁 Todos los tipos</option>
                <?php foreach ($tiposDocumento as $k => $v): ?>
                    <option value="<?= $k ?>" <?= $filtroTipo === $k ? 'selected' : '' ?>><?= $v ?></option>
                <?php endforeach; ?>
            </select>
            
            <?php if (!empty($aniosDisponibles)): ?>
            <select name="anio" onchange="this.form.submit()">
                <option value="">📅 Todos los años</option>
                <?php foreach ($aniosDisponibles as $anio): ?>
                    <option value="<?= $anio ?>" <?= $filtroAnio == $anio ? 'selected' : '' ?>><?= $anio ?></option>
                <?php endforeach; ?>
            </select>
            <?php endif; ?>
        </form>
        
        <!-- Lista de documentos -->
        <div class="card">
            <div class="card-header">
                <span class="card-title"><?= count($documentos) ?> documento(s)</span>
            </div>
            
            <?php if (empty($documentos)): ?>
                <div class="sin-docs">
                    <div class="icon">📭</div>
                    <p>No tienes documentos disponibles</p>
                </div>
            <?php else: ?>
                <div class="doc-list">
                    <?php foreach ($documentos as $doc): ?>
                        <?php $esNuevo = $doc->requiere_confirmacion && !$doc->confirmado; ?>
                        <div class="doc-item <?= $esNuevo ? 'no-leido' : '' ?>">
                            <div class="doc-icon">
                                <?php
                                $iconos = [
                                    'nomina' => '💰',
                                    'contrato' => '📝',
                                    'certificado' => '🏅',
                                    'circular' => '📢',
                                    'formacion' => '🎓',
                                    'otro' => '📄'
                                ];
                                echo $iconos[$doc->tipo_documento] ?? '📄';
                                ?>
                            </div>
                            
                            <div class="doc-info">
                                <div class="doc-nombre">
                                    <?= htmlspecialchars($doc->nombre) ?>
                                    <?php if ($esNuevo): ?>
                                        <span class="badge-nuevo">Nuevo</span>
                                    <?php endif; ?>
                                </div>
                                <div class="doc-meta">
                                    <span class="badge-tipo"><?= $tiposDocumento[$doc->tipo_documento] ?? 'Documento' ?></span>
                                    · <?= date('d/m/Y', strtotime($doc->created_at)) ?>
                                    <?php if ($doc->mes && $doc->anio): ?>
                                        · Periodo: <?= str_pad($doc->mes, 2, '0', STR_PAD_LEFT) ?>/<?= $doc->anio ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="doc-actions">
                                <a href="admin/descargar_documento.php?id=<?= $doc->id ?>" class="btn btn-primary">
                                    ⬇️ Descargar
                                </a>
                                <?php if ($esNuevo): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                        <button type="submit" name="confirmar_doc" value="<?= $doc->id ?>" class="btn btn-success">
                                            ✓ Leído
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
