<?php
/**
 * LM FICHAJES - Archivo de Configuración
 *
 * @package     LMFichajes
 * @version     2.1.0
 */

// Evitar acceso directo
if (basename($_SERVER['SCRIPT_FILENAME']) === 'config.php') {
    die('Acceso no permitido');
}

// ============================================================================
// CONFIGURACIÓN DE LA APLICACIÓN
// ============================================================================
define('APP_NAME', 'LM Fichajes');
define('APP_VERSION', '2.1.0');
define('APP_URL', '');  // URL base, vacío si está en raíz

// ============================================================================
// RUTAS DEL SISTEMA
// ============================================================================
define('ROOT_PATH', __DIR__);
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('ADMIN_PATH', ROOT_PATH . '/admin');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');

// ============================================================================
// CONFIGURACIÓN DE BASE DE DATOS
// Usar variables de entorno en producción o archivo .env
// ============================================================================
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'lmfichajes');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

// ============================================================================
// CONFIGURACIÓN DE SEGURIDAD
// ============================================================================
define('SECRET_KEY', bin2hex(random_bytes(32)));
define('MAX_LOGIN_ATTEMPTS', 5);        // Intentos antes de bloquear
define('LOCKOUT_TIME', 1800);           // 30 minutos de bloqueo
define('SESSION_TIMEOUT', 1800);        // 30 minutos de inactividad
define('PASSWORD_EXPIRY_DAYS', 90);     // Días para expirar contraseña
define('CSRF_TOKEN_EXPIRY', 3600);      // 1 hora para token CSRF

// ============================================================================
// CONFIGURACIÓN DE FICHAJES
// ============================================================================
define('FICHAJE_RADIO_DEFECTO', 100);   // Radio en metros
define('FICHAJE_TOLERANCIA_MINUTOS', 5); // Tolerancia entrada/salida

// ============================================================================
// CONEXIÓN A BASE DE DATOS
// ============================================================================
try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $opciones = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);

} catch (PDOException $e) {
    // En desarrollo mostrar error, en producción log y mensaje genérico
    if (defined('DEV_MODE') && DEV_MODE) {
        die('Error de conexión a BD: ' . $e->getMessage());
    } else {
        error_log('Error de conexión a BD: ' . $e->getMessage());
        die('Error de conexión a la base de datos. Contacte al administrador.');
    }
}

// ============================================================================
// INICIAR SESIÓN
// ============================================================================
if (session_status() === PHP_SESSION_NONE) {
    // Configuración segura de sesión
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Strict');

    // En producción con HTTPS:
    // ini_set('session.cookie_secure', 1);

    session_start();
}

// ============================================================================
// ZONA HORARIA
// ============================================================================
date_default_timezone_set('Europe/Madrid');

// ============================================================================
// MODO DESARROLLO (usar variable de entorno o false por defecto en producción)
// ============================================================================
define('DEV_MODE', filter_var(getenv('DEV_MODE'), FILTER_VALIDATE_BOOLEAN));

if (DEV_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', LOGS_PATH . '/php_errors.log');
}
