/**
 * LM FICHAJES - JavaScript del Portal del Empleado
 * @version 1.0.0
 */

// ============================================================================
// RELOJ
// ============================================================================
function actualizarReloj() {
    const ahora = new Date();
    const horas = String(ahora.getHours()).padStart(2, '0');
    const minutos = String(ahora.getMinutes()).padStart(2, '0');
    const segundos = String(ahora.getSeconds()).padStart(2, '0');
    const reloj = document.getElementById('reloj');
    if (reloj) {
        reloj.textContent = `${horas}:${minutos}:${segundos}`;
    }
}
setInterval(actualizarReloj, 1000);

// ============================================================================
// GEOLOCALIZACIÓN
// ============================================================================
let coordenadasActuales = '';

function obtenerUbicacion() {
    const statusDiv = document.getElementById('ubicacionStatus');
    const iconSpan = document.getElementById('ubicacionIcon');
    const textoSpan = document.getElementById('ubicacionTexto');
    
    if (!statusDiv || !iconSpan || !textoSpan) return;
    
    if (!navigator.geolocation) {
        statusDiv.className = 'ubicacion-status warning';
        iconSpan.textContent = '⚠️';
        textoSpan.textContent = 'Geolocalización no disponible';
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            coordenadasActuales = `${position.coords.latitude},${position.coords.longitude}`;
            const inputCoords = document.getElementById('coordenadas');
            if (inputCoords) {
                inputCoords.value = coordenadasActuales;
            }
            
            statusDiv.className = 'ubicacion-status ok';
            iconSpan.textContent = '✅';
            textoSpan.textContent = `Ubicación obtenida (±${Math.round(position.coords.accuracy)}m)`;
        },
        function(error) {
            statusDiv.className = 'ubicacion-status warning';
            iconSpan.textContent = '⚠️';
            
            const errores = {
                1: 'Permiso denegado',
                2: 'Ubicación no disponible',
                3: 'Tiempo agotado'
            };
            textoSpan.textContent = errores[error.code] || 'Error de ubicación';
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        }
    );
}

// Obtener ubicación al cargar
document.addEventListener('DOMContentLoaded', function() {
    obtenerUbicacion();
    // Actualizar cada 30 segundos
    setInterval(obtenerUbicacion, 30000);
});

// ============================================================================
// FICHAJE
// ============================================================================
function fichar(tipo) {
    const accionInput = document.getElementById('accionFichaje');
    const form = document.getElementById('formFichaje');
    
    if (accionInput && form) {
        accionInput.value = tipo;
        form.submit();
    }
}

// ============================================================================
// MODAL DE INCIDENCIA
// ============================================================================
function cancelarFichaje() {
    const modal = document.getElementById('modalObservacion');
    if (modal) {
        modal.remove();
    }
}

// Focus en textarea del modal si está abierto
document.addEventListener('DOMContentLoaded', function() {
    const modalObs = document.getElementById('modalObservacion');
    if (modalObs) {
        const textarea = document.getElementById('observacion');
        if (textarea) {
            textarea.focus();
        }
    }
});
