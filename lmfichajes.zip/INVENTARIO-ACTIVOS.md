# 📦 INVENTARIO DE ACTIVOS DE INFORMACIÓN

## LM Fichajes - Sistema de Control Horario

**Versión:** 1.0.0  
**Fecha:** Enero 2026  
**Clasificación:** INTERNO  
**Responsable:** Departamento de Sistemas  

---

## 1. ACTIVOS DE SOFTWARE

### 1.1 Aplicación Principal

| ID | Activo | Versión | Propietario | Clasificación | Criticidad |
|----|--------|---------|-------------|---------------|------------|
| SW-001 | LM Fichajes Core | 2.1.0 | Desarrollo | CONFIDENCIAL | ALTA |
| SW-002 | Panel Administración | 2.1.0 | Desarrollo | CONFIDENCIAL | ALTA |
| SW-003 | Portal Empleado | 2.1.0 | Desarrollo | INTERNO | ALTA |
| SW-004 | API Inspección | 2.1.0 | Desarrollo | CONFIDENCIAL | MEDIA |

### 1.2 Componentes del Sistema

| ID | Componente | Ubicación | Líneas | Función |
|----|------------|-----------|--------|---------|
| SW-010 | config.php | /raíz | 130 | Configuración central |
| SW-011 | auth.php | /includes | 300 | Autenticación |
| SW-012 | seguridad.php | /includes | 520 | Funciones seguridad |
| SW-013 | auditoria.php | /includes | 770 | Sistema de auditoría |
| SW-014 | fichajes.php | /includes | 860 | Lógica de fichajes |
| SW-015 | ausencias.php | /includes | 850 | Gestión ausencias |

### 1.3 Dependencias Externas

| ID | Dependencia | Versión | Licencia | Uso |
|----|-------------|---------|----------|-----|
| DEP-001 | PHP | 8.1+ | PHP License | Runtime |
| DEP-002 | MySQL/MariaDB | 8.0+ | GPL | Base de datos |
| DEP-003 | Apache/Nginx | 2.4+ | Apache/BSD | Servidor web |

---

## 2. ACTIVOS DE DATOS

### 2.1 Base de Datos Principal

| ID | Tabla | Registros Est. | Clasificación | Retención |
|----|-------|----------------|---------------|-----------|
| DB-001 | empleados | 500 | CONFIDENCIAL | Activo + 4 años |
| DB-002 | fichajes | 500.000 | CONFIDENCIAL | 4 años |
| DB-003 | ausencias | 10.000 | CONFIDENCIAL | 4 años |
| DB-004 | auditoria | 1.000.000 | INTERNO | 4 años |
| DB-005 | configuracion | 100 | INTERNO | Permanente |
| DB-006 | centros | 50 | PÚBLICO | Permanente |
| DB-007 | horarios | 100 | INTERNO | Permanente |

### 2.2 Archivos del Sistema

| ID | Directorio | Contenido | Clasificación | Backup |
|----|------------|-----------|---------------|--------|
| FS-001 | /uploads/justificantes | Justificantes ausencias | CONFIDENCIAL | Diario |
| FS-002 | /uploads/documentos | Documentos empleados | CONFIDENCIAL | Diario |
| FS-003 | /uploads/logos | Logos empresa | PÚBLICO | Semanal |
| FS-004 | /logs | Logs aplicación | INTERNO | Diario |

---

## 3. ACTIVOS DE INFRAESTRUCTURA

### 3.1 Servidores

| ID | Servidor | Función | SO | Ubicación | Propietario |
|----|----------|---------|----|-----------| ------------|
| SRV-001 | Producción | App + BD | Ubuntu 24 | Raiola Networks | IT |
| SRV-002 | Backup | Respaldos | Ubuntu 24 | Raiola Networks | IT |

### 3.2 Red y Comunicaciones

| ID | Activo | Función | Configuración |
|----|--------|---------|---------------|
| NET-001 | Dominio | fichaje-ayto.denunciarapida.com | SSL/TLS 1.3 |
| NET-002 | Certificado SSL | Let's Encrypt | Renovación automática |
| NET-003 | CDN | Cloudflare (opcional) | Cache + WAF |

---

## 4. CLASIFICACIÓN DE LA INFORMACIÓN

### 4.1 Niveles de Clasificación

| Nivel | Descripción | Ejemplos | Controles |
|-------|-------------|----------|-----------|
| PÚBLICO | Sin restricciones | Nombre empresa, horarios generales | Ninguno especial |
| INTERNO | Solo empleados | Organigramas, procedimientos | Autenticación |
| CONFIDENCIAL | Acceso restringido | Datos personales, fichajes | RBAC + Auditoría |
| SECRETO | Máxima protección | Contraseñas, claves API | Cifrado + MFA |

### 4.2 Matriz de Datos por Clasificación

| Dato | Clasificación | Acceso | Cifrado |
|------|---------------|--------|---------|
| NIF/DNI | CONFIDENCIAL | Admin, Usuario propio | En tránsito |
| Email | CONFIDENCIAL | Admin, Usuario propio | En tránsito |
| Contraseña | SECRETO | Sistema | bcrypt |
| Fichajes | CONFIDENCIAL | Admin, Usuario propio | En tránsito |
| Geolocalización | CONFIDENCIAL | Admin | En tránsito |
| Logs auditoría | INTERNO | Admin | No |

---

## 5. PROPIETARIOS Y CUSTODIOS

### 5.1 Roles

| Rol | Responsabilidad | Contacto |
|-----|-----------------|----------|
| Propietario de Datos | Define clasificación y acceso | Dirección RRHH |
| Custodio de Datos | Implementa controles técnicos | Departamento IT |
| Usuario de Datos | Usa datos según autorización | Empleados |

### 5.2 Matriz RACI

| Activo | Propietario | Custodio | Responsable Backup |
|--------|-------------|----------|-------------------|
| Base de datos | RRHH | IT | IT |
| Aplicación | IT | IT | IT |
| Documentos | RRHH | IT | IT |
| Logs | IT | IT | IT |

---

## 6. GESTIÓN DEL CICLO DE VIDA

### 6.1 Creación
- Los activos se registran en este inventario al crearse
- Se asigna propietario y clasificación
- Se definen controles de acceso

### 6.2 Mantenimiento
- Revisión trimestral del inventario
- Actualización ante cambios significativos
- Verificación de controles

### 6.3 Eliminación
- Borrado seguro de datos (sobrescritura)
- Registro de eliminación en auditoría
- Actualización del inventario

---

## 7. CONTROL DE CAMBIOS

| Versión | Fecha | Cambios | Autor |
|---------|-------|---------|-------|
| 1.0.0 | Enero 2026 | Versión inicial | IT |

---

*Documento clasificado como INTERNO*  
*Revisión: Trimestral*
