<?php
/**
 * LM FICHAJES - Página Principal
 *
 * Redirige al login o a la página de fichaje según el estado de autenticación.
 *
 * @package     LMFichajes
 * @version     2.2.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';

// Si hay sesión activa, ir a fichar
if (isset($_SESSION['usuario_id'])) {
    header('Location: fichar.php');
    exit;
}

// Si no hay sesión, ir a login
header('Location: login.php');
exit;
