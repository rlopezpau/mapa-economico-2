# 📖 MANUAL DE USUARIO

## LM Fichajes - Sistema de Control Horario

**Versión:** 2.1.0  
**Fecha:** Enero 2026  

---

## ÍNDICE

1. [Introducción](#1-introducción)
2. [Acceso al Sistema](#2-acceso-al-sistema)
3. [Portal del Empleado](#3-portal-del-empleado)
4. [Fichaje](#4-fichaje)
5. [Mis Gestiones](#5-mis-gestiones)
6. [Solicitud de Ausencias](#6-solicitud-de-ausencias)
7. [Mi Perfil](#7-mi-perfil)
8. [Preguntas Frecuentes](#8-preguntas-frecuentes)

---

## 1. INTRODUCCIÓN

LM Fichajes es el sistema de control horario que permite registrar tu jornada laboral de forma sencilla, cumpliendo con el Real Decreto 8/2019.

### ¿Qué puedo hacer?
- ✅ Fichar entrada y salida
- ✅ Consultar mi histórico de fichajes
- ✅ Solicitar ausencias y vacaciones
- ✅ Ver mis documentos
- ✅ Actualizar mis datos de contacto

---

## 2. ACCESO AL SISTEMA

### 2.1 Iniciar Sesión

1. Abre el navegador y accede a la URL proporcionada
2. Introduce tu **NIF/NIE** (sin espacios ni guiones)
3. Introduce tu **contraseña**
4. Pulsa **"Acceder"**

### 2.2 Primera Vez / Contraseña Temporal

Si es tu primer acceso o te han reseteado la contraseña:
1. El sistema te pedirá cambiar la contraseña
2. Introduce la contraseña temporal
3. Crea una nueva contraseña segura (mínimo 8 caracteres)
4. Confirma la nueva contraseña

### 2.3 ¿Olvidaste tu Contraseña?

1. En la pantalla de login, pulsa **"¿Olvidaste tu contraseña?"**
2. Introduce tu NIF/NIE
3. Recibirás un email con una contraseña temporal
4. Revisa también la carpeta de SPAM

### 2.4 Bloqueo por Intentos Fallidos

Si introduces la contraseña incorrecta 5 veces:
- Tu cuenta quedará bloqueada 15 minutos
- Espera y vuelve a intentarlo
- Si persiste, contacta con tu administrador

---

## 3. PORTAL DEL EMPLEADO

### 3.1 Pantalla Principal

Al acceder, verás:

```
┌─────────────────────────────────────┐
│  Buenos días, [Tu nombre]           │
│  Hoy es Lunes, 12 de Enero          │
│                                     │
│  ┌─────────┐    ┌─────────┐        │
│  │ ENTRADA │    │ SALIDA  │        │
│  │  09:00  │    │  --:--  │        │
│  └─────────┘    └─────────┘        │
│                                     │
│  [ FICHAR ENTRADA ]                 │
│                                     │
└─────────────────────────────────────┘
```

### 3.2 Navegación

En la parte inferior encontrarás:

| Icono | Sección | Función |
|-------|---------|---------|
| 🏠 | Inicio | Volver al portal principal |
| ⏱️ | Fichar | Registrar entrada/salida |
| 📋 | Gestiones | Ver fichajes y solicitudes |
| 👤 | Perfil | Tus datos personales |

---

## 4. FICHAJE

### 4.1 Fichar Entrada

1. Accede a la sección **Fichar** o pulsa el botón en el portal
2. Si tienes varios centros, selecciona dónde estás trabajando
3. Pulsa **"Fichar Entrada"**
4. Verás la confirmación con la hora registrada

### 4.2 Fichar Salida

1. Accede a la sección **Fichar**
2. Pulsa **"Fichar Salida"**
3. Verás el resumen de horas trabajadas

### 4.3 Pausas (si están habilitadas)

1. Para iniciar una pausa, pulsa **"Inicio Pausa"**
2. Al volver, pulsa **"Fin Pausa"**
3. Las pausas se descuentan del tiempo trabajado

### 4.4 Problemas Comunes

**"No puedes fichar entrada, ya tienes una entrada registrada"**
- Ya has fichado entrada hoy. Debes fichar salida primero.

**"Fichaje fuera de horario"**
- Estás fichando fuera de tu horario habitual. El fichaje se registra con observación.

**"Centro de trabajo no válido"**
- Selecciona un centro donde estés autorizado a trabajar.

---

## 5. MIS GESTIONES

### 5.1 Ver Fichajes

En la pestaña **"Fichajes"** puedes ver:
- Histórico de todos tus fichajes
- Filtrar por mes/año
- Ver estado de validación

### 5.2 Estados de Fichaje

| Estado | Significado |
|--------|-------------|
| ✅ Validado | Fichaje aprobado |
| ⏳ Pendiente | Esperando validación |
| ❌ Rechazado | Fichaje rechazado (ver motivo) |
| ⚠️ Incidencia | Requiere revisión |

### 5.3 Solicitar Corrección

Si detectas un error en un fichaje:
1. Pulsa sobre el fichaje
2. Selecciona **"Solicitar corrección"**
3. Describe el problema
4. Tu supervisor lo revisará

---

## 6. SOLICITUD DE AUSENCIAS

### 6.1 Tipos de Ausencia

| Tipo | Descripción |
|------|-------------|
| Vacaciones | Días de vacaciones anuales |
| Asuntos Propios | Días de libre disposición |
| Baja Médica | Incapacidad temporal |
| Permiso | Permisos retribuidos |
| Otros | Otras ausencias justificadas |

### 6.2 Solicitar Ausencia

1. Accede a **Gestiones** > **Ausencias**
2. Pulsa **"Nueva Solicitud"**
3. Selecciona el tipo de ausencia
4. Indica las fechas (desde - hasta)
5. Añade observaciones si es necesario
6. Adjunta justificante si corresponde
7. Pulsa **"Enviar Solicitud"**

### 6.3 Estados de Solicitud

| Estado | Significado |
|--------|-------------|
| 📝 Pendiente | Esperando aprobación |
| ✅ Aprobada | Ausencia confirmada |
| ❌ Rechazada | Ausencia denegada |
| 🔄 En revisión | Requiere información adicional |

### 6.4 Ver Saldo de Días

En la pantalla de ausencias puedes ver:
- Días de vacaciones disponibles
- Días de asuntos propios
- Días consumidos este año

---

## 7. MI PERFIL

### 7.1 Datos Personales

Puedes consultar tus datos:
- NIF/NIE
- Nombre completo
- Email
- Teléfono
- Centro de trabajo
- Horario asignado

### 7.2 Cambiar Contraseña

1. Accede a **Perfil**
2. Pulsa **"Cambiar contraseña"**
3. Introduce la contraseña actual
4. Introduce la nueva contraseña (mínimo 8 caracteres)
5. Confirma la nueva contraseña
6. Pulsa **"Guardar"**

### 7.3 Actualizar Datos de Contacto

1. Accede a **Perfil**
2. Modifica email o teléfono
3. Pulsa **"Guardar cambios"**

> ⚠️ El NIF y nombre solo puede modificarlos un administrador.

---

## 8. PREGUNTAS FRECUENTES

### ¿Qué hago si olvidé fichar?
Contacta con tu supervisor para que registre el fichaje manualmente o solicita una corrección desde "Mis Gestiones".

### ¿Puedo fichar desde el móvil?
Sí, el sistema es responsive y funciona en móviles y tablets.

### ¿Cómo sé cuántas horas he trabajado este mes?
En "Mis Gestiones" > "Fichajes", verás un resumen mensual con el total de horas.

### ¿Qué pasa si mi contraseña caduca?
El sistema te avisará y te pedirá crear una nueva contraseña al iniciar sesión.

### ¿Quién puede ver mis fichajes?
- Tú mismo
- Tu supervisor directo
- El departamento de RRHH
- Inspección de Trabajo (con código de acceso temporal)

### ¿Cómo solicito mis datos personales?
Accede a Perfil > "Mis Datos" > "Exportar datos" para descargar un archivo con toda tu información.

---

## SOPORTE

Si tienes problemas técnicos:

1. **Email:** soporte@tuempresa.es
2. **Teléfono:** Ext. 1234
3. **Horario:** Lunes a Viernes, 9:00 - 14:00

---

*Manual de Usuario v2.1.0 - Enero 2026*
