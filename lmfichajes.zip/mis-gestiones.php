<?php
/**
 * LM FICHAJES - Mis Gestiones
 * 
 * Portal completo del empleado con:
 * - Mi historial de fichajes
 * - Mis ausencias (solicitar/ver)
 * - Mis documentos
 * - Mi perfil y datos
 * - Resumen de horas
 * 
 * @package     LMFichajes
 * @version     3.0.0
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/seguridad.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/fichajes.php';
require_once INCLUDES_PATH . '/ausencias.php';
require_once INCLUDES_PATH . '/documentos.php';

// Notificaciones (si existe)
if (file_exists(INCLUDES_PATH . '/notificaciones.php')) {
    require_once INCLUDES_PATH . '/notificaciones.php';
}

establecer_headers_seguridad();
requerir_login();

// Configuración empresa
$nombreEmpresa = defined('APP_NAME') ? APP_NAME : 'LM Fichajes';
try {
    $stmt = $pdo->query("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa' LIMIT 1");
    $config = $stmt->fetch();
    if ($config && !empty($config->valor)) {
        $nombreEmpresa = $config->valor;
    }
} catch (Exception $e) {}

// Datos del usuario
$usuario = obtener_usuario_actual($pdo);
$centros = obtener_centros_usuario($pdo);

// Contador de notificaciones
$notificacionesNoLeidas = 0;
if (function_exists('contar_notificaciones_no_leidas')) {
    $notificacionesNoLeidas = contar_notificaciones_no_leidas($pdo, $usuario->id);
}

// Pestaña activa
$seccion = $_GET['seccion'] ?? 'historial';

// ============================================================================
// DATOS SEGÚN SECCIÓN
// ============================================================================

$datos = [];

// HISTORIAL DE FICHAJES
if ($seccion === 'historial') {
    $mes = $_GET['mes'] ?? date('Y-m');
    $fechaInicio = $mes . '-01';
    $fechaFin = date('Y-m-t', strtotime($fechaInicio));
    
    // Obtener fichajes agrupados por día (excluyendo rechazados)
    $stmt = $pdo->prepare("
        SELECT f.fecha,
               MIN(CASE WHEN f.tipo = 'entrada' AND f.estado != 'rechazado' THEN f.hora END) as hora_entrada,
               MAX(CASE WHEN f.tipo = 'salida' AND f.estado != 'rechazado' THEN f.hora END) as hora_salida,
               (SELECT c2.nombre FROM fichajes f2 
                LEFT JOIN centros c2 ON f2.centro_id = c2.id 
                WHERE f2.empleado_id = f.empleado_id AND f2.fecha = f.fecha 
                AND f2.tipo = 'entrada' AND f2.estado != 'rechazado'
                ORDER BY f2.hora ASC LIMIT 1) as centro_nombre,
               CASE 
                   WHEN SUM(CASE WHEN f.estado = 'pendiente' AND f.estado != 'rechazado' THEN 1 ELSE 0 END) > 0 THEN 'pendiente'
                   WHEN SUM(CASE WHEN f.estado = 'validado' AND f.estado != 'rechazado' THEN 1 ELSE 0 END) > 0 THEN 'validado'
                   ELSE 'auto_aprobado'
               END as estado,
               (SELECT f3.modo FROM fichajes f3 
                WHERE f3.empleado_id = f.empleado_id AND f3.fecha = f.fecha 
                AND f3.tipo = 'entrada' AND f3.estado != 'rechazado'
                ORDER BY f3.hora ASC LIMIT 1) as modo
        FROM fichajes f
        WHERE f.empleado_id = ? 
          AND f.fecha BETWEEN ? AND ?
          AND f.estado != 'rechazado'
        GROUP BY f.fecha
        ORDER BY f.fecha DESC
    ");
    $stmt->execute([$usuario->id, $fechaInicio, $fechaFin]);
    $datos['fichajes'] = $stmt->fetchAll();
    
    // Resumen del mes (simplificado, excluyendo rechazados)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT fecha) as dias_trabajados
        FROM fichajes
        WHERE empleado_id = ? AND fecha BETWEEN ? AND ? AND tipo = 'entrada' AND estado != 'rechazado'
    ");
    $stmt->execute([$usuario->id, $fechaInicio, $fechaFin]);
    $resumenBase = $stmt->fetch();
    
    // Calcular minutos totales con PHP (más fiable)
    $minutosTotales = 0;
    foreach ($datos['fichajes'] as $f) {
        if ($f->hora_entrada && $f->hora_salida) {
            $minutosTotales += (strtotime($f->hora_salida) - strtotime($f->hora_entrada)) / 60;
        }
    }
    
    $datos['resumen'] = (object)[
        'dias_trabajados' => $resumenBase->dias_trabajados ?? 0,
        'minutos_totales' => $minutosTotales
    ];
    
    // Detalle de fichaje específico (si viene de notificación)
    $verFecha = $_GET['ver'] ?? '';
    if ($verFecha && preg_match('/^\d{4}-\d{2}-\d{2}$/', $verFecha)) {
        $stmt = $pdo->prepare("
            SELECT f.*, c.nombre as centro_nombre,
                   CONCAT(v.nombre, ' ', v.apellido1) as validador_nombre
            FROM fichajes f
            LEFT JOIN centros c ON f.centro_id = c.id
            LEFT JOIN empleados v ON f.validado_por = v.id
            WHERE f.empleado_id = ? AND f.fecha = ?
            ORDER BY f.hora ASC
        ");
        $stmt->execute([$usuario->id, $verFecha]);
        $datos['detalle_fichajes'] = $stmt->fetchAll();
        $datos['detalle_fecha'] = $verFecha;
    }
}

// MIS AUSENCIAS
if ($seccion === 'ausencias') {
    $anio = $_GET['anio'] ?? date('Y');
    
    // Saldos
    $datos['saldos'] = obtener_saldos_empleado($pdo, $usuario->id, $anio);
    
    // Solicitudes
    $datos['solicitudes'] = obtener_solicitudes_empleado($pdo, $usuario->id, $anio);
    
    // Tipos disponibles
    $datos['tipos'] = obtener_tipos_ausencia_empleado($pdo, $usuario->id);
    
    // Detalle de solicitud específica (si viene de notificación)
    $verSolicitud = (int)($_GET['ver'] ?? 0);
    if ($verSolicitud > 0) {
        $stmt = $pdo->prepare("
            SELECT sa.*, ta.nombre as tipo_nombre, ta.color,
                   CONCAT(v.nombre, ' ', v.apellido1) as validador_nombre
            FROM solicitudes_ausencia sa
            LEFT JOIN tipos_ausencia ta ON sa.tipo_ausencia_id = ta.id
            LEFT JOIN empleados v ON sa.validador1_id = v.id
            WHERE sa.id = ? AND sa.empleado_id = ?
        ");
        $stmt->execute([$verSolicitud, $usuario->id]);
        $datos['detalle_solicitud'] = $stmt->fetch();
    }
    
    // Procesar solicitud
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && verificar_csrf($_POST['csrf_token'] ?? '')) {
        $accion = $_POST['accion'] ?? '';
        
        if ($accion === 'solicitar') {
            $resultado = crear_solicitud_ausencia($pdo, [
                'empleado_id' => $usuario->id,
                'tipo_ausencia_id' => (int)$_POST['tipo_ausencia_id'],
                'fecha_inicio' => $_POST['fecha_inicio'],
                'fecha_fin' => $_POST['fecha_fin'],
                'jornada_inicio' => $_POST['jornada_inicio'] ?? 'completa',
                'jornada_fin' => $_POST['jornada_fin'] ?? 'completa',
                'motivo' => sanitizar($_POST['motivo'] ?? ''),
                'estado' => 'pendiente'
            ]);
            
            if ($resultado['exito']) {
                $_SESSION['mensaje_ausencias'] = $resultado['mensaje'];
                header('Location: mis-gestiones.php?seccion=ausencias');
                exit;
            } else {
                $datos['error'] = $resultado['mensaje'];
            }
        }
        
        if ($accion === 'cancelar') {
            $resultado = cancelar_solicitud_ausencia($pdo, (int)$_POST['solicitud_id'], $usuario->id);
            $_SESSION['mensaje_ausencias'] = $resultado['mensaje'];
            header('Location: mis-gestiones.php?seccion=ausencias');
            exit;
        }
    }
    
    $datos['mensaje'] = $_SESSION['mensaje_ausencias'] ?? '';
    unset($_SESSION['mensaje_ausencias']);
}

// MIS DOCUMENTOS
if ($seccion === 'documentos') {
    // Obtener centro principal del usuario (si existe)
    $centroPrincipal = null;
    if (!empty($centros)) {
        foreach ($centros as $c) {
            if ($c->es_principal ?? false) {
                $centroPrincipal = $c->id;
                break;
            }
        }
        // Si no hay principal, usar el primero
        if (!$centroPrincipal && isset($centros[0])) {
            $centroPrincipal = $centros[0]->id;
        }
    }
    $datos['documentos'] = obtener_documentos_empleado($pdo, $usuario->id, $centroPrincipal);
}

// MI PERFIL
if ($seccion === 'perfil') {
    $stmt = $pdo->prepare("
        SELECT e.*, 
               h.nombre as horario_nombre,
               CONCAT(s.nombre, ' ', s.apellido1) as supervisor_nombre
        FROM empleados e
        LEFT JOIN horarios h ON e.horario_id = h.id
        LEFT JOIN empleados s ON e.supervisor_id = s.id
        WHERE e.id = ?
    ");
    $stmt->execute([$usuario->id]);
    $datos['perfil'] = $stmt->fetch();
    
    // Horario semanal
    if ($usuario->horario_id) {
        $stmt = $pdo->prepare("SELECT * FROM horarios_dias WHERE horario_id = ? ORDER BY dia_semana");
        $stmt->execute([$usuario->horario_id]);
        $datos['horarios'] = $stmt->fetchAll();
    }
}

// Nombres días
$nombresDias = ['', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e3a5f">
    <title>Mis Gestiones - <?= htmlspecialchars($nombreEmpresa) ?></title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/img/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="manifest" href="/manifest.json">
    <style>
        :root {
            --primary: #1e3a5f;
            --primary-light: #2d5a87;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-500: #64748b;
            --gray-700: #334155;
            --gray-900: #0f172a;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header h1 {
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .header-actions a {
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.15);
            transition: all 0.2s;
        }
        
        .header-actions a:hover { background: rgba(255,255,255,0.25); }
        .header-actions a.btn-fichar { background: var(--success); }
        
        /* Navegación */
        .nav-tabs {
            background: white;
            display: flex;
            overflow-x: auto;
            border-bottom: 1px solid var(--gray-200);
            padding: 0 10px;
        }
        
        .nav-tab {
            padding: 15px 20px;
            text-decoration: none;
            color: var(--gray-500);
            font-size: 0.9rem;
            font-weight: 500;
            white-space: nowrap;
            border-bottom: 3px solid transparent;
            transition: all 0.2s;
        }
        
        .nav-tab:hover { color: var(--primary); }
        .nav-tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }
        
        /* Contenido */
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 1.1rem;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .card-body { padding: 20px; }
        
        /* Tablas */
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .table th {
            background: var(--gray-50);
            font-size: 0.75rem;
            text-transform: uppercase;
            color: var(--gray-500);
            font-weight: 600;
        }
        
        .table tr:hover { background: var(--gray-50); }
        .table tr:last-child td { border-bottom: none; }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #dbeafe; color: #1e40af; }
        .badge-secondary { background: var(--gray-200); color: var(--gray-700); }
        
        /* Formularios */
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-size: 0.85rem; font-weight: 500; margin-bottom: 5px; color: var(--gray-700); }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-size: 0.95rem;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30,58,95,0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        /* Botones */
        .btn {
            display: inline-block;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-light); }
        .btn-success { background: var(--success); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-outline { background: transparent; border: 1px solid var(--gray-300); color: var(--gray-700); }
        .btn-sm { padding: 6px 12px; font-size: 0.8rem; }
        
        /* Alertas */
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        
        .alert-success { background: #d1fae5; color: #065f46; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        .alert-info { background: #dbeafe; color: #1e40af; }
        
        /* Saldos */
        .saldos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .saldo-card {
            background: var(--gray-50);
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }
        
        .saldo-card .tipo { font-size: 0.85rem; color: var(--gray-500); margin-bottom: 5px; }
        .saldo-card .disponible { font-size: 2rem; font-weight: 700; color: var(--primary); }
        .saldo-card .detalle { font-size: 0.75rem; color: var(--gray-500); margin-top: 5px; }
        
        /* Perfil */
        .perfil-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .dato-item {
            padding: 12px 0;
            border-bottom: 1px solid var(--gray-100);
        }
        
        .dato-item:last-child { border-bottom: none; }
        .dato-item .label { font-size: 0.75rem; color: var(--gray-500); text-transform: uppercase; }
        .dato-item .value { font-size: 1rem; font-weight: 500; color: var(--gray-900); margin-top: 3px; }
        
        /* Filtros */
        .filtros {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .filtros select, .filtros input {
            padding: 8px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 6px;
            font-size: 0.9rem;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-500);
        }
        
        .empty-state .icon { font-size: 3rem; margin-bottom: 10px; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
            .header { flex-direction: column; gap: 10px; text-align: center; }
            .header-actions { flex-wrap: wrap; justify-content: center; }
            .table { font-size: 0.85rem; }
            .table th, .table td { padding: 10px 8px; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <h1><img src="/assets/img/logo-header.png" alt="LMF" style="height:36px;vertical-align:middle;margin-right:8px;border-radius:6px;"> <?= htmlspecialchars($nombreEmpresa) ?></h1>
        <div class="header-actions">
            <span><?= htmlspecialchars($usuario->nombre . ' ' . $usuario->apellido1) ?></span>
            <a href="fichar.php" class="btn-fichar">🕐 Fichar</a>
            <?php if (es_supervisor()): ?>
            <a href="admin/">⚙️ Admin</a>
            <?php endif; ?>
            <a href="login.php?logout=1">Salir</a>
        </div>
    </header>
    
    <!-- Navegación -->
    <nav class="nav-tabs">
        <a href="?seccion=historial" class="nav-tab <?= $seccion === 'historial' ? 'active' : '' ?>">📋 Mi Historial</a>
        <a href="?seccion=ausencias" class="nav-tab <?= $seccion === 'ausencias' ? 'active' : '' ?>">🏖️ Mis Ausencias</a>
        <a href="?seccion=documentos" class="nav-tab <?= $seccion === 'documentos' ? 'active' : '' ?>">📁 Mis Documentos</a>
     <a href="?seccion=notificaciones" class="nav-tab <?= $seccion === 'notificaciones' ? 'active' : '' ?>">🔔 Notificaciones<?php if ($notificacionesNoLeidas > 0): ?><span style="background:#dc2626;color:white;border-radius:50%;padding:2px 8px;font-size:0.75rem;margin-left:5px;"><?= $notificacionesNoLeidas ?></span><?php endif; ?></a>
    <a href="?seccion=perfil" class="nav-tab <?= $seccion === 'perfil' ? 'active' : '' ?>">👤 Mi Perfil</a>
    <a href="mis-datos.php" class="nav-tab">🔐 Mis Datos RGPD</a>
    </nav>
    
    <div class="container">
        
        <?php // ================================================================
              // SECCIÓN: HISTORIAL
              // ================================================================ ?>
        <?php if ($seccion === 'historial'): ?>
        
        <?php if (!empty($datos['detalle_fichajes'])): ?>
        <div class="card" style="border-left: 4px solid #3b82f6; margin-bottom: 20px;">
            <div class="card-header">
                <h2>📋 Detalle del día <?= date('d/m/Y', strtotime($datos['detalle_fecha'])) ?></h2>
                <a href="?seccion=historial" class="btn btn-sm btn-outline">✕ Cerrar</a>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>Hora</th>
                            <th>Centro</th>
                            <th>Estado</th>
                            <th>Validado por</th>
                            <th>Observaciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos['detalle_fichajes'] as $f): ?>
                        <tr>
                            <td><?= $f->tipo === 'entrada' ? '🟢 Entrada' : '🔴 Salida' ?></td>
                            <td><strong><?= date('H:i', strtotime($f->hora)) ?></strong>
                                <?php if ($f->hora_corregida): ?>
                                <br><small style="color:#f59e0b;">Corregida: <?= date('H:i', strtotime($f->hora_corregida)) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($f->centro_nombre ?? '-') ?></td>
                            <td>
                                <?php
                                $badgeClass = match($f->estado) {
                                    'validado' => 'badge-success',
                                    'pendiente' => 'badge-warning',
                                    'rechazado' => 'badge-danger',
                                    default => 'badge-secondary'
                                };
                                ?>
                                <span class="badge <?= $badgeClass ?>"><?= ucfirst($f->estado) ?></span>
                            </td>
                            <td><?= htmlspecialchars($f->validador_nombre ?? '-') ?>
                                <?php if ($f->validado_fecha): ?>
                                <br><small><?= date('d/m H:i', strtotime($f->validado_fecha)) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($f->observacion_validador ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h2>📋 Mi Historial de Fichajes</h2>
                <div class="filtros">
                    <form method="GET">
                        <input type="hidden" name="seccion" value="historial">
                        <input type="month" name="mes" value="<?= $mes ?>" onchange="this.form.submit()">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <?php if (!empty($datos['resumen'])): ?>
                <div class="alert alert-info" style="margin-bottom: 20px;">
                    📊 <strong>Resumen del mes:</strong> 
                    <?= $datos['resumen']->dias_trabajados ?? 0 ?> días trabajados |
                    <?= floor(($datos['resumen']->minutos_totales ?? 0) / 60) ?>h <?= (int)($datos["resumen"]->minutos_totales ?? 0) % 60 ?>m registradas
                </div>
                <?php endif; ?>
                
                <?php if (empty($datos['fichajes'])): ?>
                <div class="empty-state">
                    <div class="icon">📭</div>
                    <p>No hay fichajes en este período</p>
                </div>
                <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Entrada</th>
                            <th>Salida</th>
                            <th>Centro</th>
                            <th>Tiempo</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos['fichajes'] as $f): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($f->fecha)) ?></td>
                            <td><?= $f->hora_entrada ? date('H:i', strtotime($f->hora_entrada)) : '-' ?></td>
                            <td><?= $f->hora_salida ? date('H:i', strtotime($f->hora_salida)) : '<span class="badge badge-warning">En curso</span>' ?></td>
                            <td><?= htmlspecialchars($f->centro_nombre ?? '-') ?></td>
                            <td>
                                <?php if ($f->hora_entrada && $f->hora_salida): 
                                    $mins = (int)((strtotime($f->hora_salida) - strtotime($f->hora_entrada)) / 60);
                                    echo floor($mins / 60) . 'h ' . ($mins % 60) . 'm';
                                else: echo '-'; endif; ?>
                            </td>
                            <td>
                                <?php
                                $badgeClass = match($f->estado) {
                                    'validado' => 'badge-success',
                                    'pendiente' => 'badge-warning',
                                    'rechazado' => 'badge-danger',
                                    default => 'badge-secondary'
                                };
                                ?>
                                <span class="badge <?= $badgeClass ?>"><?= ucfirst($f->estado) ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
        
        <?php // ================================================================
              // SECCIÓN: AUSENCIAS
              // ================================================================ ?>
        <?php elseif ($seccion === 'ausencias'): ?>
        
        <?php if (!empty($datos['mensaje'])): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($datos['mensaje']) ?></div>
        <?php endif; ?>
        
        <?php if (!empty($datos['error'])): ?>
        <div class="alert alert-error">❌ <?= htmlspecialchars($datos['error']) ?></div>
        <?php endif; ?>
        
        <?php if (!empty($datos['detalle_solicitud'])): ?>
        <?php $det = $datos['detalle_solicitud']; ?>
        <div class="card" style="border-left: 4px solid <?= htmlspecialchars($det->color ?? '#3b82f6') ?>; margin-bottom: 20px;">
            <div class="card-header">
                <h2>📋 Detalle de Solicitud</h2>
                <a href="?seccion=ausencias" class="btn btn-sm btn-outline">✕ Cerrar</a>
            </div>
            <div class="card-body">
                <div class="perfil-grid">
                    <div>
                        <div class="dato-item">
                            <div class="label">Tipo</div>
                            <div class="value"><?= htmlspecialchars($det->tipo_nombre) ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Fechas</div>
                            <div class="value"><?= date('d/m/Y', strtotime($det->fecha_inicio)) ?> - <?= date('d/m/Y', strtotime($det->fecha_fin)) ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Días solicitados</div>
                            <div class="value"><?= $det->dias_solicitados ?></div>
                        </div>
                    </div>
                    <div>
                        <div class="dato-item">
                            <div class="label">Estado</div>
                            <div class="value">
                                <?php
                                $badge = match($det->estado) {
                                    'pendiente' => ['warning', '⏳ Pendiente'],
                                    'aprobada' => ['success', '✅ Aprobada'],
                                    'rechazada' => ['danger', '❌ Rechazada'],
                                    'cancelada' => ['secondary', '🚫 Cancelada'],
                                    default => ['secondary', $det->estado]
                                };
                                ?>
                                <span class="badge badge-<?= $badge[0] ?>"><?= $badge[1] ?></span>
                            </div>
                        </div>
                        <?php if ($det->validador_nombre): ?>
                        <div class="dato-item">
                            <div class="label">Validado por</div>
                            <div class="value"><?= htmlspecialchars($det->validador_nombre) ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Fecha validación</div>
                            <div class="value"><?= $det->validador1_fecha ? date('d/m/Y H:i', strtotime($det->validador1_fecha)) : '-' ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if ($det->validador1_observacion): ?>
                        <div class="dato-item">
                            <div class="label">Observaciones</div>
                            <div class="value"><?= htmlspecialchars($det->validador1_observacion) ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Saldos -->
        <div class="saldos-grid">
            <?php foreach ($datos['saldos'] as $saldo): 
                // Formatear números: enteros si es .0, con 1 decimal si tiene fracción
                $disponible = ($saldo->dias_disponibles == floor($saldo->dias_disponibles)) 
                    ? (int)$saldo->dias_disponibles 
                    : number_format($saldo->dias_disponibles, 1);
                $asignados = ($saldo->dias_asignados == floor($saldo->dias_asignados)) 
                    ? (int)$saldo->dias_asignados 
                    : number_format($saldo->dias_asignados, 1);
                $usados = ($saldo->dias_disfrutados == floor($saldo->dias_disfrutados)) 
                    ? (int)$saldo->dias_disfrutados 
                    : number_format($saldo->dias_disfrutados, 1);
            ?>
            <div class="saldo-card">
                <div class="tipo"><?= htmlspecialchars($saldo->nombre) ?></div>
                <div class="disponible"><?= $disponible ?></div>
                <div class="detalle">de <?= $asignados ?> días | <?= $usados ?> usados</div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Solicitar -->
        <div class="card">
            <div class="card-header">
                <h2>➕ Solicitar Ausencia</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="solicitar">
                    
                    <?php
                    // Info del convenio si tiene
                    $convenioEmpleado = $datos['tipos']['_convenio'] ?? null;
                    unset($datos['tipos']['_convenio']);
                    ?>
                    <?php if ($convenioEmpleado): ?>
                    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 10px 15px; margin-bottom: 15px; font-size: 0.9rem;">
                        📋 <strong>Tu convenio:</strong> <?= htmlspecialchars($convenioEmpleado) ?>
                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label">Tipo de ausencia</label>
                        <select name="tipo_ausencia_id" class="form-control" required id="selectTipoAusencia">
                            <option value="">Seleccione...</option>
                            <?php foreach ($datos['tipos'] as $cat => $grupo): ?>
                            <optgroup label="<?= htmlspecialchars($grupo['nombre']) ?>">
                                <?php foreach ($grupo['tipos'] as $tipo):
                                    // Construir texto de la opción con días
                                    $textoOpcion = $tipo->nombre;
                                    if ($tipo->dias_disponibles !== null && $tipo->dias_asignados !== null) {
                                        $disponibles = ($tipo->dias_disponibles == floor($tipo->dias_disponibles))
                                            ? (int)$tipo->dias_disponibles
                                            : number_format($tipo->dias_disponibles, 1);
                                        $asignados = ($tipo->dias_asignados == floor($tipo->dias_asignados))
                                            ? (int)$tipo->dias_asignados
                                            : number_format($tipo->dias_asignados, 1);
                                        $textoOpcion .= " ({$disponibles} de {$asignados} días)";
                                    } elseif ($tipo->dias_maximos) {
                                        $textoOpcion .= " (máx. {$tipo->dias_maximos} días)";
                                    }
                                ?>
                                <option value="<?= $tipo->id ?>"
                                        data-disponibles="<?= $tipo->dias_disponibles ?? '' ?>"
                                        data-asignados="<?= $tipo->dias_asignados ?? '' ?>"
                                        data-preaviso="<?= $tipo->dias_preaviso ?? 0 ?>"
                                        data-justificante="<?= $tipo->requiere_justificante ?? 0 ?>">
                                    <?= htmlspecialchars($textoOpcion) ?>
                                </option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endforeach; ?>
                        </select>
                        <div id="infoTipoSeleccionado" style="margin-top: 8px; font-size: 0.85rem; color: #64748b;"></div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Fecha inicio</label>
                            <input type="date" name="fecha_inicio" class="form-control" required min="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Fecha fin</label>
                            <input type="date" name="fecha_fin" class="form-control" required min="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Jornada inicio</label>
                            <select name="jornada_inicio" class="form-control">
                                <option value="completa">Día completo</option>
                                <option value="mañana">Solo mañana</option>
                                <option value="tarde">Solo tarde</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Jornada fin</label>
                            <select name="jornada_fin" class="form-control">
                                <option value="completa">Día completo</option>
                                <option value="mañana">Solo mañana</option>
                                <option value="tarde">Solo tarde</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Motivo (opcional)</label>
                        <textarea name="motivo" class="form-control" rows="2"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">📤 Enviar Solicitud</button>
                </form>
            </div>
        </div>
        
        <!-- Mis solicitudes -->
        <div class="card">
            <div class="card-header">
                <h2>📋 Mis Solicitudes</h2>
            </div>
            <div class="card-body">
                <?php if (empty($datos['solicitudes'])): ?>
                <div class="empty-state">
                    <div class="icon">📭</div>
                    <p>No tienes solicitudes este año</p>
                </div>
                <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>Fechas</th>
                            <th>Días</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos['solicitudes'] as $sol): ?>
                        <tr>
                            <td>
                                <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?= $sol->color ?>;margin-right:5px;"></span>
                                <?= htmlspecialchars($sol->tipo_nombre) ?>
                            </td>
                            <td>
                                <?= date('d/m', strtotime($sol->fecha_inicio)) ?>
                                <?php if ($sol->fecha_inicio !== $sol->fecha_fin): ?>
                                - <?= date('d/m', strtotime($sol->fecha_fin)) ?>
                                <?php endif; ?>
                            </td>
                            <td><?= $sol->dias_solicitados ?></td>
                            <td>
                                <?php
                                $badge = match($sol->estado) {
                                    'pendiente' => ['warning', '⏳ Pendiente'],
                                    'aprobada' => ['success', '✅ Aprobada'],
                                    'rechazada' => ['danger', '❌ Rechazada'],
                                    'cancelada' => ['secondary', '🚫 Cancelada'],
                                    default => ['secondary', $sol->estado]
                                };
                                ?>
                                <span class="badge badge-<?= $badge[0] ?>"><?= $badge[1] ?></span>
                            </td>
                            <td>
                                <?php if ($sol->estado === 'pendiente'): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('¿Cancelar esta solicitud?');">
                                    <?= csrf_campo() ?>
                                    <input type="hidden" name="accion" value="cancelar">
                                    <input type="hidden" name="solicitud_id" value="<?= $sol->id ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Cancelar</button>
                                </form>
                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
        
        <?php // ================================================================
              // SECCIÓN: DOCUMENTOS
              // ================================================================ ?>
        <?php elseif ($seccion === 'documentos'): ?>
        
        <div class="card">
            <div class="card-header">
                <h2>📁 Mis Documentos</h2>
            </div>
            <div class="card-body">
                <?php if (empty($datos['documentos'])): ?>
                <div class="empty-state">
                    <div class="icon">📭</div>
                    <p>No tienes documentos asignados</p>
                </div>
                <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Documento</th>
                            <th>Tipo</th>
                            <th>Fecha</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos['documentos'] as $doc): ?>
                        <tr>
                            <td><?= htmlspecialchars($doc->titulo ?? $doc->nombre ?? 'Sin título') ?></td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($doc->categoria_nombre ?? 'Otro') ?></span></td>
                            <td><?= date('d/m/Y', strtotime($doc->created_at)) ?></td>
                            <td>
                                <a href="admin/descargar_documento.php?id=<?= $doc->id ?>" class="btn btn-outline btn-sm">📥 Descargar</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
        

        <?php // ================================================================
              // SECCIÓN: NOTIFICACIONES
              // ================================================================ ?>
        <?php elseif ($seccion === 'notificaciones'): ?>
        
        <?php
        // Marcar como leída si se solicita
        if (isset($_GET['marcar_leida']) && is_numeric($_GET['marcar_leida']) && function_exists('marcar_notificacion_leida')) {
            marcar_notificacion_leida($pdo, (int)$_GET['marcar_leida'], $usuario->id);
            header('Location: mis-gestiones.php?seccion=notificaciones');
            exit;
        }
        
        // Marcar todas como leídas
        if (isset($_GET['marcar_todas']) && function_exists('marcar_todas_leidas')) {
            marcar_todas_leidas($pdo, $usuario->id);
            header('Location: mis-gestiones.php?seccion=notificaciones');
            exit;
        }
        
        // Obtener notificaciones
        $notificaciones = function_exists('obtener_notificaciones') 
            ? obtener_notificaciones($pdo, $usuario->id, false, 50) 
            : [];
        ?>
        
        <div class="card">
            <div class="card-header">
                <h2>🔔 Mis Notificaciones</h2>
                <?php if ($notificacionesNoLeidas > 0): ?>
                    <a href="?seccion=notificaciones&marcar_todas=1" class="btn btn-sm" style="background:#6b7280;color:white;">
                        ✓ Marcar todas como leídas
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body" style="padding:0;">
                <?php if (empty($notificaciones)): ?>
                    <div class="empty-state">
                        <div class="icon">🔔</div>
                        <p>No tienes notificaciones</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($notificaciones as $notif): ?>
                        <div style="display:flex;align-items:flex-start;padding:15px 20px;border-bottom:1px solid #e5e7eb;background:<?= $notif->leida ? 'white' : '#f0f9ff' ?>;">
                            <div style="font-size:24px;margin-right:15px;">
                                <?= function_exists('obtener_icono_notificacion') ? obtener_icono_notificacion($notif->tipo) : '🔔' ?>
                            </div>
                            <div style="flex:1;">
                                <div style="font-weight:<?= $notif->leida ? 'normal' : '600' ?>;color:#1e293b;margin-bottom:4px;">
                                    <?= htmlspecialchars($notif->titulo) ?>
                                </div>
                                <div style="font-size:0.9rem;color:#64748b;margin-bottom:6px;">
                                    <?= htmlspecialchars($notif->mensaje) ?>
                                </div>
                                <div style="font-size:0.8rem;color:#94a3b8;">
                                    <?= date('d/m/Y H:i', strtotime($notif->created_at)) ?>
                                    <?php if ($notif->enlace): ?>
                                        · <a href="<?= htmlspecialchars($notif->enlace) ?>" style="color:#3b82f6;">Ver detalle</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if (!$notif->leida): ?>
                                <a href="?seccion=notificaciones&marcar_leida=<?= $notif->id ?>" 
                                   style="color:#94a3b8;font-size:0.85rem;text-decoration:none;padding:5px 10px;"
                                   title="Marcar como leída">✓</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <?php // ================================================================
              // SECCIÓN: PERFIL
              // ================================================================ ?>
        <?php elseif ($seccion === 'perfil'): ?>
        
        <div class="card">
            <div class="card-header">
                <h2>👤 Mis Datos</h2>
            </div>
            <div class="card-body">
                <?php $p = $datos['perfil']; ?>
                <div class="perfil-grid">
                    <div>
                        <div class="dato-item">
                            <div class="label">Nombre completo</div>
                            <div class="value"><?= htmlspecialchars($p->nombre . ' ' . $p->apellido1 . ' ' . ($p->apellido2 ?? '')) ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">NIF</div>
                            <div class="value"><?= htmlspecialchars($p->nif) ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Email</div>
                            <div class="value"><?= htmlspecialchars($p->email ?? '-') ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Teléfono</div>
                            <div class="value"><?= htmlspecialchars($p->telefono ?? '-') ?></div>
                        </div>
                    </div>
                    <div>
                        <div class="dato-item">
                            <div class="label">Horario asignado</div>
                            <div class="value"><?= htmlspecialchars($p->horario_nombre ?? 'Sin asignar') ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Supervisor</div>
                            <div class="value"><?= htmlspecialchars($p->supervisor_nombre ?? 'Sin asignar') ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Fecha alta</div>
                            <div class="value"><?= $p->fecha_alta ? date('d/m/Y', strtotime($p->fecha_alta)) : '-' ?></div>
                        </div>
                        <div class="dato-item">
                            <div class="label">Último acceso</div>
                            <div class="value"><?= $p->ultimo_acceso ? date('d/m/Y H:i', strtotime($p->ultimo_acceso)) : '-' ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Horario semanal -->
        <?php if (!empty($datos['horarios'])): ?>
        <div class="card">
            <div class="card-header">
                <h2>🕐 Mi Horario Semanal</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Día</th>
                            <th>Entrada</th>
                            <th>Salida</th>
                            <th>Troncal</th>
                            <th>Horas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos['horarios'] as $h): ?>
                        <tr>
                            <td><strong><?= $nombresDias[$h->dia_semana] ?></strong></td>
                            <?php if ($h->es_laborable): ?>
                            <td><?= substr($h->hora_entrada, 0, 5) ?></td>
                            <td><?= substr($h->hora_salida, 0, 5) ?></td>
                            <td><?= $h->troncal_inicio ? substr($h->troncal_inicio, 0, 5) . ' - ' . substr($h->troncal_fin, 0, 5) : '-' ?></td>
                            <td><span class="badge badge-info"><?= number_format($h->horas_esperadas, 1) ?>h</span></td>
                            <?php else: ?>
                            <td colspan="4" style="color: var(--gray-500);">🏖️ No laborable</td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Centros asignados -->
        <?php if (!empty($centros)): ?>
        <div class="card">
            <div class="card-header">
                <h2>🏢 Mis Centros de Trabajo</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Centro</th>
                            <th>Dirección</th>
                            <th>Principal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($centros as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c->nombre) ?></td>
                            <td><?= htmlspecialchars($c->direccion ?? '-') ?></td>
                            <td><?= $c->es_principal ? '<span class="badge badge-success">⭐ Sí</span>' : '-' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Cambiar contraseña -->
        <div class="card">
            <div class="card-header">
                <h2>🔐 Seguridad</h2>
            </div>
            <div class="card-body">
                <a href="cambiar_password.php" class="btn btn-outline">🔑 Cambiar Contraseña</a>
            </div>
        </div>
        
        <?php endif; ?>
        
    </div>

    <script>
    // Mostrar información del tipo de ausencia seleccionado
    document.getElementById('selectTipoAusencia')?.addEventListener('change', function() {
        var option = this.options[this.selectedIndex];
        var infoDiv = document.getElementById('infoTipoSeleccionado');

        if (!option.value) {
            infoDiv.innerHTML = '';
            return;
        }

        var disponibles = option.dataset.disponibles;
        var asignados = option.dataset.asignados;
        var preaviso = parseInt(option.dataset.preaviso) || 0;
        var justificante = option.dataset.justificante === '1';

        var html = [];

        if (disponibles !== '' && asignados !== '') {
            var disp = parseFloat(disponibles);
            var color = disp > 0 ? '#10b981' : '#ef4444';
            html.push('<span style="color:' + color + ';">📊 Disponibles: <strong>' + disp + '</strong> de ' + asignados + ' días</span>');
        }

        if (preaviso > 0) {
            html.push('<span style="color:#f59e0b;">⏰ Requiere ' + preaviso + ' días de preaviso</span>');
        }

        if (justificante) {
            html.push('<span style="color:#3b82f6;">📎 Requiere justificante</span>');
        }

        infoDiv.innerHTML = html.join(' · ');
    });
    </script>
</body>
</html>
