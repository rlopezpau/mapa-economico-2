<?php
/**
 * LM FICHAJES - Página de Login
 * CON AUDITORÍA ENS INTEGRADA
 * 
 * @version     1.2.0
 * @modified    2025-01-09 - Añadido recuperar contraseña y aviso spam
 */

define('LMFICHAJES', true);
require_once __DIR__ . '/config.php';
require_once INCLUDES_PATH . '/auth.php';

establecer_headers_seguridad();

// Logout si se solicita
if (isset($_GET['logout'])) {
    cerrar_sesion();
    header('Location: login.php');
    exit;
}

// Si ya está logueado, redirigir al portal de fichaje
if (esta_logueado()) {
    header('Location: fichar.php');
    exit;
}

$error = '';
$mensaje = '';
$mostrarRecuperar = isset($_GET['recuperar']);

// Procesar recuperación de contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'recuperar') {
    if (!verificar_csrf()) {
        $error = 'Error de seguridad. Recarga la página.';
    } else {
        $nifRecuperar = strtoupper(trim($_POST['nif_recuperar'] ?? ''));
        
        if (empty($nifRecuperar)) {
            $error = 'Introduce tu NIF/NIE';
            $mostrarRecuperar = true;
        } else {
            // Buscar empleado
            $stmt = $pdo->prepare("SELECT id, nif, nombre, apellido1, email FROM empleados WHERE nif = ? AND activo = 1");
            $stmt->execute([$nifRecuperar]);
            $empleado = $stmt->fetch();
            
            if (!$empleado) {
                $error = 'NIF no encontrado o cuenta inactiva';
                $mostrarRecuperar = true;
            } elseif (empty($empleado->email)) {
                $error = 'Tu cuenta no tiene email configurado. Contacta con tu administrador.';
                $mostrarRecuperar = true;
            } else {
                // Verificar si email está configurado en el sistema
                $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = 'email_activo'");
                $stmt->execute();
                $emailActivo = $stmt->fetchColumn();
                
                if (!$emailActivo || $emailActivo === '0') {
                    $error = 'El envío de email no está configurado. Contacta con tu administrador.';
                    $mostrarRecuperar = true;
                } else {
                    // Generar nueva contraseña
                    $nuevaPass = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'), 0, 10);
                    $hash = password_hash($nuevaPass, PASSWORD_DEFAULT);
                    
                    // Actualizar contraseña
                    $pdo->prepare("UPDATE empleados SET password = ?, debe_cambiar_password = 1, password_temporal = 1 WHERE id = ?")
                        ->execute([$hash, $empleado->id]);
                    
                    // Intentar enviar email
                    $emailEnviado = enviarEmailRecuperacion($pdo, $empleado, $nuevaPass);
                    
                    if ($emailEnviado) {
                        $mensaje = '✅ Se ha enviado una nueva contraseña a tu email. <strong>Revisa también la carpeta de Spam.</strong>';
                        
                        // Auditoría
                        if (function_exists('registrar_auditoria')) {
                            registrar_auditoria('PASSWORD_RECOVERY', "Recuperación de contraseña: {$empleado->nombre} {$empleado->apellido1}", 
                                ['nif' => $empleado->nif, 'email' => $empleado->email], 'WARNING', null, 'empleados', $empleado->id);
                        }
                    } else {
                        $error = 'Error al enviar el email. Contacta con tu administrador.';
                        $mostrarRecuperar = true;
                    }
                }
            }
        }
    }
}

// Procesar formulario de login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (!isset($_POST['accion']) || $_POST['accion'] !== 'recuperar')) {
    if (!verificar_csrf()) {
        $error = 'Error de seguridad. Recarga la página e inténtalo de nuevo.';
        
        if (function_exists('audit_alerta_seguridad')) {
            audit_alerta_seguridad("Intento de login con token CSRF inválido", [
                'ip' => obtener_ip_cliente()
            ]);
        }
    } else {
        $nif = $_POST['nif'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($nif) || empty($password)) {
            $error = 'Introduce tu NIF y contraseña';
        } else {
            $resultado = intentar_login($pdo, $nif, $password);
            
            if ($resultado['exito']) {
                if ($resultado['requiere_mfa'] ?? false) {
                    header('Location: mfa.php');
                    exit;
                }
                if ($resultado['requiere_cambio_password'] ?? false) {
                    header('Location: cambiar_password.php');
                    exit;
                }
                header('Location: fichar.php');
                exit;
            } else {
                $error = $resultado['mensaje'];
            }
        }
    }
    
    regenerar_csrf();
}

/**
 * Enviar email de recuperación de contraseña
 */
function enviarEmailRecuperacion($pdo, $empleado, $password) {
    try {
        // Obtener configuración SMTP
        $stmt = $pdo->prepare("SELECT clave, valor FROM configuracion WHERE clave LIKE 'smtp_%' OR clave = 'email_activo'");
        $stmt->execute();
        $config = [];
        while ($row = $stmt->fetch()) {
            $config[$row->clave] = $row->valor;
        }
        
        if (empty($config['smtp_from_email'])) {
            return false;
        }
        
        $nombreCompleto = $empleado->nombre . ' ' . $empleado->apellido1;
        
        $asunto = 'LM Fichajes - Recuperación de contraseña';
        $cuerpo = "
        <html>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
            <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                <div style='background: #1a365d; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;'>
                    <h1 style='margin: 0;'>🕐 LM Fichajes</h1>
                </div>
                <div style='background: #f8fafc; padding: 30px; border: 1px solid #e2e8f0; border-radius: 0 0 8px 8px;'>
                    <p>Hola <strong>{$nombreCompleto}</strong>,</p>
                    <p>Has solicitado recuperar tu contraseña. Aquí tienes tus nuevas credenciales:</p>
                    <div style='background: white; padding: 20px; border-radius: 8px; border: 2px solid #e2e8f0; margin: 20px 0;'>
                        <p style='margin: 0 0 10px;'><strong>Usuario:</strong> {$empleado->nif}</p>
                        <p style='margin: 0;'><strong>Nueva contraseña:</strong> <code style='background: #fef3c7; padding: 2px 8px; border-radius: 4px;'>{$password}</code></p>
                    </div>
                    <p style='color: #dc2626;'><strong>⚠️ Importante:</strong> Deberás cambiar esta contraseña en tu primer acceso.</p>
                    <p style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b;'>
                        Si no has solicitado este cambio, contacta inmediatamente con tu administrador.<br>
                        Este es un mensaje automático. Por favor, no respondas a este correo.
                    </p>
                </div>
            </div>
        </body>
        </html>";
        
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . ($config['smtp_from_nombre'] ?? 'LM Fichajes') . " <{$config['smtp_from_email']}>\r\n";
        
        return mail($empleado->email, $asunto, $cuerpo, $headers);
    } catch (Exception $e) {
        error_log('Error enviando email recuperación: ' . $e->getMessage());
        return false;
    }
}

// Obtener nombre de la entidad
$nombreEntidad = 'LM Fichajes';
try {
    $stmt = $pdo->prepare("SELECT valor FROM configuracion WHERE clave = 'nombre_empresa'");
    $stmt->execute();
    $config = $stmt->fetch();
    if ($config && $config->valor) {
        $nombreEntidad = $config->valor;
    }
} catch (Exception $e) {
    // Usar nombre por defecto
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#1e3a5f">
    <title>Acceso - <?= htmlspecialchars($nombreEntidad) ?></title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/img/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #1a365d 0%, #2d5a87 50%, #3d7ab5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container { width: 100%; max-width: 420px; }
        
        .login-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        
        .login-header {
            background: linear-gradient(135deg, #2d5a87 0%, #1a365d 100%);
            padding: 30px;
            text-align: center;
            color: white;
        }
        
        .login-header .logo { margin-bottom: 15px; }
        .login-header h1 { font-size: 24px; font-weight: 600; margin-bottom: 5px; }
        .login-header p { font-size: 14px; opacity: 0.9; }
        
        .login-body { padding: 40px 30px; }
        
        .form-group { margin-bottom: 24px; }
        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }
        
        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f9fafb;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #2d5a87;
            background: white;
            box-shadow: 0 0 0 4px rgba(45, 90, 135, 0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #2d5a87 0%, #1a365d 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(45, 90, 135, 0.4);
        }
        
        .error-message {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 24px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .error-message::before { content: '⚠️'; font-size: 18px; }
        
        .success-message {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #16a34a;
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 24px;
            font-size: 14px;
        }
        
        .info-message {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1e40af;
            padding: 12px 14px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 13px;
            text-align: center;
        }
        
        .login-footer {
            text-align: center;
            padding: 20px 30px 30px;
            border-top: 1px solid #f3f4f6;
        }
        
        .login-footer p { font-size: 12px; color: #9ca3af; }
        
        .input-icon { position: relative; }
        .input-icon input { padding-left: 48px; }
        .input-icon .icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
            font-size: 18px;
        }
        
        .forgot-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #2d5a87;
            text-decoration: none;
            font-size: 14px;
        }
        
        .forgot-link:hover { text-decoration: underline; }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 16px;
            color: #6b7280;
            text-decoration: none;
            font-size: 14px;
        }
        
        .back-link:hover { color: #374151; }
        
        @media (max-width: 480px) {
            .login-body { padding: 30px 20px; }
            .login-header { padding: 25px 20px; }
        }
        
        .btn-login.loading { pointer-events: none; opacity: 0.8; }
        
        .spinner {
            width: 20px;
            height: 20px;
            border: 2px solid transparent;
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            display: none;
        }
        
        .btn-login.loading .spinner { display: block; }
        .btn-login.loading .btn-text { display: none; }
        
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo"><img src="/assets/img/icon-192.png" alt="LMF" style="width:80px;height:80px;border-radius:12px;"></div>
                <h1><?= htmlspecialchars($nombreEntidad) ?></h1>
                <p>Control Horario</p>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="error-message"><?= $error ?></div>
                <?php endif; ?>
                
                <?php if ($mensaje): ?>
                    <div class="success-message"><?= $mensaje ?></div>
                <?php endif; ?>
                
                <?php if ($mostrarRecuperar): ?>
                <!-- FORMULARIO RECUPERAR CONTRASEÑA -->
                <form method="POST" id="recuperarForm">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="accion" value="recuperar">
                    
                    <p style="color: #6b7280; font-size: 14px; margin-bottom: 20px; text-align: center;">
                        Introduce tu NIF/NIE y te enviaremos una nueva contraseña a tu email registrado.
                    </p>
                    
                    <div class="form-group">
                        <label for="nif_recuperar">NIF / NIE</label>
                        <div class="input-icon">
                            <span class="icon">👤</span>
                            <input 
                                type="text" 
                                id="nif_recuperar" 
                                name="nif_recuperar" 
                                placeholder="12345678A"
                                required
                                maxlength="15"
                                value="<?= htmlspecialchars($_POST['nif_recuperar'] ?? '') ?>"
                            >
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-login">
                        <span class="btn-text">📧 Enviar nueva contraseña</span>
                        <div class="spinner"></div>
                    </button>
                    
                    <a href="login.php" class="back-link">← Volver al inicio de sesión</a>
                </form>
                
                <?php else: ?>
                <!-- FORMULARIO LOGIN -->
                <form method="POST" id="loginForm">
                    <?= csrf_campo() ?>
                    
                    <div class="form-group">
                        <label for="nif">NIF / NIE</label>
                        <div class="input-icon">
                            <span class="icon">👤</span>
                            <input 
                                type="text" 
                                id="nif" 
                                name="nif" 
                                placeholder="12345678A"
                                autocomplete="username"
                                required
                                maxlength="15"
                                value="<?= htmlspecialchars($_POST['nif'] ?? '') ?>"
                            >
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="input-icon">
                            <span class="icon">🔒</span>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                placeholder="••••••••"
                                autocomplete="current-password"
                                required
                            >
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-login" id="btnLogin">
                        <span class="btn-text">Acceder</span>
                        <div class="spinner"></div>
                    </button>
                    
                    <a href="?recuperar" class="forgot-link">¿Olvidaste tu contraseña?</a>
                    
                    <div class="info-message">
                        💡 Si no recibes el email de credenciales, revisa tu carpeta de <strong>Spam</strong>
                    </div>
                </form>
                <?php endif; ?>
            </div>
            
            <div class="login-footer">
                <p>LM Fichajes v<?= APP_VERSION ?> © <?= date('Y') ?></p>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('nif')?.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
        
        document.getElementById('nif_recuperar')?.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
        
        document.getElementById('loginForm')?.addEventListener('submit', function() {
            document.getElementById('btnLogin').classList.add('loading');
        });
        
        document.getElementById('recuperarForm')?.addEventListener('submit', function(e) {
            this.querySelector('.btn-login').classList.add('loading');
        });
    </script>
</body>
</html>
